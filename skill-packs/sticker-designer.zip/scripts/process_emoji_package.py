#!/usr/bin/env python3
"""
企业表情包素材包处理脚本

功能：
1. 批量下载表情包主图
2. 调整尺寸到400x400
3. 生成JPEG主图和PNG预览图
4. 压缩预览图到60KB以下
5. 处理封面图和菜单图标
6. 生成上传用文案文件
7. 打包成zip

使用方法：
    python process_emoji_package.py --config config.json

config.json 格式：
{
    "emoji_list": [
        {"num": "01", "name": "Hi~", "meaning_cn": "你好", "meaning_en": "Hello", "url": "https://..."},
        ...
    ],
    "cover_url": "https://...",
    "icon_url": "https://...",
    "album_name_cn": "专辑名称",
    "album_name_en": "Album Name",
    "album_desc_cn": "专辑介绍",
    "album_desc_en": "Album Description",
    "output_dir": "输出目录"
}
"""

import os
import sys
import json
import zipfile
import requests
from PIL import Image
import io


def download_image(url):
    """下载图片"""
    response = requests.get(url)
    return Image.open(io.BytesIO(response.content))


def process_main_image(img, output_path, size=(400, 400), quality=85):
    """处理主图 - JPEG格式"""
    img = img.resize(size, Image.LANCZOS)
    img_rgb = img.convert('RGB')
    img_rgb.save(output_path, 'JPEG', quality=quality, optimize=True)
    return os.path.getsize(output_path) / 1024


def process_preview_image(img, output_path, size=(400, 400), max_size_kb=60):
    """处理预览图 - PNG格式，压缩到指定大小以下"""
    img = img.resize(size, Image.LANCZOS)
    
    # 先尝试直接保存
    img.save(output_path, 'PNG', optimize=True)
    file_size = os.path.getsize(output_path) / 1024
    
    # 如果超过限制，逐步减少颜色数量
    colors = 256
    while file_size > max_size_kb and colors >= 32:
        img_quantized = img.quantize(colors=colors, method=Image.Quantize.MEDIANCUT)
        img_quantized.save(output_path, 'PNG', optimize=True)
        file_size = os.path.getsize(output_path) / 1024
        colors -= 32
    
    return file_size


def process_cover_image(img, output_path, size=(750, 380), quality=85):
    """处理封面图 - JPEG格式"""
    img = img.resize(size, Image.LANCZOS)
    img_rgb = img.convert('RGB')
    img_rgb.save(output_path, 'JPEG', quality=quality, optimize=True)
    return os.path.getsize(output_path) / 1024


def process_menu_icon(img, output_path, size=(48, 48)):
    """处理菜单图标 - PNG格式，透明背景"""
    img = img.resize(size, Image.LANCZOS)
    img.save(output_path, 'PNG', optimize=True)
    return os.path.getsize(output_path) / 1024


def generate_copywriting_file(emoji_list, album_name_cn, album_name_en, 
                              album_desc_cn, album_desc_en, output_path):
    """生成上传用文案文件"""
    lines = []
    lines.append("=" * 30)
    lines.append("表情专辑信息文案")
    lines.append("=" * 30)
    lines.append("")
    lines.append("【专辑名称】")
    lines.append(f"中文：{album_name_cn}")
    lines.append(f"英文：{album_name_en}")
    lines.append("")
    lines.append("【专辑介绍】")
    lines.append(f"中文：{album_desc_cn}")
    lines.append(f"英文：{album_desc_en}")
    lines.append("")
    lines.append("=" * 30)
    lines.append("表情含义词（按序号填写）")
    lines.append("=" * 30)
    lines.append("")
    
    for emoji in emoji_list:
        num = emoji['num']
        name = emoji['name']
        meaning_cn = emoji.get('meaning_cn', name)
        meaning_en = emoji.get('meaning_en', name)
        lines.append(f"{num}. 表情：{name}")
        lines.append(f"    中文含义：{meaning_cn}")
        lines.append(f"    英文含义：{meaning_en}")
        lines.append("")
    
    lines.append("=" * 30)
    lines.append("上传提示：")
    lines.append("1. 主图上传 main_images 文件夹下的 01.jpg ~ NN.jpg")
    lines.append("2. 预览图上传 preview_images 文件夹下的 01.png ~ NN.png")
    lines.append("3. 封面图上传 album_cover.jpg")
    lines.append("4. 菜单图标上传 menu_icon.png")
    lines.append("5. 按上述序号依次填写每个表情的含义词")
    lines.append("=" * 30)
    
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))


def create_zip_package(package_dir, zip_path):
    """打包成zip文件"""
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(package_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, os.path.dirname(package_dir))
                zipf.write(file_path, arcname)


def process_package(config):
    """处理完整的表情包素材包"""
    emoji_list = config['emoji_list']
    cover_url = config.get('cover_url')
    icon_url = config.get('icon_url')
    album_name_cn = config.get('album_name_cn', '表情包专辑')
    album_name_en = config.get('album_name_en', 'Emoji Album')
    album_desc_cn = config.get('album_desc_cn', '可爱的表情包')
    album_desc_en = config.get('album_desc_en', 'Cute emoji pack')
    output_dir = config.get('output_dir', './emoji_package')
    
    # 创建目录结构
    main_dir = os.path.join(output_dir, 'main_images')
    preview_dir = os.path.join(output_dir, 'preview_images')
    os.makedirs(main_dir, exist_ok=True)
    os.makedirs(preview_dir, exist_ok=True)
    
    print(f"开始处理 {len(emoji_list)} 个表情包...")
    print("-" * 40)
    
    # 处理每个表情
    for emoji in emoji_list:
        num = emoji['num']
        name = emoji['name']
        url = emoji['url']
        
        print(f"处理 {num}_{name}...")
        
        # 下载图片
        img = download_image(url)
        
        # 处理主图
        main_path = os.path.join(main_dir, f"{num}.jpg")
        main_size = process_main_image(img, main_path)
        
        # 处理预览图
        preview_path = os.path.join(preview_dir, f"{num}.png")
        preview_size = process_preview_image(img, preview_path)
        
        print(f"  主图: {main_size:.1f}KB, 预览图: {preview_size:.1f}KB")
    
    # 处理封面图
    if cover_url:
        print("\n处理封面图...")
        cover_img = download_image(cover_url)
        cover_path = os.path.join(output_dir, 'album_cover.jpg')
        cover_size = process_cover_image(cover_img, cover_path)
        print(f"  封面图: {cover_size:.1f}KB")
    
    # 处理菜单图标
    if icon_url:
        print("\n处理菜单图标...")
        icon_img = download_image(icon_url)
        icon_path = os.path.join(output_dir, 'menu_icon.png')
        icon_size = process_menu_icon(icon_img, icon_path)
        print(f"  菜单图标: {icon_size:.1f}KB")
    
    # 生成文案文件
    print("\n生成文案文件...")
    copywriting_path = os.path.join(output_dir, '表情专辑信息文案.txt')
    generate_copywriting_file(emoji_list, album_name_cn, album_name_en,
                              album_desc_cn, album_desc_en, copywriting_path)
    print("  文案文件生成完成")
    
    # 打包zip
    print("\n打包素材包...")
    zip_path = output_dir.rstrip('/') + '.zip'
    create_zip_package(output_dir, zip_path)
    zip_size = os.path.getsize(zip_path) / 1024
    print(f"  素材包大小: {zip_size:.1f}KB")
    
    print("\n" + "=" * 40)
    print("✅ 素材包处理完成！")
    print(f"📦 输出目录: {output_dir}")
    print(f"📄 Zip文件: {zip_path}")
    print("=" * 40)
    
    return zip_path


def main():
    if len(sys.argv) < 2:
        print("使用方法: python process_emoji_package.py --config config.json")
        print("")
        print("或者直接在代码中传入config字典调用 process_package(config)")
        return
    
    config_path = None
    for i, arg in enumerate(sys.argv):
        if arg == '--config' and i + 1 < len(sys.argv):
            config_path = sys.argv[i + 1]
            break
    
    if not config_path:
        print("错误：请指定配置文件路径 --config config.json")
        return
    
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    process_package(config)


if __name__ == '__main__':
    main()
