#!/usr/bin/env python3
"""
NVT 合同审核助手 —— 批注版 Word 生成脚本

读取原始 .docx 合同，根据风险清单 JSON：
1. 在匹配风险点的段落添加红/黄/绿底纹
2. 在风险段落后插入批注（问题 + 修改建议）
3. 文末附加风险汇总表

用法:
    python3 generate_annotated_docx.py <原合同.docx> --risks <风险清单.json> --output <输出.docx>

风险清单 JSON 格式:
{
  "contract_name": "合同名称",
  "risks": [
    {
      "id": 1,
      "level": "high",        // high / medium / low
      "location": "§6.2 知识产权归属",
      "clue": "知识产权",      // 用于在文档中定位的关键词（可选，无则用 location 中的关键词）
      "issue": "问题描述",
      "suggestion": "修改建议"
    }
  ]
}
"""

import argparse
import json
import sys
import re
from copy import deepcopy

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Cm
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn, nsmap
    from docx.oxml import OxmlElement
except ImportError:
    print("错误：需要 python-docx 库。请运行: pip install python-docx", file=sys.stderr)
    sys.exit(1)


# 底纹颜色（十六进制，不带 #）
COLORS = {
    "high": "FFC7CE",      # 浅红
    "medium": "FFEB9C",    # 浅黄
    "low": "C6EFCE",       # 浅绿
}

# 批注文字颜色
COMMENT_COLORS = {
    "high": "C00000",      # 深红
    "medium": "BF8F00",    # 深黄
    "low": "375623",       # 深绿
}

LEVEL_LABELS = {
    "high": "高风险",
    "medium": "中风险",
    "low": "低风险",
}


def set_paragraph_shading(paragraph, color_hex):
    """给段落设置底纹颜色。"""
    pPr = paragraph._p.get_or_add_pPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), color_hex)
    pPr.append(shd)


def insert_paragraph_after(paragraph, text="", style=None):
    """在指定段落后插入新段落，返回新段落对象。"""
    new_p = OxmlElement('w:p')
    paragraph._p.addnext(new_p)
    from docx.text.paragraph import Paragraph
    new_para = Paragraph(new_p, paragraph._parent)
    if text:
        new_para.add_run(text)
    if style:
        new_para.style = style
    return new_para


def find_matching_paragraph(doc, clue, location=""):
    """
    在文档中查找包含 clue 关键词的段落。
    优先匹配同时包含 location 中条款号（如 6.2）和 clue 的段落。
    返回第一个匹配的段落索引，未找到返回 None。
    """
    paragraphs = doc.paragraphs

    # 尝试从 location 提取条款号（如 §6.2 -> 6.2）
    clause_num = ""
    m = re.search(r'§\s*([\d.]+)', location)
    if m:
        clause_num = m.group(1)

    # 第一轮：同时匹配条款号 + clue
    if clause_num and clue:
        for i, p in enumerate(paragraphs):
            text = p.text.strip()
            if clause_num in text and clue in text:
                return i

    # 第二轮：匹配 clue
    if clue:
        for i, p in enumerate(paragraphs):
            if clue in p.text:
                return i

    # 第三轮：匹配条款号
    if clause_num:
        for i, p in enumerate(paragraphs):
            if clause_num in p.text:
                return i

    return None


def add_comment_paragraph(doc, para_index, risk):
    """在风险段落后插入批注段落。"""
    target_para = doc.paragraphs[para_index]

    level = risk.get("level", "medium")
    color = COMMENT_COLORS.get(level, "000000")
    label = LEVEL_LABELS.get(level, "风险")
    rid = risk.get("id", "?")
    issue = risk.get("issue", "")
    suggestion = risk.get("suggestion", "")

    # 插入批注标题行
    comment_text = f"【审核批注 #{rid} · {label}】问题：{issue}"
    comment_para = insert_paragraph_after(target_para, comment_text)
    for run in comment_para.runs:
        run.font.color.rgb = RGBColor.from_string(color)
        run.font.size = Pt(9)
        run.italic = True

    # 插入建议行
    if suggestion:
        sugg_text = f"　　建议：{suggestion}"
        sugg_para = insert_paragraph_after(comment_para, sugg_text)
        for run in sugg_para.runs:
            run.font.color.rgb = RGBColor.from_string(color)
            run.font.size = Pt(9)
            run.italic = True

    return comment_para


def add_risk_summary_table(doc, risks):
    """在文档末尾添加风险汇总表。"""
    # 分页
    doc.add_page_break()

    # 标题
    title = doc.add_heading("风险汇总表", level=1)

    # 统计表
    stats_para = doc.add_paragraph()
    high_count = sum(1 for r in risks if r.get("level") == "high")
    medium_count = sum(1 for r in risks if r.get("level") == "medium")
    low_count = sum(1 for r in risks if r.get("level") == "low")
    stats_run = stats_para.add_run(
        f"共 {len(risks)} 处风险：高风险 {high_count} 项（必须修改后再签）、"
        f"中风险 {medium_count} 项（建议协商完善）、低风险 {low_count} 项（签署时一并修正）"
    )
    stats_run.bold = True

    # 汇总表
    table = doc.add_table(rows=1, cols=5)
    table.style = 'Table Grid'

    # 表头
    hdr = table.rows[0].cells
    headers = ["序号", "风险等级", "位置", "问题", "修改建议"]
    for i, h in enumerate(headers):
        hdr[i].text = h
        for p in hdr[i].paragraphs:
            for run in p.runs:
                run.bold = True

    # 填充行
    for risk in risks:
        row = table.add_row().cells
        row[0].text = str(risk.get("id", ""))
        row[1].text = LEVEL_LABELS.get(risk.get("level", ""), "")
        row[2].text = risk.get("location", "")
        row[3].text = risk.get("issue", "")
        row[4].text = risk.get("suggestion", "")

        # 设置等级单元格底纹
        level = risk.get("level", "")
        if level in COLORS:
            for p in row[1].paragraphs:
                set_paragraph_shading(p, COLORS[level])

    return table


def main():
    parser = argparse.ArgumentParser(description="NVT 合同审核批注版 Word 生成")
    parser.add_argument("input_docx", help="原始合同 .docx 文件路径")
    parser.add_argument("--risks", required=True, help="风险清单 JSON 文件路径")
    parser.add_argument("--output", required=True, help="输出 .docx 文件路径")
    args = parser.parse_args()

    # 读取风险清单
    with open(args.risks, "r", encoding="utf-8") as f:
        data = json.load(f)

    risks = data.get("risks", [])
    if not risks:
        print("警告：风险清单为空，仅复制原文档。", file=sys.stderr)

    # 打开原文档
    doc = Document(args.input_docx)

    # 记录已标注的段落索引，避免重复标注同一段落
    annotated_indices = set()
    unmatched_risks = []

    # 按 id 排序处理（从大到小，避免插入段落后索引偏移）
    sorted_risks = sorted(risks, key=lambda r: r.get("id", 0), reverse=True)

    for risk in sorted_risks:
        clue = risk.get("clue", "")
        location = risk.get("location", "")
        level = risk.get("level", "medium")

        para_idx = find_matching_paragraph(doc, clue, location)

        if para_idx is not None and para_idx not in annotated_indices:
            # 设置底纹
            set_paragraph_shading(doc.paragraphs[para_idx], COLORS.get(level, "FFEB9C"))
            # 插入批注
            add_comment_paragraph(doc, para_idx, risk)
            annotated_indices.add(para_idx)
        else:
            unmatched_risks.append(risk)

    # 添加风险汇总表
    add_risk_summary_table(doc, risks)

    # 保存
    doc.save(args.output)

    # 输出统计
    matched = len(risks) - len(unmatched_risks)
    print(f"✅ 批注版 Word 已生成: {args.output}")
    print(f"   已标注段落: {matched}/{len(risks)}")
    if unmatched_risks:
        print(f"   未在原文中定位到关键词的风险（已纳入汇总表）:")
        for r in unmatched_risks:
            print(f"     - #{r.get('id')} {r.get('location', '')}: {r.get('clue', '')}")


if __name__ == "__main__":
    main()
