#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
豆包端探针 #2:跨工具轮次 env 持久化

目的:
    判定 v0.1.1 里 `export DECK_PLAN_CONFIRMED_V2=1` 这个约定在豆包 D-mode 下能否
    跨"一轮工具调用 → 下一轮工具调用"持久化。
    v9.8.9 里 provenance.py 是从当前进程的 os.environ 读取的;如果豆包每轮工具调用
    起新 shell / 新进程,这个 env 就会丢,provenance 硬闸会误伤所有 build_material 调用。

跑法(分两步):
    Step A: 在轮次#1 执行  → 写 env 并写一个 sidecar 探针文件
        DOUBAO_PROBE_ENV_TAG=alive_at_$(date +%s) python3 probe_env_persist.py --step A

    Step B: 在轮次#2 执行(必须是"下一轮"、不能同一条 Bash 命令里)
        python3 probe_env_persist.py --step B

判定标准:
    PERSIST     env 在 Step B 里还能读到 → v0.1.1 可原样用 `export`
    EPHEMERAL   env 在 Step B 里丢了 → 必须改造:通过 sidecar 文件 / --plan-confirmed-v2 CLI 参数传递

退出码:
    0 = PERSIST(可原样)
    1 = EPHEMERAL(必须改造)
    2 = 调用方式不对(缺 --step,或 Step A 没建 sidecar)
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

SIDECAR = Path.home() / ".doubao_env_probe.json"


def step_a():
    tag = os.environ.get("DOUBAO_PROBE_ENV_TAG", "").strip()
    if not tag:
        print(json.dumps({
            "step": "A",
            "result": "FAIL",
            "reason": "请这么跑:DOUBAO_PROBE_ENV_TAG=alive_at_$(date +%s) python3 probe_env_persist.py --step A"
        }, ensure_ascii=False, indent=2))
        return 2
    SIDECAR.write_text(json.dumps({
        "tag_set_in_step_a": tag,
        "step_a_time": int(time.time()),
        "step_a_pid": os.getpid(),
    }), encoding="utf-8")
    print(json.dumps({
        "step": "A",
        "result": "OK",
        "tag_set": tag,
        "sidecar": str(SIDECAR),
        "next": "现在切到下一轮工具调用,跑:python3 probe_env_persist.py --step B",
    }, ensure_ascii=False, indent=2))
    return 0


def step_b():
    if not SIDECAR.exists():
        print(json.dumps({
            "step": "B",
            "result": "FAIL",
            "reason": f"sidecar 不存在:{SIDECAR},请先跑 Step A",
        }, ensure_ascii=False, indent=2))
        return 2
    prev = json.loads(SIDECAR.read_text(encoding="utf-8"))
    now_tag = os.environ.get("DOUBAO_PROBE_ENV_TAG", "").strip()
    prev_tag = prev.get("tag_set_in_step_a", "")

    report = {
        "step": "B",
        "step_a_tag": prev_tag,
        "step_b_read_env": now_tag,
        "step_a_pid": prev.get("step_a_pid"),
        "step_b_pid": os.getpid(),
        "step_a_time": prev.get("step_a_time"),
        "step_b_time": int(time.time()),
    }
    if now_tag and now_tag == prev_tag:
        report["verdict"] = "PERSIST: env 在 Step A/B 之间保留,v0.1.1 可原样用 `export DECK_PLAN_CONFIRMED_V2=1`"
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    else:
        report["verdict"] = (
            "EPHEMERAL: env 在 Step B 已丢失(每轮工具调用起新 shell)。"
            "v0.1.1 必须改造 provenance 传递:改成"
            "(A) sidecar 文件 <deck>.plan.json 或 "
            "(B) build_material.py / render_page.py 加 --plan-confirmed-v2 CLI 参数"
        )
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--step", choices=["A", "B"], required=True)
    args = ap.parse_args()
    if args.step == "A":
        sys.exit(step_a())
    else:
        sys.exit(step_b())


if __name__ == "__main__":
    main()
