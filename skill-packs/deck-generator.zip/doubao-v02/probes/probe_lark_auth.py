#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
豆包端探针 #3:飞书鉴权下载(lark-doc / lark-drive)可用性

目的:
    判定 v0.1.1 里模块 d / e / f 三类图片模块能否在豆包上出片。
    v9.8.9 硬闸(verify_shot_provenance.py 等)强制要求:d/e/f 的所有截图必须来自
    lark-doc / lark-drive 鉴权下载。豆包平台如果没绑飞书身份,这三个模块会因取材
    失败 → 出不了片。

判定标准(需人工提供一个测试用飞书文档/文件 token):
    L1 平台上有可调用的 lark-doc / lark-drive skill
    L2 能拿到用户身份(user_access_token 或等价 sidecar)
    L3 能对 test token 发起下载,拿回非空 bytes
    L4 (可选) 下载的 bytes 是合法图片格式(PNG/JPG magic bytes)

跑法:
    python3 probe_lark_auth.py \\
        --test-doc-token doccnXXXXXXX \\
        --test-image-token boxcnYYYYYYY

    --test-doc-token   任意一份你有权限访问的飞书云文档 token(测 lark-doc 读取)
    --test-image-token 云盘里任一张图片文件的 token(测 lark-drive 下载)

如果豆包平台**根本没有 lark-doc / lark-drive skill 可用**:
    直接跑不带参数的 `python3 probe_lark_auth.py --check-skills-only`,
    脚本会尝试用几种常见方式探测(env 里的飞书 SDK / 系统 PATH 里的 lark-cli /
    可访问的 HTTP endpoint),输出探测报告。

退出码:
    0 = PASS(可原样出 d/e/f)
    1 = 无鉴权(d/e/f 出不了片,需先绑飞书身份)
    2 = 有鉴权但下载失败(需排查 token 权限或 endpoint 可达性)
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


def check_skill_availability():
    """探测豆包环境里能不能调 lark-doc / lark-drive"""
    report = {}

    # 1. env 里有没有飞书 SDK 相关的 token
    env_signals = {}
    for key in ("LARK_APP_ID", "LARK_APP_SECRET", "LARK_USER_ACCESS_TOKEN",
                "FEISHU_APP_ID", "FEISHU_APP_SECRET",
                "X_Mira_User_Access_Token", "MIRA_USER_SIGN", "MIRA_CURRENT_USERID"):
        env_signals[key] = "SET" if os.environ.get(key) else "MISSING"
    report["env_signals"] = env_signals

    # 2. 系统 PATH 里有没有 lark-cli
    report["lark_cli_in_path"] = shutil.which("lark") or shutil.which("lark-cli") or "NOT_FOUND"

    # 3. Python 端能否 import 常见飞书 SDK
    sdk_signals = {}
    for mod in ("lark_oapi", "larksuiteoapi", "feishu"):
        try:
            __import__(mod)
            sdk_signals[mod] = "IMPORTABLE"
        except ImportError:
            sdk_signals[mod] = "NOT_INSTALLED"
    report["python_sdk"] = sdk_signals

    return report


def try_lark_doc(doc_token):
    """尝试用 lark-cli 读一份飞书文档"""
    lark_bin = shutil.which("lark") or shutil.which("lark-cli")
    if not lark_bin:
        return {"tried": "lark-cli", "result": "SKIP", "reason": "lark-cli 不在 PATH"}
    try:
        r = subprocess.run(
            [lark_bin, "docs", "+read", "--token", doc_token],
            capture_output=True, timeout=30, text=True
        )
        return {
            "tried": "lark-cli docs +read",
            "returncode": r.returncode,
            "stdout_head": r.stdout[:500],
            "stderr_head": r.stderr[:500],
            "result": "OK" if r.returncode == 0 else "FAIL",
        }
    except Exception as e:
        return {"tried": "lark-cli docs +read", "result": "ERROR", "error": str(e)}


def try_lark_drive_download(image_token, out_path):
    """尝试下载云盘里一张图片"""
    lark_bin = shutil.which("lark") or shutil.which("lark-cli")
    if not lark_bin:
        return {"tried": "lark-cli", "result": "SKIP", "reason": "lark-cli 不在 PATH"}
    try:
        r = subprocess.run(
            [lark_bin, "drive", "+download", "--token", image_token, "--out", str(out_path)],
            capture_output=True, timeout=60, text=True
        )
        outcome = {
            "tried": "lark-cli drive +download",
            "returncode": r.returncode,
            "stdout_head": r.stdout[:500],
            "stderr_head": r.stderr[:500],
        }
        if r.returncode == 0 and Path(out_path).exists() and Path(out_path).stat().st_size > 0:
            head = Path(out_path).read_bytes()[:8]
            is_png = head[:8] == b"\x89PNG\r\n\x1a\n"
            is_jpg = head[:3] == b"\xff\xd8\xff"
            outcome["bytes_downloaded"] = Path(out_path).stat().st_size
            outcome["is_valid_image"] = is_png or is_jpg
            outcome["result"] = "OK" if (is_png or is_jpg) else "FAIL_NOT_IMAGE"
        else:
            outcome["result"] = "FAIL"
        return outcome
    except Exception as e:
        return {"tried": "lark-cli drive +download", "result": "ERROR", "error": str(e)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-doc-token", help="任一份你有权限的飞书文档 token")
    ap.add_argument("--test-image-token", help="任一张云盘图片文件的 token")
    ap.add_argument("--check-skills-only", action="store_true",
                    help="只探测 skill 是否可用,不做实际读/下载")
    args = ap.parse_args()

    report = {"skill_availability": check_skill_availability()}

    # 有没有任一鉴权信号
    has_signal = (
        report["skill_availability"]["lark_cli_in_path"] != "NOT_FOUND"
        or any(v == "IMPORTABLE" for v in report["skill_availability"]["python_sdk"].values())
        or any(v == "SET" for v in report["skill_availability"]["env_signals"].values())
    )
    report["has_any_auth_signal"] = has_signal

    if args.check_skills_only:
        report["verdict"] = "PASS_SIGNAL_ONLY" if has_signal else "FAIL_NO_AUTH"
        print(json.dumps(report, ensure_ascii=False, indent=2))
        sys.exit(0 if has_signal else 1)

    # 实测
    if args.test_doc_token:
        report["lark_doc_test"] = try_lark_doc(args.test_doc_token)
    if args.test_image_token:
        out = Path.home() / ".doubao_probe_image_download.bin"
        report["lark_drive_test"] = try_lark_drive_download(args.test_image_token, out)

    # 裁决
    if not has_signal:
        report["verdict"] = "FAIL_NO_AUTH: 豆包沙盒无飞书鉴权信号,d/e/f 三个模块出不了片,必须先绑飞书身份"
        print(json.dumps(report, ensure_ascii=False, indent=2))
        sys.exit(1)

    doc_ok = report.get("lark_doc_test", {}).get("result") == "OK"
    drive_ok = report.get("lark_drive_test", {}).get("result") == "OK"

    if args.test_doc_token and args.test_image_token:
        if doc_ok and drive_ok:
            report["verdict"] = "PASS_FULL: lark-doc + lark-drive 双通,可原样出 d/e/f"
            print(json.dumps(report, ensure_ascii=False, indent=2))
            sys.exit(0)
        else:
            report["verdict"] = "FAIL_DOWNLOAD: 有鉴权信号但下载失败,请检查 token 权限或 endpoint 可达"
            print(json.dumps(report, ensure_ascii=False, indent=2))
            sys.exit(2)

    report["verdict"] = "SIGNAL_ONLY: 有鉴权信号但没跑实测,请补 --test-doc-token / --test-image-token"
    print(json.dumps(report, ensure_ascii=False, indent=2))
    sys.exit(0)


if __name__ == "__main__":
    main()
