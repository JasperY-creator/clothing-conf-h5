# 豆包端 3 项前置探针

在把 v0.1.1 正式挂上豆包之前跑这 3 个探针,10 分钟内判定 v9.8.9 原封搬迁在豆包上
能真跑到哪一步、哪些闸门要降级。

## 探针 1 — Chromium / Playwright 可用性

**验的是**:几何 3 轮闸门(`verify_*_geom.py` / `verify_content_position.py` /
`deck-acceptance` B 段 DOM 探针)能不能原样跑。

```bash
python3 probes/probe_chromium.py
```

- **退 0** = 全 PASS,几何闸门可原样运行,输出与 v9.8.9 完全一致
- **退 1** = Playwright 或 Chromium 起不来,几何闸门必须降级为「视觉截图 + 模型判定」近似判定
- **退 2** = 部分能力可用,按 JSON 报告里 C1-C5 项裁剪

## 探针 2 — 跨工具轮次 env 持久化

**验的是**:`export DECK_PLAN_CONFIRMED_V2=1` 在豆包 D-mode 下能不能跨工具调用轮次
保留。这个 env 一旦丢失,`provenance.verify` 会硬拦所有 `build_material.py` 调用。

必须分两步、分两轮工具调用跑(同一条 Bash 命令里不算):

```bash
# 轮次#1
DOUBAO_PROBE_ENV_TAG=alive_at_$(date +%s) python3 probes/probe_env_persist.py --step A

# 轮次#2(必须是"下一次"工具调用)
python3 probes/probe_env_persist.py --step B
```

- **退 0** = PERSIST,`export` 有效,v0.1.1 无需改
- **退 1** = EPHEMERAL,必须改造 provenance:
  - 方案 A:改成 `<deck>.plan.json` sidecar 传递
  - 方案 B:所有 `build_material.py` / `render_page.py` 加 `--plan-confirmed-v2` CLI 参数

## 探针 3 — 飞书鉴权下载(lark-doc / lark-drive)

**验的是**:模块 d(痛点截图)/ e(方案全景截图)/ f(方案细节截图)能不能在豆包上出片。
这 3 个模块的截图**只允许**从飞书云文档鉴权下载,没鉴权就出不了片。

先探能力(不需要 token):

```bash
python3 probes/probe_lark_auth.py --check-skills-only
```

再实测(需要提供你有权限访问的一份飞书文档 token + 一张云盘图片 token):

```bash
python3 probes/probe_lark_auth.py \
    --test-doc-token   doccnXXXXXXX \
    --test-image-token boxcnYYYYYYY
```

- **退 0** = PASS,d/e/f 三模块可原样出片
- **退 1** = 无鉴权信号,必须先在豆包平台绑飞书身份(否则 d/e/f 全废)
- **退 2** = 有鉴权信号但下载失败,查 token 权限或 endpoint 可达性

## 结果解读矩阵

| 探针 1 | 探针 2 | 探针 3 | 结论 |
|---|---|---|---|
| PASS | PASS | PASS | v0.1.1 可原样上,预期与 v9.8.9 效果一致 |
| PASS | FAIL | PASS | 只需改 provenance 传递(sidecar / CLI 参数),其余不动 |
| FAIL | PASS | PASS | 几何闸门降级为视觉近似;3 轮联合报告仍能出,但位置误差容差要放宽 |
| PASS | PASS | FAIL | 出 a/b/c/g 类模块可以,d/e/f 类模块**必须先解决飞书身份问题** |
| FAIL | FAIL | FAIL | 需要一次较大改造:换成"云函数生成 → 豆包只负责编排"的双侧架构 |
