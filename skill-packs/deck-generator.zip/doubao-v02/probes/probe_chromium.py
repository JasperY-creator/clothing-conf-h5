#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
豆包端探针 #1:Playwright + Chromium 可用性

目的:
    判定 v0.1.1 里的几何 3 轮闸门(verify_*_geom.py / verify_content_position.py /
    deck-acceptance B 段 DOM 探针)在豆包沙盒里能否原样跑起来。

判定标准(全部满足才 PASS):
    C1 Python 能 `import playwright.sync_api`
    C2 系统能启动 Chromium(playwright.chromium.launch(headless=True) 不抛异常)
    C3 能加载一段 HTML 并调 evaluate("document.title") 返回 "probe"
    C4 能调 evaluate("elem.getBoundingClientRect()") 返回像素几何(几何闸门底座)
    C5 能调 page.screenshot() 拿到非空 PNG 字节(视觉判定底座)

退出码:
    0 = 全 PASS,几何 3 轮闸门可原样运行
    1 = C1 或 C2 失败,几何闸门必须降级为视觉近似判定
    2 = C3-C5 部分失败,几何闸门部分可用,需按项裁剪
"""
import json
import sys
import traceback


def probe():
    report = {"C1": None, "C2": None, "C3": None, "C4": None, "C5": None,
              "detail": {}, "verdict": None}

    # C1 import
    try:
        from playwright.sync_api import sync_playwright  # noqa
        report["C1"] = "PASS"
    except Exception as e:
        report["C1"] = "FAIL"
        report["detail"]["C1"] = f"{type(e).__name__}: {e}"
        report["verdict"] = "FAIL_HARD: playwright 未安装,几何闸门必须降级"
        return report, 1

    # C2 launch
    try:
        from playwright.sync_api import sync_playwright
        p = sync_playwright().start()
        browser = p.chromium.launch(headless=True)
        report["C2"] = "PASS"
    except Exception as e:
        report["C2"] = "FAIL"
        report["detail"]["C2"] = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        report["verdict"] = "FAIL_HARD: Chromium 起不来(缺 libnspr4/libdbus 等系统库),几何闸门必须降级"
        return report, 1

    # C3-C5
    try:
        page = browser.new_page(viewport={"width": 1280, "height": 720})
        page.set_content(
            "<html><head><title>probe</title></head>"
            "<body><div id='t' style='position:absolute;left:100px;top:200px;"
            "width:300px;height:150px;background:#f00'>hi</div></body></html>"
        )

        # C3 evaluate title
        title = page.evaluate("document.title")
        report["C3"] = "PASS" if title == "probe" else "FAIL"
        report["detail"]["C3"] = f"title={title!r}"

        # C4 getBoundingClientRect
        rect = page.evaluate("document.getElementById('t').getBoundingClientRect()")
        need = {"x": 100, "y": 200, "width": 300, "height": 150}
        ok4 = all(abs(rect.get(k, -1) - v) < 2 for k, v in need.items())
        report["C4"] = "PASS" if ok4 else "FAIL"
        report["detail"]["C4"] = f"rect={rect}"

        # C5 screenshot
        png = page.screenshot(type="png")
        ok5 = png and len(png) > 500 and png[:8] == b"\x89PNG\r\n\x1a\n"
        report["C5"] = "PASS" if ok5 else "FAIL"
        report["detail"]["C5"] = f"png_bytes={len(png) if png else 0}"

    except Exception as e:
        report["detail"]["C3-C5"] = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
        for k in ("C3", "C4", "C5"):
            if report[k] is None:
                report[k] = "FAIL"
    finally:
        try:
            browser.close()
            p.stop()
        except Exception:
            pass

    # 裁决
    all_pass = all(report[k] == "PASS" for k in ("C1", "C2", "C3", "C4", "C5"))
    if all_pass:
        report["verdict"] = "PASS_FULL: 几何 3 轮闸门可原样运行"
        return report, 0
    else:
        report["verdict"] = "FAIL_PARTIAL: 几何闸门部分可用,需按项裁剪"
        return report, 2


if __name__ == "__main__":
    report, code = probe()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    sys.exit(code)
