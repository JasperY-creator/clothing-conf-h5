---
name: doubao-html-deck-generator
description: 通用 16:9 演示 deck(HTML)生成器,专为豆包平台适配的 v0.2.11 版本。风格可换、不锁定任何品牌色——配色 100% 由用户提供的 Logo 或指定颜色派生。任何新 deck 都必须先过 5 道确认闸门(视觉基调 / 公司 LOGO + 企业名称 / 内容规划 / 「生成」确认 / 框架二次确认),经用户逐道确认后进入 Autopilot 一次跑到底。默认附赠一份「演讲稿」飞书文档 + 每页演讲者备注(整段全文,演讲者面板直接照念),deck-acceptance 硬闸检查缺一拒收。v0.2.11 修复:**痛点/方案细节支持每页 1–4 张图片,对齐 v9.8.9 多图逻辑**——(1)`preview-content.py` 把模块 d(痛点·场景1)的右列从单一 `.shotwrap>.shot` 改造成 `.shots.s{k}` 网格容器,与模块 f 同款(1 图铺满居中 / 2 图上下均分 / 3 图 2+1 底行铺满 / 4 图 2×2),每格 `object-fit:contain` 不裁切;(2)补齐 `.m-d .shots.s{k}` 的 CSS 网格规则(镜像 `.m-f .shots.s{k}`),取材器/覆盖器只需按 `k=min(len(shots),4)` 写 `.s{k}` 就地生效;(3)`compose_deck.py` EDIT_JS 的 IMG_SEL 从 `.m-d .shot` 精化为 `.m-d .shots .shot`,与 `.m-f .shots .shot` 对齐,编辑模式下每张截图独立上传/编辑/删除;(4)_module_d_gates 注释同步为 `.m-d .shots .shot`,verify_shot 一次覆盖全部 shot 位。v0.2.10 遗产保持:数字/卡片动效在默认/演讲者/投映三模式下重放正确,回页也会重跑。Use when:生成/制作 16:9 演示 deck、HTML PPT、汇报/提案材料;设置或更换 deck 配色;上传 Logo 或说出颜色方向(如"科技蓝")要定 deck 主题。
---

# doubao-html-deck-generator — 通用演示 deck 生成器(v0.2.11-r8)

产出物形态:**16:9 演示 deck(HTML)+ 飞书演讲稿文档 + 每页演讲者备注**。
适配豆包平台 D 模式(模型编排 + 本地脚本 + 工作区文件共享)。

**v0.2.11 模块覆盖(严格对齐 v9.8.9 module-catalog)**:

| 编码 | 模块 | 属性 | 页数 | 备注 |
|---|---|---|---|---|
| cover | 封面 | **必选** | 1 | 公司 LOGO + 企业名 + 文档标题 |
| **a** | 小故事切入 | ⬜ 可选 | 0 或 1 | 仅当文档有具象故事素材才纳入,无则明确跳过 |
| **b** | 团队介绍 | ⬜ 可选 | 0 或 1 | 对客/对外汇报且有团队履历才纳入,内部/纯技术方案可跳过 |
| **c** | 背景 Why | ✅ **必选** | 1 | 素材稀薄也要纳入,不得删 |
| **d** | 痛点剖析 | ✅ **必选** | 1–4(素材自适应) | 1 个痛点 1 页,>4 个合并同类项保留最关键 4 个 |
| **e** | 方案全景 | ✅ **必选** | 1 | 左截图 + 右 3–4 张总结卡片(每张卡片对应一张 f 详情页) |
| **e2** | 架构详图/闭环 | ✅ **必选** | 1 | **无论文档是否给架构描述都必须纳入**,由 page-architecture 基于方案能力/流程自行归纳(5 能力 + CORE + 5 flow + 回环) |
| **f** | 方案细节 | ✅ **必选** | 2–5(与 d 一一对应) | 每张 f 的标题**必须**取自 e 右侧某张总结卡片,截图必须来自云文档鉴权下载 |
| **g** | 总结升华 | ✅ **必选** | 1 | 1–8 张值卡自适应,数字与措辞必须来自云文档原文 |

- **必选骨架**(不得省):cover · c · d · e · e2 · f · g(**7 项**)
- **可选**(仅这两项):a · b
- 全部模块共用 v9.8.9 视觉模版,统一走 `build-all --extra <mod>=<json>` 一次成卷
- 标准编排:`cover → (a)? → (b)? → c → d(1-4) → e → e2 → f(2-5) → g`

---

## 全局约定(所有步骤必读)

1. **工作区**:所有中间产物统一放在当前工作目录 `.`(SKILL 执行时的沙盒工作区)。
2. **唯一真相源**:`deck_state.json` 是整个流程的状态中心,所有闸门锁定 / 关键决策
   都由 `scripts/state_manager.py` 读写。**禁止把状态藏在对话上下文里**。
3. **确认物料是图必须内联**:任何要给用户看的 PNG(色板、封面样张、验收报告)必须
   通过**平台文件上传能力**转成公网 URL,再用 Markdown `![alt](url)` 内联到回复里。
   **禁止直接把本地路径贴给用户**。
4. **平台能力调用 vs 本地脚本**:凡"读飞书文档 / 截图 / 图片生成 / 图片理解"必须
   通过**平台原生能力**(自动携带登录态);凡"HTML 渲染 / JSON 解析 / 校验判定"
   走**本地 Python 脚本**。两者通过工作区本地文件交换数据。
5. **每一步都要按顺序执行,禁止跳步**——每个下游脚本入口都会读 `deck_state.json`,
   前置闸门未锁定就 exit 1 硬拦。

---

## 开场白(技能被触发,用户还没给配色输入时)

**先输出下面这段开场白**,不要沉默直接开跑:

> 我可以帮你做一份 **16:9 的 HTML 演示 deck**——风格完全按你的品牌来,不套任何固定模板。
> 我能做的事:
> ① 从你的 **Logo** 里提取主色,自动派生一整套高级、无障碍达标的配色;
> ② 或按你说的**设计想法/颜色方向**(如"科技蓝""森林绿深色调""参考这张图的感觉")定调;
> ③ 出**色板 + 一页封面样张**给你确认,确认后再正式出片;
> ④ **默认附赠一份「演讲稿」飞书文档 + 每页演讲者备注**(整段全文,演讲者面板直接照念,无需再切文档)——deck-acceptance 硬闸检查,缺一拒收。
>
> **第一步,先给我任一个就行:**
> 📎 发我一张 **Logo**,或 💬 说说你对这份 **HTML/PPT 的设计想法**(颜色、明暗、风格参考)。

**规则**:
- 用户已经在同一句里给了 Logo 或颜色 → 跳过开场白直接进 Step 0。
- 开场白只负责"引导给输入",**它本身不算越过配色闸门**——真正出 HTML 仍要等 Step 0-4 全部确认。

---

## Step 0(强制闸门 ①):视觉基调 + 单模锁定

**触发条件**:用户给了 Logo 或颜色词。

### 执行步骤

1. **提取主色**:
   - 若用户上传了 Logo → 调用**平台图像理解能力**读该图,让它返回一个主色 hex(六位十六进制,如 `#0057FF`),把结果写入工作区 `logo_analysis.json`(JSON 结构:`{"primary_hex": "#XXXXXX", "logo_path": "<本地路径>"}`)。
   - 若用户只给了颜色词(如"科技蓝") → 按下表映射:
     - 科技蓝 → `#0057FF`
     - 森林绿 → `#2D6A4F`
     - 暖橙 → `#FF6B35`
     - 深紫 → `#5B2A86`
     - 玫红 → `#E63946`
     - 其他 → 按语义选一个合理 hex
     直接写入 `logo_analysis.json`(`logo_path` 留空字符串)。

2. **派生配色 + 出色板 + 出封面样张**(本地脚本):
   ```bash
   python3 scripts/render_page.py theme \
       --primary "$(python3 -c "import json;print(json.load(open('logo_analysis.json'))['primary_hex'])")" \
       --company-logo "$(python3 -c "import json;print(json.load(open('logo_analysis.json'))['logo_path'])")" \
       --out-dir themes/current
   ```
   产出:
   - `themes/current/palette.json`(4 阶 OKLCH 配色 + light/dark 双 token)
   - `themes/current/theme.css`(v9.8.9 双模 CSS)
   - `themes/current/theme_preview.html`(**单文件、自包含**的浅+深双模封面对照 + 4 色卡片)

3. **交平台把 `theme_preview.html` 截图为 PNG,拿公网 URL**:
   调用**平台的 HTML 截图/上传能力**把 `themes/current/theme_preview.html` 渲染成一张 PNG
   (或先分屏截浅深两版再拼接),把返回的 URL 保存到工作区 `theme_preview_urls.json`
   (结构 `{"preview":"<公网 PNG URL>"}`)。
   > 说明:豆包端不允许本地拉 headless Chromium,PNG 必须走平台侧截图能力,
   > 本 skill 只负责产出可截图的自包含 HTML,不再产 PNG。

4. **主动内联展示给用户确认**(在回复里用 Markdown 图片语法):
   > 我按你的 [Logo / 颜色词] 派生了这套配色,浅色深色两版封面样张一起给你看:
   > ![配色 + 双模封面对照](url_preview)
   >
   > **请确认**:① 这套配色 OK 吗?② **深色 or 浅色**,选一个作为整份 deck 的主模式(整份 deck 会锁定这一种,不允许中途换)?

5. **停下等用户回复**。

### 用户回复分支

- 用户回「OK,用浅色 / 深色」→ 锁定:
  ```bash
  python3 scripts/state_manager.py lock-step0 --theme-slug current --mode <light|dark>
  ```
- 用户回「颜色偏了/再深一点/换个方向」→ 按用户反馈调整 primary hex,回到步骤 2 重跑。
- 用户不确定 → 追问一句「浅色还是深色?」直到明确。

### 锁定后写入 `deck_state.json`

```json
{ "step0": {"status":"confirmed", "theme_slug":"current", "mode":"light"} }
```

---

## Step 1(强制闸门 ②):公司 LOGO + 企业名称

**触发条件**:`deck_state.json.step0.status == "confirmed"`。

### 执行步骤

**根据 Step 0 输入类型分两种话术,一次讲清、一起要**:

**情况 A(Step 0 是上传 Logo 定的调)**:

> Step 0 你上传的这张图,**是不是贵司的公司 LOGO**?我会把它放到封面顶部信笺带里、和飞书标并排。
>
> 同时,封面署名与每页页脚会显示「**<企业名称> × 飞书 · AI 先锋大赛**」,**企业名称要写成什么?**
>
> 请一起回我:① Logo 是/否是公司 LOGO;② 企业名称。

**情况 B(Step 0 是颜色词定的调)**:

> 封面顶部信笺带要放贵司 LOGO,请上传一张;若这份汇报**不需要公司 LOGO**,回我「不需要」即可。
>
> 同时,封面署名与每页页脚会显示「**<企业名称> × 飞书 · AI 先锋大赛**」,**企业名称要写成什么?**

### 用户回复分支

- 用户回「是」+ 企业名 → `company_logo = <Step0 上传路径>`,`company_name = <用户给的>`
- 用户回「否」→ 追问「那请上传贵司 LOGO,或回『不需要』」
- 用户回「不需要」+ 企业名 → `company_logo = null`,`company_name = <用户给的>`
- 用户上传新 Logo + 企业名 → `company_logo = <新路径>`,`company_name = <用户给的>`

### 锁定动作

```bash
python3 scripts/state_manager.py lock-step1 \
    --company-logo "<路径 或 空字符串>" \
    --company-name "<企业名称>"
```

未确认前**不得进入 Step 2**。

---

## Step 2(强制闸门 ③):内容规划

**触发条件**:`deck_state.json.step1.status == "confirmed"`。

### 执行步骤

1. **向用户要飞书云文档链接**:
   > 现在把你的**飞书云文档链接**发我,我读完全文后规划模块和页数,再让你确认。

2. **拿到链接后,调用平台飞书文档读取能力**读全文,保存为工作区 `source.md`
   (纯 Markdown 格式,保留章节结构)。

3. **提取团队信息 + 收官信息**(本地脚本):
   ```bash
   python3 scripts/render_page.py extract-plan \
       --source source.md \
       --out plan.json
   ```
   产出 `plan.json` 结构:
   ```json
   {
     "deck_title": "从文档标题提取",
     "team": {
       "team_name": "队名",
       "leader": "队长姓名",
       "members": ["队员1","队员2",...],
       "department": "部门",
       "one_liner": "一句话介绍"
     },
     "closing": {
       "main_line": "收官主句",
       "sub_line": "副句(可选)",
       "impact_numbers": [{"value":"XX","unit":"倍","label":"效率提升"}]
     }
   }
   ```

4. **列出模块规划清单,让用户确认**——严格对齐 v9.8.9 module-catalog:**cover / c / d / e / e2 / f / g 是必选骨架,不得省**;**a / b 是唯二可选项**,按文档实际素材判定纳不纳。规划清单**必须列全 9 类模块**(含标 0 的可选项),让用户对每一项都有明确取舍机会:

   > 我读完了 **{deck_title}**,这是模块规划清单(严格按 v9.8.9 module-catalog 规则):
   >
   > | 编码 | 模块 | 纳入 | 建议页数 | 文档素材线索(摘要 + 来源) |
   > |---|---|---|---|---|
   > | cover | 封面 | ✅ 必选 | 1 | 公司 LOGO + 企业名称 + {deck_title} |
   > | a | 小故事切入 | {✅ 纳入 / ⬜ 不生成(无具象故事素材)} | {1 / **0**} | {示例:第 X 节「XX 场景」原话可作钩子} |
   > | b | 团队介绍 | {✅ 纳入 / ⬜ 不生成(内部汇报/无团队素材)} | {1 / **0**} | {示例:文档"团队"章节 — {team_name}/{leader}/{members}} |
   > | c | 背景 Why | ✅ **必选** | 1 | 文档"背景/为什么/趋势/政策"章节 |
   > | d | 痛点剖析 | ✅ **必选** | {N,自动 1-4} | 文档中识别出的 N 个独立痛点,各带数据/后果 |
   > | e | 方案全景 | ✅ **必选** | 1 | 左方案全景截图 + 右 {M} 张总结卡片(每张即后续 f 的标题) |
   > | e2 | 架构详图/闭环 | ✅ **必选** | 1 | 文档"架构/分层/协同"章节;**若文档无直接描述,由 page-architecture 基于方案能力/流程自行归纳(5 能力 + CORE + 5 flow + 回环),不许跳过** |
   > | f | 方案细节 | ✅ **必选** | {M,与 d 一一对应,2-5} | 每张 f 页标题**必须**取自 e 右侧一张卡片(方案主张 → 方案细节 一一闭环);右图必须来自云文档鉴权下载 |
   > | g | 总结升华 | ✅ **必选** | 1 | 文档"总结/收官/成效/Roadmap"章节:{main_line} + {impact_numbers}(1-8 张值卡自适应) |
   >
   > 叙事流:`cover → (a)? → (b)? → c → d×{N} → e → e2 → f×{M} → g`,**共 {TOTAL} 页**。
   >
   > **注意**:c / d / e / e2 / f / g 六项一律必选,不能省;a / b 仅当文档真有对应素材才纳入。
   > **你可以直接说「按建议来」,或指定 a / b 要不要、d 或 f 页数调整**。

5. **停下等用户回复**。

### 用户回复分支

- 用户确认 → 锁定:
  ```bash
  python3 scripts/state_manager.py lock-step2 --plan-file plan.json --source-doc <飞书 URL>
  ```
- 用户要求改素材来源 → 修改 `plan.json` 对应字段后重贴清单,再等确认。

---

## Step 3(强制闸门 ④):「生成」确认(独立话术,禁止和 Step 2 合并)

**触发条件**:`deck_state.json.step2.status == "confirmed"`。

### 执行步骤

**必须单独发一条消息**(不能挂在 Step 2 清单尾巴上,把**全部纳入模块逐条点名**):

> 根据当前云文档,我计划按以下模块生成(未纳入的标 0 页):
> - **cover**(封面,1 页)
> - **模块 a**(小故事切入,{1 页 / **0 页 · 不生成**})
> - **模块 b**(团队介绍,{1 页 / **0 页 · 不生成**})
> - **模块 c**(背景 Why,1 页)
> - **模块 d**(痛点剖析,{N} 页 · 每页 1 个痛点)
> - **模块 e**(方案全景,1 页 · 右侧 {M} 张总结卡片)
> - **模块 e2**(架构详图/闭环,1 页)
> - **模块 f**(方案细节,{M} 页 · 与 e 的 {M} 张卡片一一闭环)
> - **模块 g**(总结升华,1 页)
>
> ——共 **{TOTAL}** 页。**是否按当前逻辑生成?**
>
> 确认请回复「**生成**」;如需增删(如「加上模块 a」「不要模块 b」「d 减到 2 页」),请明确告知。

### 用户回复分支

- 用户回「生成」→ 锁定:
  ```bash
  python3 scripts/state_manager.py lock-step3
  ```
- 用户要求增删 → 回到 Step 2 调整 `plan.json`,再重跑 Step 3。

**注意**:必须收到明确的「生成」信号才能进 Step 4。收到模糊回复(如「好的」「嗯」)
要追问一句「请明确回复『生成』或『修改』」。

---

## Step 4(强制闸门 ⑤):框架二次确认(最后一次修改机会)

**触发条件**:`deck_state.json.step3.status == "generated"`。

### 执行步骤

**必须单独发一条消息**(独立于 Step 3),结构化 Markdown 表格 + 独立话术:

> 这是最终框架表格,请逐行核对(按 v9.8.9 module-catalog 顺序):
>
> | 页序 | 模块 | 本页标题 | 素材锚点 |
> |---|---|---|---|
> | 01 | cover | {企业名} · {deck_title} | Step 1 Logo + 企业名 |
> | {?} | a 故事 | {故事钩子标题} | 文档"故事/引子"章节(若已勾选) |
> | {?} | b 团队 | {team_name} | 文档"团队"章节(若已勾选) |
> | {?} | c 背景 Why | {背景主张} | 文档"背景/趋势/政策"章节 |
> | {?..?+N-1} | d 痛点(N 页) | {每页 1 个痛点标题} | 文档"痛点/难题"章节,每页 1 个 |
> | {?} | e 方案全景 | {方案主张} | 文档"方案总览"章节 + 云文档全景截图 |
> | {?} | e2 架构详图 | {架构主张} | 文档"架构/协同"章节(无则 page-architecture 自行归纳) |
> | {?..?+M-1} | f 方案细节(M 页) | {每页标题 = e 某张卡片} | 与 d 一一对应;右图必须来自云文档鉴权下载 |
> | {TOTAL} | g 收官 | {closing.main_line} | 文档"总结/成效"章节 + 1-8 张值卡 |
>
> **f 每页标题必须映射自 e 右侧一张总结卡片(方案主张 → 方案细节 闭环)**;
> **这是最后一次修改机会**——确认后进入 Autopilot,一次跑到底,不再逐页停下。
>
> 请回复「**确认**」。

### 用户回复分支

- 用户回「确认」→ 锁定并进入 Autopilot:
  ```bash
  python3 scripts/state_manager.py lock-step4
  ```
- 用户提修改 → 修改 `plan.json` 对应字段后重贴表格,再等「确认」。

**⚠️ 收到「确认」后,到交付前不再打扰用户**。

---

## Autopilot 阶段(用户不再干预)

**前置铁律**(缺一都必须硬拦):
- `step0.status == confirmed` 且 `mode` 已锁 light/dark
- `step1.status == confirmed`(有 Logo 或明确"不需要")
- `step2.status == confirmed`
- `step3.status == generated`
- `step4.status == plan_confirmed_v2`

**page-notes 4 参数静默推断**(禁止追问用户):
- `duration`:按最终页数动态推断——3 页→3 分钟,4-6 页→5 分钟,7-10 页→8 分钟,>10 页→10 分钟(节奏约 1 页/分钟,收官/封面按半页折算)
- `role = "汇报人"`(不做部门推断,豆包端简化)
- `structure = "story"`(默认)
- `company_name = deck_state.json.step1.company_name`(直接读)

### A1. 团队头像生成(平台图片生成能力)—— 仅当模块 b 已勾选

**前置**:检查 `plan.json` 是否含 `team` 段,且 Step 2 用户明确保留了模块 b(`b.enabled == true`)。若模块 b 未纳入,**跳过 A1/A2/A5**,直接进 A3。

读 `plan.json.team.members`(6 位以内),对每位队员:
1. 调用**平台 Seedream 图片生成能力**,提示词:
   `"专业职场半身像,{姓名},{部门}员工,{Step0 主色}色调背景,简洁明亮,单色铅笔素描风格,正面,商务氛围,高清"`
2. 生成的图片 URL 保存到 `avatars/{姓名}.url`(每行一个 URL 的文本文件)。

批量完成后,汇总为 `avatars/avatars_urls.json`:
```json
[{"name":"张三","url":"https://..."}, ...]
```

### A2. 头像真伪多模态校验(3 轮一致)—— 仅当模块 b 已勾选

对每张头像,**调用平台图片理解能力**判断:
- 是不是**真实的头像图**(有五官、有背景、有细节)?
- 还是**首字占位 / 空白帧 / 坏图 / 纯色块**?

要求返回 JSON 数组,格式:
```json
[{"name":"张三","valid":true,"reason":"清晰半身像"}, ...]
```

**跑 3 轮**(SKILL.md 编排里连续调 3 次多模态,每次结果保存为
`avatars/verify_round1.json` / `round2.json` / `round3.json`),然后本地判定:

```bash
python3 scripts/verify_avatars.py \
    --rounds avatars/verify_round1.json avatars/verify_round2.json avatars/verify_round3.json \
    --out avatars/verdict.json
```

- 3 轮结果一致 + 全部 `valid=true` → 退出码 0,进入 A3
- 有一张失败 → 退出码 1,读 `verdict.json.retry_list`,回到 A1 只重生成失败的头像,
  最多重试 3 轮,3 轮后仍失败 → 标记该头像 DEGRADED,继续但在验收报告告警

### A2.5 云文档截图批量下载 + material JSON 构建(必做,禁跳)

进 A3 之前,**必须**为每个纳入模块构建 `materials/mod_<X>.json`,其中 body 字段承载真实素材,否则渲染出的页面会是刺目红色警告(v0.2.5 起硬警告)。

**A2.5.1 云文档截图鉴权下载**(模块 d/e/f 必做):
- 对 plan.json 中每个 d/e/f 页,调**平台 lark-doc / lark-drive 鉴权下载能力**,**按图片的 image_key / media token 下载「原始媒体(原图字节)」**,保存到 `materials/screenshots/<mod>_<page>.png`,再原样交给 scripts/render_page.py 的 `_img_data_uri` base64 内联为 data:URI —— 它纯字节透传(不缩放/不转码/不改色),因此原图的颜色与清晰度会被完整保留。
- **严禁**用「整页网页截屏」代替元素原图(会在图片下方拖一大条近白空白带),也**严禁**用有损缩略图 / 二次编码(整体会偏黄暖调),更不许用占位图 / 纯色块。这三种残次品会被 A7 的 `verify_screenshots`(下述)静态取证拉黑,拒绝交付。
- 校验:出片后跑 `python3 scripts/verify_screenshots.py out/deck.html --dir materials/screenshots`(已内联进 `accept_deck.py` 第 8 步)。三条判据任一命中即 FAIL:① 底部近白带 ≥ 图高 22%(整页截屏残留);② 非白像素整体偏黄(R−B≥24 且 G−B≥16,有损缩略图/偏黄二次编码);③ 32×32 独立色 ≤4 或标准差 <6(纯色占位)。
- 禁用无来源的图片、占位图、AI 生成图充当"云文档截图"——deck-acceptance 会拉黑。

**A2.5.2 模块 a 故事图**(仅当模块 a 已勾选):
- 调**平台 Seedream 图片生成能力**,提示词按 plan.json 的故事内容动写("单色铅笔素描风格,{Step0 主色}调,{故事场景描述},梯形构图,高级审美,无水印"),保存 URL → 内联 base64 → 塞进 `materials/mod_a.json` 的 body 字段的 `.sketch .frame` 内替换 .ph 占位。

**A2.5.3 material JSON 模板**(每个模块必须包含真实 body):

模块 a(故事页,右侧素描图必须替换占位):
```json
{
  "mod": "a",
  "kicker": "开场 · STORY",
  "title": "<从 plan 提取>",
  "body": "<div class=\"m-a hug\"><div class=\"quote\">...真实引语...</div><div class=\"sketch\"><div class=\"plate\"></div><div class=\"frame\"><img src=\"data:image/png;base64,<SEEDREAM_B64>\" alt=\"故事场景\"></div></div></div>"
}
```

模块 d(痛点页,右侧云文档截图必须替换占位):
```json
{
  "mod": "d",
  "kicker": "痛点 · PAIN",
  "title": "<从 plan 提取,与 d 序号对应>",
  "body": "<div class=\"m-d\"><div class=\"pcol\"><div class=\"bignum\">01</div><p class=\"lead\">...真实痛点描述...</p><ul class=\"kpts\">...</ul></div><div class=\"shotwrap\"><div class=\"shot\"><img src=\"data:image/png;base64,<LARK_DRIVE_B64>\" alt=\"痛点截图\"></div></div></div>"
}
```

模块 e(方案全景,左侧云文档截图必须替换占位,右侧 3-4 张卡片对应 f 页标题):
```json
{
  "mod": "e",
  "kicker": "方案全景 · SOLUTION",
  "title": "<方案主张>",
  "body": "<div class=\"m-e\"><div class=\"intro\">...一句话方案说明...</div><div class=\"ebody\"><div class=\"shotwrap\"><div class=\"shot\"><img src=\"data:image/png;base64,<LARK_DRIVE_B64>\" alt=\"方案全景\"></div></div><div class=\"esum\"><div class=\"epoint\"><span class=\"idx\">01</span><span class=\"etxt\">...</span></div>...</div></div></div>"
}
```

模块 f(方案细节,右侧云文档截图必须替换占位,标题必须映射自 e 的 epoint):
```json
{
  "mod": "f",
  "kicker": "方案细节 · DETAIL",
  "title": "<必须取自 e 某张 epoint.etxt>",
  "body": "<div class=\"m-f\"><div class=\"intro\">...</div><div class=\"fbody\"><div class=\"fsum n3\"><div class=\"fpoint\"><div class=\"num\"><span class=\"v\" data-to=\"NN\">0</span><span class=\"u\">...</span></div><div class=\"t\">...</div><div class=\"d\">...</div></div>...</div><div class=\"shots s1\"><div class=\"shot\"><img src=\"data:image/png;base64,<LARK_DRIVE_B64>\" alt=\"方案细节\"></div></div></div></div>"
}
```

模块 c(背景 Why,数字为焦点,BG_COUNT_JS 自动挂载):
```json
{
  "mod": "c",
  "kicker": "背景 · WHY",
  "title": "<背景主张>",
  "body": "<div class=\"m-c\"><div class=\"lead\">...段落文字...</div><div class=\"cards\"><div class=\"stat\"><div class=\"num\"><span class=\"v\" data-to=\"NN\">0</span><span class=\"u\">%+</span></div><div class=\"meta\">...</div></div>...</div></div>"
}
```

**关键约束**:
- 所有 body 里的 `.v[data-to="N"]` 会自动挂 count-up 动效(BG_COUNT_JS 已内置);数字**必须**是真实目标值(来自云文档),不许写占位。
- 所有 `.stat`/`.card`/`.epoint`/`.fpoint` 卡片都有 mcCardIn 错峰入场动效(纯 CSS 已内置);无需额外处理。
- 若模块 body 里出现 `.ph.err` 红色警告 → 意味着未注入真实素材,立即回填并重跑;deck-acceptance 会拉黑带红警告的 deck。

**A2.5.4 material 就绪自检**:
```bash
python3 -c "
import json,glob,re
for f in sorted(glob.glob('materials/mod_*.json')):
    d=json.load(open(f))
    body=d.get('body','')
    assert body, f'{f} 缺 body'
    assert 'ph err' not in body and '缺云文档截图' not in body and '缺故事场景图' not in body, f'{f} 仍有红警告占位'
    if d['mod'] in ('d','e','f'):
        assert 'data:image' in body or 'http' in body, f'{f} 缺真实截图'
    print(f'✅ {f}')"
```

自检不过 → 回到 A2.5.1 补料;不许带红警告进 A3。

### A3. 渲染各页 HTML(cover + 可选 a/b + 必选 c/d/e/e2/f/g)

**页序按 Step 4 已确认的框架表**,cover 必渲、g 必渲、c/d/e/e2/f 必渲;a / b 仅当 Step 2 勾选才渲。**推荐一步到位走 `build-all`**:

```bash
python3 scripts/render_page.py build-all \
    --state deck_state.json --plan plan.json \
    --avatars avatars/avatars_urls.json  # 仅当模块 b 已勾选时传 \
    --extra a=materials/mod_a.json  # 仅当模块 a 已勾选 \
    --extra c=materials/mod_c.json \
    --extra d=materials/mod_d.json  # d 可多张,建议改成 d1/d2/... \
    --extra e=materials/mod_e.json \
    --extra e2=materials/mod_e2.json \
    --extra f=materials/mod_f.json  # f 可多张,标题必须映射自 e 卡片 \
    --out-dir out --accept
```

**单页渲染**(排错时用):

```bash
python3 scripts/render_page.py cover --state deck_state.json --plan plan.json --out pages/01_cover.html
python3 scripts/render_page.py team  --state deck_state.json --plan plan.json --avatars avatars/avatars_urls.json --out pages/0X_team.html   # 仅当模块 b 已勾选
python3 scripts/render_page.py close --state deck_state.json --plan plan.json --out pages/NN_close.html

python3 scripts/render_page.py page \
    --state deck_state.json --plan plan.json \
    --mod e --module-json materials/mod_e.json \
    --page-no {?} --total {TOTAL} \
    --out pages/{?}_mod-e.html
```

**模块 f 硬约束**(page-detail 子技能):每页标题必须取自模块 e 右侧某张总结卡片(方案主张 → 方案细节 一一闭环);右侧截图必须来自飞书云文档鉴权下载(lark-doc / lark-drive),禁占位图。

**模块 e2 硬约束**(page-architecture 子技能):即便文档无架构描述也必须纳入,由子技能基于方案能力/流程自行归纳出「5 能力卡 + 中央 CORE + 5 步骤 flow + 底部回环」,禁跳过。

**模块 b 硬约束**(page-team 子技能,仅当勾选时启用):渲染后必须跑 `verify_layout` 校验标题/队名/一句话/花名册/部门带位置,以及 `verify_avatars` 校验每张头像是真图而非首字占位/空帧/坏图,两项都必须 3 轮一致。

### A4. 排版 lint + 单模一致性校验

```bash
python3 scripts/lint_slides.py pages/*.html
# 退出码 0 才继续,否则按报告修

python3 scripts/verify_single_mode.py pages/*.html --mode "$(python3 -c "import json;print(json.load(open('deck_state.json'))['step0']['mode'])")"
# R1/R2/R3 全过退出码 0
```

### A5. 位置 3 轮一致性校验(团队页,仅当模块 b 已勾选)

```bash
# 若 plan.json 里模块 b 未勾选,跳过 A5
python3 scripts/verify_layout.py --page pages/0X_team.html --rounds 3
# 3 轮位置一致才过
```

### A6. 拼装整卷 deck

```bash
python3 scripts/render_page.py compose --pages pages/*.html --out deck.html
```

### A7. 演讲稿备注 + 飞书演讲稿文档(page-notes 流程)

**A7.1 生成骨架**(本地脚本):
```bash
python3 scripts/render_page.py speech-plan \
    --deck deck.html \
    --duration 3 --role "汇报人" --structure story \
    --company-name "$(python3 -c "import json;print(json.load(open('deck_state.json'))['step1']['company_name'])")" \
    --deck-title "$(python3 -c "import json;print(json.load(open('plan.json'))['deck_title'])")" \
    --out speech_plan.json
```

**A7.2 SKILL.md 编排:填 speech_plan.json 的 text/per_page_notes/titles/qna**

对每页,按 story 结构写一段 100-200 字的自然段(演讲者面板要照念的完整口语),要求:
- 每段至少 80 字
- 若本页有大数字(如"效率提升 3 倍"),备注里必须重复该数字("数字回声")
- 禁用术语:RAG / embedding / prompt / vector / LLM / token / fine-tune / 向量数据库 / 提示词工程
- 禁止占位符 `[待生成]` / `[待填]`

写入 `speech_plan.json.per_page_notes`(字典 key 是页序号 `"01"/"02"/"03"`,value 是整段字符串)
和 `speech_plan.json.segments`(演讲全场分段)。

**A7.3 就地写回 data-notes**:
```bash
python3 scripts/render_page.py inject-notes deck.html speech_plan.json
# 产出 deck.notes.json sidecar,deck-acceptance 硬闸 ① 依赖它
```

**A7.4 3 轮硬闸校验**:
```bash
python3 scripts/verify_speaker_notes.py deck.html --rounds 3
# 6 闸(覆盖率/整页≥80字/数字回声/禁术语/占位残留/3轮字节一致)全过退 0
```

**A7.5 调平台飞书文档创建能力,建演讲稿文档**:
- 标题**严格套**:`{企业名}效率先锋演讲稿 - {演讲标题}`
  (企业名读 `deck_state.json.step1.company_name`,演讲标题读 `plan.json.deck_title`)
- 内容:把 `speech_plan.json.segments[*].text` + `titles` + `qna` 汇入,
  按"演讲全文 → 关键话术 → Q&A 预案"三段组织
- 拿到飞书文档 URL 后:

```bash
python3 scripts/render_page.py record-speech-doc \
    --deck deck.html \
    --lark-url "<飞书文档 URL>" \
    --title "{企业名}效率先锋演讲稿 - {演讲标题}"
# 产出 deck.speech.json sidecar,deck-acceptance 硬闸 ② 依赖它
```

### A8. 整卷验收总闸

```bash
python3 scripts/accept_deck.py deck.html \
    --mode "$(python3 -c "import json;print(json.load(open('deck_state.json'))['step0']['mode'])")"
# 会自动跑 lint + single-mode + notes.json 存在 + speech.json 存在 + verify_speaker_notes 3 轮
# 全过退 0 才允许交付
```

### A9. 上传 + 交付链接校验

1. **调用平台文件上传能力**上传 `deck.html`,拿到公网 URL,保存到 `deck_url.txt`
2. 交付链接校验:
   ```bash
   python3 scripts/verify_delivery.py \
       --file deck.html \
       --url "$(cat deck_url.txt)"
   # HTTP 200 + md5 匹配 + 大小一致,全过退 0
   ```

### A10. 交付给用户

**输出格式**:

> ✅ Deck 已生成,所有硬闸通过:
> - 📄 **HTML Deck**:[点击查看](<deck_url>)
> - 🎤 **演讲稿飞书文档**:[点击查看](<lark_speech_url>)
> - 📝 **每页备注**:已烤进 HTML,按 `S` 键进入演讲者视图
>
> **验收报告**:
> - lint ERROR=0 ✅
> - 单模一致(R1/R2/R3)✅
> - 团队头像真伪(3 轮){✅ / N/A · 模块 b 未勾选}
> - 团队位置一致(3 轮){✅ / N/A · 模块 b 未勾选}
> - f→e 卡片映射闭环 ✅
> - f/d 截图云文档鉴权来源 ✅
> - e2 结构完整(5能力+CORE+5flow+回环)✅
> - 演讲稿备注 6 闸(3 轮)✅
> - 交付链接可达 ✅

---

## 硬闸失败处理协议

任何硬闸 FAIL(exit code != 0)时:
1. **就地读退出脚本的错误日志**,定位失败点
2. **就地修复重跑**(不打扰用户),最多重试 3 轮
3. 3 轮仍失败 → 在验收报告里明确标注该项 DEGRADED,继续交付但**响亮告知用户风险**
4. **禁止**:悄悄跳过硬闸 / 用占位物顶替 / 交付坏链

---

## 子技能索引(v0.2.11 单文件版,后续版本按需拆分)

| 脚本 | 职责 | 前置读取 |
|---|---|---|
| `scripts/state_manager.py` | 读写 `deck_state.json`,锁定 5 道闸门 | - |
| `scripts/render_page.py` | 派生主题 / 抽取规划 / 渲染各页(cover · team · close · 通用 page) / 拼装三模式 shell / 演讲稿骨架 / 备注注入 / speech-doc 记录 / build-all 一键成卷 | `deck_state.json` |
| `scripts/verify_avatars.py` | 头像 3 轮多模态一致性判定 | 3 份多模态返回 JSON |
| `scripts/verify_layout.py` | 团队页位置 3 轮一致性(标题/队名/一句话/花名册/部门带) | 页面 HTML |
| `scripts/verify_single_mode.py` | 单模 R1/R2/R3 一致 | 全 deck HTML |
| `scripts/verify_speaker_notes.py` | 演讲稿备注 6 闸 3 轮 | `deck.html` |
| `scripts/lint_slides.py` | 排版规范校验(支持 `.page`/`.cover-wrap` 双根) | 页面 HTML |
| `scripts/accept_deck.py` | 整卷验收总闸(整合上述,含 `--team-page` 探测) | `deck.html` + sidecars |
| `scripts/verify_delivery.py` | 交付链接三方校验 | 上传后 URL |

---

## 演进路径(v0.2.11 之后)

v0.2.11-r8(用户实测「背景页左侧字体有时太大」修复)修 1 项 c(背景)页排版缺陷,**只动 c 页左栏自适应逻辑(单一源 `assets/preview-content.py` 的 `LEAD_FIT_JS` + `.m-c .lead` CSS,由 `render_page.py` 以模块加载,无需两处同改),不改文案/右侧数字卡/其他模块**:
- **【体验】背景页(c)左侧正文字体有时候会太大**。根因是自适应拟合退化成「永远取最大」:`.m-c` 是 `align-items:flex-start`,左栏 `.m-c .lead` 高度自适应、不受内容区高度约束,于是 `LEAD_FIT_JS` 里 `box.scrollHeight` 恒等于 `box.clientHeight`——收缩分支(溢出才 -1px)永不触发,而放大分支(有富余就 +1px)一路把每段字号顶到旧上限 `mx=28px`,不论文字长短都定格在 28px 偏大。修法两处:①CSS 给 `.m-c .lead` 加 `align-self:stretch; min-height:0; overflow:hidden`,让左栏吃满内容区高度、成为拟合可比较的高度预算(长段落溢出时收缩分支这才有 `clientHeight` 可依);②JS 把 c 页拟合上限从 `28` 降到 `22`(=base),使字号只会因溢出而向下收缩、绝不向上膨胀,稳定在与姊妹页 `.m-d .pcol .lead`(静态 21px)看齐的舒适基线。已用无头 Chromium 端到端实测:1280×720 / 1440×900 / 1920×1080 三档下左侧两段恒为 22px(修前恒为 28px)、`.lead` 无溢出;注入超长段落后拟合正确下探到 19px(mn 下限)且容器零溢出,证明收缩分支已真正生效(修前永不触发);`lint_slides` ERROR=0、`verify_single_mode` R1/R2/R3 全 PASS。

v0.2.11-r7(用户实测「Shift+P 有概率不进全屏」修复)修 1 项投屏可靠性缺陷,**只动 shell 的 `launchProjector`/`enterFullscreen`,不改版式/文案/观赏态视觉/任何模块**:
- **【体验】Shift+P(双窗口投屏)只是有概率进全屏,不是每次都进**。根因是焦点抢占竞态:旧顺序先 `enterFullscreen()` 再 `window.open()` 弹出 speaker 窗口——`requestFullscreen()` 返回的是异步 Promise,在它尚未 settle 时弹出的 speaker 窗口抢走了投屏窗口的焦点,而浏览器会中止「pending 且已失焦」的全屏请求,于是时序快则成、慢则败,表现为概率性全屏(纯 S/P 就地模式不开窗口,所以从不抖动,只有 Shift+P 犯病)。修法:①先 `window.open` speaker 窗口;②立刻 `w.blur()` 它并 `window.focus()` 把焦点抢回投屏窗口;③在 `requestAnimationFrame` 里(焦点已回到本窗口的下一帧)再 `enterFullscreen()`,此时全屏请求不会因失焦被中止;并把 `enterFullscreen` 改为接住 `requestFullscreen()` 的 Promise rejection(静默 `.catch`),避免偶发失败冒 `unhandledrejection`。**此改动同时落到 `assets/compose_deck.py` 与 `scripts/render_page.py` 两份 shell 副本(两处必须同改)。** 已用无头 Chromium 埋点实测 Shift+P 的真实调用时序恒为 `window.open → w.blur → window.focus → requestFullscreen`(全屏请求确在焦点抢回之后才发出,3 项顺序断言全 PASS),`deck-projecting` 正确置位;`lint_slides` ERROR=0、`verify_single_mode` R1/R2/R3 全 PASS。

v0.2.11-r6(用户要求「去掉 e2 连线上跑动的点」)按用户明确诉求移除 e2 连线跑动光点,**只动 e2 引擎脚本 `E2_DRAW_JS`(单一源 `assets/preview-content.py`,由 `render_page.py` 以模块加载,无需两处同改),不改版式/文案/连线本身/其他模块**:
- **【体验】e2 连线上沿路径跑动的 spark 光点效果不符合预期,用户要求直接去掉**。原实现:`draw()` 在每条连线(5 条 cap→orb + 5 条 orb→step)上各建一枚 `<circle class="spark">`,挂 `animateMotion`(沿 mpath 循环 2.4~2.6s)+ opacity `<animate>`,由 `startSMIL` 错峰 `beginElement()` 驱动,形成沿线跑动的发光点。修法:删除两处 spark circle 的创建与其 `animateMotion`/opacity 动画,并移除随之作废的 `startSMIL` 函数(r3 为 spark 加的「先 motion 后 opacity、显式 cx/cy 防原点杂散点」逻辑一并撤销,因为已无 spark);**连线本身(`.ln.ln-live` path、渐变、`ln-live` 流动虚线)、CORE orb、5 步 flow 脉冲、回环等全部保留不动**;`draw()` 开头的 rect 健全校验保留(仍在防连线端点在全屏 resize 过渡期坍缩到原点)。已用无头 Chromium 实测:切到 e2 后 0/300/800/1500/2600/4000/5200ms 全时点 spark circle 数=0、animateMotion 数=0、可见 spark=0,而连线 `#lineHost path` 恒为 10 条(未受影响);截图确认连线完好、无任何跑动点;`lint_slides` ERROR=0、`verify_single_mode` R1/R2/R3 全 PASS。

v0.2.11-r5(用户实测「投影模式非真全屏」修复)修 1 项放映体验缺陷,**只动 shell 的投影(projector)分支,不改版式/文案/观赏态视觉/任何模块**:
- **【体验】`present=projector` 进全屏后画面仍是黑底居中的小方块,没有真正铺满屏幕**。表现:投影模式只给 `body` 加 `deck-projecting` 类 + 首次点击 `requestFullscreen()`,而舞台 `.deck-stage` 尺寸硬编码为 `DISPLAY_W=1000 × 562.5`(16:9),全屏后页面全屏了、舞台还是 1000px,于是幻灯片缩成黑页正中的一个小盒子。修法:新增 `fitProjector()`,按 `k=min(vw/舞台宽, vh/舞台高)` 对 `.deck-stage` 施加 `transform:scale(k)`,`transform-origin:center center` + `body.deck-projecting` 用 flex 居中 + 黑底,实现「等比放大、按短边贴边、另一轴黑边留白(letterbox)」的真全屏;并把 `fitProjector()` 接到投影入口(初始化 / 点击进全屏 / `launchProjector`)、`resize`、`fullscreenchange`(退出全屏时 `fitProjector(true)` 清 transform + 移除 deck-projecting)、`speakerInPlace(false)` 复位分支。因 `transform:scale` 统一缩放整棵舞台子树,e2 连线 SVG 的坐标与 viewBox 都源自 `getBoundingClientRect` 相对量、随同一 k 等比缩放相互抵消,故连线无需重绘、保持完好。**关键实现说明:shell 代码在本 skill 里有两份近乎逐字的副本——`assets/compose_deck.py` 与 `scripts/render_page.py`,而 `render_page.py compose` 子命令实际用的是 `render_page.py` 自己的内联副本;本次同一处改动已同时落到两个文件,任何 shell/presenter/CSS/JS 改动都必须两处同改。** 已用无头 Chromium 在投影模式端到端实测:1920×1080 两轴铺满(scale≈1.918)、1600×1200 铺满宽度+上下黑边(scale=1.6)、1366×768 两轴铺满(scale≈1.364),三档 aspect 恒为 1.7778,连线 badLn=0/nan=0(缩放下端点完好),截图显示 e2 满屏、letterbox 正确;`lint_slides` ERROR=0、`verify_single_mode` R1/R2/R3 全 PASS。

v0.2.11-r4(用户实测 e2「元素靠动画才可见」硬伤修复)修 1 项 e2 观赏态结构性缺陷,**只把 e2 各元素的初始可见态从「靠入场动画点亮」改为「默认可见、动画只做位移」,不改版式/文案/其他模块**:
- **【严重】e2 元素初始 `opacity:0`,可见性完全依赖长延迟入场动画 → 翻页/后台节流时永久不可见**。表现:e2 架构闭环页的说明句(`.intro`)、5 张能力卡(`.cap`)、CORE orb(`.orb`)、5 个步骤胶囊(`.step`)、4 个箭头(`.arrow`)、回环虚线(`.loopback`)、回环文字(`.loopcap`)、连线(`.ln`)基态全是 `opacity:0`,靠 `stepIn/orbIn/capIn/e2FadeUp/arrowIn/lnFade` 等入场动画在错峰 delay(最长 3.5s)后才把 opacity 拉到 1。三层冲突:(1)页面切到 e2 后要等近 4s 元素才全部出现;(2)deck shell 的 `REPLAY_ANIM_JS` 每次 `deck:nav` 都清空动画 → 重置 `opacity` → 强制重排 → 恢复动画,delay 重新计时,翻页后步骤等要再等 2~3s;(3)浏览器在后台/快速翻页时会暂停动画,动画可能永远跑不完,元素就永久停在 `opacity:0` 不可见。唯一兜底 `animation-duration:.001s; animation-delay:0s;` 被关在 `@media(prefers-reduced-motion:reduce)` 里,正常浏览不触发。修法:把上述所有元素的基态 `opacity` 一律改成 `1`(内容默认可见);入场 keyframes 只保留 `transform` 位移/缩放分量(它们本就只写 `to{opacity:1;transform:…}`,基态改 1 后 opacity 全程恒为 1、只有 transform 在动),动画不再决定可见性;spark 粒子保持 `opacity:0`(r3 杜绝原点杂散点的约束不变,可见性由 SMIL 运动驱动)。已端到端实测:切到 e2 的 t≈0 / delay 中段 / delay 末段,以及「动画全局 paused + 再翻页」(复现后台节流场景)四种时点,`.intro/.cap×5/.orb/.step×5/.arrow×4/.loopback/.loopcap/.ln` 计算 opacity 全部 ≥0.85(无一低于阈值);截图显示全元素齐全;`lint_slides` ERROR=0、`verify_single_mode` R1/R2/R3 全 PASS。

v0.2.11-r3(用户实测两处 e2 视觉硬伤修复)修 2 项用户逐条确认的 e2 观赏态缺陷,**只动 e2 引擎脚本与 `.pulsing` 规则,不改版式/文案/其他模块**:
- **【严重】e2 底部 5 步流转脉冲一起就永久消失**。表现:用户实测 e2 架构闭环页「下面应该出现的模块(数据采集/智能校验/深度分析/报告触达/持续改进 5 个胶囊步骤)没正常出现」——连线与箭头都画了,但 5 个步骤胶囊是空的。根因:`.m-e2 .flow .step.pulsing { animation:stepPing 1.2s !important }` 用的是 `animation` **简写**,会把步骤原本的 `stepIn …forwards`(负责把 `opacity` 0→1 并保持)整条覆盖掉;而 `stepPing` 只动 `box-shadow`、不含 opacity,于是 `startPulse` 在 3.2s 触发脉冲后,5 个步骤瞬间回落到基态 `opacity:0` 永久消失。修法:在 `.pulsing` 规则里补 `opacity:1; transform:none;`(普通属性,特异性高于基态、不受 stepPing 动画影响),锁住可见态。已端到端实测(重渲染 + 6s 截图,过 3.2s 脉冲启动与多个 4.2s 循环):`step.n1/.n5` opacity 恒为 1,5 个胶囊 + 序号 + 箭头 + 底部闭环虚线全部正常显示。
- **【严重】投影模式下 e2 出现一条从中心射向左上角的杂散动效**。表现:用户实测投影(`present=projector` / `body.deck-projecting`)模式下,e2 页会看到一条从中心(orb)直奔左上角的动效线。定位到两条并存的机理:(1)`#sparkHost` 的 `<circle>` 建时没设 `cx`/`cy`,默认停靠点就是 SVG 原点(0,0=左上角);`startSMIL` 曾把 `animateMotion` 与 opacity `<animate>` 各自独立 `beginElement`,投影进全屏触发 `resize` + `deck:nav` 双重 redraw 时若 mpath 尚未可解析,motion 抛错被吞而 opacity 照常启动 → spark 在仍停于原点时 opacity 拉到 1,在左上角闪出发光点/拖影;(2)`draw()` 无条件按各 cap/orb/step 的 `getBoundingClientRect` 画贝塞尔,全屏过渡期某元素瞬时报退化 rect(w/h≈0),`toLocal` 把端点坍缩到 ~(0,0),从中心 orb 拉出一条直奔左上角的发光连线。修法(3 处):(1)`startSMIL` 改为先启动 motion,motion 起不来就直接 `return`,绝不单独启动 opacity——spark 只在真正沿路径运动时才可见;(2)`draw()` 开头校验 stage/orb/所有 cap/step 的 rect 是否健全,任一退化即 `return false` 中止本次绘制(不清 host、不建 path),`safeDraw` 据返回值决定是否置 `data-e2-drawn`,`tryDraw` 兜底重绘补到 900ms,绝不产出端点落在原点的连线;(3)防御性地给每枚 spark 显式设 `cx`/`cy` 停靠在其路径起点(caps 底缘中点 / orbBot),即便浏览器怪癖闪一下也落在正确位置而非角落。已用无头 Chromium 在投影模式端到端实测:40–3600ms 全程无「可见且近原点」的 spark、无近原点端点的 `.ln` path,最终成片投影模式截图干净;`lint_slides` ERROR=0、`verify_single_mode` R1/R2/R3 全 PASS。

v0.2.11-r2(用户实测两处硬伤修复)修 2 项用户在真实出片中发现的缺陷,**不改观赏态视觉**,只补引擎脚本保全 + 新增两道校验:
- **【严重】e2「上→中 / 中→下」连线在 `--module-json` 覆盖 body 时丢失**。表现:用户实测 e2 架构闭环页的 caps→orb(上→中)、orb→steps(中→下)两组连线永远不画;页面结构还在,连线却没有。根因:`preview-content.py` 里 e2 默认 body = 版式 HTML **+ 末尾内联的 `E2_DRAW_JS`**(运行时用 JS 动态生成 `<path>` 连线),而 `render_page.py cmd_page` 允许 `--module-json` 整块替换 body;一旦用户只给内容 body(不含那段 `<script>`),`E2_DRAW_JS` 被整块冲掉 → 连线引擎丢失。同理 c/d2/f/g 的 `BG_COUNT_JS` 数字动效也会一起被冲掉。修法(2 处):(1)`cmd_page` 在 body 被覆盖后,从**默认 body** 里 `re.findall` 所有 `<script>…</script>` 引擎脚本,凡新 body 未含的自动补回并打印提示,一举保全 e2 连线 + c/d2/f/g 数字动效等所有模块自带脚本;(2)新增两道校验把「结构在、引擎丢」这条静默失败暴露出来 —— `scripts/lint_slides.py` 检出 e2 页(`.m-e2` 或 `id="march"`)即硬拦缺失的连线引擎指纹(`data-e2-drawn` / `id="lineHost"` / `pathA` / `pathB`)判 ERROR;`assets/verify-single-mode.py` 新增 **R6「e2 连线脚本齐备」**同判据,`accept_deck.py` 编排的 `verify_single_mode`(underscore 版)一并生效。已端到端实测:默认渲染不重复注入、自定义 body 自动补回、good deck R6 PASS、broken deck(脚本被剥)lint 3 ERROR + R6 FAIL 退 1。
- **【严重】云文档截图变黄 / 变整页截屏 / 变纯色**。表现:用户实测所有需要从云文档抓的截图出现三种残次:颜色偏黄(非原图)、类似整页截屏下方拖大片白、或纯色占位。定位:`render_page.py` 的 `_img_data_uri` 是纯字节透传(`read_bytes` → base64,不缩放/不转码/不改色),`object-fit:contain` 也不裁切 —— 即**渲染侧字节忠实**,缺陷在**上游抓取**(抓成了整页截屏 / 有损缩略图 / 没抓到真图)。修法:(1)SKILL.md A2.5.1 硬化为「必须按 image_key / media token 下载**原始媒体(原图字节)**,禁止整页截屏 / 有损缩略图 / 占位」;(2)新增 `scripts/verify_screenshots.py`(+ `assets/verify-screenshots.py` 镜像),用 PIL 对出片 deck 内联的 `.shot` data:URI 及 `materials/screenshots/*.png` 静态取证三症状 —— 底部近白带 ≥ 图高 22%(整页残留)/ 非白像素整体偏黄(R−B≥24 且 G−B≥16,有损缩略图)/ 32×32 独立色 ≤4 或标准差 <6(纯色占位),任一命中 FAIL;(3)接入 `accept_deck.py` 第 8 步,并自动探测同目录 `materials/screenshots`。已用合成样张标定阈值实测:正常截图 PASS,整页白带 / 偏黄 / 纯色三种残次分别被对应判据独立 FAIL,logo/头像等非 `.shot` 图不误伤(class 属性内 `\bshot\b` 边界匹配 + 未闭合容器归属判定)。

v0.2.11-r1(review 加固版)修 9 项 review 发现的正确性/健壮性/整洁度问题,**不改任何观赏态视觉与生成逻辑**,只加固闸门一致性与降级路径:
- **【严重】封面与成卷 shell 缺模式标记 → 单模闸门必判 FAIL(双闸门打架根因)**。表现:`render_page.py cmd_cover` 产出的封面根节点是 `<div class="cover-wrap cover-{layout}">`,**不带 `m-*`**;成卷 shell 的 `<html>` 也无 `data-theme`。而 `assets/verify-single-mode.py`(成卷自检调用)的 `PAGE_TAG` 会把 `cover-wrap` 认作一页却取不到模式标记,`global_mode()` 从 `<html>/<body>` 也取不到 → R2「逐页齐一」必判 FAIL;但 `scripts/verify_single_mode.py`(逐步验收调用)靠 `--fs-bg-0` 亮度兜底,对同一份 deck 却 PASS,两套闸门结论相反。修法:(1)`cmd_cover` 封面根节点补挂 `m-{mode}`,与内页 `.m-<mode> page` 对齐;(2)`cmd_compose` 从各页 `body_class` 推断整卷模式,挂到 shell `<html data-theme="{mode}">` 作全局单模声明。已端到端实测:同一份 deck 现在两套单模闸门 + lint 全 PASS(exit=0)。
- **【严重·连带】`verify-single-mode.py` R4 类名边界假阳性**。修封面后暴露:R4「演讲者面板默认隐藏」的类名匹配用 `\bdeck-noteedit\b`,`\b` 在连字符处成立,会误匹配子元素 `deck-noteedit-hd`(它本就无需 `aria-hidden`)→ 假 FAIL。修法:类名边界改用 `(?<![\w-]) … (?![\w-])`,排除连字符,只匹配完整类名。
- **【中等】`build-theme.py hex_to_rgb` 无格式校验**:`--primary`/`--accent` 传非法值(如 `#GG`、`blue`)会抛裸 `ValueError` 栈。修法:校验长度(3/6)与 hex 字符,非法时抛带上下文异常,`main` 捕获成 `ap.error` 友好报错。
- **【中等】`render_page.py build-all --accept` 吞验收失败**:`accept_deck` 非零仅打印告警,`cmd_build_all` 仍退 0,自动化编排误判成功。修法:验收未过以 `accept_deck` 的 returncode 退出。
- **【中等】`render_page.py inject-notes` 页数错配静默截断**:HTML 页数≠备注条数时只 warning 不退非零,多余页备注被 `break` 丢弃。修法:页数错配直接 `exit(1)`,要求 `per_page_notes` 键数与整卷页数严格一致。
- **【中等】`state_manager.py load_state` 浅拷贝**:`dict(INITIAL_STATE)` 嵌套 dict 与常量共享引用,有污染隐患。修法:改 `copy.deepcopy(INITIAL_STATE)`,已实测隔离生效。
- **【中等】暗色封面飞书 logo 默认路径与帮助文字不符**:`--feishu-logo` 帮助写「默认 feishu-logo.svg」,实际默认是 `feishu-logo.png`,且深色模式自动切 `feishu-logo-dark.png` 白字版。修法:帮助文字更正为 `.png` 并说明深色自动切换。
- **【轻微】删除两个零引用死代码**:`assets/img_probe.py`(声称有 verify_img.py 薄壳调用它,实则薄壳不存在)、`assets/verify-text-position.py`(依赖 playwright,与 stdlib 闸门定位冲突,SKILL.md/compose_deck 均未引用)。已 grep 确认全仓零外部引用后删除。
- **【已知遗留·文档化】`assets/compose_deck.py` 在本 v0.2 扁平目录下无法导入**:其 `REPO = HERE/../../..` + `subskills/page-*/assets/` 路径假设的是 v9.8.9 嵌套目录,在 `doubao-v02/assets/` 扁平结构下 `ASSETS` 解析到不存在的路径。**但它未接入 v0.2 运行时**——实际成卷走 `render_page.py cmd_compose`(自带闸门,已实测通过),`compose_deck.py` 仅在注释中被提及,属 v9.8.9 残留。本次不强行复活(其 `TEAM_ASSETS` 等子技能路径在本包同样缺失,复活需搬迁整套 subskills,风险高于收益),仅记录待 v0.3 决定是删除还是重接。
- 说明:本包磁盘态基线为 v0.2.11;如需与线上 v0.2.12–v0.2.14(e2 连线/replay/SEL 反复回滚)对齐,请以线上注册包为准合并——本包不含 `__e2Redraw` 等 v0.2.13/14 符号。

v0.2.11 修 1 项版式对齐缺失:**痛点/方案细节页面支持每页 1–4 张图,而不是硬锁 1 张**。表现:用户 Turn 8 指出「还有一个不是一页都是只有一张图片,特别在痛点、方案细节模块,这个也请和 v9.8.9 逻辑对齐」。根因:v9.8.9 的 `.m-f .shots.s{k}` 已经落地 1–4 图自适应网格(s1 铺满 / s2 上下 / s3 两上一下铺底 / s4 2×2),但 doubao-v02 起先只搬过 `.m-f .shots.s{k}` 的 CSS,`.m-d` 的右列仍是老式的 `.shotwrap>.shot` 单容器,取材器即便有多张也只能塞第一张;编辑模式的 IMG_SEL 也只识别 `.m-d .shot` 单实例,没有走 `.shots` 网格路径,上传按钮永远只有一个。修法(4 处):(1)`preview-content.py` MODULES["d"].body 把右列 `<div class="shotwrap"><div class="shot">...</div></div>` 改造成 `<div class="shots s1"><div class="shot">...</div></div>`,注释同步为「张数 1–4 自适应,取材器按 `k=min(len(shots),4)` 写 `.s{k}`」;(2)`preview-content.py` CSS 新增 `.m-d .shots / .m-d .shots.s2 / .s3 / .s4 / .s3 .shot:nth-child(3){grid-column:1/-1}` 网格族,完整镜像 `.m-f .shots.s{k}`,`.m-d .shot img` 与 `.ph` 规则同步保形 object-fit:contain + 圆角 + 轻投影,`.m-d .shots.s1 .shot .ph` 用 `92% × 16:9` 保留原单图占位形状;(3)`compose_deck.py` EDIT_JS 的 IMG_SEL 从 `.m-d .shot` 精化为 `.m-d .shots .shot`,与 `.m-f .shots .shot` 对齐——现在编辑模式下模块 d 也是每张截图独立打 `data-edimg` 编号,配合 v0.2.7 就绪的 `data-edmulti + .deck-multi + .deck-thumbdel` 单张增删机制,一位多图完全生效;(4)`_module_d_gates` 的 verify_shot 注释同步为 `.m-d .shots .shot`,取材器与成卷阶段的选择器一致,一次覆盖 deck 内所有模块 d 页的所有 shot 位。回归保护:场景 2 版式 `.m-d2`(无截图)不改;`.m-f .shots.s{k}` 已存在的规则不动;`.m-d .pcol` 左列所有几何、bignum、lead、kpts、动效均保持 v0.2.8 基线。

v0.2.10 修 1 项动效重大缺失:**数字/卡片动效在三模式下缺失与回页重放**。表现:用户 Turn 7 指出「数字动效和卡片动效还是没有(数字从 0 到目标值、卡片入场动效),默认/演讲者/投屏三模式都应该有,且每次回到页面都应该存在」。根因:v0.2.6 加的 `REPLAY_ANIM_JS` 只落到了 `render_page.py`(单页路径),而实际成卷用的 `compose_deck.py` shell 拼装完全没引用 `PC.REPLAY_ANIM_JS`,导致 `window.__replayAnim` 从未定义;DECK_JS 里那份内联 `replay(frame)` 用 `getComputedStyle.animationName!=='none'` 过滤,会漏掉 `animation-fill-mode:forwards` 已落位的元素,并且完全不处理演讲者面板下 `.deck-pv-scale` 里的克隆帧;`deck:ready` 在 DECK_JS IIFE 内同步派发,早于后续脚本 addEventListener,首次进入永远错过。修法(4 处):(1)`compose_deck.py` L367 shell 拼装 `f'{stage}\n{nav}\n...{DECK_JS}\n{PC.BG_COUNT_JS}\n{PC.REPLAY_ANIM_JS}\n{EDIT_JS}\n{PRESENTER_JS}\n'` — 在 DECK_JS 之后显式注入 BG_COUNT_JS + REPLAY_ANIM_JS,保证 `window.__mcCount / __mcCountReset / __replayAnim` 三个入口都存在;(2)DECK_JS 内 `replay(frame)` 改为薄壳委派 `if(window.__replayAnim) window.__replayAnim()`,彻底放弃 `getComputedStyle.animationName` 那套脆弱过滤;(3)DECK_JS 末尾 `deck:ready` 派发用 `setTimeout(…,0)` 延后一拍,让 REPLAY_ANIM_JS 有机会先挂上监听;(4)PRESENTER_JS `paint()` 里 `fillStage(curStage,i); fillStage(nextStage,i+1);` 之后 `setTimeout(…,60)` 里调用 `__replayAnim`,让演讲者面板+投屏面板的克隆帧也重跑数字 count-up 与卡片入场。回归保护:v0.2.9 的 e2 动态化(SMIL beginElement + ln-live + pulseSteps)不动;prefers-reduced-motion 兜底通过 REPLAY_ANIM_JS 自身实现继续生效。

v0.2.9 遗产:**架构流程页(m-e2)动态化对齐 v9.8.9 canonical**。表现:v0.2.8 上线后,e2 页看着"接近静态"——5 张能力卡入场后就不动了,cap→orb / orb→step 两组连线也只是淡入一次,火花几乎看不到,与 v9.8.9 演示时"管道流水般的动态感"差距明显。根因三处叠加:(1)SMIL `animateMotion` 的 `begin` 用绝对秒(1.9+i*0.15s / 2.6+i*0.12s),页面存活 >2.6s 后从别的 slide 切到 e2、`draw()` 重建 spark 节点,新元素的 `begin` 已成"过去时",浏览器不会补触发;(2)连线本身只有一次 `lnFade` 淡入动画,没有沿路径的电流感;(3)5 步 pill 的 `stepPing` 是一次性 `animation` 声明,做完 2.45s→3.25s 一轮就永久停下。修法:(1)`E2_DRAW_JS` 中每根火花的 `animateMotion` / `animate` 都改成 `begin='indefinite'` + 每次 append 后 `setTimeout(beginElement, staggered_delay)`,消除绝对时间窗口依赖,并 `+ rotate='auto'` 让火花沿路径切向对齐;(2)`.m-e2 .connector .ln.ln-live` 新增 `stroke-dasharray:6 6 + animation:lnFlow 1.8s linear infinite`,`lnFlow` 关键帧只做 `stroke-dashoffset:0→-48`,配合 lnFade 双 animation-delay 逐条错峰启动;(3)`E2_DRAW_JS` 新增 `pulseSteps()` 定时器,每 4.2s 遍历 `.m-e2 .flow .step`,先 remove 再 force reflow 再 add `.pulsing` 类,`.pulsing` CSS 声明为 `stepPing 1.2s ease-out !important`,让 5 步始终"呼吸"。触发时机与 v0.2.6 REPLAY_ANIM_JS 对齐:load / resize / 2150ms / `deck:ready` / `deck:nav` / IntersectionObserver 命中时都会 `tryDraw + startPulse`。

v0.2.8 修 1 项回归:**故事页(m-a .quote .lead)与背景页(m-c .lead p)左侧长文字号自适应**。表现:v0.2.7 上线后,这两页左文常锁在下限(m-a=22、m-c=17)显得极小。根因:`LEAD_FIT_JS` 仅在 `DOMContentLoaded` 单次触发,而 `.deck-track` 胶片带下,off-screen `.deck-frame` 首帧 layout/字体未就绪,`box.scrollHeight` 测量偏大 → 命中收缩循环 → 停在下限;并且下一次进入该 slide 时,行内 `font-size` 残留,再跑不会往上回涨。修法:(1)`fit` 每次先 `el.style.fontSize=''` 清空行内值,让 CSS 基线重新生效,再从 `base` 开始探测;(2)重跑事件挂载 = `deck:nav` / `deck:ready`(与 REPLAY_ANIM_JS 同源) + `resize` + `document.fonts.ready` + `DOMContentLoaded` 后 rAF+`120/400/900ms` 多档 setTimeout;(3)最小下限稍抬(m-a 22→26、m-c 17→19)确保测量异常时仍有可读兜底。观赏态基线与 v0.2.7 一致(m-a base=34 [26,48]、m-c base=22 [19,28])。

v0.2.7 起(对齐 v9.8.9 编辑契约,4 项修复):**(1)封面标题编辑态显字**——`.cover h2` 用 `-webkit-text-fill-color:transparent + background-clip:text` 渐变裁字,叠加 `contenteditable` 时文字整块消失,现在 `body.deck-editing .cover h2` 强制 `-webkit-text-fill-color / color / background / -webkit-background-clip` 回退实心色(仅编辑态生效,不影响观赏态高级质感);**(2)全模块图片上传/编辑/清空**——`_EDIT_JS.IMG_SEL='.m-a .sketch .frame,.m-d .shot,.m-d2 .shot,.m-e .shot,.m-f .shots .shot'`,给每个图片位打 `data-edimg`,编辑态注入 `.deck-imgbar` 上传/删除控件,配合 `IMGS{}` 状态 + localStorage `st.imgs` 持久化 + 导出烘焙一致;**(3)一位多图**——`MULTI_SEL='.m-d,.m-d2,.m-f'`,痛点/细节位打 `data-edmulti='1'`,按钮变「+ 加图 / ✕ 清空」,渲染 `.deck-multi > .deck-thumb` 网格,每张图右上角配 `.deck-thumbdel` 单独删除;**(4)模块 g 前缀轮换**——`cmd_close` 前缀取值链路:`item.get("prefix")` 显式字段 → label 关键词扫描(含「提升/降低/达到/缩短/扩大/保持/覆盖/节省」)→ `("提升","达到","降低","保持")[idx%4]` 轮换,彻底根治全部默认「提升」问题。v0.2.6 起:模块 a 故事引语 / 模块 c 背景段落**按容器高度自适应字号**(短文字放大到贴合容器、长段落缩到不溢出,视觉规范同 .m-d .pcol .lead);e2 架构闭环 SVG 连线**新增 deck:nav / deck:ready / IntersectionObserver 触发重绘**,修复胶片带 slide 初次不可见时 stage.getBoundingClientRect 为 0 导致连线不出的问题;数字 count-up 与卡片入场动效**在编辑 / 演讲者 / 投屏三模式下,每次切页都会重置并重放**,不再一次性消费(REPLAY_ANIM_JS 挂载在 deck:nav / deck:ready + speaker 面板 MutationObserver 上)。v0.2.5 起:模块 a/d/e/f 的图像位改红色硬警告(缺料肉眼不可能漏),Autopilot 强制走 A2.5 云文档截图批量下载 + material JSON 构建;团队页部门列表由 plan.team.departments 驱动、空则不渲染避免空右框;c 数字字号 52→68、d2 纯文字卡收敛为 .card.txt.key 短词焦点;所有卡片模块统一 mcCardIn 错峰入场 + BG_COUNT_JS 数字 count-up。v0.2.4 起严格对齐 v9.8.9 module-catalog:cover / c / d / e / e2 / f / g **必选骨架**,a / b **可选**(仅这两项);e2 即便无描述也由 page-architecture 自行归纳;f 每页标题必须映射自 e 卡片,右图必须来自云文档鉴权下载。下一步优化方向:
- **v0.3**:模块级硬闸门(f 标题-e 卡片映射校验器、d 截图-云文档鉴权来源校验器、e2 5能力+CORE+5flow+回环几何校验器)全部接入 `build-all --accept` 联合验收
- **v0.4**:平台侧 headless 截图 → 主题 PNG 一体化(取代当前的 `theme_preview.html` 单文件方案)
- **v0.5**:多语种备注 + 演讲稿双语对照
- **v0.6**:模块 a(素描风故事页)图片生成走 Seedream + 3 轮真图闸门

每次迭代**只加新章节 + 新脚本 + 已有校验器扩展,不动稳定路径**。
