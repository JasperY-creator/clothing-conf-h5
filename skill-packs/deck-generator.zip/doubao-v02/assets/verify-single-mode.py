#!/usr/bin/env python3
"""
verify-single-mode.py — 单模一致性 3 轮校验器 (stdlib,无第三方依赖)

规则(用户硬约束):用户确认模版风格后,整份 deck 只允许**一套模式**(light XOR dark);
封面之后的每一页内容页,都必须与用户所选的那一套模式**完全一致**,不许浅深混排、
不许出现"确认时选浅色、后面某页却是深色"这种漂移。

本脚本对**出片后的 deck HTML**做静态扫描,跑三轮断言,全过退出码 0,任一轮 FAIL 退 1:

  R1 · 单模唯一   —— 全 deck 解析出的"实际生效模式"集合大小 == 1(不是既有 light 又有 dark)。
  R2 · 逐页齐一   —— 每一页都能判定出一个明确模式,且所有页彼此相同(无缺标、无混排)。
  R3 · 合所选     —— 该唯一模式 == 用户确认锁定的模式(--mode / 或 palette.json 的 default_mode)。

模式标记识别(任一命中即认定该页模式,优先级从高到低):
  1) 祖先或自身 data-theme="light|dark"
  2) 自身或祖先 class 含 m-light / m-dark
  3) 自身或祖先 class 含 theme-light / theme-dark

"页"的识别:class 含 page / slide / cover-  的块级元素各算一页。
若整份文档在 <html>/<body> 上统一挂了 data-theme,视为"全局单一模式声明";但它**不掩盖
逐页冲突**——任一页自身显式挂了与全局不同的模式标记(data-theme / m-* / theme-*),即判为
真实的浅深混排残留,并入 applied 集合触发 R1/R2 FAIL,而不是被全局声明一把抹平。

用法
----
# 从命令行直接给锁定模式
python3 assets/verify-single-mode.py deck.html --mode light

# 或从 palette.json 读锁定模式(default_mode)
python3 assets/verify-single-mode.py deck.html --palette themes/amber/palette.json

注意:本校验只针对**出片后的单模 deck**。preview-content.py 默认出的那张 a-g 浅/深
**双模对照图是"确认物料",不是出片产物**,天然含两套模式,不要拿它跑本校验——
它的用途是让用户二选一;用户选定后,出片一律用 preview-content.py --mode <所选> 出单模。
"""
import argparse
import json
import re
import sys


def read(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        sys.exit(f"[verify-single-mode] 找不到文件:{path}")
    except OSError as e:
        sys.exit(f"[verify-single-mode] 读取文件失败:{path}({e})")


def resolve_locked_mode(args):
    """确定用户锁定的模式:--mode 优先,否则读 palette.json 的 default_mode。"""
    if args.mode:
        return args.mode.strip().lower()
    if args.palette:
        try:
            data = json.loads(read(args.palette))
        except json.JSONDecodeError as e:
            sys.exit(f"[verify-single-mode] palette JSON 解析失败:{args.palette}({e})")
        m = data.get("default_mode")
        if m:
            return str(m).strip().lower()
    return None


# 一个"页"块的起始标签:class 里含 page / slide / cover- 的元素
PAGE_TAG = re.compile(
    r'<(?P<tag>div|section|main|article)\b[^>]*\bclass="(?P<cls>[^"]*\b(?:page|slide|cover-[a-z0-9-]+)\b[^"]*)"[^>]*>',
    re.I,
)
DATA_THEME = re.compile(r'data-theme\s*=\s*"(light|dark)"', re.I)
CLS_MODE = re.compile(r'\b(?:m|theme)-(light|dark)\b', re.I)


def global_mode(html):
    """<html>/<body> 上若挂了统一 data-theme,取之(全局单模声明)。"""
    head = html[:4000]
    m = re.search(r'<html\b[^>]*' + DATA_THEME.pattern, head, re.I)
    if m:
        return m.group(1).lower()
    m = re.search(r'<body\b[^>]*' + DATA_THEME.pattern, head, re.I)
    if m:
        return m.group(1).lower()
    return None


def page_modes(html):
    """
    逐页判定模式。返回 [(page_label, mode_or_None), ...]。
    每个页块的模式 = 该块开标签自身命中的 data-theme / m-* / theme-* ;
    命中不了记 None(缺标)。
    """
    out = []
    for i, m in enumerate(PAGE_TAG.finditer(html), 1):
        opentag = m.group(0)
        cls = m.group("cls")
        label = f"page#{i}({cls.strip().split()[0]})"
        mode = None
        dt = DATA_THEME.search(opentag)
        if dt:
            mode = dt.group(1).lower()
        else:
            cm = CLS_MODE.search(cls)
            if cm:
                mode = cm.group(1).lower()
        out.append((label, mode))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html", help="出片后的 deck HTML 路径")
    ap.add_argument("--mode", choices=["light", "dark"], help="用户锁定的模式(优先)")
    ap.add_argument("--palette", help="从 palette.json 读 default_mode 作为锁定模式")
    ap.add_argument("--allow-dual", action="store_true",
                    help="确认物料(双模对照)专用:跳过 R1 单模唯一断言")
    args = ap.parse_args()

    html = read(args.html)
    locked = resolve_locked_mode(args)

    print("=" * 60)
    print(f"单模一致性校验 · {args.html}")
    print(f"锁定模式(用户所选): {locked or '(未提供,R3 将无法比对)'}")
    print("=" * 60)

    gmode = global_mode(html)
    pages = page_modes(html)

    fails = []

    # 组装"实际生效模式"集合
    if gmode:
        print(f"检测到全局单模声明 <html/body data-theme=\"{gmode}\">")
        # 关键:全局声明**不得掩盖**逐页显式标记的冲突。
        # 若某页自身显式挂了与全局不同的模式标记(data-theme / m-* / theme-*),
        # 那就是真实的浅深混排残留,必须暴露为冲突,而不是被 gmode 一把抹平。
        conflict = [(lbl, md) for lbl, md in pages if md and md != gmode]
        if conflict:
            print(f"⚠ 检出 {len(conflict)} 页的显式标记与全局声明 \"{gmode}\" 冲突:")
            for lbl, md in conflict[:10]:
                print(f"        - {lbl}: 页内显式 {md} ≠ 全局 {gmode}")
        # applied 收纳全局声明 + 任何逐页显式模式,冲突时集合会 >1 → R1 FAIL
        applied = {gmode} | {md for _, md in pages if md}
        # 逐页报告:有显式标记用其真实值(暴露冲突),缺标记的才回落到全局声明
        page_report = [(lbl, (md if md else gmode)) for lbl, md in pages]
    else:
        applied = {md for _, md in pages if md}
        page_report = pages

    # ---------- R1 单模唯一 ----------
    if args.allow_dual:
        print("\n[R1] 单模唯一 …… SKIP(--allow-dual,确认物料为双模对照)")
    else:
        if len(applied) == 1:
            print(f"\n[R1] 单模唯一 …… PASS(全 deck 仅 {next(iter(applied))} 一套)")
        elif len(applied) == 0:
            print("\n[R1] 单模唯一 …… FAIL(未检出任何模式标记,无法判定)")
            fails.append("R1")
        else:
            print(f"\n[R1] 单模唯一 …… FAIL(检出多套模式:{sorted(applied)})")
            fails.append("R1")

    # ---------- R2 逐页齐一 ----------
    total = len(page_report)
    missing = [lbl for lbl, md in page_report if not md]
    seen = {md for _, md in page_report if md}
    if total == 0:
        print("\n[R2] 逐页齐一 …… FAIL(未识别到任何页块)")
        fails.append("R2")
    elif missing:
        print(f"\n[R2] 逐页齐一 …… FAIL({len(missing)} 页缺模式标记):")
        for lbl in missing[:10]:
            print(f"        - {lbl} 无 data-theme / m-* 标记")
        fails.append("R2")
    elif len(seen) != 1:
        print(f"\n[R2] 逐页齐一 …… FAIL(逐页模式不一致:{sorted(seen)}):")
        for lbl, md in page_report:
            print(f"        - {lbl}: {md}")
        fails.append("R2")
    else:
        print(f"\n[R2] 逐页齐一 …… PASS({total} 页全部为 {next(iter(seen))})")

    # ---------- R3 合所选 ----------
    if not locked:
        print("\n[R3] 合所选   …… FAIL(未提供锁定模式,请给 --mode 或 --palette)")
        fails.append("R3")
    elif not applied:
        print("\n[R3] 合所选   …… FAIL(deck 未检出模式,无法与所选比对)")
        fails.append("R3")
    elif applied == {locked}:
        print(f"\n[R3] 合所选   …… PASS(deck 模式 == 所选 {locked})")
    else:
        print(f"\n[R3] 合所选   …… FAIL(deck 为 {sorted(applied)},所选为 {locked})")
        fails.append("R3")

    # ---------- R4 演讲者面板默认隐藏(v9.1 P1 新增)----------
    # 演讲者面板 .deck-presenter / 备注编辑面板 .deck-noteedit 是**编辑/演讲态**开关出来的
    # 空壳,静态展示态**必须默认隐藏**——否则观看者会看到一块空白的 deck-pv-* 面板,污染出片。
    # 断言两条:
    #   ① HTML 里 .deck-presenter / .deck-noteedit 的元素都写了 aria-hidden="true"
    #      (无障碍视图不误读、CSS 也可用 [aria-hidden=true] 选择器锁死默认态);
    #   ② CSS 里 .deck-presenter / .deck-noteedit 有 display:none 作默认(仅 body.deck-speaker
    #      或 body.deck-editing 时才 display:flex/grid 展开)。
    # 有的部署里 deck 是简 preview 页(无 presenter 面板),两条选择器都不出现 → SKIP,不阻断。
    def _has_hidden_attr(cls):
        # v0.2.11-r1:类名边界必须排除连字符,否则 \bdeck-noteedit\b 会误匹配子元素
        #   deck-noteedit-hd(它本就无需 aria-hidden)造成假阳性。用 (?![\w-]) 锁尾。
        pat = re.compile(rf'<div\b[^>]*\bclass="[^"]*(?<![\w-]){cls}(?![\w-])[^"]*"[^>]*>', re.I)
        for m in pat.finditer(html):
            if 'aria-hidden="true"' not in m.group(0):
                return False, m.group(0)[:120]
        return True, None

    r4_targets = []
    for cls in ("deck-presenter", "deck-noteedit"):
        if re.search(rf'\bclass="[^"]*(?<![\w-]){cls}(?![\w-])', html):
            r4_targets.append(cls)

    if not r4_targets:
        print("\n[R4] 演讲者面板默认隐藏 …… SKIP(未检出 .deck-presenter / .deck-noteedit,单页 preview 场景)")
    else:
        r4_fail = []
        for cls in r4_targets:
            ok, snip = _has_hidden_attr(cls)
            if not ok:
                r4_fail.append((cls, f'元素缺 aria-hidden="true":{snip}'))
            # CSS 断言:{cls} { … display:none … }(允许中间任意属性)
            css_pat = re.compile(
                rf'\.{re.escape(cls)}\s*\{{[^{{}}]*display\s*:\s*none[^{{}}]*\}}', re.I)
            if not css_pat.search(html):
                r4_fail.append((cls, "CSS 缺 `.{cls} {{ … display:none … }}` 默认隐藏规则"
                                     .format(cls=cls)))
        if r4_fail:
            print(f"\n[R4] 演讲者面板默认隐藏 …… FAIL:")
            for cls, why in r4_fail:
                print(f"        - .{cls}: {why}")
            print("        修正:静态壳必须 aria-hidden=\"true\";CSS 默认 display:none;"
                  "  仅 body.deck-speaker / body.deck-editing 时才展开为可见。")
            fails.append("R4")
        else:
            print(f"\n[R4] 演讲者面板默认隐藏 …… PASS({'/'.join(r4_targets)} 各含 aria-hidden + display:none 默认)")

    # ---------- R5 初始 body 无演讲者态残留(v9.2 P0 新增)----------
    # 演讲者模式必须由用户交互(S/P/点按钮)运行时切进 body.deck-speaker / deck-projecting,
    # 静态出片 HTML 里 <body> 的 class 不允许提前挂上这两个状态类——否则用户一打开就直接进
    # 演讲者/投屏态,回不到普通观看态。这是修 v9.1「点一次演讲者模式后就再也回不到普通编辑
    # 或翻页态」的根因:旧 launch() 一按就 add class 从不 remove,现在改成两次按键为切换、
    # Esc/fullscreenchange 也会移除;此断言防止「初始态残留」这条回路重新回滚。
    # 判据:提取 <body …> 开标签的 class 属性,不得包含 deck-speaker / deck-projecting。
    body_open = re.search(r'<body\b[^>]*>', html, re.I)
    if not body_open:
        print("\n[R5] 初始 body 无演讲者态残留 …… SKIP(未识别到 <body>)")
    else:
        bt = body_open.group(0)
        bcls_m = re.search(r'\bclass\s*=\s*"([^"]*)"', bt, re.I)
        bcls = bcls_m.group(1) if bcls_m else ""
        # 按空白切 token 精确匹配 —— 避免 \b 把 "deck-speaker-hint" 误伤成 "deck-speaker"
        # (连字符不是 \w,\b 会在 deck-speaker 与 -hint 之间成立)。
        bcls_tokens = set(bcls.split())
        r5_bad = [c for c in ("deck-speaker", "deck-projecting") if c in bcls_tokens]
        if r5_bad:
            print(f"\n[R5] 初始 body 无演讲者态残留 …… FAIL(<body class> 含 {r5_bad})")
            print(f"        <body> = {bt[:200]}")
            print("        修正:body 初始 class 必须为空态;deck-speaker/deck-projecting 只能由 JS 运行时按用户操作切入,退出时自行清除。")
            fails.append("R5")
        else:
            print("\n[R5] 初始 body 无演讲者态残留 …… PASS(<body> 初始为空态,演讲者模式仅运行时切换)")

    # ---------- R6 e2 连线绘制脚本齐备(v0.2.11-r2 P0 新增)----------
    # 现象根因:e2 页(架构闭环)的「上→中(caps→orb)/ 中→下(orb→steps)」连线,是靠
    # 默认 body 末尾内联的 E2_DRAW_JS 在运行时用 JS 动态画 <path> 出来的。render_page.py
    # cmd_page 支持 --module-json 覆盖 body,一旦用户只提供内容 body(不含那段 <script>),
    # 连线脚本就被整块冲掉——页面结构还在,连线却永远不画。此断言把「结构在、引擎丢」这条
    # 静默失败暴露出来:凡检出 e2 页(.m-e2 或 id="march"),必须同时具备连线引擎的三处指纹:
    #   ① data-e2-drawn(draw() 成功后打的标记,唯一属于 E2_DRAW_JS);
    #   ② id="lineHost"(动态 <path> 的挂载点)且 JS 里出现 pathA(caps→orb 上半段生成器);
    #   ③ JS 里出现 pathB(orb→steps 下半段生成器)。
    # 三者缺一即判 e2 连线引擎丢失 → FAIL。无 e2 页 → SKIP,不阻断其它类型 deck。
    has_e2 = bool(re.search(r'\bm-e2\b', html)) or ('id="march"' in html)
    if not has_e2:
        print("\n[R6] e2 连线脚本齐备 …… SKIP(本 deck 无 e2 架构闭环页)")
    else:
        r6_missing = []
        if 'data-e2-drawn' not in html:
            r6_missing.append("data-e2-drawn 标记(E2_DRAW_JS 未内联)")
        if 'id="lineHost"' not in html:
            r6_missing.append('id="lineHost" 连线挂载点')
        if 'pathA' not in html:
            r6_missing.append("pathA 生成器(上→中 caps→orb 连线)")
        if 'pathB' not in html:
            r6_missing.append("pathB 生成器(中→下 orb→steps 连线)")
        if r6_missing:
            print("\n[R6] e2 连线脚本齐备 …… FAIL(e2 页结构在,但连线引擎丢失):")
            for w in r6_missing:
                print(f"        - 缺 {w}")
            print("        根因:多半是 --module-json 覆盖 e2 的 body 时没带上默认 body 末尾的 "
                  "E2_DRAW_JS。修正:render_page.py cmd_page 已会自动补回引擎脚本;若仍缺,"
                  "请确认 preview-content.py 的 MODULES['e2'].body 末尾仍拼接 `+ E2_DRAW_JS`。")
            fails.append("R6")
        else:
            print("\n[R6] e2 连线脚本齐备 …… PASS(data-e2-drawn + lineHost + pathA/pathB 上下两段连线引擎均在)")

    print("-" * 60)
    if fails:
        print(f"单模校验未通过 ✗  失败轮次:{', '.join(fails)} —— 禁止交付,修正后重跑。")
        sys.exit(1)
    print("单模校验通过 ✓  三轮全过:整份 deck 与用户所选模版为同一套模式。")
    sys.exit(0)


if __name__ == "__main__":
    main()
