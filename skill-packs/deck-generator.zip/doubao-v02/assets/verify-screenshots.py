#!/usr/bin/env python3
"""
verify_screenshots.py — 云文档截图「原图字节」校验(v0.2.11-r2 P0 新增)

背景(用户实测的三个症状):从云文档抓取的模块 d / d2 / e / f 截图,出现:
  ① 整页截屏残留:截图不是「元素原图」,而是把整张网页截了下来,下方拖着一大条
     近白空白带(full-page screenshot padding);
  ② 颜色变黄:抓到的是有损缩略图 / 二次编码,整体偏暖(R、G 高、B 低),不是原图;
  ③ 纯色占位:某些 .shot 只是一块近纯色占位图(压根没抓到真图)。

正确做法(用户确认):用 lark-drive / lark-doc 按 image_key / media token 下载**原始媒体
(原图字节)**,存成 materials/screenshots/<mod>_<page>.png,再交给 render_page._img_data_uri
原样透传内联 —— 颜色与清晰度都对。本脚本对**出片后的 deck**(内联 data:URI)和/或
materials/screenshots/*.png 静态取证,命中上述任一症状即 FAIL,阻断交付。

判据(阈值经合成样张标定,保守取值,避免误伤正常截图):
  A · 底部近白带     —— 从底部向上统计「整行近白(亮度≥245)」的连续行数;若 ≥ 图高 22%
                        且顶部/中部不是同样近白(排除整图本就是浅色 UI)→ 判整页截屏残留。
  B · 暖黄色偏       —— 在非近白像素上算均值;若 avg(R)、avg(G) 明显高于 avg(B)
                        (R−B ≥ 24 且 G−B ≥ 16 且 R≈G)→ 判有损缩略图 / 偏黄二次编码。
  C · 近纯色占位     —— 缩略到 32×32 后独立颜色数 ≤ 4,或全图标准差 < 6 → 判纯色占位。

用法
----
# 校验出片 deck 内联的截图
python3 scripts/verify_screenshots.py out/deck.html

# 直接校验落盘的原图目录
python3 scripts/verify_screenshots.py --dir materials/screenshots

# 两者都给(deck 内联 + 落盘原图)一起查
python3 scripts/verify_screenshots.py out/deck.html --dir materials/screenshots

退出码:0=全过(或无截图可查,SKIP);1=任一截图命中症状。
依赖:Pillow(PIL)。若环境无 PIL → 打印 SKIP 并以 0 退出(不阻断,但会明确提示)。
"""

import argparse
import base64
import io
import re
import sys
from pathlib import Path

try:
    from PIL import Image
    _HAS_PIL = True
except Exception:
    _HAS_PIL = False

# 只查「截图类」<img>:模块 d / d2 / e / f 的 .shot。规避 logo / 头像 / 装饰图。
# 抓取策略:先定位 class 含 shot 的 <img ... src="data:image/...;base64,...">。
# 兼容 shot 在 img 自身 class 或其父 <div class="shot"> 里(两种写法都在用)。
_IMG_TAG = re.compile(r'<img\b[^>]*>', re.I)
_DATAURI = re.compile(r'src\s*=\s*["\']data:image/(?P<ext>[a-z0-9.+-]+);base64,(?P<b64>[A-Za-z0-9+/=\s]+)["\']', re.I)
_SHOT_CTX = re.compile(r'\bshot\b', re.I)
# 只在 class 属性里认 shot,避免 alt/src 里恰好含 "shot" 子串造成误吸(v0.2.11-r2)
_SHOT_CLASS = re.compile(r'class\s*=\s*["\'][^"\']*\bshot\b[^"\']*["\']', re.I)


def _in_shot_container(html, img_start, tag):
    """
    该 <img> 是否真属于 .shot:要么 img 自身 class 含 shot,要么它前方最近一个
    **尚未闭合**的容器开标签 class 含 shot。用「最近的 shot 命中之后不得出现 </xxx>
    容器闭合」来避免跨过 </div> 误吸上一个块的 shot(修 v0.2.11-r2 首版假阳性)。
    """
    if _SHOT_CLASS.search(tag):
        return True
    win = html[max(0, img_start - 300):img_start]
    last = None
    for m in _SHOT_CLASS.finditer(win):
        last = m
    if not last:
        return False
    # last shot 命中之后,若出现任一容器闭合标签 → 说明已经跨出该 shot 块
    tail = win[last.end():]
    return not re.search(r'</(?:div|figure|section|a|span)\s*>', tail, re.I)


def _iter_deck_shots(html):
    """
    从 deck HTML 里挑出「截图类」内联 <img> 的 (label, PIL.Image)。
    判据:该 <img> 自身 class 含 shot,或它确实位于一个未闭合的 .shot 容器内。
    """
    out = []
    n = 0
    for m in _IMG_TAG.finditer(html):
        tag = m.group(0)
        if not _in_shot_container(html, m.start(), tag):
            continue
        d = _DATAURI.search(tag)
        if not d:
            # .shot 里有 <img> 却不是 data:URI → 可能是外链/占位,单独提示但不解码
            out.append((f"shot#{n+1}(非内联/无 data:URI)", None))
            n += 1
            continue
        try:
            raw = base64.b64decode(re.sub(r'\s+', '', d.group('b64')))
            img = Image.open(io.BytesIO(raw)).convert("RGB")
        except Exception as e:
            out.append((f"shot#{n+1}(解码失败:{e})", None))
            n += 1
            continue
        n += 1
        out.append((f"shot#{n}({d.group('ext')},{img.width}x{img.height})", img))
    return out


def _iter_dir_shots(dirpath):
    out = []
    d = Path(dirpath)
    if not d.is_dir():
        return out
    for p in sorted(d.glob("*.png")) + sorted(d.glob("*.jpg")) + sorted(d.glob("*.jpeg")):
        try:
            img = Image.open(p).convert("RGB")
            out.append((f"{p.name}({img.width}x{img.height})", img))
        except Exception as e:
            out.append((f"{p.name}(打开失败:{e})", None))
    return out


def _row_brightness(img):
    """返回每一行的平均亮度(0-255)。用缩窄宽度加速。"""
    w, h = img.size
    tw = min(w, 64)
    small = img.resize((tw, h))
    px = small.load()
    rows = []
    for y in range(h):
        s = 0
        for x in range(tw):
            r, g, b = px[x, y]
            s += (r + g + b)
        rows.append(s / (tw * 3))
    return rows


def _bottom_white_band(img):
    """底部连续近白行占比。返回 (band_ratio, top_is_white)。"""
    h = img.height
    if h < 10:
        return 0.0, False
    rows = _row_brightness(img)
    WHITE = 245
    band = 0
    for y in range(h - 1, -1, -1):
        if rows[y] >= WHITE:
            band += 1
        else:
            break
    # 顶部 20% 是否本就近白(整图浅色 UI 的话不该判「整页残留」)
    top_n = max(1, int(h * 0.2))
    top_white = sum(1 for y in range(top_n) if rows[y] >= WHITE) / top_n > 0.8
    return band / h, top_white


def _warm_cast(img):
    """非近白像素上的 (avgR, avgG, avgB)。近白像素(和≥720)排除,免被白底稀释。"""
    small = img.resize((min(img.width, 48), min(img.height, 48)))
    px = small.load()
    sr = sg = sb = cnt = 0
    for y in range(small.height):
        for x in range(small.width):
            r, g, b = px[x, y]
            if r + g + b >= 720:  # 近白,跳过
                continue
            sr += r; sg += g; sb += b; cnt += 1
    if cnt == 0:
        return 0.0, 0.0, 0.0
    return sr / cnt, sg / cnt, sb / cnt


def _near_solid(img):
    """近纯色占位:32×32 独立色数 ≤4 或整体标准差 <6。"""
    small = img.resize((32, 32))
    colors = small.getcolors(32 * 32) or []
    uniq = len(colors)
    px = list(small.getdata())
    n = len(px)
    mr = sum(p[0] for p in px) / n
    mg = sum(p[1] for p in px) / n
    mb = sum(p[2] for p in px) / n
    var = sum((p[0]-mr)**2 + (p[1]-mg)**2 + (p[2]-mb)**2 for p in px) / (n * 3)
    std = var ** 0.5
    return uniq, std


def check_image(label, img):
    """对单张图跑三症状。返回 problems 列表(空=通过)。"""
    problems = []
    if img is None:
        problems.append(f"{label}:无法作为原图内联(非 data:URI / 解码失败)")
        return problems

    # C 近纯色占位(先查,最省)
    uniq, std = _near_solid(img)
    if uniq <= 4 or std < 6:
        problems.append(f"{label}:疑似纯色占位(独立色数={uniq}, 标准差={std:.1f}) —— 未抓到真图")
        return problems  # 纯色图再查白带/色偏没意义

    # A 底部近白带(整页截屏残留)
    band, top_white = _bottom_white_band(img)
    if band >= 0.22 and not top_white:
        problems.append(f"{label}:底部近白带占 {band*100:.0f}%(≥22%) —— 疑似整页截屏残留,"
                        f"应改抓元素原图而非整页")

    # B 暖黄色偏(有损缩略图 / 二次编码)
    r, g, b = _warm_cast(img)
    if r - b >= 24 and g - b >= 16 and abs(r - g) <= 22:
        problems.append(f"{label}:整体偏黄暖调(R={r:.0f} G={g:.0f} B={b:.0f}) —— "
                        f"疑似有损缩略图 / 二次编码,应按 media token 下载原图字节")

    return problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck", nargs="?", help="出片后的 deck HTML(校验内联截图)")
    ap.add_argument("--dir", default="", help="截图原图目录(如 materials/screenshots)")
    args = ap.parse_args()

    if not _HAS_PIL:
        print("[verify-screenshots] SKIP:环境无 Pillow(PIL),无法解码截图做取证。"
              "如需启用,请 pip install pillow。")
        sys.exit(0)

    if not args.deck and not args.dir:
        ap.error("至少给一个:deck HTML 或 --dir 截图目录")

    print("=" * 60)
    print("云文档截图原图校验 · verify-screenshots (v0.2.11-r2)")
    print("=" * 60)

    shots = []
    if args.deck:
        html = Path(args.deck).read_text(encoding="utf-8")
        deck_shots = _iter_deck_shots(html)
        print(f"deck 内联截图:{len(deck_shots)} 张  ← {args.deck}")
        shots += [("[deck] " + lbl, im) for lbl, im in deck_shots]
    if args.dir:
        dir_shots = _iter_dir_shots(args.dir)
        print(f"落盘原图:{len(dir_shots)} 张  ← {args.dir}")
        shots += [("[dir] " + lbl, im) for lbl, im in dir_shots]

    if not shots:
        print("\nSKIP:未发现任何截图(本 deck 无 d/d2/e/f 截图页,或目录为空)。")
        sys.exit(0)

    all_problems = []
    for label, img in shots:
        probs = check_image(label, img)
        if probs:
            all_problems += probs
        else:
            print(f"  ✓ {label}:原图字节正常(非纯色 / 无整页白带 / 无偏黄)")

    print("-" * 60)
    if all_problems:
        print(f"❌ 截图校验未通过({len(all_problems)} 项):")
        for p in all_problems:
            print(f"  - {p}")
        print("\n修正:用 lark-drive / lark-doc 按 image_key / media token 下载**原始媒体**"
              "(原图字节),存成 materials/screenshots/<mod>_<page>.png,交给 _img_data_uri "
              "原样内联;禁止用整页截屏或有损缩略图。")
        sys.exit(1)
    print(f"✅ 截图校验通过:{len(shots)} 张均为原图字节(无整页残留 / 无偏黄 / 非纯色)。")
    sys.exit(0)


if __name__ == "__main__":
    main()
