#!/usr/bin/env python3
"""
compose_deck.py — page-composer:把封面 + a,b,c,d,e,e2,f,g 内容页拼成「一份幻灯片浏览器式 HTML」

用户要的最终交付物 = **一份幻灯片浏览器式的 HTML**(不再是类 PDF 的整卷竖向滚动):
每次只展示一页 16:9,底部有「‹ 左钮 · 页码圆点(当前页高亮成胶囊)· › 右钮 · N/M 计数」
导航条,支持点击 / ← → 键翻页,翻到某页时该页的入场动效 + 数字 count-up **重放可见**。
首页(封面)必须与 Step 0 确认的那张封面样张**严格一致**。

⚠ 「只调展示形式、保证已确认的 skill 生成」的关键设计:
  · 幻灯片用**水平胶片带**(.deck-track 内所有 .deck-frame 横向排布),整条被 .deck-stage
    的 overflow:hidden 裁切、靠 translateX 平移切页。**所有页始终在 DOM、完整渲染、可见**
    ——绝不用 display:none / visibility:hidden / opacity:0 藏页。因为裁切**不影响**
    getBoundingClientRect,verify_img / verify_cards_geom* / verify_content_position* /
    deck-acceptance DOM 探针依旧能量到每页每元素的真实包围盒,三轮一致性校验判定与竖排
    整卷完全等价(逐页出片 + 各闸门判定一字不改)。
  · 导航 chrome 类名统一 deck-*(不含 page/slide/cover- 子串),不被 verify-single-mode
    的 PAGE_TAG 当作"一页"、不干扰单模计数;品牌色只用于当前圆点/箭头 hover 辉光
    (var(--fs-accent)/var(--fs-glow-accent)),不写死品牌 hex。
  · 动效重放**只由用户导航触发**,load 时不额外跑——load 时所有页 count-up 已落位
    (data-counted=1),不导航的校验器量到的仍是落位态,重放不影响任何三轮校验。

严格一致怎么保证(本文件的核心设计):
  · 封面**不另写一份**,而是**复用 preview-theme.py 的完整封面代码路径**——
    同一套 COVER_PRESETS 版式 markup + COVER_CSS + build_cobrand 双标 + fit_title_px
    标题自适应 + BIRD_SVG 飞鸟,同样的 mode class(m-light/m-dark)。
  · 封面按 Step 0 的**原生几何**(cover-wrap 宽 580px,与确认物料里每格封面同宽)渲染,
    再对整页做**等比 transform 缩放**到统一展示宽度——等比缩放保形,观感与 Step 0 逐像素同构。
  · 另有 verify-cover-parity.py:把本 deck 首页封面裁出来、和用 preview-theme 符号
    重建的参考封面在同一几何/DSF 下截图,比对 PNG 的 md5,**逐字节证明一致**。

内容页复用 preview-content.py 的 CONTENT_CSS / page() / MODULES(单一样式源,不重写 CSS)。
整份 <html data-theme="{mode}"> 全局单模声明,过 verify-single-mode 三轮。

编辑层(改造 2):deck 底部导航区带「✎ 编辑模式」开关 + 「⬇ 导出 HTML」按钮(均 deck-*
前缀,不被单模/验收当作一页)。**默认展示态与原先逐字一致**——编辑能力(文字 contenteditable、
图片位上传/删除、痛点位一位多图)只在点开编辑模式后由 JS 注入,退出即移除;任何修改即时
写入 localStorage(key = 标题+页数派生 hash),重开同一浏览器同一文件自动回显;导出按钮把
当前 DOM 烘焙成独立单文件 HTML 下载。纯前端 JS 无法回写服务器原文件,故"保存进 html"由
localStorage 回显 + 导出 HTML 两条腿实现(见 SUBSKILL.md 持久化边界)。EDIT_CSS/EDIT_JS 见下。

星型低耦合:composer 是唯一编排者,只依赖既有 assets/(preview-theme / preview-content /
lint / verify-*),不引入新第三方包。

用法
----
python3 subskills/page-composer/assets/compose_deck.py themes/mint/palette.json \
    --mode light --title "智慧医疗 AI 落地" --author "发起人" --date 2026.07.28 \
    --cover-layout corner --company-logo path/to/logo.png \
    --pages pages.json --out deck.html

pages.json 形如(封面自动为第 1 页,内容页从第 2 页起):
  [ {"module":"c"},
    {"module":"d","material":{"kicker":"痛点 01 · PAIN","title":"排班全靠手工"}},
    {"module":"e"}, {"module":"f"}, {"module":"g"} ]
material 缺省或缺键时,回退 preview-content.py 该模块示例文案。
"""
import argparse
import gc
import importlib.util
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
ASSETS = os.path.join(REPO, "assets")
# 模块 b(page-team)三闸门脚本所在(星型:composer 经 REPO 路径引到 page-team 的既有校验器)
TEAM_ASSETS = os.path.join(REPO, "subskills", "page-team", "assets")
# 模块 c(page-background)校验器所在(星型:同法经 REPO 路径引到 page-background 的既有校验器)
BG_ASSETS = os.path.join(REPO, "subskills", "page-background", "assets")
# 模块 d(page-pain)校验器所在(星型:同法经 REPO 路径引到 page-pain 的既有校验器)
PAIN_ASSETS = os.path.join(REPO, "subskills", "page-pain", "assets")
# 模块 a(page-story)校验器所在(星型:同法经 REPO 路径引到 page-story 的既有校验器)
STORY_ASSETS = os.path.join(REPO, "subskills", "page-story", "assets")
# 模块 e(page-overview · 方案全景)校验器所在(星型:同法经 REPO 路径引到 page-overview 的既有校验器)
OVERVIEW_ASSETS = os.path.join(REPO, "subskills", "page-overview", "assets")
# 模块 e2(page-architecture · 架构详图/闭环)校验器所在(星型:同法经 REPO 路径引到 page-architecture 的既有校验器)
ARCH_ASSETS = os.path.join(REPO, "subskills", "page-architecture", "assets")
# 模块 f(page-detail · 方案细节)校验器所在(星型:同法经 REPO 路径引到 page-detail 的既有校验器)
DETAIL_ASSETS = os.path.join(REPO, "subskills", "page-detail", "assets")
# 模块 g(page-close · 总结升华与行动)校验器所在(星型:同法经 REPO 路径引到 page-close 的既有校验器)
CLOSE_ASSETS = os.path.join(REPO, "subskills", "page-close", "assets")

# 统一展示宽度:每页 transform 缩放到此宽度,所有页同尺寸(1000×562.5)
DISPLAY_W = 1000.0
COVER_NATIVE_W = 580.0     # 与 Step 0 确认物料里每格封面 cover-wrap 同宽(严格一致的关键)
CONTENT_NATIVE_W = 1280.0  # preview-content .page 原生宽
ASPECT = 9 / 16


# ── 低内存自愈:沙盒 512MB 内存上限下,composer 父进程 + 逐页 launch Chromium 的
# ──   子进程叠加,历史上会撞 OOM 被 kill (exit 143)。此模块加两道保护:
# ──   (1) 每次 subprocess 调用前后 gc.collect(),尽量把父进程堆压到最低,让出内存给
# ──       Chromium 子进程;
# ──   (2) 每次 gate 完成后释放 stdout/stderr buffer (r.stdout/r.stderr 大多不用),
# ──       并给 OS 一小段时间回收 Chromium 子进程;
# ──   (3) 主流程开跑前探测 MemAvailable,低于阈值 → 默认自动降级 (--low-memory):
# ──       只跑 lint + single-mode 两枚不 launch Chromium 的轻量校验,重量级 gate
# ──       (._module_*_gates) 集体降级为 WARN,并打印一份 shell 命令清单,让用户
# ──       在**新 shell** 逐个跑 (每条只吃自己那份内存,不与父进程叠加)。
LOW_MEM_THRESHOLD_MB = 700  # MemAvailable 低于此值 → 判为低内存环境


def _mem_available_mb():
    """读 /proc/meminfo 拿 MemAvailable (kB) → 转 MB。读不到返回 None(不判定)。"""
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) // 1024
    except Exception:
        return None
    return None


def _is_low_memory():
    """True if 系统可用内存不足以并发跑 composer + Chromium 子进程。"""
    mb = _mem_available_mb()
    if mb is None:
        return False
    return mb < LOW_MEM_THRESHOLD_MB


def _run_gate(cmd, timeout=180):
    """
    统一封装 subprocess.run:调用前 gc.collect() 压父进程堆,调用后再 gc.collect()
    并主动 discard stdout/stderr 缓冲。返回 (returncode, combined_output_tail)。

    - 只保留最后 800 字符 (足够定位失败,不撑爆回执);
    - 显式设定 timeout,避免个别 gate 卡死拖住整场;
    - 超时视为退 124(bash 惯例),让上层按 FAIL 处理但不炸裂。
    """
    gc.collect()
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        tail = (r.stdout + r.stderr).strip()[-800:]
        rc = r.returncode
    except subprocess.TimeoutExpired as te:
        rc = 124
        tail = f"(timeout after {timeout}s) " + str(te)[:600]
    gc.collect()
    return rc, tail


def _run_gate_list(gates):
    """
    统一跑一组 (label, cmd, hard) gates,返回 (ok, receipt)。
    与旧手写循环等价,但集中释放子进程/父进程堆内存 + 兜住 timeout。
    退 2 = 缺 playwright 优雅降级(hard=True 时不降级、判 FAIL);其余非 0 = FAIL。
    """
    ok = True
    receipt = []
    for label, cmd, hard in gates:
        rc, tail = _run_gate(cmd)
        if rc == 2:
            if hard:
                ok = False
                receipt.append((label, "FAIL(缺 playwright,强制闸门不降级)"))
            else:
                receipt.append((label, "SKIP(缺 playwright,优雅降级)"))
            continue
        passed = rc == 0
        ok = ok and passed
        receipt.append((label, "PASS" if passed else "FAIL"))
        if not passed:
            receipt.append(("  " + label, tail))
    return ok, receipt


def _load(mod_name, filename):
    path = os.path.join(ASSETS, filename)
    spec = importlib.util.spec_from_file_location(mod_name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


PT = _load("preview_theme", "preview-theme.py")     # 封面:严格复用
PC = _load("preview_content", "preview-content.py")  # 内容页:严格复用


def cover_wrap_fragment(data, mode, title, author, date, layout,
                        company_logo, feishu_logo, company_name=None):
    """产出 <div class="m-{mode} cover-wrap cover-{layout}">…</div> —— 与 Step 0 逐字一致。

    完全走 preview-theme.py 的符号:COVER_PRESETS / build_cobrand / feishu_logo_for_mode /
    fit_title_px / BIRD_SVG / brand_kicker。这样封面与确认物料同源,不会漂移。
    """
    markup = PT.COVER_PRESETS.get(layout, PT.COVER_PRESETS["corner"])
    cobrand = PT.build_cobrand(company_logo, PT.feishu_logo_for_mode(feishu_logo, mode))
    kicker = PT.brand_kicker(company_name if company_name is not None
                             else data.get("company_name"))
    fields = {"title": title, "author": author, "date": date,
              "cobrand": cobrand, "bird": PT.BIRD_SVG, "kicker": kicker,
              "title_px": PT.fit_title_px(title)}
    inner = markup.format(**fields)
    return f'<div class="m-{mode} cover-wrap cover-{layout}">{inner}</div>'


def content_page_fragment(mode, module, page_no, total, material=None):
    """产出一页内容页 <div class="m-{mode} page">…</div> —— 复用 preview-content.page()。

    provenance 硬闸(P0):material 必须经 build_material.py 产出并烙 `_provenance`,
    module 字段必须与本页 module 匹配。缺失或不匹配一律 sys.exit=1;仅当环境变量
    DECK_ALLOW_DEBUG=1 时降级 WARN。这条闸门堵住"手写 material JSON 绕过所有闸门"
    这条历史暗路。
    """
    # 内部延迟导入 provenance,避免加载 compose_deck 就必须存在 page-base(测试友好)
    import importlib.util as _iu
    _pv_path = os.path.abspath(os.path.join(HERE, "..", "..", "page-base", "assets",
                                            "provenance.py"))
    if os.path.exists(_pv_path):
        _spec = _iu.spec_from_file_location("provenance", _pv_path)
        _pv = _iu.module_from_spec(_spec)
        _spec.loader.exec_module(_pv)
        # 允许"零素材"页(纯示例)——只在 material 非空时才校验 provenance
        if material:
            _pv.verify(material, expected_module=module,
                       source_path=f"module={module}, page_no={page_no}")

    base = dict(PC.MODULES[module])
    if material:
        # 消费掉 provenance 与其它非文案键,避免混进 MODULES 文案
        payload = {k: v for k, v in material.items()
                   if v is not None and not k.startswith("_")}
        base.update(payload)
    saved = PC.MODULES[module]
    PC.MODULES[module] = base
    try:
        return PC.page("m-" + mode, module, page_no, total)
    finally:
        PC.MODULES[module] = saved


def _frame(page_html, native_w):
    """把一页按原生宽渲染、等比缩放到 DISPLAY_W。等比缩放保形,观感不变。"""
    s = DISPLAY_W / native_w
    nh = native_w * ASPECT
    return (
        f'<div class="deck-frame" style="width:{DISPLAY_W:.2f}px;height:{DISPLAY_W*ASPECT:.2f}px">'
        f'<div class="deck-scale" '
        f'style="width:{native_w:.2f}px;height:{nh:.2f}px;transform:scale({s:.5f})">'
        f'{page_html}</div></div>'
    )


def build_deck(data, mode, title, author, date, layout,
               company_logo, feishu_logo, pages, company_name=None):
    tbm = data["tokens_by_mode"]

    def scope(cls, toks):
        body = "\n".join(f"    {k}: {v};" for k, v in toks.items())
        return f"  .{cls} {{\n{body}\n  }}"

    m_light = scope("m-light", tbm["light"])
    m_dark = scope("m-dark", tbm["dark"])

    total = 1 + len(pages)  # 封面 + 内容页

    # 第 1 页:封面(与 Step 0 严格一致),按 580 原生宽缩放
    frames = [_frame(cover_wrap_fragment(data, mode, title, author, date,
                                         layout, company_logo, feishu_logo,
                                         company_name),
                     COVER_NATIVE_W)]
    # 第 2..N 页:内容页,按 1280 原生宽缩放
    for i, spec in enumerate(pages):
        no = i + 2
        frag = content_page_fragment(mode, spec["module"], no, total,
                                     spec.get("material"))
        frames.append(_frame(frag, CONTENT_NATIVE_W))

    track = "\n".join(frames)
    stage_h = DISPLAY_W * ASPECT
    track_w = DISPLAY_W * total

    # 底部导航:‹ 圆钮 · 页码圆点(当前页高亮成胶囊)· › 圆钮 · N/M 计数
    dots = "".join(
        f'<button class="deck-dot" type="button" aria-label="第 {i + 1} 页"></button>'
        for i in range(total)
    )
    nav = (
        '<nav class="deck-nav" aria-label="幻灯片导航">'
        '<button class="deck-arrow" id="deckPrev" type="button" aria-label="上一页">‹</button>'
        f'<div class="deck-dots">{dots}</div>'
        '<button class="deck-arrow" id="deckNext" type="button" aria-label="下一页">›</button>'
        f'<div class="deck-count" id="deckCount">01 / {total:02d}</div>'
        # 编辑层开关 + 导出按钮(deck-* 前缀,不被 verify-single-mode 的 PAGE_TAG 当作一页)
        '<button class="deck-tool deck-edit" id="deckEdit" type="button" '
        'aria-pressed="false">✎ 编辑模式</button>'
        '<button class="deck-tool deck-export" id="deckExport" type="button">⬇ 导出 HTML</button>'
        # 演讲者模式入口(deck-* 前缀,不被 PAGE_TAG 当作一页):
        # v9.2 默认 = 单窗口就地(S/P 或点按钮);Shift+S/P 才是双窗口投屏;Esc 或再按一次退出。
        '<button class="deck-tool deck-present" id="deckPresent" type="button" '
        'title="演讲者模式:S / P 单窗口就地;Shift+S / Shift+P 双屏投屏;再按或 Esc 退出">🖥 演讲者模式</button>'
        '</nav>'
    )

    # 演讲者面板(默认 display:none;仅演讲者窗口 body.deck-speaker 时显示)。
    # 类名 deck-presenter / deck-pv-* 均不含 page/slide/cover- 子串,不被单模/验收计为一页;
    # 面板内的当前页/下一页克隆由 PRESENTER_JS 只在演讲者角色窗口运行时注入,静态 HTML 为空壳。
    presenter = (
        '<div class="deck-presenter" id="deckPresenter" aria-hidden="true">'
        '<div class="deck-pv-main">'
        '<div class="deck-pv-col deck-pv-left">'
        '<div class="deck-pv-label">当前页 · <b id="pvCount">— / —</b></div>'
        '<div class="deck-pv-stage" id="pvCurStage"></div>'
        '</div>'
        '<div class="deck-pv-col deck-pv-right">'
        '<div class="deck-pv-label">下一页预览</div>'
        '<div class="deck-pv-stage" id="pvNextStage"></div>'
        '<div class="deck-pv-notes-wrap">'
        '<div class="deck-pv-label">本页备注</div>'
        '<div class="deck-pv-notes is-empty" id="pvNotes">（本页无备注）</div>'
        '</div>'
        '</div>'
        '</div>'
        '<div class="deck-pv-bar">'
        '<button class="deck-tool" id="pvPrev" type="button">‹ 上一页</button>'
        '<button class="deck-tool" id="pvNext" type="button">下一页 ›</button>'
        '<button class="deck-tool" id="pvReset" type="button">重置计时</button>'
        '<div class="deck-pv-timer" id="pvTimer">00:00:00</div>'
        '</div>'
        '</div>'
    )

    # 编辑态·当前页备注编辑面板(deck-* 前缀,默认 display:none;仅 body.deck-editing 显示)。
    # 与团队页头像替换 = 同一套编辑机制:静态空壳 + JS 在编辑态绑定当前页 data-notes、
    # 实时写回 + localStorage 存 + 并入现有「⬇ 导出 HTML」(导出的 DOM 已含 data-notes)。
    noteedit = (
        '<div class="deck-noteedit is-collapsed" id="deckNoteEdit" aria-hidden="true">'
        '<div class="deck-noteedit-hd" id="deckNoteHd">'
        '<span>📝 本页备注 · 第 <b id="deckNotePage">01</b> 页</span>'
        '<span class="deck-noteedit-caret">▾</span>'
        '</div>'
        '<div class="deck-noteedit-body">'
        '<div class="deck-noteedit-box" id="deckNoteBox" contenteditable="false" '
        'data-ph="在此输入/修改本页演讲者备注…"></div>'
        '<div class="deck-noteedit-hint">改动实时写回本页 data-notes、存本地并同步演讲者窗口；'
        '随「⬇ 导出 HTML」一并固化。</div>'
        '</div>'
        '</div>'
    )

    stage = (
        f'<div class="deck-stage" style="width:{DISPLAY_W:.0f}px;height:{stage_h:.2f}px">'
        f'<div class="deck-track" id="deckTrack" style="width:{track_w:.0f}px">'
        f'{track}</div></div>'
    )

    return (
        f'<!doctype html><html lang="zh-CN" data-theme="{mode}"><head>'
        '<meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        f'<title>{title} · deck</title>\n<style>\n'
        f'{m_light}\n{m_dark}\n'
        f'{SHELL_CSS}\n'
        f'{EDIT_CSS}\n'
        f'{PRESENTER_CSS}\n'
        f'{PT.COVER_CSS}\n{PC.CONTENT_CSS}\n'
        # body 挂 m-{mode}:让底部导航条能读到该模式的 --fs-accent / --fs-glow-accent
        # 品牌强调色(其余为中性 viewer chrome)。body 是 <body> 标签,不被 verify-single-mode
        # 的 PAGE_TAG(仅 div/section/main/article 且 class 含 page/slide/cover-)识别,
        # 也不被 global_mode(仅读 html/body 的 data-theme)误判 → 单模三轮不受影响。
        f'</style></head>\n<body class="m-{mode}">\n'
        # v0.2.10 修:PC.BG_COUNT_JS + PC.REPLAY_ANIM_JS 必须**在 shell 层显式注入一次**,
        # 而不是仅靠模块 c/d/e/d2/f/g 各自内联的那份——那份只保证首次 DOMContentLoaded 时
        # 落位,不会响应 deck:nav / deck:ready / MutationObserver。REPLAY_ANIM_JS 提供的
        # window.__replayAnim 也只有 shell 注入后才存在,否则 DECK_JS.go() 后既没数字
        # count-up 也没卡片 mcCardIn 重放,演讲者克隆帧更是死态。放在 DECK_JS 之后,以确保
        # window.__deck / deck:ready 事件已就绪,__replayAnim 能立刻拿到当前帧。
        f'{stage}\n{nav}\n{presenter}\n{noteedit}\n{DECK_JS}\n{PC.BG_COUNT_JS}\n{PC.REPLAY_ANIM_JS}\n{EDIT_JS}\n{PRESENTER_JS}\n'
        '</body></html>'
    )


# ── 幻灯片浏览器外壳样式(viewer chrome)────────────────────────────────────────
# 设计约束(为「只调展示形式、保证已确认的 skill 生成」服务):
#   · 幻灯片用**水平胶片带**布局:所有页始终在 DOM 里、完整渲染、可见(不 display:none /
#     visibility:hidden / opacity:0),仅被 .deck-stage 的 overflow:hidden 裁切、靠
#     .deck-track 的 translateX 平移切换。裁切**不影响** getBoundingClientRect —— 所以
#     verify_img / verify_cards_geom* / verify_content_position* / deck-acceptance DOM 探针
#     依旧能量到每一页每个元素的真实包围盒,三轮一致性校验判定不变(与竖排整卷等价)。
#   · 导航 chrome 类名统一用 deck-* 前缀,**不含** page / slide / cover- 子串,不被
#     verify-single-mode 的 PAGE_TAG 当作"一页",不干扰单模计数。
#   · chrome 底色为深色 viewer 背景上的中性白透明,品牌色只用于「当前页圆点 / 箭头 hover
#     辉光」= var(--fs-accent) / var(--fs-glow-accent),与所选主题联动;不写死品牌 hex。
SHELL_CSS = """
  * { box-sizing:border-box; margin:0; padding:0; }
  html,body { width:100%; }
  /* 封面继承 system-ui(与 Step 0 preview-theme 的 body 字体栈一致 → 首页严格一致);
     内容页 .page 自带方正兰亭黑,自行覆盖。 */
  body { background:#0B0D12; min-height:100vh;
         padding:38px 24px 30px;
         font-family:system-ui,"Noto Sans SC","PingFang SC",sans-serif;
         display:flex; flex-direction:column; align-items:center;
         justify-content:center; gap:24px; }
  .deck-stage { position:relative; overflow:hidden; border-radius:20px;
                box-shadow:0 30px 80px -24px rgba(0,0,0,.62),
                           0 0 0 1px rgba(255,255,255,.05); }
  .deck-track { display:flex; gap:0; height:100%;
                transform:translateX(0);
                transition:transform .55s cubic-bezier(.6,.02,.1,1);
                will-change:transform; }
  /* 每页保持原生几何(width/height 由内联 style 给),等比 transform 缩放不变;
     仅去掉逐页圆角/阴影(改由 .deck-stage 承载),避免相邻帧阴影渗入可视区。 */
  .deck-frame { flex:0 0 auto; position:relative; overflow:hidden;
                border-radius:0; box-shadow:none; }
  .deck-scale { transform-origin:top left; }
  .deck-nav { display:flex; align-items:center; gap:18px; padding:6px 12px; }
  .deck-arrow { width:44px; height:44px; border-radius:50%;
                display:flex; align-items:center; justify-content:center;
                font-size:22px; line-height:1; cursor:pointer;
                background:rgba(255,255,255,.06);
                border:1px solid rgba(255,255,255,.14);
                color:rgba(255,255,255,.82);
                transition:border-color .25s, box-shadow .25s, color .25s,
                           background .25s, transform .12s; }
  .deck-arrow:hover:not(:disabled) { border-color:var(--fs-accent);
                box-shadow:var(--fs-glow-accent); color:#fff;
                background:rgba(255,255,255,.10); }
  .deck-arrow:active:not(:disabled) { transform:scale(.9); }
  .deck-arrow:disabled { opacity:.26; cursor:default; }
  .deck-dots { display:flex; align-items:center; gap:9px; }
  .deck-dot { width:9px; height:9px; padding:0; border:none; border-radius:50%;
              cursor:pointer; background:rgba(255,255,255,.22);
              transition:width .32s cubic-bezier(.6,.02,.1,1),
                         background .3s, box-shadow .3s, border-radius .3s; }
  .deck-dot:hover { background:rgba(255,255,255,.42); }
  .deck-dot.is-active { width:26px; border-radius:6px;
              background:var(--fs-accent); box-shadow:var(--fs-glow-accent); }
  .deck-count { font-size:13px; letter-spacing:.16em;
              font-variant-numeric:tabular-nums; min-width:60px; text-align:center;
              color:rgba(255,255,255,.5);
              font-family:system-ui,"Noto Sans SC",sans-serif; }
  @media (prefers-reduced-motion:reduce) {
    .deck-track { transition:none; }
  }
"""

# ── 编辑层样式(deck-* chrome;**仅编辑态可见**,默认展示态零影响)──────────────
# 设计约束(与 SHELL_CSS 同源,为「默认展示态与现在一模一样」服务):
#   · 所有编辑视觉都挂在 body.deck-editing 之下 —— 未进入编辑模式时,DOM 与观感与原先
#     **逐字一致**(编辑控件由 JS 在点「✎ 编辑模式」时才注入,退出即移除)。
#   · 类名统一 deck-* 前缀,**不含** page / slide / cover- 子串,不被 verify-single-mode
#     的 PAGE_TAG 当作"一页",不被 deck-acceptance 计入页数,不干扰单模计数。
#   · 颜色只用中性 viewer 白透明 + 品牌 token(var(--fs-accent)/var(--fs-glow-accent)),
#     **零写死品牌 hex**;字号均 ≥12px(不触 lint F4)。
EDIT_CSS = """
  .deck-tool { height:34px; padding:0 14px; border-radius:17px; font-size:13px; line-height:1;
        cursor:pointer; white-space:nowrap;
        background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.14);
        color:rgba(255,255,255,.82);
        font-family:system-ui,"Noto Sans SC","PingFang SC",sans-serif;
        transition:border-color .25s, box-shadow .25s, color .25s, background .25s; }
  .deck-tool:hover { border-color:var(--fs-accent); box-shadow:var(--fs-glow-accent);
        color:#fff; background:rgba(255,255,255,.10); }
  .deck-edit.is-on { border-color:var(--fs-accent); box-shadow:var(--fs-glow-accent);
        color:#fff; background:rgba(255,255,255,.12); }
  /* 编辑态:可编辑文字描虚线框、聚焦描实线;图片位露上传/删除控件 */
  .deck-editing [data-edt] { outline:1px dashed var(--fs-accent); outline-offset:2px;
        border-radius:3px; cursor:text; }
  .deck-editing [data-edt]:focus { outline:2px solid var(--fs-accent);
        background:rgba(255,255,255,.05); }
  .deck-editing [data-edimg] { position:relative; }
  .deck-imgbar { position:absolute; z-index:30; left:8px; top:8px;
        display:flex; gap:6px; flex-wrap:wrap; }
  .deck-imgbtn { font-size:12px; line-height:1; padding:6px 9px; border-radius:8px;
        cursor:pointer; white-space:nowrap;
        background:rgba(0,0,0,.58); border:1px solid rgba(255,255,255,.34); color:#fff;
        font-family:system-ui,"Noto Sans SC","PingFang SC",sans-serif; }
  .deck-imgbtn:hover { border-color:var(--fs-accent); box-shadow:var(--fs-glow-accent); }
  /* 痛点「一个图片位多张图」:居中网格 + 可横滑/纵滑;每张右上角 ✕ 删除(仅编辑态) */
  .deck-multi { display:flex; flex-wrap:wrap; gap:12px; width:100%; height:100%;
        align-items:center; align-content:center; justify-content:center; overflow:auto; }
  .deck-multi .deck-thumb { position:relative; flex:0 1 auto;
        max-width:47%; max-height:47%; }
  .deck-multi .deck-thumb img { max-width:100%; max-height:100%; width:auto; height:auto;
        object-fit:contain; display:block; border-radius:12px;
        box-shadow:0 14px 32px -18px var(--fs-glow-accent); }
  .deck-thumbdel { position:absolute; top:-8px; right:-8px; width:22px; height:22px;
        border-radius:50%; font-size:12px; line-height:1; cursor:pointer; padding:0;
        display:flex; align-items:center; justify-content:center;
        background:rgba(0,0,0,.7); border:1px solid rgba(255,255,255,.5); color:#fff; }
  .deck-thumbdel:hover { border-color:var(--fs-accent); box-shadow:var(--fs-glow-accent); }
  /* —— 编辑态·当前页备注编辑面板(deck-* 前缀,默认隐藏,不入正文/投屏可见区)—— */
  .deck-noteedit { display:none; }
  body.deck-editing .deck-noteedit {
        display:flex; flex-direction:column; position:fixed; right:20px; bottom:86px;
        width:330px; max-width:calc(100vw - 40px); z-index:60;
        background:rgba(18,20,26,.95); border:1px solid rgba(255,255,255,.16);
        border-radius:12px; box-shadow:0 18px 50px -20px rgba(0,0,0,.72);
        font-family:system-ui,"Noto Sans SC","PingFang SC",sans-serif; }
  .deck-noteedit-hd { display:flex; align-items:center; justify-content:space-between;
        gap:10px; padding:9px 12px; cursor:pointer; font-size:13px; line-height:1.2;
        color:rgba(255,255,255,.82); border-bottom:1px solid rgba(255,255,255,.1);
        user-select:none; }
  .deck-noteedit-hd b { color:var(--fs-accent); font-variant-numeric:tabular-nums; }
  .deck-noteedit-caret { font-size:12px; color:rgba(255,255,255,.5); transition:transform .2s; }
  .deck-noteedit.is-collapsed .deck-noteedit-caret { transform:rotate(-90deg); }
  .deck-noteedit.is-collapsed .deck-noteedit-body { display:none; }
  .deck-noteedit-body { padding:10px 12px 12px; }
  .deck-noteedit-box { min-height:74px; max-height:168px; overflow:auto;
        font-size:13px; line-height:1.6; color:#fff; background:rgba(255,255,255,.05);
        border:1px solid rgba(255,255,255,.14); border-radius:8px; padding:8px 10px;
        outline:none; white-space:pre-wrap; word-break:break-word; }
  .deck-noteedit-box:focus { border-color:var(--fs-accent); box-shadow:var(--fs-glow-accent); }
  .deck-noteedit-box:empty:before { content:attr(data-ph); color:rgba(255,255,255,.4); }
  .deck-noteedit-hint { font-size:12px; color:rgba(255,255,255,.42); margin-top:7px; }
"""

# ── 幻灯片浏览器交互(纯客户端,零依赖)────────────────────────────────────────
# · 左右钮 / 圆点 / ← → PageUp/Down 键切换页;当前页圆点高亮成胶囊。
# · **动效重放**:切到某页时,重置该页 CSS 入场动画(mcCardIn 等)并重跑数字 count-up,
#   让用户"在幻灯片里看到动效"。关键:重放**只由用户导航触发**,绝不在 load 时额外跑——
#   load 时 preview-content 的 BG_COUNT_JS 已让所有页 count-up 落位(data-counted=1),
#   校验器(不导航)在 2800ms 量到的就是落位态,故重放不影响任何三轮校验判定。
# · 尊重 prefers-reduced-motion:reduce → 不重放动画。
DECK_JS = """<script>
(function(){
  var track=document.getElementById('deckTrack');
  if(!track)return;
  var frames=Array.prototype.slice.call(track.children);
  var dots=Array.prototype.slice.call(document.querySelectorAll('.deck-dot'));
  var prev=document.getElementById('deckPrev');
  var next=document.getElementById('deckNext');
  var count=document.getElementById('deckCount');
  var N=frames.length, cur=0;
  var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion:reduce)').matches;
  function pad(n){return (n<10?'0':'')+n;}
  // v0.2.10: 委派给 shell 层注入的 window.__replayAnim(由 PC.REPLAY_ANIM_JS 定义)。
  // 那份实现处理:(1)当前 .deck-frame 主帧,(2)演讲者面板下的 .deck-pv-scale 克隆帧,
  // (3)数字先 __mcCountReset 清除 data-counted 再 __mcCount 重放,(4)卡片 remove+
  // reflow+add animation 三步。旧内联 replay 用 getComputedStyle.animationName!=='none'
  // 会漏掉 animation-fill-mode:forwards 且已落位的元素,也不管克隆帧——彻底废弃。
  function replay(frame){
    if(reduce)return;
    if(window.__replayAnim){try{window.__replayAnim();}catch(e){}return;}
    // 兜底(理论上 shell 已注入 __replayAnim,不会走到这里):
    var vs=frame.querySelectorAll('.num .v[data-to]');
    for(var j=0;j<vs.length;j++){(function(el,idx){
      var to=parseFloat(el.getAttribute('data-to'));if(isNaN(to))return;
      var dur=1100, delay=200+idx*140; el.setAttribute('data-counted','0');
      setTimeout(function(){var s=performance.now();
        function tick(now){var p=Math.min((now-s)/dur,1);
          el.textContent=String(Math.round((1-Math.pow(1-p,3))*to));
          if(p<1){requestAnimationFrame(tick);}
          else{el.textContent=String(to);el.setAttribute('data-counted','1');}}
        requestAnimationFrame(tick);},delay);
    })(vs[j],j);}
  }
  function render(){
    track.style.transform='translateX(-'+frames[cur].offsetLeft+'px)';
    for(var i=0;i<dots.length;i++){dots[i].classList.toggle('is-active',i===cur);}
    if(prev)prev.disabled=(cur===0);
    if(next)next.disabled=(cur===N-1);
    if(count)count.textContent=pad(cur+1)+' / '+pad(N);
  }
  function go(i){if(i<0||i>=N||i===cur)return;cur=i;render();replay(frames[cur]);
    try{document.dispatchEvent(new CustomEvent('deck:nav',{detail:{idx:cur,total:N}}));}catch(e){}}
  if(prev)prev.addEventListener('click',function(){go(cur-1);});
  if(next)next.addEventListener('click',function(){go(cur+1);});
  for(var k=0;k<dots.length;k++){(function(idx){
    dots[idx].addEventListener('click',function(){go(idx);});})(k);}
  document.addEventListener('keydown',function(e){
    // 编辑态下把 ← → 让给 contenteditable 移动光标,不翻页(点击圆点/箭头仍可翻页)。
    if(document.body.classList.contains('deck-editing'))return;
    if(e.key==='ArrowRight'||e.key==='PageDown'){go(cur+1);}
    else if(e.key==='ArrowLeft'||e.key==='PageUp'){go(cur-1);}
  });
  render();
  // 暴露最小导航 API,供演讲者模式(PRESENTER_JS)跨窗口同步复用同一套翻页逻辑;
  // 不改变默认观看态行为(未开启演讲者模式时无人调用)。
  window.__deck={go:go,frames:frames,total:N,cur:function(){return cur;}};
  // v0.2.10:deck:ready 必须 setTimeout(…,0) 延后一拍派发。IIFE 内同步派发时,后续注入
  // 的 REPLAY_ANIM_JS / PRESENTER_JS 尚未 addEventListener,会永久错过初次事件,导致
  // 首页数字动效/卡片入场在默认/演讲者/投屏模式下全部缺失(用户 Turn 7 复现)。
  setTimeout(function(){
    try{document.dispatchEvent(new CustomEvent('deck:ready',{detail:{idx:cur,total:N}}));}catch(e){}
  },0);
})();
</script>"""


# ── 编辑层交互(纯原生 JS,零依赖;单文件内联)──────────────────────────────────
# 目标(改造 2):让最终 deck 支持「用户自行改文字 + 图片上传/删除/多图 + 自动保存,
# 重开回显更新后内容 + 一键导出独立 HTML」,同时**默认展示态与原先逐字一致**。
#
# 关键契约(为「零回归 + 不破坏各闸门」服务):
#   · **载入即静默**:load 时**只做**「打标记(data-edt/data-edimg 属性,无结构/视觉变化)
#     + 从 localStorage 回显」。不进入编辑模式、不注入任何控件、不改任何文字/图片默认值
#     —— 全新生成的 deck 无本地存档 → 回显是 no-op → 校验器(playwright 执行 JS 但从不点
#     「编辑模式」)量到的仍是原始 DOM,verify_shot / verify_content_position* /
#     verify_*_geom / deck-acceptance 判定一字不变。
#   · **编辑态才注入**:点「✎ 编辑模式」才把文字置 contenteditable、给图片位注入上传/删除
#     控件;退出即移除,DOM 复原。
#   · 持久化 = localStorage(key = 标题+页数派生的稳定 hash)回显 + 「⬇ 导出 HTML」烘焙
#     独立单文件两条腿(纯前端 JS 无法回写服务器原文件,见 SUBSKILL.md 持久化边界说明)。
#   · 数字(count-up 巨值/卡片大数字,含 .num 子树)**不纳入** contenteditable,避免与翻页
#     动效重放冲突;痛点巨号 .bignum = 序号,亦为纯文本可编辑但不影响动效。
EDIT_JS = r"""<script>
(function(){
  // 主要内容图片位:故事素描 / 痛点截图 / 方案全景 / 方案细节;
  // 痛点 (.m-d .shots) 与方案细节 (.m-f .shots) 都支持 1–4 图网格(v0.2.11 对齐 v9.8.9)。
  var IMG_SEL='.m-a .sketch .frame,.m-d .shots .shot,.m-e .shot,.m-f .shots .shot';
  var body=document.body;
  var frames=Array.prototype.slice.call(document.querySelectorAll('.deck-frame'));
  if(!frames.length)return;
  var editBtn=document.getElementById('deckEdit');
  var exportBtn=document.getElementById('deckExport');
  var ORIG={};      // eid -> 图片位原始 innerHTML(用于"清空"复原)
  var IMGS={};      // eid -> [dataURI,...] 当前图片列表(仅被编辑过的位才有键)
  var editing=false, saveTimer=null;

  // ---- 稳定 deck id:标题 + 页数派生 hash(同一文件在同一浏览器里 key 恒定)----
  function hash(s){var h=5381,i=s.length;while(i){h=(h*33)^s.charCodeAt(--i);}return (h>>>0).toString(36);}
  var deckId='deckedit:'+hash((document.title||'')+'|'+frames.length);

  // ---- localStorage 读写(全程 try/catch:file:// 安全策略/配额异常都不炸)----
  function load(){try{var r=localStorage.getItem(deckId);return r?JSON.parse(r):null;}catch(e){return null;}}
  function collect(){
    var texts={};
    for(var i=0;i<frames.length;i++){
      var ts=frames[i].querySelectorAll('[data-edt]');
      for(var j=0;j<ts.length;j++){texts[ts[j].getAttribute('data-edt')]=ts[j].innerHTML;}
    }
    // 备注:逐页收集当前 data-notes(有值才记),供 localStorage 持久化 + 重开回显。
    var notes={};
    for(var n=0;n<frames.length;n++){var rt=slideRoot(n);
      if(rt){var nv=rt.getAttribute('data-notes');if(nv!=null&&nv!=='')notes[n]=nv;}}
    return {v:1,texts:texts,imgs:IMGS,notes:notes};
  }
  function save(){try{localStorage.setItem(deckId,JSON.stringify(collect()));}catch(e){
    if(window.console)console.warn('[deck-edit] 保存失败(可能超 localStorage 配额):',e);}}
  function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(save,400);}

  // ── 备注(notes)编辑:与头像/文字 = 同一套编辑机制 ───────────────────────────
  // 备注承载在每页幻灯片根节点(.page / .cover-wrap)的 data-notes 属性上(演讲者模式读它)。
  // 编辑面板绑定「当前页」:进编辑态显示、随翻页切换到对应页的备注;实时写回 data-notes、
  // localStorage 持久化、并经同源 BroadcastChannel('deck-sync') 通知已开的演讲者窗口刷新。
  var noteEdit=document.getElementById('deckNoteEdit');
  var noteHd=document.getElementById('deckNoteHd');
  var noteBox=document.getElementById('deckNoteBox');
  var notePage=document.getElementById('deckNotePage');
  var noteBC=null; try{noteBC=new BroadcastChannel('deck-sync');}catch(e){noteBC=null;}
  function slideRoot(i){return frames[i]?frames[i].querySelector('.page,.cover-wrap'):null;}
  function curIdx(){return (window.__deck&&window.__deck.cur)?window.__deck.cur():0;}
  function pad2(n){return (n<10?'0':'')+n;}
  function noteLoadBox(){
    if(!noteBox)return;
    var i=curIdx(), rt=slideRoot(i);
    noteBox.textContent=rt?(rt.getAttribute('data-notes')||''):'';
    if(notePage)notePage.textContent=pad2(i+1);
  }
  function noteWriteBack(){
    if(!noteBox)return;
    var i=curIdx(), rt=slideRoot(i);if(!rt)return;
    var txt=noteBox.innerText.replace(/\u00a0/g,' ');
    if(txt&&txt.trim()!=='')rt.setAttribute('data-notes',txt);else rt.removeAttribute('data-notes');
    scheduleSave();
    // 跨窗同步:通知演讲者窗口更新该页备注(即时刷新;演讲者窗口未开则下次翻到该页读新值)
    if(noteBC){try{noteBC.postMessage({note:{idx:i,text:txt}});}catch(e){}}
  }
  if(noteBox)noteBox.addEventListener('input',function(){if(editing)noteWriteBack();});
  if(noteHd)noteHd.addEventListener('click',function(){
    if(noteEdit)noteEdit.classList.toggle('is-collapsed');});
  // 翻页时(编辑态)把面板切到新当前页的备注
  document.addEventListener('deck:nav',function(){if(editing)noteLoadBox();});

  function hasDirectText(el){
    var n=el.firstChild;
    while(n){if(n.nodeType===3&&n.nodeValue&&n.nodeValue.trim())return true;n=n.nextSibling;}
    return false;
  }

  // ---- 打标记(属性 only,无结构/视觉变化)----
  frames.forEach(function(frame,fi){
    // 图片位先标(便于文字扫描跳过其子树)
    var slots=frame.querySelectorAll(IMG_SEL);
    for(var k=0;k<slots.length;k++){
      var s=slots[k], eid='i'+fi+'-'+k;
      s.setAttribute('data-edimg',eid);
      if(s.closest('.m-d'))s.setAttribute('data-edmulti','1'); // 痛点位:一位多图
      ORIG[eid]=s.innerHTML;
    }
    // 文字最小可编辑单元:含直接文本节点、且祖先未被标过的"最外层文本块"
    var all=frame.querySelectorAll('*'), c=0;
    for(var a=0;a<all.length;a++){
      var el=all[a], cn=(typeof el.className==='string')?el.className:'';
      if(cn.indexOf('deck-')===0)continue;      // 跳过编辑层自身 chrome
      if(el.closest('[data-edimg]'))continue;    // 跳过图片位子树
      if(el.closest('.num'))continue;            // 跳过 count-up 数字/单位子树
      if(!hasDirectText(el))continue;
      if(el.parentElement&&el.parentElement.closest('[data-edt]'))continue; // 只标最外层
      el.setAttribute('data-edt','t'+fi+'-'+(c++));
    }
  });

  // ---- 图片渲染(只写"图片内容"本身,控件由 addChrome 另注)----
  function imgTag(src){return '<img src="'+src+'" alt="">';}
  function renderSlot(slot){
    var eid=slot.getAttribute('data-edimg'), list=IMGS[eid];
    if(!list)return;                       // 未编辑过 → 保持原始 DOM
    if(!list.length){slot.innerHTML=ORIG[eid];return;} // 清空 → 复原占位/原图
    if(slot.getAttribute('data-edmulti')&&list.length>1){
      var h='<div class="deck-multi">';
      for(var i=0;i<list.length;i++){h+='<span class="deck-thumb">'+imgTag(list[i])+'</span>';}
      slot.innerHTML=h+'</div>';
    }else{slot.innerHTML=imgTag(list[0]);}
  }
  function seed(slot){ // 首次交互时把"已有图片"纳入列表(不丢原截图)
    var eid=slot.getAttribute('data-edimg');
    if(IMGS[eid])return IMGS[eid];
    var imgs=slot.querySelectorAll('img'), l=[];
    for(var i=0;i<imgs.length;i++)l.push(imgs[i].src);
    IMGS[eid]=l;return l;
  }

  // ---- file -> dataURI(多选时全部读完再回调)----
  function pickFiles(multi,cb){
    var inp=document.createElement('input');
    inp.type='file';inp.accept='image/*';if(multi)inp.multiple=true;inp.style.display='none';
    body.appendChild(inp);
    inp.addEventListener('change',function(){
      var fs=inp.files;if(!fs||!fs.length){body.removeChild(inp);return;}
      var arr=[],done=0;
      for(var i=0;i<fs.length;i++){(function(idx){
        var rd=new FileReader();
        rd.onload=function(e){arr[idx]=e.target.result;if(++done===fs.length){cb(arr);body.removeChild(inp);}};
        rd.readAsDataURL(fs[i]);
      })(i);}
    });
    inp.click();
  }

  // ---- 编辑态给图片位注入上传/删除控件 ----
  function hasBar(slot){
    var kids=slot.children;
    for(var i=0;i<kids.length;i++){var c=''+(kids[i].className||'');if(c.indexOf('deck-imgbar')>=0)return true;}
    return false;
  }
  function addThumbDel(slot){
    var eid=slot.getAttribute('data-edimg');
    var thumbs=slot.querySelectorAll('.deck-thumb');
    for(var i=0;i<thumbs.length;i++){(function(th,idx){
      if(th.querySelector('.deck-thumbdel'))return;
      var x=document.createElement('button');x.type='button';x.className='deck-thumbdel';x.textContent='✕';
      x.addEventListener('click',function(ev){ev.stopPropagation();ev.preventDefault();
        var l=IMGS[eid]||seed(slot);l.splice(idx,1);IMGS[eid]=l;
        renderSlot(slot);addChrome(slot);save();});
      th.appendChild(x);
    })(thumbs[i],i);}
  }
  function addChrome(slot){
    if(!editing)return;
    if(hasBar(slot)){addThumbDel(slot);return;}
    var multi=!!slot.getAttribute('data-edmulti'), eid=slot.getAttribute('data-edimg');
    var bar=document.createElement('div');bar.className='deck-imgbar';
    var add=document.createElement('button');add.type='button';add.className='deck-imgbtn';
    add.textContent=multi?'＋ 加图':'⬆ 上传';
    add.addEventListener('click',function(ev){ev.stopPropagation();ev.preventDefault();
      pickFiles(multi,function(uris){
        var l=seed(slot);
        IMGS[eid]=multi?l.concat(uris):[uris[0]];
        renderSlot(slot);addChrome(slot);save();});
    });
    bar.appendChild(add);
    var del=document.createElement('button');del.type='button';del.className='deck-imgbtn';
    del.textContent=multi?'✕ 清空':'✕ 删除';
    del.addEventListener('click',function(ev){ev.stopPropagation();ev.preventDefault();
      IMGS[eid]=[];renderSlot(slot);addChrome(slot);save();});
    bar.appendChild(del);
    slot.appendChild(bar);
    addThumbDel(slot);
  }
  function removeChrome(){
    var junk=document.querySelectorAll('.deck-imgbar,.deck-thumbdel');
    for(var i=0;i<junk.length;i++){if(junk[i].parentNode)junk[i].parentNode.removeChild(junk[i]);}
  }

  // ---- 切换编辑模式 ----
  function setEditing(on){
    editing=on;
    body.classList.toggle('deck-editing',on);
    if(editBtn){editBtn.classList.toggle('is-on',on);
      editBtn.setAttribute('aria-pressed',on?'true':'false');
      editBtn.textContent=on?'✓ 退出编辑':'✎ 编辑模式';}
    var ts=document.querySelectorAll('[data-edt]');
    for(var i=0;i<ts.length;i++){if(on)ts[i].setAttribute('contenteditable','true');else ts[i].removeAttribute('contenteditable');}
    var slots=document.querySelectorAll('[data-edimg]');
    if(on){for(var j=0;j<slots.length;j++)addChrome(slots[j]);}else{removeChrome();}
    // 备注编辑面板:进编辑态 → 绑定当前页备注 + 置 contenteditable;退出 → 关可编辑
    if(noteBox){
      if(on){noteBox.setAttribute('contenteditable','true');noteLoadBox();}
      else{noteBox.removeAttribute('contenteditable');}
    }
  }
  if(editBtn)editBtn.addEventListener('click',function(){setEditing(!editing);});

  // ---- 文字改动 → 自动保存(编辑态才生效)----
  document.addEventListener('input',function(e){
    if(!editing)return;
    if(e.target&&e.target.closest&&e.target.closest('[data-edt]'))scheduleSave();
  });

  // ---- 重开回显:从 localStorage 覆盖默认内容(无存档=no-op)----
  (function(){
    var st=load();if(!st)return;
    if(st.texts){for(var i=0;i<frames.length;i++){var ts=frames[i].querySelectorAll('[data-edt]');
      for(var j=0;j<ts.length;j++){var id=ts[j].getAttribute('data-edt');
        if(Object.prototype.hasOwnProperty.call(st.texts,id))ts[j].innerHTML=st.texts[id];}}}
    if(st.imgs){for(var k in st.imgs){if(!Object.prototype.hasOwnProperty.call(st.imgs,k))continue;
      IMGS[k]=st.imgs[k];var slot=document.querySelector('[data-edimg="'+k+'"]');if(slot)renderSlot(slot);}}
    // 备注回显:把存档里的 data-notes 写回各页根节点(演讲者模式随后读到新值);
    // 空值 → 移除属性,保持默认干净。data-notes 不可见 → 不影响观看态/校验。
    if(st.notes){for(var m=0;m<frames.length;m++){if(!Object.prototype.hasOwnProperty.call(st.notes,m))continue;
      var rt=slideRoot(m);if(!rt)continue;var nv=st.notes[m];
      if(nv&&(''+nv).trim()!=='')rt.setAttribute('data-notes',nv);else rt.removeAttribute('data-notes');}}
  })();

  // ---- 导出:把当前(含所有修改)DOM 烘焙成独立单文件 HTML 下载 ----
  if(exportBtn)exportBtn.addEventListener('click',function(){
    var was=editing;if(was)setEditing(false);          // 先剥离控件/contenteditable 再烘焙
    var clone=document.documentElement.cloneNode(true);
    var eds=clone.querySelectorAll('[contenteditable]');
    for(var i=0;i<eds.length;i++)eds[i].removeAttribute('contenteditable');
    var htmlStr='<!doctype html>\n'+clone.outerHTML;
    var blob=new Blob([htmlStr],{type:'text/html;charset=utf-8'});
    var a=document.createElement('a');a.href=URL.createObjectURL(blob);
    a.download=(document.title||'deck').replace(/[\\/:*?"<>|]+/g,'_').slice(0,80)+'.html';
    body.appendChild(a);a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);if(a.parentNode)body.removeChild(a);},0);
    if(was)setEditing(true);
  });
})();
</script>"""


# ── 演讲者模式(Presenter View)样式 —— 效果对标 PPT 演讲者视图 ──────────────────
# 设计约束(为「非侵入 · 不破坏既有闸门 · 默认展示态零影响」服务):
#   · 全部类名用 deck-pv- / deck-presenter / deck-present 前缀,**均不含** page/slide/cover-
#     子串 —— 不被 verify-single-mode 的 PAGE_TAG 当作"一页",不被 deck-acceptance 计入页数,
#     不干扰单模计数;演讲者面板里运行时克隆出来的 .deck-frame/.page 只在**演讲者角色窗口**
#     (body.deck-speaker)由 JS 注入,静态 HTML 与「无 present 参数的默认加载」里始终为空,
#     故 lint / verify-single-mode / verify-cover-parity / accept_deck(DOM 探针)都探不到。
#   · deck-presenter 默认 display:none;仅在 body.deck-speaker 时显示。
#   · 投屏(观众)窗口进入 body.deck-projecting 时隐藏底部导航,保留纯净单页全屏。
#   · 颜色只用中性 viewer 白透明 + 品牌 token(var(--fs-accent)),零写死品牌 hex;字号 ≥12px。
PRESENTER_CSS = """
  /* 角落入口小按钮(deck-* 前缀,默认观看态可见的中性 chrome;不含 page/slide) */
  .deck-present { }
  /* —— 投屏(观众)窗口:进入演示时隐藏导航,只留干净单页 —— */
  body.deck-projecting .deck-nav { opacity:0; pointer-events:none; }
  body.deck-projecting { cursor:none; }
  /* v0.2.11-r5: 真·全屏——投屏时舞台原生仍是 1000×562.5px,若只 requestFullscreen
     整页,幻灯片会缩在黑底正中的小方块里,并非铺满屏幕。这里把 body 铺满视口纯黑
     letterbox 居中,舞台去圆角/阴影,由 JS(fitProjector)按 min(vw/1000,vh/562.5)
     等比 scale 铺满。transform:scale 均匀缩放整棵舞台子树(含 e2 连线 SVG);连线坐标
     与 viewBox 同取自 getBoundingClientRect,对缩放同比、数学上不变 → 不错位、无需重绘。 */
  body.deck-projecting { padding:0; margin:0; background:#000; gap:0;
        width:100vw; height:100vh; min-height:100vh; overflow:hidden;
        justify-content:center; align-items:center; }
  body.deck-projecting .deck-stage { border-radius:0; box-shadow:none;
        transform-origin:center center; }
  /* —— 演讲者(自己屏幕)窗口:隐藏普通舞台/导航,铺满演示者面板 —— */
  .deck-presenter { display:none; }
  body.deck-speaker { padding:0; background:#0B0D12; display:block; }
  body.deck-speaker .deck-stage,
  body.deck-speaker .deck-nav { display:none !important; }
  body.deck-speaker .deck-presenter {
    display:flex; flex-direction:column; position:fixed; inset:0;
    padding:22px 26px 16px; gap:16px; color:rgba(255,255,255,.9);
    font-family:system-ui,"Noto Sans SC","PingFang SC",sans-serif; z-index:9000; }
  .deck-pv-main { flex:1 1 auto; display:flex; gap:22px; min-height:0; }
  .deck-pv-col { display:flex; flex-direction:column; min-width:0; min-height:0; }
  .deck-pv-col.deck-pv-left { flex:1.55 1 0; }
  .deck-pv-col.deck-pv-right { flex:1 1 0; }
  .deck-pv-label { font-size:13px; letter-spacing:.14em; text-transform:uppercase;
    color:rgba(255,255,255,.5); margin-bottom:8px; }
  .deck-pv-label b { color:var(--fs-accent); font-variant-numeric:tabular-nums; }
  .deck-pv-stage { position:relative; flex:0 0 auto; overflow:hidden; border-radius:14px;
    background:#000; box-shadow:0 20px 60px -24px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.06); }
  .deck-pv-scale { position:absolute; top:0; left:0; transform-origin:top left; }
  .deck-pv-notes-wrap { flex:1 1 auto; display:flex; flex-direction:column;
    margin-top:14px; min-height:0; }
  .deck-pv-notes { flex:1 1 auto; overflow:auto; font-size:17px; line-height:1.7;
    color:rgba(255,255,255,.92); background:rgba(255,255,255,.05);
    border:1px solid rgba(255,255,255,.1); border-radius:12px; padding:14px 16px;
    white-space:pre-wrap; }
  .deck-pv-notes.is-empty { color:rgba(255,255,255,.4); font-style:italic; }
  .deck-pv-bar { flex:0 0 auto; display:flex; align-items:center; gap:16px; }
  .deck-pv-timer { font-size:26px; font-variant-numeric:tabular-nums; letter-spacing:.04em;
    color:#fff; margin-left:auto; }
  .deck-pv-count { font-size:15px; letter-spacing:.14em; font-variant-numeric:tabular-nums;
    color:rgba(255,255,255,.6); min-width:78px; text-align:center; }
"""

# ── 演讲者模式交互(纯客户端,零依赖;v9.2 默认单窗口就地,双窗口为可选)────────────
# 角色区分:同一份 deck HTML,靠 URL(?present=speaker | #present=speaker)判定角色:
#   · 无 present         → 普通观看态(与改造前逐字一致,本脚本仅注册按键/入口,不改布局)。
#   · present=speaker    → 演讲者窗口:渲染演示者面板(当前页克隆 + 下一页预览 + 备注 +
#                          计时器 + 页码 + 上/下页控制);隐藏普通舞台与导航。
#   · present=projector  → 投屏(观众)窗口:进入 body.deck-projecting(隐藏导航、纯净单页),
#                          由发起窗口 requestFullscreen 后 window.open 出演讲者窗口。
# 交互(v9.2):
#   · **默认 S / P / 点按钮 = 单窗口就地**:当前窗口 add body.deck-speaker,原地渲染演讲者
#     面板(无投屏、无 requestFullscreen、无 window.open);再按一次 S/P 或按 Esc → remove
#     class,直接回到普通观看/编辑态。修 v9.1「点一次就再也回不去」的根因。
#   · **Shift+S / Shift+P = 双窗口投屏**:本窗口 add body.deck-projecting + requestFullscreen,
#     另 window.open 出 speaker 窗口。弹窗被拦 → alert 告知 + 回退到单窗口就地模式。
# 翻页同步:同源 BroadcastChannel('deck-sync')双向广播当前页 idx;任一窗口翻页,另一窗口跟随
#   (收到广播时用 __suppress 抑制回环,不再二次广播)。BroadcastChannel 不可用时降级 localStorage。
# 备注来源:读当前页/下一页 .deck-frame 里幻灯片根节点的 data-notes(compose 时由 page() 注入);
#   缺省显示占位「(本页无备注)」。当前页/下一页预览 = 克隆既有 .deck-frame 等比缩放,不重复渲染。
PRESENTER_JS = r"""<script>
(function(){
  var qs=new URLSearchParams(location.search);
  var role=qs.get('present')||(location.hash.match(/present=(\w+)/)||[])[1]||'';
  var CH='deck-sync';
  var bc=null; try{bc=new BroadcastChannel(CH);}catch(e){bc=null;}
  var suppress=false;
  function post(idx){
    if(bc){try{bc.postMessage({idx:idx});}catch(e){}}
    else{try{localStorage.setItem('deck-sync-idx',idx+':'+Date.now());}catch(e){}}
  }
  function onRemote(idx){
    if(!window.__deck)return; if(idx===window.__deck.cur())return;
    suppress=true; window.__deck.go(idx); suppress=false;
  }
  // 收到备注更新(来自编辑窗口):把本窗口对应页的 data-notes 同步为新值,便于下次翻到该页
  // 或当前正显示该页时即时刷新演讲者备注区。
  function onRemoteNote(nd){
    if(!nd||typeof nd.idx!=='number'||!window.__deck)return;
    var f=window.__deck.frames[nd.idx];if(f){var r=f.querySelector('.page,.cover-wrap');
      if(r){if(nd.text&&(''+nd.text).trim()!=='')r.setAttribute('data-notes',nd.text);
        else r.removeAttribute('data-notes');}}
    try{document.dispatchEvent(new CustomEvent('deck:noteupdate',{detail:nd}));}catch(e){}
  }
  if(bc){bc.onmessage=function(ev){if(!ev.data)return;
    if(typeof ev.data.idx==='number')onRemote(ev.data.idx);
    if(ev.data.note)onRemoteNote(ev.data.note);};}
  else{window.addEventListener('storage',function(e){
    if(e.key==='deck-sync-idx'&&e.newValue){onRemote(parseInt(e.newValue,10));}});}
  // 本窗口任一翻页 → 广播(收到远端同步触发的翻页除外,由 suppress 抑制)
  document.addEventListener('deck:nav',function(e){if(!suppress)post(e.detail.idx);});

  function enterFullscreen(){var el=document.documentElement;
    var fn=el.requestFullscreen||el.webkitRequestFullscreen||el.mozRequestFullScreen;
    if(!fn)return;
    // v0.2.11-r7: requestFullscreen 返回 Promise,失败(如文档失焦被中止)时若不接住会抛
    //   unhandledrejection。这里静默接住;真正的「进不去全屏」根因在 launchProjector 的
    //   焦点竞态,已在那里修。
    try{var pr=fn.call(el);if(pr&&pr.catch){pr.catch(function(){});}}catch(e){}}

  // v0.2.11-r5: 把舞台按 16:9 等比铺满视口(letterbox 居中),让投屏成为真·全屏。
  //   舞台原生 1000×562.5px;k=min(vw/1000,vh/562.5) 取能放进视口的最大等比系数,
  //   scale(k) 后短边贴边、长边居中留黑边。transform 只缩放不改布局,e2 连线 SVG 随之
  //   同比缩放且坐标不变(见 CSS 注释),故无需重绘。off=true 时清除 transform 复位。
  function fitProjector(off){
    var st=document.querySelector('.deck-stage');
    if(!st)return;
    if(off){st.style.transform='';return;}
    var vw=window.innerWidth||document.documentElement.clientWidth;
    var vh=window.innerHeight||document.documentElement.clientHeight;
    var bw=st.offsetWidth||1000, bh=st.offsetHeight||(1000*0.5625);
    var k=Math.min(vw/bw, vh/bh);
    if(!isFinite(k)||k<=0)return;
    st.style.transform='scale('+k+')';
  }

  // —— 观众/投屏角色:纯净单页 + 全屏 ——
  if(role==='projector'){
    document.body.classList.add('deck-projecting');
    fitProjector();
    // 点击任意处 → 请求浏览器全屏(用户手势内),进全屏后 fullscreenchange 会再 fit 一次
    document.addEventListener('click',function(){enterFullscreen();fitProjector();},{once:true});
    window.addEventListener('resize',function(){
      if(document.body.classList.contains('deck-projecting'))fitProjector();
    });
  }

  // —— 演讲者角色:构建演示者面板 ——
  function buildSpeaker(){
    document.body.classList.add('deck-speaker');
    var frames=(window.__deck&&window.__deck.frames)||[];
    var total=(window.__deck&&window.__deck.total)||frames.length;
    var pv=document.getElementById('deckPresenter');
    var curStage=document.getElementById('pvCurStage');
    var nextStage=document.getElementById('pvNextStage');
    var notesEl=document.getElementById('pvNotes');
    var countEl=document.getElementById('pvCount');
    var timerEl=document.getElementById('pvTimer');
    function notesOf(i){var f=frames[i];if(!f)return '';
      var n=f.querySelector('[data-notes]');return n?n.getAttribute('data-notes'):'';}
    function fillStage(stage,i){
      stage.innerHTML='';
      if(i<0||i>=frames.length){return;}
      var clone=frames[i].cloneNode(true);
      var wrap=document.createElement('div');wrap.className='deck-pv-scale';
      wrap.appendChild(clone);stage.appendChild(wrap);
      // 等比缩放:deck-frame 原生 1000px 宽,按容器可用宽缩放到位
      var sw=stage.clientWidth||stage.getBoundingClientRect().width;
      var fw=frames[i].getBoundingClientRect().width||1000;
      var k=sw/fw;
      wrap.style.transform='scale('+k+')';
      stage.style.height=(fw*0.5625*k)+'px';
    }
    function paint(){
      var i=window.__deck?window.__deck.cur():0;
      fillStage(curStage,i);
      fillStage(nextStage,i+1);
      var nt=notesOf(i);
      if(nt){notesEl.textContent=nt;notesEl.classList.remove('is-empty');}
      else{notesEl.textContent='（本页无备注）';notesEl.classList.add('is-empty');}
      var pad=function(n){return (n<10?'0':'')+n;};
      countEl.textContent=pad(i+1)+' / '+pad(total);
      // v0.2.10: fillStage 里的 clone 会复制主帧当前 DOM(数字已 data-counted='1'、
      // 卡片 animation 已跑完),.deck-pv-scale 里直接呈现静态终态。必须显式重放,
      // 才能让演讲者面板 / 投屏都看到"每次翻到本页就重跑动效"。REPLAY_ANIM_JS 里的
      // MutationObserver 也会兜底触发一次(childList 变化),这里显式+延时确保时序。
      setTimeout(function(){if(window.__replayAnim){try{window.__replayAnim();}catch(e){}}},60);
    }
    document.addEventListener('deck:nav',paint);
    window.addEventListener('resize',paint);
    // 编辑窗口改了当前页备注 → 即时刷新备注区(onRemoteNote 已更新本窗口 data-notes)
    document.addEventListener('deck:noteupdate',function(e){
      if(e.detail&&e.detail.idx===(window.__deck?window.__deck.cur():0)){
        var nt=notesOf(e.detail.idx);
        if(nt){notesEl.textContent=nt;notesEl.classList.remove('is-empty');}
        else{notesEl.textContent='（本页无备注）';notesEl.classList.add('is-empty');}
      }});
    // 计时器(v9.5 修:赋值给 window.__pvTimer,使 speakerInPlace(false) 能正确 clearInterval;
    //         guard if(el) 防止 timer 与 DOM 生命周期竞争)
    var t0=Date.now();
    function fmt(ms){var s=Math.floor(ms/1000);
      return ('0'+Math.floor(s/3600)).slice(-2)+':'+('0'+Math.floor(s%3600/60)).slice(-2)+':'+('0'+(s%60)).slice(-2);}
    if(window.__pvTimer){clearInterval(window.__pvTimer);}
    window.__pvTimer=setInterval(function(){var el=document.getElementById('pvTimer');if(el)el.textContent=fmt(Date.now()-t0);},250);
    var rst=document.getElementById('pvReset');if(rst)rst.addEventListener('click',function(){t0=Date.now();});
    var pp=document.getElementById('pvPrev'),pn=document.getElementById('pvNext');
    if(pp)pp.addEventListener('click',function(){if(window.__deck)window.__deck.go(window.__deck.cur()-1);});
    if(pn)pn.addEventListener('click',function(){if(window.__deck)window.__deck.go(window.__deck.cur()+1);});
    paint();
    // 演讲者窗口打开后，向观众窗口索要一次当前页(通过广播自身当前页对齐)
    post(window.__deck?window.__deck.cur():0);
  }
  if(role==='speaker'){
    if(window.__deck)buildSpeaker();
    else document.addEventListener('deck:ready',buildSpeaker,{once:true});
  }

  // —— 入口:按键 S / P 或角落按钮 —— v9.2 修:默认「单窗口就地」演讲者模式(不弹窗、不全屏)。
  //   · S / P / 点按钮  → 就地把当前窗口切成 body.deck-speaker 演讲者面板(单屏用户唯一可行姿势)
  //   · Shift+S / Shift+P → 老的双窗口投屏 + 演讲者(要求外接屏 + 允许弹窗)
  //   · Esc 或 再按一次 S/P → 退出演讲者模式,清态回默认观看态
  // 修 v9.1「点一次演讲者后就回不到普通编辑/翻页态」的根因(旧实现只加 class 从不移除,
  //   还偷偷 requestFullscreen,单屏用户不知道怎么退出)。
  function speakerInPlace(on){
    if(on){
      document.body.classList.add('deck-speaker');
      // 直接调用 speaker 面板构建(与 role==='speaker' 分支同一入口)
      if(window.__deck){ buildSpeaker(); }
      else{ document.addEventListener('deck:ready',buildSpeaker,{once:true}); }
    }else{
      document.body.classList.remove('deck-speaker');
      document.body.classList.remove('deck-projecting');
      fitProjector(true);  // v0.2.11-r5: 退出投屏清除舞台 scale,复位默认观看态
      // 清理 speakerInPlace 期间注入的克隆帧,避免 DOM 泄漏(v9.4 P2)
      var stages=['pvCurStage','pvNextStage'];
      for(var i=0;i<stages.length;i++){
        var el=document.getElementById(stages[i]);
        if(el){ while(el.firstChild) el.removeChild(el.firstChild); }
      }
      // 停掉计时器 & 复位备注占位(可选;避免下次开启时看到旧状态)
      try{
        if(window.__pvTimer){ clearInterval(window.__pvTimer); window.__pvTimer=null; }
      }catch(e){}
    }
  }
  function launchProjector(){
    // 双窗口模式:本窗口作投屏,弹出演讲者窗口(旧行为,现在需要 Shift 修饰)
    document.body.classList.add('deck-projecting');
    // v0.2.11-r7: 修 Shift+P「有概率不进全屏」的焦点竞态。旧顺序是先 enterFullscreen()
    //   再 window.open() —— requestFullscreen 是异步 Promise,尚未 settle 时弹出的
    //   speaker 窗口抢走本窗口焦点,浏览器会中止「pending 且已失焦」的全屏请求,于是
    //   时序快则成、慢则败,表现为概率性全屏。修法:①先开 speaker 窗口;②立刻把它 blur、
    //   focus 抢回投屏窗口;③在焦点回到本窗口后(下一帧)再 enterFullscreen(),此时请求
    //   不会因失焦被中止。fitProjector 的 scale 是同步 CSS,不受影响,先做也无碍。
    fitProjector();
    var u=location.href.split('#')[0];
    u+= (u.indexOf('?')>=0?'&':'?')+'present=speaker';
    var w=window.open(u,'deckSpeaker','width=1280,height=800');
    if(!w){
      // 弹窗被拦或不支持 → 明确告诉用户,并回退到就地模式,不留半开状态
      try{alert('演讲者窗口被浏览器弹窗拦截。已回退到「单窗口就地演讲者模式」。\n如需双屏,请允许本站弹出窗口后按 Shift+P 重试。');}catch(e){}
      document.body.classList.remove('deck-projecting');
      fitProjector(true);
      try{document.exitFullscreen&&document.exitFullscreen();}catch(e){}
      speakerInPlace(true);
      return;
    }
    // 把焦点从新弹出的 speaker 窗口抢回投屏(本)窗口,再请求全屏 —— 否则失焦会中止全屏。
    try{w.blur();}catch(e){}
    try{window.focus();}catch(e){}
    requestAnimationFrame(function(){
      try{window.focus();}catch(e){}
      enterFullscreen();
      fitProjector();
    });
    setTimeout(function(){post(window.__deck?window.__deck.cur():0);},400);
  }
  function launch(dualWindow){
    if(role)return; // 已经是某个角色窗口,不再自开
    // 切换语义:再按一次 S/P/点按钮 = 退出演讲者模式,回默认观看态(修「回不去」根因)
    if(document.body.classList.contains('deck-speaker')||
       document.body.classList.contains('deck-projecting')){
      speakerInPlace(false);
      try{document.exitFullscreen&&document.exitFullscreen();}catch(e){}
      return;
    }
    if(dualWindow){ launchProjector(); }
    else         { speakerInPlace(true); }
  }
  // Esc / 退出全屏 → 一键清态,保证「点一次演讲者后仍能回到普通编辑/翻页态」
  document.addEventListener('keydown',function(e){
    if(document.body.classList.contains('deck-editing'))return;
    if(role)return;
    if(e.key==='Escape'){
      if(document.body.classList.contains('deck-speaker')||
         document.body.classList.contains('deck-projecting')){
        speakerInPlace(false);
        try{document.exitFullscreen&&document.exitFullscreen();}catch(e){}
        e.preventDefault();
      }
      return;
    }
    if(e.key==='s'||e.key==='S'||e.key==='p'||e.key==='P'){
      // Shift 修饰 = 走双窗口投屏;否则默认单窗口就地
      launch(!!e.shiftKey);
    }
  });
  // 退出全屏(用户按 F11/浏览器 Esc)→ 同步移除 projecting 态,避免残留隐藏导航
  document.addEventListener('fullscreenchange',function(){
    if(document.fullscreenElement){
      // 进入全屏:视口尺寸已变为整屏,重算舞台等比铺满(v0.2.11-r5)
      if(document.body.classList.contains('deck-projecting'))fitProjector();
    }else{
      document.body.classList.remove('deck-projecting');
      fitProjector(true);
    }
  });
  var btn=document.getElementById('deckPresent');
  if(btn){
    btn.title='演讲者模式(S/P 就地;Shift+S/P 双窗口投屏;再按或 Esc 退出)';
    btn.addEventListener('click',function(ev){
      // v9.4:与 keydown 分支对齐——编辑态点按钮不切演讲者(避免与 contenteditable 打架)
      if(document.body.classList.contains('deck-editing'))return;
      launch(!!ev.shiftKey);
    });
  }
})();
</script>"""


def _module_a_gates(deck_path, mode, palette):
    """成卷路径补跑模块 a(page-story · 故事页)校验:故事素描画位是否为真图,3 轮。

    与 _module_b/c/d 对称——逐页出片时 page-story 的 build_material.py 会跑 sketch_gate +
    verify_img,强约束「模块 a 只要生成就必须有真图,绝不占位交付」;但**成卷**时 compose_deck
    直接拼 HTML、绕过了 build_material,导致合成 deck 从未复核过右侧素描画位——占位框会一路
    绿灯逃逸(这正是本次修复的缺口:b/c/d 都补了、唯独 a 漏了)。此函数把这道图像闸门补回来:

      · verify_img.py:选择器 .m-a .sketch .frame 在合成 deck 里依然存在(transform:scale
        只缩放不删元素),直接对**合成 deck HTML** 探测右侧素描画位,判「真图 / 占位 / 空帧 /
        坏图」三态,一次覆盖 deck 内所有模块 a 页。**占位默认判 FAIL**——这是用户的硬规则:
        只要生成了故事页,就必须有真图,不允许虚线占位框进入交付。

    优雅降级:缺 playwright(退 2)→ 记 SKIP(与逐页 build_material 一致,不判失败);
    其余退非 0(含占位/空帧/坏图)→ 记 FAIL 并计入整体失败。返回 (ok, receipt_lines)。

    注:sketch_gate(内联前源图体检:亮度/主色相/宽高比)依赖原始素描 PNG 文件路径 + 故事
    场景描述,成卷阶段两者都拿不到——故不在成卷阶段跑,由逐页出片把关;成卷阶段以 verify_img
    的「渲染后真图」判定守住「不许占位交付」这条底线。素描朝向/图文相符属语义关(G3),须
    多模态复核,成卷阶段标注人工复核。
    """
    ok = True
    receipt = []
    gates = [
        ("模块 a · 故事素描真图 (R1/R2/R3)",
         [sys.executable, os.path.join(STORY_ASSETS, "verify_img.py"), deck_path], False),
    ]
    sub_ok, sub_receipt = _run_gate_list(gates)
    ok = ok and sub_ok
    receipt.extend(sub_receipt)
    receipt.append(("⚠ WARNING 模块 a · 素描朝向/图文相符(语义 G3)",
                    "本阶段【未校验】——需多模态/人工复核,成卷阶段不硬判。"
                    "⚠ 成卷自检全绿 ≠ 此项已通过,请务必人工复核素描朝向与图文相符性。"))
    return ok, receipt


def _module_b_gates(deck_path, mode, palette):
    """成卷路径补跑模块 b(page-team)三闸门:头像真图 + 花名册几何 + 内容位置,均 3 轮。

    这是成卷路径的关键补全——逐页出片时 build_material.py 会跑这三闸门,但**成卷**时
    compose_deck 直接拼 HTML、绕过了 build_material,导致合成 deck 从未复核过头像/几何/
    位置。此函数把三闸门补回来,让「用户确认后自动成卷」也能完整且准确:

      · verify_img.py / verify_grid_geom.py:选择器 .m-b .roster .ava / .rcard 在合成
        deck 里依然存在(transform:scale 只缩放不删元素),故直接对**合成 deck HTML**
        探测即可,一次覆盖 deck 内所有模块 b 页。
      · verify_content_position.py:校验的是版式模板本身(自行构造 3 轮内容跨度),只需
        palette + mode,与具体成卷素材无关,故独立跑一次。

    优雅降级:图像/几何/尺寸闸门缺 playwright(退 2)→ 记 SKIP(不判失败,与 build_material
    一致);但**内容位置是强制限制条件**,缺 playwright 量不到位置 → 记 FAIL 并计入失败,
    绝不 SKIP 放行。任一闸门退非 0 → 记 FAIL 并计入整体失败。返回 (ok, receipt_lines)。
    """
    ok = True
    receipt = []
    if not palette:
        receipt.append(("模块 b 三闸门", "SKIP(未传 palette,无法跑内容位置校验)"))
        return ok, receipt

    gates = [
        ("模块 b · 头像真图 (R1/R2/R3)",
         [sys.executable, os.path.join(TEAM_ASSETS, "verify_img.py"), deck_path], False),
        ("模块 b · 花名册几何 (R1/R2/R3)",
         [sys.executable, os.path.join(TEAM_ASSETS, "verify_grid_geom.py"), deck_path], False),
        ("模块 b · 内容位置 (R1/R2/R3)【强制闸门】",
         [sys.executable, os.path.join(TEAM_ASSETS, "verify_content_position.py"),
          palette, "--mode", mode], True),
        ("模块 b · 元素尺寸 (R1/R2/R3)",
         [sys.executable, os.path.join(TEAM_ASSETS, "verify_elem_size.py"),
          palette, "--mode", mode], False),
    ]
    sub_ok, sub_receipt = _run_gate_list(gates)
    ok = ok and sub_ok
    receipt.extend(sub_receipt)
    # 团队素材云文档取材关联(verify_text_relevance)依赖具体 --source-doc 云文档原文,
    # 成卷阶段拿不到原文(与 c/d 的关联度校验同一处置),故此处不跑——由逐页出片阶段
    # build_material.py 把关(严禁 agent 编造队名/成员/部门),成卷阶段标注人工复核。
    receipt.append(("⚠ WARNING 模块 b · 团队素材取材关联",
                    "本阶段【未校验】——成卷阶段无 source-doc 原文,该闸门只在逐页出片把关。"
                    "⚠ 成卷自检全绿 ≠ 此项已通过,请务必人工复核队名/队长/队员/部门"
                    "是否确来自用户云文档,而非 agent 编造。"))
    return ok, receipt


def _module_c_gates(deck_path, mode, palette):
    """成卷路径补跑模块 c(page-background)校验:卡片几何+动效 + 内容位置,均 3 轮。

    与 _module_b_gates 对称——逐页出片时 build_material.py 会跑模块 c 的三枚校验,但**成卷**
    时 compose_deck 直接拼 HTML、绕过了 build_material,导致合成 deck 从未复核过 c 页的卡片
    几何/动效/位置。此函数把这两枚补回来,让「用户确认后自动成卷」对 b、c 待遇一致:

      · verify_cards_geom.py:选择器 .m-c .cards .stat 在合成 deck 里依然存在
        (transform:scale 只缩放不删元素),故直接对**合成 deck HTML**探测即可,一次覆盖
        deck 内所有模块 c 页(等高/均匀间距/左对齐/每张有重点/数字 count-up 落位)。
      · verify_content_position.py:校验的是版式模板本身(自行构造 3 轮内容跨度),只需
        palette + mode,与具体成卷素材无关,故独立跑一次。
      · 关联度校验(verify_lead_relevance)依赖具体 --source-doc 云文档原文,成卷阶段拿不到
        原文,故此处不跑——由逐页出片阶段把关,成卷阶段标注人工复核。

    优雅降级:卡片几何缺 playwright(退 2)→ 记 SKIP(不判失败,与 build_material 一致);
    但**内容位置是强制限制条件**,缺 playwright 量不到位置 → 记 FAIL 并计入失败,绝不 SKIP
    放行。任一闸门退非 0 → 记 FAIL 并计入整体失败。返回 (ok, receipt_lines)。
    """
    ok = True
    receipt = []
    if not palette:
        receipt.append(("模块 c 校验", "SKIP(未传 palette,无法跑内容位置校验)"))
        return ok, receipt

    gates = [
        ("模块 c · 卡片几何+动效 (R1/R2/R3)",
         [sys.executable, os.path.join(BG_ASSETS, "verify_cards_geom.py"), deck_path], False),
        ("模块 c · 内容位置 (R1/R2/R3)【强制闸门】",
         [sys.executable, os.path.join(BG_ASSETS, "verify_content_position.py"),
          palette, "--mode", mode], True),
    ]
    sub_ok, sub_receipt = _run_gate_list(gates)
    ok = ok and sub_ok
    receipt.extend(sub_receipt)
    receipt.append(("⚠ WARNING 模块 c · 关联度",
                    "本阶段【未校验】——成卷阶段无 source-doc 原文,该闸门只在逐页出片把关。"
                    "⚠ 成卷自检全绿 ≠ 此项已通过,请务必人工复核数字卡片与云文档原文的关联度。"))
    return ok, receipt


def _module_d_gates(deck_path, mode, palette):
    """成卷路径补跑模块 d(page-pain · 痛点场景1)校验:截图真图 + 内容位置,均 3 轮。

    与 _module_b_gates / _module_c_gates 对称——逐页出片时 build_material.py 会跑模块 d 的
    四枚校验(文字关联 / 截图真图 / 截图-痛点关联 / 内容位置),但**成卷**时 compose_deck 直接
    拼 HTML、绕过了 build_material,导致合成 deck 从未复核过 d 页的截图真图/位置。此函数把
    能在成卷阶段确定判定的两枚补回来,让「用户确认后自动成卷」对 b、c、d 待遇一致:

      · verify_shot.py:选择器 .m-d .shots .shot 在合成 deck 里依然存在(v0.2.11 起,
        痛点右列升级为 .shots.s{k} 1–4 图自适应网格;transform:scale 只缩放不删元素),
        故直接对**合成 deck HTML**探测右截图是否真图即可,一次覆盖 deck 内所有模块 d 页
        的所有 shot 位。
      · verify_content_position.py:校验的是版式模板本身(自行构造 3 轮内容跨度 + 截图长宽比
        变化),只需 palette + mode,与具体成卷素材无关,故独立跑一次。
      · 文字-云文档关联(verify_text_relevance)依赖具体 --source-doc 云文档原文,成卷阶段
        拿不到原文;截图-痛点关联(verify_shot_relevance)依赖原始截图文件路径与多模态复核,
        成卷阶段只有内联 data:URI——故此两枚不在成卷阶段跑,由逐页出片把关,成卷标注人工复核。

    优雅降级:截图真图缺 playwright(退 2)→ 记 SKIP(不判失败,与 build_material 一致);
    但**内容位置是强制限制条件**,缺 playwright 量不到位置 → 记 FAIL 并计入失败,绝不 SKIP
    放行。任一闸门退非 0 → 记 FAIL 并计入整体失败。返回 (ok, receipt_lines)。
    """
    ok = True
    receipt = []
    if not palette:
        receipt.append(("模块 d 校验", "SKIP(未传 palette,无法跑内容位置校验)"))
        return ok, receipt

    gates = [
        ("模块 d · 截图真图 (R1/R2/R3)",
         [sys.executable, os.path.join(PAIN_ASSETS, "verify_shot.py"), deck_path], False),
        ("模块 d · 内容位置 (R1/R2/R3)【强制闸门】",
         [sys.executable, os.path.join(PAIN_ASSETS, "verify_content_position.py"),
          palette, "--mode", mode], True),
    ]
    sub_ok, sub_receipt = _run_gate_list(gates)
    ok = ok and sub_ok
    receipt.extend(sub_receipt)
    receipt.append(("⚠ WARNING 模块 d · 文字关联 / 截图-痛点关联",
                    "本阶段【未校验】——成卷阶段无 source-doc 原文 / 原始截图路径,该两枚闸门只在逐页出片把关。"
                    "⚠ 成卷自检全绿 ≠ 这两项已通过,请务必人工复核文字-云文档与截图-痛点的关联。"))
    return ok, receipt


def _module_d2_gates(deck_path, mode, palette):
    """成卷路径补跑模块 d 场景2(page-pain · 痛点无截图 · 上下卡片布局)校验:
    卡片几何+数字动效 + 内容位置,均 3 轮。

    与 _module_d_gates(场景1 左右截图)对称,但场景2 **无截图**,故不跑截图真图 /
    截图-痛点关联两枚,改跑场景2 专属的:

      · verify_cards_geom_s2.py:选择器 .m-d2 .cards .card 在合成 deck 里依然存在
        (transform:scale 只缩放不删元素),直接对**合成 deck HTML** 探测卡片几何
        (2–8 张 / ≤2 行 / 等高 / 均匀间距 / 末行左对齐 / 每张有重点 / 数字 count-up 落位)。
        软闸门:缺 playwright(退 2)→ 记 SKIP(与逐页 build_material_s2 一致)。
      · verify_content_position_s2.py:校验版式模板本身(自行构造 2/4/8 张 3 轮内容跨度),
        只需 palette + mode,与具体成卷素材无关,故独立跑一次。**强制闸门**:缺 playwright
        量不到位置 → 记 FAIL,绝不 SKIP 放行。
      · 文字-云文档关联(verify_text_relevance)依赖具体 --source-doc 云文档原文,成卷阶段
        拿不到原文——故不在成卷阶段跑,由逐页出片把关,成卷标注人工复核。

    任一闸门退非 0 → 记 FAIL 并计入整体失败。返回 (ok, receipt_lines)。
    """
    ok = True
    receipt = []
    if not palette:
        receipt.append(("模块 d2 校验", "SKIP(未传 palette,无法跑内容位置校验)"))
        return ok, receipt

    gates = [
        ("模块 d2 · 卡片几何+数字动效 (R1/R2/R3)",
         [sys.executable, os.path.join(PAIN_ASSETS, "verify_cards_geom_s2.py"), deck_path], False),
        ("模块 d2 · 内容位置 (R1/R2/R3)【强制闸门】",
         [sys.executable, os.path.join(PAIN_ASSETS, "verify_content_position_s2.py"),
          palette, "--mode", mode], True),
    ]
    sub_ok, sub_receipt = _run_gate_list(gates)
    ok = ok and sub_ok
    receipt.extend(sub_receipt)
    receipt.append(("⚠ WARNING 模块 d2 · 文字-云文档关联",
                    "本阶段【未校验】——成卷阶段无 source-doc 原文,该闸门只在逐页出片把关。"
                    "⚠ 成卷自检全绿 ≠ 此项已通过,请务必人工复核文字与云文档原文的一致性。"))
    return ok, receipt


def _module_e_gates(deck_path, mode, palette):
    """成卷路径补跑模块 e(page-overview · 方案全景 · 上文字下截图)校验:
    截图真图 + 总结卡片几何/错峰入场动效 + 内容位置,均 3 轮。

    与 _module_d_gates(痛点场景1 左右截图)对称——逐页出片时 build_material.py 会跑模块 e 的
    五枚校验(截图出处 / 文字关联 / 截图真图 / 截图-方案关联 / 内容位置),但**成卷**时
    compose_deck 直接拼 HTML、绕过了 build_material,故此函数把能在成卷阶段确定判定的三枚补回来:

      · verify_shot.py:选择器 .m-e .shot 在合成 deck 里依然存在(transform:scale 只缩放
        不删元素),直接对**合成 deck HTML** 探测下截图是否真图,一次覆盖 deck 内所有模块 e 页。
      · verify_points_geom.py:选择器 .m-e .esum .epoint 在合成 deck 里依然存在,直接对
        **合成 deck HTML** 探测右列总结卡片的几何(张数/等宽/左对齐/间距/有内容)+ 错峰入场
        动效是否落位。软闸门:缺 playwright → 记 SKIP 放行。
      · verify_content_position.py:校验的是版式模板本身(自行构造 3 轮说明跨度 + 截图长宽比
        变化),只需 palette + mode,与具体成卷素材无关,故独立跑一次。**强制闸门**:缺
        playwright 量不到位置 → 记 FAIL,绝不 SKIP 放行。
      · 截图出处(verify_shot_provenance)依赖原始截图文件与飞书下载回执、文字-云文档关联
        (verify_text_relevance)依赖 --source-doc 原文、截图-方案关联(verify_shot_relevance)
        依赖原始截图路径与多模态复核——成卷阶段只有内联 data:URI、拿不到这些,故此三枚不在
        成卷阶段跑,由逐页出片把关,成卷标注人工复核。

    优雅降级:截图真图缺 playwright(退 2)→ 记 SKIP(与 build_material 一致);
    但**内容位置是强制限制条件**,缺 playwright → 记 FAIL 并计入失败,绝不 SKIP 放行。
    任一闸门退非 0 → 记 FAIL 并计入整体失败。返回 (ok, receipt_lines)。
    """
    ok = True
    receipt = []
    if not palette:
        receipt.append(("模块 e 校验", "SKIP(未传 palette,无法跑内容位置校验)"))
        return ok, receipt

    gates = [
        ("模块 e · 截图真图 (R1/R2/R3)",
         [sys.executable, os.path.join(OVERVIEW_ASSETS, "verify_shot.py"), deck_path], False),
        ("模块 e · 总结卡片几何+错峰入场动效 (R1/R2/R3)",
         [sys.executable, os.path.join(OVERVIEW_ASSETS, "verify_points_geom.py"),
          deck_path], False),
        ("模块 e · 内容位置 (R1/R2/R3)【强制闸门】",
         [sys.executable, os.path.join(OVERVIEW_ASSETS, "verify_content_position.py"),
          palette, "--mode", mode], True),
    ]
    sub_ok, sub_receipt = _run_gate_list(gates)
    ok = ok and sub_ok
    receipt.extend(sub_receipt)
    receipt.append(("⚠ WARNING 模块 e · 截图出处 / 文字关联 / 截图-方案关联",
                    "本阶段【未校验】——成卷阶段只有内联 data:URI,拿不到原始截图/飞书下载回执/source-doc 原文。"
                    "这三枚闸门只在逐页出片(build_material.py)把关,成卷阶段无法复跑。"
                    "⚠ 成卷自检全绿 ≠ 这三项已通过,请务必人工复核截图出处与文字-方案关联。"))
    return ok, receipt


def _module_e2_gates(deck_path, mode, palette):
    """成卷路径补跑模块 e-2(page-architecture · 架构详图/闭环 · .m-e2)校验:
    位置 + 动效 + 连线 + 重绘钩子,3 轮独立渲染硬闸门(58 条 check)。

    与 _module_e_gates(page-overview · 方案全景 上文字下截图)**并列平行**——e 与 e2 是两个
    并存的一等模块,各由独立子技能承载(e=page-overview / e2=page-architecture)。
    e-2 结构为 5 caps + CORE orb + 5 pill flow + loopback,**无真实产品截图**,因此:
      · verify_shot_provenance / verify_shot / verify_shot_relevance 三闸门
        显式打 skipped-by-mode 标记(而非静默跳过),以便审计;
      · verify_content_position(e 的通用版) 也 skipped-by-mode,由 e-2 专属闸门
        verify_e2_content_position.py 覆盖;
      · verify_points_geom 也 skipped-by-mode(e-2 无右侧总结卡片);
      · verify_text_relevance 复用 page-overview 的(逐页出片阶段跑,成卷阶段无 source-doc)。

    验证器:page-architecture/assets/verify_e2_content_position.py —— 58 条 check 覆盖
    shell/intro/cap × 5/orb/mid 居中/flow × 5/arrow × 4/loop-zone/loopback/loopcap/
    connector 层级/gradient userSpaceOnUse/端点连线 × 10/sparks × 10/vertical wiggle/redraw hook。
    3 轮独立渲染 + 探针,任一轮失败 → FAIL;3 轮不一致 → FLAKY(exit 2 → FAIL)。

    注:此闸门直接对**合成 deck HTML** 探测 .m-e2 版式(deck 内所有 e-2 页),
    是**强制闸门**,不降级。缺 playwright → 记 FAIL。返回 (ok, receipt_lines)。
    """
    ok = True
    receipt = []
    gates = [
        ("模块 e-2 · 位置/动效/连线/重绘 (R1/R2/R3)【强制闸门】",
         [sys.executable, os.path.join(ARCH_ASSETS, "verify_e2_content_position.py"),
          deck_path], True),
    ]
    sub_ok, sub_receipt = _run_gate_list(gates)
    ok = ok and sub_ok
    receipt.extend(sub_receipt)
    receipt.append(("模块 e-2 · shot 家族三闸门",
                    "SKIPPED-BY-MODE —— e-2 版式无真实产品截图,verify_shot_provenance / "
                    "verify_shot / verify_shot_relevance 依契约跳过并留 skipped-by-mode 标记。"))
    receipt.append(("模块 e-2 · verify_points_geom",
                    "SKIPPED-BY-MODE —— e-2 无右侧总结卡片,该闸门不适用。"))
    receipt.append(("⚠ WARNING 模块 e-2 · 文字-云文档关联",
                    "本阶段【未校验】——成卷阶段无 source-doc 原文,该闸门只在逐页出片把关。"
                    "⚠ 成卷自检全绿 ≠ 此项已通过,请务必人工复核 caps/steps/orb/intro 文字与云文档的一致性。"))
    return ok, receipt


def _module_f_gates(deck_path, mode, palette):
    """成卷路径补跑模块 f(page-detail · 方案细节 · 左大数字卡片 + 右截图)校验:
    截图真图 + 大数字卡片几何/错峰入场动效/大数字不溢出 + 内容位置,均 3 轮。

    与 _module_e_gates(方案全景 上文字下截图)镜像——逐页出片时 build_material.py 会跑模块 f 的
    六枚校验(截图出处 / 文字关联 / 截图真图 / 截图-方案关联 / 内容位置 / 大数字卡片几何+动效),
    但**成卷**时 compose_deck 直接拼 HTML、绕过了 build_material,故此函数把能在成卷阶段确定
    判定的三枚补回来:

      · verify_shot.py:选择器 .m-f .shot 在合成 deck 里依然存在(transform:scale 只缩放
        不删元素),直接对**合成 deck HTML** 探测 1–4 张细节截图是否真图(all_default=True,
        一次覆盖 deck 内所有模块 f 页所有截图)。
      · verify_feat_geom.py:选择器 .m-f .fsum .fpoint 在合成 deck 里依然存在,直接对
        **合成 deck HTML** 探测左列大数字卡片的几何(2–6 张 / 等宽 / 等高 / 左对齐 / 纵向均匀
        间距 / 每张有大数字+标题)+ 错峰入场动效是否落位 + **大数字 .num 稳稳落在卡片内**
        (用户硬要求:overflow:hidden + 字号随张数降档后不顶出、不横裁)。软闸门:缺
        playwright → 记 SKIP 放行。
      · verify_content_position.py:校验的是版式模板本身(自行构造 3 轮说明跨度 + 卡片张数
        2→4→6 + 截图张数 1→3→4 变化),只需 palette + mode,与具体成卷素材无关,故独立
        跑一次。**强制闸门**:缺 playwright 量不到位置 → 记 FAIL,绝不 SKIP 放行。
      · 截图出处(verify_shot_provenance)依赖原始截图文件与飞书下载回执、文字-云文档关联
        (verify_text_relevance)依赖 --source-doc 原文、截图-方案关联(verify_shot_relevance)
        依赖原始截图路径与多模态复核——成卷阶段只有内联 data:URI、拿不到这些,故此三枚不在
        成卷阶段跑,由逐页出片把关,成卷标注人工复核。

    优雅降级:截图真图 / 大数字卡片几何缺 playwright(退 2)→ 记 SKIP(与 build_material 一致);
    但**内容位置是强制限制条件**,缺 playwright → 记 FAIL 并计入失败,绝不 SKIP 放行。
    任一闸门退非 0 → 记 FAIL 并计入整体失败。返回 (ok, receipt_lines)。
    """
    ok = True
    receipt = []
    if not palette:
        receipt.append(("模块 f 校验", "SKIP(未传 palette,无法跑内容位置校验)"))
        return ok, receipt

    gates = [
        ("模块 f · 截图真图 (R1/R2/R3)",
         [sys.executable, os.path.join(DETAIL_ASSETS, "verify_shot.py"), deck_path], False),
        ("模块 f · 大数字卡片几何+错峰入场动效+数字不溢出 (R1/R2/R3)",
         [sys.executable, os.path.join(DETAIL_ASSETS, "verify_feat_geom.py"),
          deck_path], False),
        ("模块 f · 内容位置 (R1/R2/R3)【强制闸门】",
         [sys.executable, os.path.join(DETAIL_ASSETS, "verify_content_position.py"),
          palette, "--mode", mode], True),
    ]
    sub_ok, sub_receipt = _run_gate_list(gates)
    ok = ok and sub_ok
    receipt.extend(sub_receipt)
    receipt.append(("⚠ WARNING 模块 f · 截图出处 / 文字关联 / 截图-方案关联",
                    "本阶段【未校验】——成卷阶段只有内联 data:URI,拿不到原始截图/飞书下载回执/source-doc 原文。"
                    "这三枚闸门只在逐页出片(build_material.py)把关,成卷阶段无法复跑。"
                    "⚠ 成卷自检全绿 ≠ 这三项已通过,请务必人工复核截图出处(飞书云文档/云盘)与文字-方案关联。"))
    return ok, receipt


def _module_g_gates(deck_path, mode, palette):
    """成卷路径补跑模块 g(page-close · 总结升华与行动 · 上值卡带 + 下总结主副句)校验:
    值卡几何 + 错峰入场动效 + count-up 落位 + 大数字不溢出 + 收官 .closing 落位 + 内容位置,均 3 轮。

    与 _module_f_gates(方案细节 左大数字卡片 + 右截图)对称——但 g 是**纯文本/数字模块**,
    没有截图、没有配图,故不跑截图真图 / 截图-方案关联 / 截图出处等图像闸门,只跑两枚:

      · verify_impact_geom.py:选择器 .m-g .impact .card 在合成 deck 里依然存在,直接对
        **合成 deck HTML** 探测 1–8 张值卡的几何(张数合规 + .n{k} 布局匹配:n1 hero-stat
        居中 / n2–n6 单行 flex 等宽等高 / n7–n8 grid 4×2)+ 每张有内容(prefix+v+t+d)+
        错峰入场动效落位(delay 严格递增、opacity→1)+ **count-up 真的跑到 data-to**(用户
        硬要求)+ **大数字 .pct 稳稳落在卡片内**(overflow:hidden 下不顶出、不横裁)+
        收官 .closing .cmain 存在非空 + closingIn 落位。软闸门:缺 playwright → 记 SKIP 放行。
      · verify_content_position.py:校验的是版式模板本身(自行构造 3 轮内容跨度 +
        卡片张数 1→4→8 变化,精准覆盖 n1 / n2–n6 / n7–n8 三种布局分支),只需 palette + mode,
        与具体成卷素材无关,故独立跑一次。**强制闸门**:缺 playwright 量不到位置 → 记 FAIL,
        绝不 SKIP 放行。
      · 文字关联(verify_text_relevance)依赖 --source-doc 云文档原文——成卷阶段只有内联的
        HTML 文本、拿不到云文档,故不在成卷阶段跑,由逐页出片把关,成卷标注人工复核。
        g 无截图,故也无「截图出处/截图-方案关联」两枚。

    优雅降级:值卡几何缺 playwright(退 2)→ 记 SKIP(与 build_material 一致);
    但**内容位置是强制限制条件**,缺 playwright → 记 FAIL 并计入失败,绝不 SKIP 放行。
    任一闸门退非 0 → 记 FAIL 并计入整体失败。返回 (ok, receipt_lines)。
    """
    ok = True
    receipt = []
    if not palette:
        receipt.append(("模块 g 校验", "SKIP(未传 palette,无法跑内容位置校验)"))
        return ok, receipt

    gates = [
        ("模块 g · 值卡几何+错峰入场+count-up+数字不溢出+收官落位 (R1/R2/R3)",
         [sys.executable, os.path.join(CLOSE_ASSETS, "verify_impact_geom.py"),
          deck_path], False),
        ("模块 g · 内容位置 (R1/R2/R3)【强制闸门】",
         [sys.executable, os.path.join(CLOSE_ASSETS, "verify_content_position.py"),
          palette, "--mode", mode], True),
    ]
    sub_ok, sub_receipt = _run_gate_list(gates)
    ok = ok and sub_ok
    receipt.extend(sub_receipt)
    receipt.append(("⚠ WARNING 模块 g · 文字-云文档关联",
                    "本阶段【未校验】——成卷阶段只有内联 HTML 文本,拿不到 --source-doc 云文档原文。"
                    "文字关联闸门只在逐页出片(build_material.py)把关,成卷阶段无法复跑。"
                    "⚠ 成卷自检全绿 ≠ 值卡数字与总结措辞已核对云文档,请务必人工复核卡片数字"
                    "(基线→新值)与总结主/副句是否忠实云文档表述。"))
    return ok, receipt


def self_check(deck_path, mode, pages=None, palette=None, layout="corner",
               low_memory=None):
    """整份自检:全 deck lint(ERROR=0)+ verify-single-mode 三轮合所选;
    若成卷含模块 a 页,补跑模块 a 图像闸门(故事素描真图,3 轮;占位默认 FAIL、不许交付);
    若成卷含模块 b 页,补跑模块 b 四闸门(头像真图 / 花名册几何 / 内容位置 / 元素尺寸,均 3 轮);
    若成卷含模块 c 页,补跑模块 c 校验(卡片几何+动效 / 内容位置,均 3 轮);
    若成卷含模块 d 页,补跑模块 d 校验(截图真图 / 内容位置,均 3 轮);
    若成卷含模块 d2 页(痛点场景2·无截图卡片布局),补跑模块 d2 校验
    (卡片几何+数字动效 / 内容位置,均 3 轮);
    若成卷含模块 e 页(方案全景·上文字下截图),补跑模块 e 校验(截图真图 / 总结卡片几何+错峰入场动效 / 内容位置,均 3 轮);
    若成卷含模块 f 页(方案细节·左大数字卡片+右截图),补跑模块 f 校验(截图真图 / 大数字卡片几何+错峰入场动效+数字不溢出 / 内容位置,均 3 轮);
    若成卷含模块 g 页(总结升华·上值卡带+下总结主副句),补跑模块 g 校验(值卡几何+错峰入场+count-up+数字不溢出+收官落位 / 内容位置,均 3 轮)。

    参数 low_memory:
      · None(默认)→ 自动:MemAvailable < LOW_MEM_THRESHOLD_MB (700MB) 时进入 True。
      · True         → 强制降级模式:只跑 lint + single-mode 两枚不 launch Chromium 的
                       轻量校验;重量级 gate(_module_*_gates + 封面呼吸感,均需 launch
                       Chromium 子进程)集体降级为 WARN,并在回执里把「应在新 shell 单独
                       跑的命令」打印出来——每条只吃自己那份内存,不与父进程叠加,
                       从根上规避沙盒 512MB 内存上限下父进程 + Chromium 子进程叠加的 OOM。
      · False        → 强制不降级(用于回归测试 / 内存充裕环境)。

    历史故障:成卷自检默认全跑时,曾在 512MB 沙盒被 OOM kill(exit 143)——父进程仍持有
    preview-theme/preview-content 的 CONTENT_CSS 等大字符串,子进程再 launch Chromium 时
    父+子 RSS 叠加撞顶。本函数从此**默认按内存自适应**:低内存 → 降级 WARN,
    输出可复制的复跑命令(每条 subprocess 独立跑,不叠加);内存充裕 → 全跑。
    """
    if low_memory is None:
        low_memory = _is_low_memory()

    ok = True
    receipt = []

    lint = os.path.join(ASSETS, "lint-slides.py")
    rc, tail = _run_gate([sys.executable, lint, deck_path])
    ok = ok and rc == 0
    receipt.append(("lint 全 deck (ERROR=0)", "PASS" if rc == 0 else "FAIL"))
    if rc != 0:
        receipt.append(("  lint", tail))

    vsm = os.path.join(ASSETS, "verify-single-mode.py")
    rc, tail = _run_gate([sys.executable, vsm, deck_path, "--mode", mode])
    ok = ok and rc == 0
    receipt.append(("single-mode (R1/R2/R3)", "PASS" if rc == 0 else "FAIL"))
    if rc != 0:
        receipt.append(("  single-mode", tail))

    # ── 低内存降级路径:重量级 gate(_module_*_gates + 封面呼吸感)全部记为 WARN,
    # ──   并输出一份 shell 命令清单(每条命令单跑,不与父进程叠加内存)。
    if low_memory:
        mb = _mem_available_mb()
        receipt.append(
            ("低内存降级(MemAvailable≈{}MB < {}MB 阈值)".format(
                mb if mb is not None else "?", LOW_MEM_THRESHOLD_MB),
             "重量级 gate(需 launch Chromium)本次跳过。请在**新 shell** 逐条复跑:"))
        followups = _low_memory_followup_cmds(deck_path, mode, palette, layout, pages)
        for lbl, cmd in followups:
            receipt.append(("  ↳ " + lbl, "  ".join(cmd)))
        receipt.append(("⚠ WARNING 重量级 gate 全部未在本次成卷阶段校验",
                        "自检结果 = lint + single-mode 通过 ≠ 全绿。请按上方命令清单逐条复跑,"
                        "或在内存充裕环境下用 --no-low-memory 重跑一次完整自检。"))
        return ok, receipt

    # 成卷含模块 a 页时,补跑 page-story 图像闸门(故事素描真图,3 轮)——
    # 硬规则:只要生成了故事页就必须有真图,占位框默认判 FAIL、不许交付。
    has_a = bool(pages) and any((p.get("module") == "a") for p in pages)
    if has_a:
        a_ok, a_receipt = _module_a_gates(deck_path, mode, palette)
        ok = ok and a_ok
        receipt.extend(a_receipt)

    # 成卷含模块 b 页时,补跑 page-team 三闸门(逐页路径有、成卷路径原先缺)
    has_b = bool(pages) and any((p.get("module") == "b") for p in pages)
    if has_b:
        b_ok, b_receipt = _module_b_gates(deck_path, mode, palette)
        ok = ok and b_ok
        receipt.extend(b_receipt)

    # 成卷含模块 c 页时,补跑 page-background 校验(卡片几何+动效 / 内容位置,均 3 轮)
    has_c = bool(pages) and any((p.get("module") == "c") for p in pages)
    if has_c:
        c_ok, c_receipt = _module_c_gates(deck_path, mode, palette)
        ok = ok and c_ok
        receipt.extend(c_receipt)

    # 成卷含模块 d 页时,补跑 page-pain 校验(截图真图 / 内容位置,均 3 轮)
    has_d = bool(pages) and any((p.get("module") == "d") for p in pages)
    if has_d:
        d_ok, d_receipt = _module_d_gates(deck_path, mode, palette)
        ok = ok and d_ok
        receipt.extend(d_receipt)

    # 成卷含模块 d2 页(痛点场景2·无截图卡片布局)时,补跑 page-pain 场景2 校验
    # (卡片几何+数字动效 / 内容位置,均 3 轮)
    has_d2 = bool(pages) and any((p.get("module") == "d2") for p in pages)
    if has_d2:
        d2_ok, d2_receipt = _module_d2_gates(deck_path, mode, palette)
        ok = ok and d2_ok
        receipt.extend(d2_receipt)

    # 成卷含模块 e 页(方案全景·上文字下截图)时,补跑 page-overview 校验
    # (截图真图 / 内容位置,均 3 轮)
    has_e = bool(pages) and any((p.get("module") == "e") for p in pages)
    if has_e:
        e_ok, e_receipt = _module_e_gates(deck_path, mode, palette)
        ok = ok and e_ok
        receipt.extend(e_receipt)

    # 成卷含模块 e-2 页(page-architecture · 架构详图/闭环 .m-e2)时,补跑 e-2 校验
    # (verify_e2_content_position:位置/动效/连线/重绘,3 轮强制闸门)
    has_e2 = bool(pages) and any((p.get("module") == "e2") for p in pages)
    if has_e2:
        e2_ok, e2_receipt = _module_e2_gates(deck_path, mode, palette)
        ok = ok and e2_ok
        receipt.extend(e2_receipt)

    # 成卷含模块 f 页(方案细节·左大数字卡片+右截图)时,补跑 page-detail 校验
    # (截图真图 / 大数字卡片几何+错峰入场动效+数字不溢出 / 内容位置,均 3 轮)
    has_f = bool(pages) and any((p.get("module") == "f") for p in pages)
    if has_f:
        f_ok, f_receipt = _module_f_gates(deck_path, mode, palette)
        ok = ok and f_ok
        receipt.extend(f_receipt)

    # 成卷含模块 g 页(总结升华·上值卡带+下总结主副句)时,补跑 page-close 校验
    # (值卡几何+错峰入场+count-up+数字不溢出+收官落位 / 内容位置,均 3 轮)
    has_g = bool(pages) and any((p.get("module") == "g") for p in pages)
    if has_g:
        g_ok, g_receipt = _module_g_gates(deck_path, mode, palette)
        ok = ok and g_ok
        receipt.extend(g_receipt)

    # 封面呼吸感闸门:corner 版式的首页背景飞书 logo 必须有「点亮呼吸」(birdLit),
    # 且降级(reduced-motion)下冻结——用 verify-cover-breath.py 做规格锁定 + 运行时
    # 逐帧采样(3 轮一致)+ 降级冻结(3 轮)三层硬证据。缺 playwright 时该器只跑规格层
    # 并自行退 0(优雅降级),不阻断成卷。仅 corner 版式有呼吸元素,其余版式该器直接 SKIP。
    if palette and layout == "corner":
        breath = os.path.join(HERE, "verify-cover-breath.py")
        rc, tail = _run_gate([sys.executable, breath, palette, "--mode", mode,
                              "--cover-layout", layout])
        passed = rc == 0
        ok = ok and passed
        receipt.append(("封面 · 背景 logo 呼吸感 (规格+运行时 R1/R2/R3+降级冻结)",
                        "PASS" if passed else "FAIL"))
        if not passed:
            receipt.append(("  封面呼吸感", tail))

    return ok, receipt


def _low_memory_followup_cmds(deck_path, mode, palette, layout, pages):
    """
    构造低内存降级模式下的「新 shell 复跑命令清单」——每条对应一枚重量级 gate
    (需 launch Chromium 的模块闸门 / 封面呼吸感),命令按当前 deck 的模块用量按需列出。
    输出 [(label, [argv...]), ...]。argv 是 subprocess 风格的 list, 打印时空格连起来即可。
    """
    cmds = []
    if pages is None:
        pages = []

    def _has(m):
        return any(p.get("module") == m for p in pages)

    if _has("a"):
        cmds.append(("模块 a · 故事素描真图 (R1/R2/R3)",
                     [sys.executable, os.path.join(STORY_ASSETS, "verify_img.py"), deck_path]))
    if _has("b") and palette:
        cmds.append(("模块 b · 头像真图",
                     [sys.executable, os.path.join(TEAM_ASSETS, "verify_img.py"), deck_path]))
        cmds.append(("模块 b · 花名册几何",
                     [sys.executable, os.path.join(TEAM_ASSETS, "verify_grid_geom.py"), deck_path]))
        cmds.append(("模块 b · 内容位置【强制】",
                     [sys.executable, os.path.join(TEAM_ASSETS, "verify_content_position.py"),
                      palette, "--mode", mode]))
        cmds.append(("模块 b · 元素尺寸",
                     [sys.executable, os.path.join(TEAM_ASSETS, "verify_elem_size.py"),
                      palette, "--mode", mode]))
    if _has("c") and palette:
        cmds.append(("模块 c · 卡片几何+动效",
                     [sys.executable, os.path.join(BG_ASSETS, "verify_cards_geom.py"), deck_path]))
        cmds.append(("模块 c · 内容位置【强制】",
                     [sys.executable, os.path.join(BG_ASSETS, "verify_content_position.py"),
                      palette, "--mode", mode]))
    if _has("d") and palette:
        cmds.append(("模块 d · 截图真图",
                     [sys.executable, os.path.join(PAIN_ASSETS, "verify_shot.py"), deck_path]))
        cmds.append(("模块 d · 内容位置【强制】",
                     [sys.executable, os.path.join(PAIN_ASSETS, "verify_content_position.py"),
                      palette, "--mode", mode]))
    if _has("d2") and palette:
        cmds.append(("模块 d2 · 卡片几何+数字动效",
                     [sys.executable, os.path.join(PAIN_ASSETS, "verify_cards_geom_s2.py"), deck_path]))
        cmds.append(("模块 d2 · 内容位置【强制】",
                     [sys.executable, os.path.join(PAIN_ASSETS, "verify_content_position_s2.py"),
                      palette, "--mode", mode]))
    if _has("e") and palette:
        cmds.append(("模块 e · 截图真图",
                     [sys.executable, os.path.join(OVERVIEW_ASSETS, "verify_shot.py"), deck_path]))
        cmds.append(("模块 e · 总结卡片几何+错峰入场",
                     [sys.executable, os.path.join(OVERVIEW_ASSETS, "verify_points_geom.py"),
                      deck_path]))
        cmds.append(("模块 e · 内容位置【强制】",
                     [sys.executable, os.path.join(OVERVIEW_ASSETS, "verify_content_position.py"),
                      palette, "--mode", mode]))
    if _has("f") and palette:
        cmds.append(("模块 f · 截图真图",
                     [sys.executable, os.path.join(DETAIL_ASSETS, "verify_shot.py"), deck_path]))
        cmds.append(("模块 f · 大数字卡片几何+错峰入场+数字不溢出",
                     [sys.executable, os.path.join(DETAIL_ASSETS, "verify_feat_geom.py"),
                      deck_path]))
        cmds.append(("模块 f · 内容位置【强制】",
                     [sys.executable, os.path.join(DETAIL_ASSETS, "verify_content_position.py"),
                      palette, "--mode", mode]))
    if _has("g") and palette:
        cmds.append(("模块 g · 值卡几何+错峰入场+count-up+收官落位",
                     [sys.executable, os.path.join(CLOSE_ASSETS, "verify_impact_geom.py"),
                      deck_path]))
        cmds.append(("模块 g · 内容位置【强制】",
                     [sys.executable, os.path.join(CLOSE_ASSETS, "verify_content_position.py"),
                      palette, "--mode", mode]))
    if palette and layout == "corner":
        breath = os.path.join(HERE, "verify-cover-breath.py")
        cmds.append(("封面 · 背景 logo 呼吸感",
                     [sys.executable, breath, palette, "--mode", mode,
                      "--cover-layout", layout]))
    return cmds


def shoot(html_path, png_path):
    """整卷长图截图(full_page),供人工验收滚动效果。"""
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch(args=["--no-sandbox", "--disable-dev-shm-usage",
                                     "--disable-gpu"])
        pg = b.new_page(viewport={"width": 1056, "height": 900}, device_scale_factor=1)
        pg.goto("file://" + os.path.abspath(html_path))
        # 等网络空闲 + 字体就绪,替代固定盲等,避免慢环境下未渲染完就截图
        try:
            pg.wait_for_load_state("networkidle", timeout=10000)
        except Exception:
            pass
        try:
            pg.evaluate("document.fonts && document.fonts.ready")
        except Exception:
            pass
        pg.wait_for_timeout(150)
        pg.screenshot(path=png_path, full_page=True)
        b.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("palette")
    ap.add_argument("--mode", required=True, choices=["light", "dark"])
    ap.add_argument("--title", default="标题占位 · 第二行")
    ap.add_argument("--author", default="发起人")
    ap.add_argument("--date", default="2026.07.28")
    ap.add_argument("--cover-layout", default=None,
                    help="封面版式(不传读 palette.json cover_layout,再兜底 corner)")
    ap.add_argument("--company-logo", default=None)
    ap.add_argument("--company-name", default=None,
                    help="企业名称(Step 1 确认后传入),替换封面 kicker 与内容页页脚前缀;"
                         "缺省占位「企业名称」")
    ap.add_argument("--feishu-logo",
                    default=os.path.join(ASSETS, "feishu-logo.png"))
    ap.add_argument("--pages", help="内容页 JSON 列表;不传用 a,b,c,d,e,e2,f,g 全套示例")
    ap.add_argument("--out", required=True)
    ap.add_argument("--no-shoot", action="store_true")
    ap.add_argument("--no-selfcheck", action="store_true")
    # 低内存降级模式的三态开关(参见 self_check.low_memory 参数):
    #   默认(不加)→ 自动:MemAvailable < 700MB 时进入降级
    #   --low-memory      → 强制降级(即使内存充裕,也只跑 lint + single-mode,不 launch Chromium)
    #   --no-low-memory   → 强制关闭降级(即使内存不足也全跑,可能被 OOM kill,用于回归测试)
    ap.add_argument("--low-memory", dest="low_memory", action="store_true", default=None,
                    help="强制进入低内存降级模式:只跑 lint + single-mode,"
                         "重量级 gate 降级为 WARN + 复跑命令清单。")
    ap.add_argument("--no-low-memory", dest="low_memory", action="store_false",
                    help="强制关闭低内存降级(用于内存充裕环境的回归测试)。")
    args = ap.parse_args()

    # 运行期注入企业名称:内容页页脚经 preview-content.current_brand_foot() 读取此环境变量;
    # 封面 kicker 则通过 build_deck 的 company_name 参数直传。
    if args.company_name:
        os.environ["DECK_COMPANY_NAME"] = args.company_name

    if not os.path.exists(args.palette):
        sys.exit(f"[compose_deck] 找不到 palette:{args.palette}")
    try:
        with open(args.palette, encoding="utf-8") as f:
            data = json.load(f)
    except json.JSONDecodeError as e:
        sys.exit(f"[compose_deck] palette JSON 解析失败:{args.palette}({e})")
    layout = args.cover_layout or data.get("cover_layout", "corner")
    if args.pages:
        if not os.path.exists(args.pages):
            sys.exit(f"[compose_deck] 找不到 pages 清单:{args.pages}")
        try:
            with open(args.pages, encoding="utf-8") as f:
                pages = json.load(f)
        except json.JSONDecodeError as e:
            sys.exit(f"[compose_deck] pages JSON 解析失败:{args.pages}({e})")
    else:
        pages = [{"module": m} for m in PC.ORDER]  # 默认 a,b,c,d,e,e2,f,g 全套(演示)

    html = build_deck(data, args.mode, args.title, args.author, args.date,
                      layout, args.company_logo, args.feishu_logo, pages,
                      args.company_name)
    with open(args.out, "w") as f:
        f.write(html)
    print("wrote", args.out, f"({1+len(pages)} 页:封面 + {len(pages)} 内容页)")

    if args.no_shoot:
        if os.environ.get("DECK_ALLOW_DEBUG", "").strip() not in ("1", "true", "yes"):
            sys.exit("[compose_deck] --no-shoot 只在 DECK_ALLOW_DEBUG=1 时可用(调试后门)。\n"
                     "  正式出片必须成截图,以便运行验收闸门与 verify-cover-parity。")
        print("⚠ [DEBUG] 跳过整卷截图(--no-shoot + DECK_ALLOW_DEBUG=1)")
    else:
        png = os.path.splitext(args.out)[0] + ".png"
        shoot(args.out, png)
        print("整卷预览长图:", png)

    if args.no_selfcheck:
        if os.environ.get("DECK_ALLOW_DEBUG", "").strip() not in ("1", "true", "yes"):
            # exit=2 区别于正常 exit=0,让 CI/上游明确识别"用户主动跳过自检"
            sys.exit("[compose_deck] --no-selfcheck 只在 DECK_ALLOW_DEBUG=1 时可用(调试后门)。\n"
                     "  正式出片禁止跳过自检(P0 硬闸)。")
        print("⚠ [DEBUG] 自检已跳过(--no-selfcheck + DECK_ALLOW_DEBUG=1),仅限本地调试。")
        sys.exit(2)

    ok, receipt = self_check(args.out, args.mode, pages=pages, palette=args.palette,
                             layout=layout, low_memory=args.low_memory)
    print("\n—— 整份自检回执 ——")
    for k, v in receipt:
        print(f"  {k}: {v}")
    # 醒目汇总:成卷阶段无法复跑的语义/出处闸门(截图出处、文字-云文档关联、截图-方案关联、
    # 素描图文相符等)一律记为 ⚠ WARNING。这些项【未在成卷阶段校验】——自检全绿 ≠ 它们已通过,
    # 必须人工复核。把它们从散落回执里汇总成一条横幅,避免"全绿即万无一失"的误读。
    warns = [k for k, _ in receipt if str(k).lstrip().startswith("⚠ WARNING")]
    if warns:
        print("\n" + "=" * 68)
        print(f"⚠ 人工复核提醒:以下 {len(warns)} 项语义/出处闸门【无法在成卷阶段校验】,")
        print("  只在逐页出片(build_material.py)把关。自检全绿 ≠ 这些项已通过,请务必人工复核:")
        for w in warns:
            print("    · " + str(w).lstrip().replace("⚠ WARNING ", "", 1))
        print("=" * 68)
    print("\n提示:首页与 Step 0 的严格一致,另用 verify-cover-parity.py 逐字节证明。")
    if not ok:
        print("\n✗ 自检未过,按报告修正后重跑。")
        # 按失败项/涉及模块打印 Path A 复现指引,便于用户直接照抄修复(P0 #3)
        try:
            import importlib.util as _iu
            _pv_path = os.path.abspath(os.path.join(HERE, "..", "..", "page-base", "assets",
                                                    "provenance.py"))
            if os.path.exists(_pv_path):
                _spec = _iu.spec_from_file_location("provenance", _pv_path)
                _pv = _iu.module_from_spec(_spec)
                _spec.loader.exec_module(_pv)
                # 从 pages 提取涉及模块 + 从 receipt 提取带模块字母的失败行
                _mods = sorted({p.get("module") for p in pages if isinstance(p, dict)
                                and p.get("module")})
                _failed_mods = []
                for _k, _v in receipt:
                    _s = f"{_k} {_v}".lower()
                    if "fail" not in _s:
                        continue
                    for _m in _mods:
                        # 匹配如 "module a"/"m-a"/"page-story"/"模块 a" 等口径
                        if any(_p in _s for _p in
                               (f"module {_m}", f"m-{_m}", f"page-{_m}",
                                f"模块 {_m}", f"_{_m}_")):
                            _failed_mods.append(_m)
                if not _failed_mods:
                    _failed_mods = _mods  # 无法定位就打所有涉及模块
                hint = _pv.failure_hints_by_modules(_failed_mods)
                if hint:
                    print("\n—— Path A 复现指引 ——")
                    print(hint)
        except Exception as _e:
            print(f"(未能加载 provenance 指引:{_e})", file=sys.stderr)
        sys.exit(1)
    print("\n✓ 整份自检通过(mode=" + args.mode + f" · {1+len(pages)} 页)。")
    # v9.8.6 —— compose 只到"整份自检 PASS",不代表可交付。page-notes 五步流水
    # (build_speech_plan → agent 填 → inject_notes → verify_speaker_notes → agent
    # 建飞书文档 → record_speech_doc)是 SKILL.md Step 5 的**硬闸**,由
    # deck-acceptance/accept_deck.py 强制校验。Autopilot 必须按序跑完,否则
    # accept_deck 会拒收(退 1)。
    print("\n" + "═" * 68)
    print("下一步:page-notes 五步流水(硬闸,不可跳过)")
    print("═" * 68)
    print("  ① 取材 (deterministic):")
    print(f"     python3 subskills/page-notes/assets/build_speech_plan.py {args.out} \\")
    print("        --company-name \"$DECK_COMPANY_NAME\" --duration <分钟数> \\")
    print("        --role \"<部门/角色>\" --structure {story|logic|impact} \\")
    print("        --deck-title \"<Step 4 确认标题>\" \\")
    print(f"        --out {os.path.splitext(args.out)[0]}.speech_plan.json")
    print("  ② agent 按 subskills/page-notes/references/coach-refs/ 的评分标准 +")
    print("     结构模板 + 大白话/数字驱动/故事优先原则,填 speech_plan.json 的")
    print("     per_page_notes / segments.text / titles / qna 字段")
    print("  ③ 写回 data-notes(仅改属性,不重渲染):")
    print(f"     python3 subskills/page-notes/assets/inject_notes.py {args.out} \\")
    print(f"        {os.path.splitext(args.out)[0]}.speech_plan.json")
    print("  ④ agent 用 lark-doc 建飞书演讲稿文档,标题严格套")
    print("     '{企业名}效率先锋演讲稿 - {演讲标题}'")
    print("  ⑤ 落 sidecar 证明文档已建成(deck-acceptance 会拒收缺 sidecar 的 deck):")
    print(f"     python3 subskills/page-notes/assets/record_speech_doc.py {args.out} \\")
    print("        --lark-url <飞书文档 URL> --title \"<套壳标题>\"")
    print("  ⑥ 再跑 deck-acceptance:")
    print(f"     python3 subskills/deck-acceptance/assets/accept_deck.py {args.out} \\")
    print(f"        --mode {args.mode}")
    print("═" * 68)
    sys.exit(0)


if __name__ == "__main__":
    main()
