#!/usr/bin/env python3
"""
preview-content.py — 内容页模版确认物料生成器 (a,b,c,d,e,e2,f,g 共 8 类标准模块)

延续封面 corner 的视觉语言(mesh 流光底 + accent 起笔线 + --fs-* token + 浅/深两套),
但**内容页不放 LOGO 图**,改为左下角页脚展示「企业名称 × 飞书 · AI 先锋大赛」文字。
每类模块(a 故事 / b 团队 / c 背景 / d 痛点 / e 方案全景 / e2 架构详图-协同闭环 / f 细节 / g 总结)各一套内容版式,
全部套已确认主题的配色 token,自动跟随浅/深。

输出:一张 PNG 确认物料,8 类模块逐行「浅色 | 深色」并排,交用户确认。

用法
----
python3 assets/preview-content.py themes/amber/palette.json --out /tmp/content.html
python3 assets/preview-content.py themes/amber/palette.json --out x.html --module d   # 只出某一类

依赖 playwright(与 preview-theme.py 相同)。若缺系统库,调用方注入 LD_LIBRARY_PATH。
"""
import argparse
import base64
import html as _html  # 模块顶部导入,避免 page() 内每帧 re-import(v9.1 P2 收敛)
import json
import os


# 模块 b 头像「浏览器内上传」脚本:点头像 → 选图 → FileReader 读为 data:URI → 替换/新建 <img>。
# 纯客户端、零网络、零依赖;不改变卡片几何(只换圆盘内的图),自检不受影响。
# 每页 body 里只需拼接一次(重复拼接也安全:函数幂等、事件走 onchange 内联)。
TEAM_UPLOAD_JS = (
    "<script>window.__avaUp=window.__avaUp||function(inp){"
    "var f=inp.files&&inp.files[0];if(!f)return;"
    "var rd=new FileReader();rd.onload=function(e){"
    "var lab=inp.closest('.ava');if(!lab)return;"
    "var img=lab.querySelector('img');"
    "if(!img){img=document.createElement('img');"
    "var mono=lab.querySelector('.mono');if(mono)mono.style.display='none';"
    "lab.insertBefore(img,lab.firstChild);}"
    "img.src=e.target.result;};rd.readAsDataURL(f);};</script>"
)


# 队名自适应字号:队名单行(white-space:nowrap)、位置固定在 name-wrap(max-width 60%)。
# 字数多时按需把字号从 58px 逐步缩到下限 30px,直到不溢出 name-wrap——保证「位置固定、
# 仅字号自适应」(与封面标题同一策略)。纯客户端、零依赖、幂等;设 data-fit 供校验器识别。
TEAM_FIT_JS = (
    "<script>window.__teamFit=window.__teamFit||function(){"
    "var ns=document.querySelectorAll('.m-b .tname');"
    "for(var i=0;i<ns.length;i++){var el=ns[i];el.setAttribute('data-fit','1');"
    "var box=el.parentElement;var max=58,min=30,fs=max;el.style.fontSize=fs+'px';"
    "var guard=0;while(el.scrollWidth>box.clientWidth&&fs>min&&guard<80){"
    "fs-=1;el.style.fontSize=fs+'px';guard++;}}};"
    "if(document.readyState!=='loading')window.__teamFit();"
    "else document.addEventListener('DOMContentLoaded',window.__teamFit);</script>"
)


# 左侧长文自适应字号:参考痛点页 (.m-d .pcol .lead) 的视觉规范 —— 短文放大到贴合容器,
# 长文缩到容器内不溢出。用于:.m-a .lead(故事页引语)、.m-c .lead p(背景页段落)。
# 策略:先按基线字号排版,若溢出高度则逐步 -1px 直到不溢出(下限 min);
# 若明显有富余则逐步 +1px 直到贴合(上限 max)——短句 -> 大字号,长段 -> 更小字号。
# 幂等、纯客户端、零依赖;设 data-fit 供校验器识别;暴露 window.__leadFit 供外部再触发。
#
# v0.2.8:胶片带(deck-track)水平布局下,off-screen frame 首帧 DOMContentLoaded 时
# 容器高度可能尚未定型(display 未 attach、字体未就绪),导致 scrollHeight/clientHeight
# 测量失真 → 命中收缩循环 → 停在下限(表现为「字体很小」)。修复:
#   1. 每次运行前先清空 el.style.fontSize,让 CSS 基线重新生效,再从 base 开始探测
#      (否则上次的错误尺寸会成为下一次的起点,永远不上涨)。
#   2. 补丁事件重跑:deck:nav / deck:ready(与 REPLAY_ANIM_JS 同源)+ resize
#      + document.fonts.ready(字体到达后重排),并在 DOMContentLoaded 后再 rAF+timeout
#      各来一次(覆盖 layout 未定型的情况)。
LEAD_FIT_JS = (
    "<script>(function(){"
    "function fit(el,box,base,mn,mx){"
    "if(!el||!box)return;el.setAttribute('data-fit','1');"
    "el.style.fontSize='';"
    "var fs=base;el.style.fontSize=fs+'px';"
    "var g=0;"
    "while((box.scrollHeight>box.clientHeight+1||el.scrollWidth>box.clientWidth+1)&&fs>mn&&g<80){"
    "fs-=1;el.style.fontSize=fs+'px';g++;}"
    "if(g===0){g=0;while(box.scrollHeight<=box.clientHeight&&el.scrollWidth<=box.clientWidth&&fs<mx&&g<80){"
    "fs+=1;el.style.fontSize=fs+'px';g++;"
    "if(box.scrollHeight>box.clientHeight||el.scrollWidth>box.clientWidth){"
    "fs-=1;el.style.fontSize=fs+'px';break;}}}"
    "}"
    "function run(root){"
    "var scope=root||document;"
    "var as=scope.querySelectorAll('.m-a .quote .lead');"
    "for(var i=0;i<as.length;i++){fit(as[i],as[i].parentElement,34,26,48);}"
    "var cs=scope.querySelectorAll('.m-c .lead');"
    "for(var j=0;j<cs.length;j++){var lead=cs[j];var ps=lead.querySelectorAll('p');"
    # v0.2.11-r8:背景页(c)左侧正文自适应上限从 28 降到 22(=base)。根因:.m-c 是
    #   align-items:flex-start,.lead 高度自适应、无约束,box.scrollHeight 恒等
    #   clientHeight,shrink 分支永不触发、grow 分支永远把每段顶到旧 mx=28 →「字体过大」。
    #   现在 mx=base:只允许因溢出而缩小(配合下方 .m-c .lead 的 stretch 高度预算),
    #   绝不向上膨胀,字号稳定在舒适基线,与姊妹页 .m-d .pcol .lead(静态 21px)看齐。
    "for(var k=0;k<ps.length;k++){fit(ps[k],lead,22,19,22);}}"
    "}"
    "window.__leadFit=run;"
    "function kick(){try{run();}catch(e){}}"
    "function boot(){"
    "kick();"
    "if(window.requestAnimationFrame)requestAnimationFrame(function(){requestAnimationFrame(kick);});"
    "setTimeout(kick,120);setTimeout(kick,400);setTimeout(kick,900);"
    "}"
    "if(document.readyState!=='loading')boot();"
    "else document.addEventListener('DOMContentLoaded',boot);"
    "document.addEventListener('deck:nav',function(){setTimeout(kick,40);setTimeout(kick,320);});"
    "document.addEventListener('deck:ready',function(){setTimeout(kick,40);setTimeout(kick,320);});"
    "window.addEventListener('resize',function(){setTimeout(kick,60);});"
    "if(document.fonts&&document.fonts.ready&&document.fonts.ready.then){"
    "document.fonts.ready.then(function(){kick();setTimeout(kick,120);});}"
    "})();</script>"
)


# 模块 c 数字卡片动效:关键数字 count-up 滚动 + 卡片错峰入场(入场用纯 CSS,见 .m-c .stat)。
# 每个数字 span.v 带 data-to(目标值);滚动结束把 textContent 落到精确目标值(供动效落位校验)。
# 纯客户端、零依赖、幂等;尊重 prefers-reduced-motion(直接落终值)。设 data-counted 供校验器识别。
BG_COUNT_JS = (
    "<script>(function(){"
    "function pickVs(scope){"
    "return (scope||document).querySelectorAll('.m-c .stat .num .v[data-to],.m-d2 .card .num .v[data-to],.m-f .fsum .fpoint .num .v[data-to],.m-g .impact .card .pct .v[data-to]');}"
    "var reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion:reduce)').matches;"
    "function ease(t){return 1-Math.pow(1-t,3);}"
    "function runOne(el,idx){"
    "var to=parseFloat(el.getAttribute('data-to'));"
    "if(isNaN(to)){el.setAttribute('data-counted','1');return;}"
    "var dur=1100,delay=180+idx*140;"
    "if(reduce){el.textContent=String(to);el.setAttribute('data-counted','1');return;}"
    "el.textContent='0';"
    "setTimeout(function(){var s=performance.now();"
    "function tick(now){var p=Math.min((now-s)/dur,1);"
    "el.textContent=String(Math.round(ease(p)*to));"
    "if(p<1){requestAnimationFrame(tick);}"
    "else{el.textContent=String(to);el.setAttribute('data-counted','1');}}"
    "requestAnimationFrame(tick);},delay);"
    "}"
    "function run(scope){var vs=pickVs(scope);for(var i=0;i<vs.length;i++){runOne(vs[i],i);}}"
    "function reset(scope){var vs=pickVs(scope);for(var i=0;i<vs.length;i++){vs[i].textContent='0';vs[i].removeAttribute('data-counted');}}"
    "window.__mcCount=run;window.__mcCountReset=reset;"
    "if(document.readyState!=='loading')run();"
    "else document.addEventListener('DOMContentLoaded',function(){run();});"
    "})();</script>"
)


# 三模式动效重放:数字 count-up 与卡片入场(mcCardIn/capIn/stepIn/orbIn/closingIn/…)在
# deck:nav / deck:ready 事件触发时,针对**当前 slide** 的元素重置并重放。
# 策略:
#   1) 找当前可见 slide 根(优先 .deck-frame.is-active,退回 .deck-frame :not(.is-hidden)),
#      在 body.deck-speaker(演讲者面板)下,同时也遍历 .deck-pv-scale 里的克隆节点。
#   2) 对数字:调用 window.__mcCountReset(root) + window.__mcCount(root) 组合。
#   3) 对卡片:通过 remove animation → 强制 reflow → 复位 animation 触发重放。
# 纯客户端、零依赖、幂等;三模式(editing/speaker/projecting)均生效。
REPLAY_ANIM_JS = (
    "<script>(function(){"
    "var SEL='.m-c .stat,.m-d2 .card,.m-e .rcard,.m-e2 .cap-row .cap,.m-e2 .orb,.m-e2 .flow .step,.m-e2 .flow .arrow,.m-e2 .loopback,.m-e2 .loopcap,.m-f .fpoint,.m-f .rcard,.m-g .impact .card,.m-g .closing';"
    "function activeScopes(){"
    "var out=[];"
    "var track=document.getElementById('deckTrack');"
    "if(!track)return [document];"
    "var frames=track.children;var cur=(window.__deck&&window.__deck.cur)?window.__deck.cur():0;"
    "if(frames[cur])out.push(frames[cur]);"
    "if(document.body.classList.contains('deck-speaker')){"
    "var scs=document.querySelectorAll('.deck-pv-scale');"
    "for(var i=0;i<scs.length;i++)out.push(scs[i]);}"
    "return out.length?out:[document];"
    "}"
    "function replayCards(scope){"
    "var els=scope.querySelectorAll(SEL);"
    "for(var i=0;i<els.length;i++){(function(el){"
    "var anim=el.style.animation;"
    "el.style.animation='none';"
    "el.style.opacity='';el.style.transform='';"
    "/* force reflow */"
    "void el.offsetWidth;"
    "el.style.animation='';"
    "})(els[i]);}"
    "}"
    "function replay(){"
    "var scopes=activeScopes();"
    "for(var s=0;s<scopes.length;s++){"
    "var sc=scopes[s];"
    "try{if(window.__mcCountReset)window.__mcCountReset(sc);"
    "if(window.__mcCount)window.__mcCount(sc);}catch(e){}"
    "try{replayCards(sc);}catch(e){}"
    "/* e2 连线重绘由 E2_DRAW_JS 自身监听 deck:nav 触发,此处不重复 */"
    "}"
    "}"
    "window.__replayAnim=replay;"
    "document.addEventListener('deck:nav',function(){setTimeout(replay,30);});"
    "document.addEventListener('deck:ready',function(){setTimeout(replay,30);});"
    "/* 演讲者面板每次 paint 会重建 clone,监听 note update / mutation 以补触发 */"
    "if('MutationObserver' in window){"
    "var stages=['pvCurStage','pvNextStage'];"
    "for(var k=0;k<stages.length;k++){(function(id){"
    "var el=document.getElementById(id);if(!el)return;"
    "var mo=new MutationObserver(function(){setTimeout(replay,60);});"
    "mo.observe(el,{childList:true});"
    "})(stages[k]);}}"
    "})();</script>"
)


# 预置素描头像(6 张亚洲面孔单色铅笔素描,与 page-team 取材器同源)。
# 按成员顺序循环取用,内联为 data:URI —— 色卡无关、离线、必然成功。
# 缺图时返回 None,由调用方回退到确定性首字徽章 .mono。
_AVATARS_DIR = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "..", "subskills", "page-team", "assets", "avatars")


def sketch_uri(idx):
    """取第 idx(0-based)张预置素描头像并内联为 data:URI;缺图返回 None。"""
    path = os.path.join(_AVATARS_DIR, f"sketch-{idx % 6 + 1}.png")
    if not os.path.exists(path):
        return None
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return f"data:image/png;base64,{b64}"


def ava_html(idx, initial):
    """渲染一个头像画位:默认内联素描 <img>,缺图回退首字徽章 .mono;
    始终带浏览器内上传 <label>/<input>(纯客户端 FileReader)。"""
    uri = sketch_uri(idx)
    img = f'<img src="{uri}" alt="">' if uri else ""
    mono_style = "" if uri is None else ' style="display:none"'
    return (
        '<label class="ava">'
        + img
        + f'<span class="mono"{mono_style}>{initial}</span>'
        '<span class="up">上传</span>'
        '<input type="file" accept="image/*" onchange="__avaUp(this)"></label>'
    )



# ---------------- 每类模块的内容区 markup(示例用医疗行业占位文案) ----------------
# 只写「内容区」内部;外层 shell(eyebrow/标题/tick/页脚)由 page() 统一包裹。
MODULES = {
    "a": {
        "kicker": "开场 · STORY",
        "title": "凌晨两点的急诊排班",
        "body": (
            '<div class="m-a hug">'
            '<div class="quote">'
            '<div class="qmark open">“</div>'
            '<p class="lead">凌晨两点,值班护士还在手工核对三十张排班表——'
            '一次疏忽,可能就是一场医疗差错。</p>'
            '<div class="qmark close">”</div>'
            '<div class="by">— 某三甲医院 护理部主任</div>'
            '</div>'
            '<div class="sketch">'
            '<div class="plate"></div>'
            '<div class="frame">'
            '<div class="ph err">⚠️ 缺故事场景图<br>请通过 Seedream/nanodraw 生成后<br>--module-json a.body 注入 &lt;img&gt;</div>'
            '</div>'
            '</div>'
            '</div>'
            + LEAD_FIT_JS
        ),
    },
    "b": {
        # 团队介绍(稀疏信息版):真实场景通常只有 队名 / 跨部门归属 / 队长 / 队员,
        # 无职位、无照片。版式重心居中偏上、位置固定:
        #   team-hero(队名主角 左 + 跨部门联合带 右) → team-tagline(一句话介绍)
        #   → roster(花名册:队长 + 队员,同尺寸同形制卡片,仅轻量徽章区分)。
        # 头像默认预置素描人像(亚洲面孔,内联 data:URI),支持浏览器内上传替换。
        "kicker": "团队 · TEAM",
        "title": "跨部门联合战队",
        "body": (
            '<div class="m-b">'
            '<div class="team-hero">'
            '<div class="name-wrap">'
            '<div class="tlabel">TEAM NAME · 队名</div>'
            '<div class="tname">云枢智能战队</div>'
            '</div>'
            '<div class="depts-wrap">'
            '<div class="dlabel">跨部门联合 · DEPARTMENTS</div>'
            '<div class="depts">'
            + "".join(
                (('<span class="plus">+</span>' if i else "")
                 + f'<span class="dept"><span class="dot"></span>{d}</span>')
                for i, d in enumerate(
                    ["交付中心", "架构组", "算法研究院"])
            )
            + '</div>'
            '</div>'
            '</div>'
            '<div class="team-tagline">'
            '让 AI 走进每一次医疗交付 —— 一支从战略到落地全链路自驱的跨部门小队。'
            '</div>'
            '<div class="roster">'
            + "".join(
                '<div class="rcard">'
                + f'<span class="badge-role {role_cls}">{role_txt}</span>'
                + ava_html(i, initial)
                + f'<div class="rname">{name}</div>'
                + f'<div class="rsub">{sub}</div></div>'
                for i, (role_cls, role_txt, initial, name, sub) in enumerate([
                    ("captain", "队长 · CAPTAIN", "张", "张明", "发起人"),
                    ("member", "队员", "李", "李航", ""),
                    ("member", "队员", "王", "王芮", ""),
                    ("member", "队员", "陈", "陈曦", ""),
                    ("member", "队员", "赵", "赵岚", ""),
                ])
            )
            + '</div>'
            '</div>'
            + TEAM_UPLOAD_JS
            + TEAM_FIT_JS
        ),
    },
    "c": {
        "kicker": "背景 · WHY",
        "title": "为什么现在必须做智慧化转型",
        "body": (
            '<div class="m-c">'
            '<div class="lead">'
            '<p>医疗行业正从「信息化」加速迈入「<span class="kw">智能化</span>」深水区,'
            '国家与地方政策连续出台,明确要求三级医院在既定时限内完成智慧化管理转型。</p>'
            '<p>与此同时,一线护理与行政人力缺口逐年扩大,大量诊疗时间被事务性工作挤占,'
            '而 HIS、LIS、PACS 系统各自为政、数据孤岛严重。'
            '<span class="kw">以 AI 重构核心业务流程、降本增效,已从「可选项」变为「必答题」。</span></p>'
            '</div>'
            '<div class="cards">'
            '<div class="stat"><div class="num"><span class="v" data-to="30">0</span>'
            '<span class="u">%+</span></div>'
            '<div class="meta"><div class="t">行政耗时占比</div>'
            '<div class="d">一线护理人员超三成时间被事务性工作挤占</div></div></div>'
            '<div class="stat"><div class="num"><span class="v" data-to="6">0</span>'
            '<span class="u">h</span></div>'
            '<div class="meta"><div class="t">每周排班耗时</div>'
            '<div class="d">跨科室人力调配全靠手工,冲突频发</div></div></div>'
            '<div class="stat"><div class="num"><span class="v" data-to="3">0</span>'
            '<span class="u">套+</span></div>'
            '<div class="meta"><div class="t">数据孤岛系统</div>'
            '<div class="d">HIS / LIS / PACS 各自为政,跨科协同困难</div></div></div>'
            '</div></div>'
            + BG_COUNT_JS
            + LEAD_FIT_JS
        ),
    },
    "d": {
        "kicker": "痛点 · PAIN",
        "title": "护士长每周花 6 小时手工排班",
        "body": (
            '<div class="m-d">'
            '<div class="pcol">'
            '<div class="bignum">01</div>'
            '<p class="lead">跨科室调配需<span class="kw">反复电话沟通</span>,'
            '排班冲突频发,一旦出错直接影响<span class="kw">病区安全</span>'
            '与<span class="kw">人力成本</span>。</p>'
            '<ul class="kpts">'
            '<li>每周排班耗时约 6 小时 / 人,占护士长近半日常</li>'
            '<li>跨科调配依赖口头协调,无统一视图,冲突难追溯</li>'
            '<li>排班结果无法沉淀复用,人员变动后需从零再排</li>'
            '</ul>'
            '</div>'
            # 右列:方案痛点截图(v0.2.11 对齐 v9.8.9 多图逻辑)。张数 1–4 自适应:
            # .shots.s{k} 决定网格布局(镜像 f 的 shots 版式)。1 图铺满居中;2 图上下
            # 均分;3 图 2 上 1 下(第 3 张跨列铺满);4 图 2×2。每格 object-fit:contain
            # 不裁切。取材器按张数写 .s{k}(k=min(len(shots),4)),不足 4 张时 <img> 缺
            # 位由取材器负责;完全缺料时保留下方红字硬警告 .ph.err。
            '<div class="shots s1">'
            '<div class="shot"><div class="ph err">⚠️ 缺云文档截图<br>请调 lark-doc/lark-drive 鉴权下载<br>后 --module-json d.body 注入 &lt;img&gt;</div></div>'
            '</div>'
            '</div>'
        ),
    },
    "d2": {
        "kicker": "痛点 · PAIN",
        "title": "排班全流程仍停留在手工时代",
        "body": (
            '<div class="m-d2">'
            '<div class="intro">'
            '<div class="bignum">01</div>'
            '<p>现有排班依赖<span class="kw">纸笔与表格</span>,跨科协同全靠电话与口头确认,'
            '效率低、易出错,直接拖累<span class="kw">病区安全</span>与人力成本。</p>'
            '</div>'
            '<div class="cards" style="grid-template-columns:repeat(2,1fr)">'
            '<div class="card"><div class="num"><span class="v" data-to="6">0</span>'
            '<span class="u">小时/周</span></div>'
            '<div class="t">护士长手工排班耗时</div>'
            '<div class="d">占护士长近半日常工作量,难以投入护理管理</div></div>'
            '<div class="card"><div class="num"><span class="v" data-to="30">0</span>'
            '<span class="u">张+</span></div>'
            '<div class="t">每周需人工核对的排班表</div>'
            '<div class="d">跨科调配无统一视图,冲突频发、难追溯</div></div>'
            '<div class="card"><div class="num"><span class="v" data-to="15">0</span>'
            '<span class="u">%</span></div>'
            '<div class="t">月均排班冲突率</div>'
            '<div class="d">换班审批走线下,一次疏忽即影响病区运转</div></div>'
            '<div class="card txt">'
            '<div class="key">无法沉淀</div>'
            '<div class="t">结果<span class="kw">无法沉淀复用</span></div>'
            '<div class="d">人员一变动即需从零再排,历史经验难以传承</div></div>'
            '</div>'
            '</div>'
            + BG_COUNT_JS
        ),
    },
    "e": {
        "kicker": "方案全景 · SOLUTION",
        "title": "智能排班平台:一图看懂整体方案",
        "body": (
            '<div class="m-e">'
            '<div class="intro">'
            '<p>以 <span class="kw">统一排班中台</span> 打通 HIS 与护理档案,'
            '业务、数据、AI 引擎三层贯通,<span class="kw">一处配置、全院协同</span>。</p>'
            '<p>规则 + AI 自动生成周排班,冲突实时自检,移动端一键换班审批。</p>'
            '</div>'
            '<div class="ebody">'
            '<div class="shotwrap"><div class="shot">'
            '<div class="ph err">⚠️ 缺方案全景截图<br>请调 lark-doc/lark-drive 鉴权下载<br>后 --module-json e.body 注入 &lt;img&gt;</div>'
            '</div></div>'
            '<div class="esum">'
            '<div class="epoint"><span class="idx">01</span>'
            '<span class="etxt">智能排班引擎:一键生成、冲突自检</span></div>'
            '<div class="epoint"><span class="idx">02</span>'
            '<span class="etxt">统一护理档案:一处配置、全院协同</span></div>'
            '<div class="epoint"><span class="idx">03</span>'
            '<span class="etxt">移动端换班:一键发起、线上审批</span></div>'
            '</div>'
            '</div>'
            '</div>'
        ),
    },
    "f": {
        "kicker": "方案细节 · DETAIL",
        # f 标题 = e 右侧某张总结卡片的内容(方案主张 → 对应细节页,一一闭环)。
        # 此处对应 e 的卡片 01「智能排班引擎:一键生成、冲突自检」。
        "title": "智能排班引擎:一键生成、冲突自检",
        "body": (
            '<div class="m-f">'
            # 标题下说明:取自云文档,精炼一句(勿堆砌)
            '<div class="intro">'
            '<p>规则 + <span class="kw">AI 引擎</span>自动生成周排班、冲突实时自检,'
            '把护士长从手工排班中解放出来。</p>'
            '</div>'
            '<div class="fbody">'
            # 左:数字导向卡片(内容全取自云文档,发大数字;等尺寸玻璃卡 + 错峰入场)。
            # 张数 2–6 自适应:.fsum 上的 .n{k} 由取材器按云文档卡片数写入,驱动字号/间距降档。
            '<div class="fsum n3">'
            '<div class="fpoint"><div class="num"><span class="v" data-to="10">0</span>'
            '<span class="u">秒</span></div>'
            '<div class="t">一键生成全周排班</div>'
            '<div class="d">规则 + AI 自动出表,告别 6 小时手工排班</div></div>'
            '<div class="fpoint"><div class="num"><span class="v" data-to="100">0</span>'
            '<span class="u">%</span></div>'
            '<div class="t">冲突实时自检</div>'
            '<div class="d">越班/连班自动预警,人力均衡一目了然</div></div>'
            '<div class="fpoint"><div class="num"><span class="v" data-to="1">0</span>'
            '<span class="u">键</span></div>'
            '<div class="t">移动端换班审批</div>'
            '<div class="d">线上一键发起,结果可沉淀复用</div></div>'
            '</div>'
            # 右:方案细节截图(弹性主体,镜像 e 的截图到右侧)。
            # 张数 1–4 自适应:.shots 上的 .s{k} 由取材器按截图数写入,驱动网格布局。
            '<div class="shots s1">'
            '<div class="shot"><div class="ph err">⚠️ 缺方案细节截图<br>请调 lark-doc/lark-drive 鉴权下载<br>后 --module-json f.body 注入 &lt;img&gt;</div></div>'
            '</div>'
            '</div>'
            '</div>'
            + BG_COUNT_JS
        ),
    },
    "g": {
        "kicker": "价值 · IMPACT AT A GLANCE",
        "title": "从手工排班到智能协同,把护士长的时间还给病人",
        "body": (
            '<div class="m-g">'
            # 上:impact 值卡带(张数 2–N 自适应,.n{k} 由取材器按云文档提炼出的价值数写入,
            # 驱动大数字字号降档;每张卡=大百分比[count-up 0→N + 单位/箭头] + 指标名 + 从X到Y 变化)
            '<div class="impact n4">'
            '<div class="card">'
            '<div class="prefix">提升</div>'
            '<div class="pct"><span class="arrow">↑</span>'
            '<span class="v" data-to="82">0</span><span class="u">%</span></div>'
            '<div class="t">排班效率</div>'
            '<div class="d">单科耗时 <span class="kw">从 6h → 65min</span></div>'
            '</div>'
            '<div class="card">'
            '<div class="prefix">降低</div>'
            '<div class="pct"><span class="arrow">↓</span>'
            '<span class="v" data-to="100">0</span><span class="u">%</span></div>'
            '<div class="t">越班冲突</div>'
            '<div class="d">周均冲突 <span class="kw">从 4 起 → 0 起</span></div>'
            '</div>'
            '<div class="card">'
            '<div class="prefix">达到</div>'
            '<div class="pct"><span class="v" data-to="3">0</span><span class="u">.4×</span></div>'
            '<div class="t">医护满意度</div>'
            '<div class="d">NPS <span class="kw">从 3.4 → 11.6</span></div>'
            '</div>'
            '<div class="card">'
            '<div class="prefix">达到</div>'
            '<div class="pct"><span class="arrow">↑</span>'
            '<span class="v" data-to="96">0</span><span class="u">%</span></div>'
            '<div class="t">全流程可追溯</div>'
            '<div class="d">留痕率 <span class="kw">从 42% → 96%</span></div>'
            '</div>'
            '</div>'
            # 下:closing 总结(主句必选,渐变描字;副句可选,取材器判断)
            '<div class="closing">'
            '<span class="cmain">让每一次排班,都成为一次<span class="kw">高质量的照护决策</span>。</span>'
            '<span class="csub">与飞书 AI 一起,把复杂协同交给引擎,把专业判断留给医护。</span>'
            '</div>'
            '</div>'
            + BG_COUNT_JS
        ),
    },
}

# ---- e-2 架构闭环的连线绘制脚本 (v0.2.9 dynamic) ----
# 与 v9.8.9 结构一致(cap→orb / orb→step 两组三次贝塞尔 + wiggle),
# 但把三处 v9.8.9 会掉链子的地方补齐,让"动"看得见:
#   (a) SMIL animateMotion 用相对 `begin='indefinite'` + 手动 beginElement(),
#       避免绝对 begin 在页面存活 >2.6s 后新建 spark 永远错过触发窗口的问题;
#   (b) 每次 draw() 完成后广播 beginElement() 序列,保证任意时刻切页都有火花跑;
#   (c) 连线 path 加入 stroke-dashoffset 动画类 `ln-live`,让管道本身也在流动,
#       + step 元素周期性追加 `.pulsing` 类触发 stepPing 循环脉冲。
E2_DRAW_JS = (
    "<script>(function(){"
    "var stage=document.getElementById('march');"
    "if(!stage)return;"
    "var caps=Array.prototype.slice.call(document.querySelectorAll('#capRow .cap'));"
    "var orb=document.getElementById('orb');"
    "var host=document.getElementById('lineHost');"
    "var spHost=document.getElementById('sparkHost');"
    "var conn=document.getElementById('connector');"
    "var spSvg=document.getElementById('sparks');"
    "var pathSeq=0;"
    "function toLocal(rect,sr){return {x:rect.left-sr.left,y:rect.top-sr.top,w:rect.width,h:rect.height};}"
    "/* v0.2.11-r6:用户要求去掉沿连线跑动的 spark 光点,故 spark/animateMotion/startSMIL"
    "   一并移除。此前 r3 为 spark 加的防杂散点逻辑(startSMIL 先 motion 后 opacity、"
    "   显式 cx/cy)随之作废;draw() 的 rect 健全校验仍保留(仍在防连线端点坍缩到原点)。 */"
    "/* v0.2.11-r3 修:draw() 曾无条件按各 cap/orb/step 的 getBoundingClientRect 画贝塞尔。"
    "   投影全屏 resize 过渡期某元素会瞬时报退化 rect(w/h≈0),toLocal 把端点坍缩到"
    "   ~(0,0),于是从中心 orb 拉出一条直奔左上角的发光连线。此处先校验 stage/orb/所有"
    "   cap/step 的 rect 是否健全,任一退化即 return false 中止本次绘制(不清空 host、不"
    "   建任何 path),交由 safeDraw 的兜底定时器重绘 —— 绝不产出端点落在原点的连线。 */"
    "function draw(){"
    "var sr=stage.getBoundingClientRect();"
    "if(sr.width<50||sr.height<50)return false;"
    "var orbRaw=orb.getBoundingClientRect();"
    "if(orbRaw.width<5||orbRaw.height<5)return false;"
    "var stepEls=Array.prototype.slice.call(document.querySelectorAll('#flow .step'));"
    "for(var qi=0;qi<caps.length;qi++){var cr=caps[qi].getBoundingClientRect();if(cr.width<5||cr.height<5)return false;}"
    "for(var qj=0;qj<stepEls.length;qj++){var srr=stepEls[qj].getBoundingClientRect();if(srr.width<5||srr.height<5)return false;}"
    "conn.setAttribute('viewBox','0 0 '+sr.width+' '+sr.height);"
    "spSvg.setAttribute('viewBox','0 0 '+sr.width+' '+sr.height);"
    "var grad=document.getElementById('lineGrad');"
    "if(grad){grad.setAttribute('y1','0');grad.setAttribute('y2',String(sr.height));}"
    "var orbR=toLocal(orbRaw,sr);"
    "var orbTop={x:orbR.x+orbR.w/2,y:orbR.y};"
    "var orbBot={x:orbR.x+orbR.w/2,y:orbR.y+orbR.h};"
    "host.innerHTML='';spHost.innerHTML='';"
    "pathSeq++;var seq=pathSeq;"
    "caps.forEach(function(c,i){"
    "var r=toLocal(c.getBoundingClientRect(),sr);"
    "var start={x:r.x+r.w/2,y:r.y+r.h};var end=orbTop;"
    "var dx=end.x-start.x;var wiggle=Math.abs(dx)<1?(i%2===0?8:-8):0;"
    "var cp1x=start.x+wiggle,cp2x=end.x-wiggle;"
    "var cp1y=start.y+(end.y-start.y)*0.55,cp2y=end.y-(end.y-start.y)*0.15;"
    "var d='M '+start.x+' '+start.y+' C '+cp1x+' '+cp1y+', '+cp2x+' '+cp2y+', '+end.x+' '+end.y;"
    "var pid='pathA'+(i+1)+'_'+seq;"
    "var p=document.createElementNS('http://www.w3.org/2000/svg','path');"
    "p.setAttribute('class','ln ln-live l'+(i+1));p.setAttribute('d',d);p.setAttribute('id',pid);"
    "host.appendChild(p);"
    "/* v0.2.11-r6:去掉沿连线跑动的 spark 光点(用户不要),只保留静态连线本身。 */"
    "});"
    "var stepEls=Array.prototype.slice.call(document.querySelectorAll('#flow .step'));"
    "stepEls.forEach(function(s,i){"
    "var r2=toLocal(s.getBoundingClientRect(),sr);"
    "var end={x:r2.x+r2.w/2,y:r2.y};"
    "var dx=end.x-orbBot.x;var wiggle=Math.abs(dx)<1?(i%2===0?8:-8):0;"
    "var cp1x=orbBot.x+wiggle,cp2x=end.x-wiggle;"
    "var cp1y=orbBot.y+(end.y-orbBot.y)*0.45,cp2y=end.y-(end.y-orbBot.y)*0.15;"
    "var d='M '+orbBot.x+' '+orbBot.y+' C '+cp1x+' '+cp1y+', '+cp2x+' '+cp2y+', '+end.x+' '+end.y;"
    "var pid='pathB'+(i+1)+'_'+seq;"
    "var p=document.createElementNS('http://www.w3.org/2000/svg','path');"
    "p.setAttribute('class','ln ln-live lb'+(i+1));p.setAttribute('d',d);p.setAttribute('id',pid);"
    "p.setAttribute('style','animation-delay:'+(1.85+i*0.08)+'s;');"
    "host.appendChild(p);"
    "/* v0.2.11-r6:同上,去掉 orb→step 段的跑动 spark 光点。 */"
    "});"
    "return true;"
    "}"
    "function safeDraw(){"
    "try{var sr2=stage.getBoundingClientRect();"
    "if(sr2.width<50||sr2.height<50){return false;}"
    "if(draw()!==true){return false;}"
    "stage.setAttribute('data-e2-drawn','1');return true;}catch(e){return false;}}"
    "function tryDraw(){if(!safeDraw()){setTimeout(safeDraw,200);setTimeout(safeDraw,500);setTimeout(safeDraw,900);}}"
    "/* step 循环脉冲:每 3.6s 给可见 step 追加 .pulsing 触发 stepPing 一轮 */"
    "var pulseTimer=null;"
    "function pulseSteps(){"
    "try{var steps=document.querySelectorAll('.m-e2 .flow .step');"
    "for(var i=0;i<steps.length;i++){(function(el,d){"
    "setTimeout(function(){"
    "el.classList.remove('pulsing');void el.offsetWidth;el.classList.add('pulsing');"
    "},d);})(steps[i],i*180);}}catch(e){}"
    "}"
    "function startPulse(){"
    "if(pulseTimer)clearInterval(pulseTimer);"
    "setTimeout(pulseSteps,3200);"
    "pulseTimer=setInterval(pulseSteps,4200);"
    "}"
    "if(document.readyState==='complete')tryDraw();"
    "else window.addEventListener('load',tryDraw);"
    "window.addEventListener('resize',function(){setTimeout(safeDraw,50);});"
    "setTimeout(tryDraw,2150);"
    "setTimeout(startPulse,1200);"
    "document.addEventListener('deck:ready',function(){setTimeout(tryDraw,50);startPulse();});"
    "document.addEventListener('deck:nav',function(){setTimeout(tryDraw,60);setTimeout(tryDraw,260);startPulse();});"
    "if('IntersectionObserver' in window){"
    "var io=new IntersectionObserver(function(entries){"
    "for(var k=0;k<entries.length;k++){if(entries[k].isIntersecting){setTimeout(tryDraw,50);startPulse();}}"
    "},{threshold:0.1});io.observe(stage);}"
    "})();</script>"
)

# 把 e2 版式注入 MODULES(与 e 并列的独立一等模块,由子技能 page-architecture 负责)。
# 结构固定:5 caps + CORE orb + 5 pill flow + loopback in independent zone,
# 数量/文字均须来自云文档(build_material_e2.py 强制 provenance:verbatim|inferred+span+rationale)。
MODULES["e2"] = {
    "kicker": "架构闭环 · ARCHITECTURE",
    "title": "飞书妙搭 + AI:业务数字化协同闭环",
    "body": (
        '<div class="m-e2" id="march">'
        '<p class="intro">'
        '以<span class="kw">妙搭为数据底座</span>、<span class="kw">AI 为智能核心</span>,'
        '由<span class="kw">「智能协同官」</span>统一编排,构建'
        '<span class="kw">"采集 — 校验 — 分析 — 触达 — 改进"</span> 完整闭环。'
        '</p>'
        '<div class="cap-row" id="capRow">'
        '<div class="cap"><div class="ico">妙</div><div class="h">飞书妙搭</div><div class="s">数据底座</div></div>'
        '<div class="cap"><div class="ico">AI</div><div class="h">AI 智能引擎</div><div class="s">推理核心</div></div>'
        '<div class="cap"><div class="ico">流</div><div class="h">自动化工作流</div><div class="s">执行中枢</div></div>'
        '<div class="cap"><div class="ico">讯</div><div class="h">飞书消息</div><div class="s">触达渠道</div></div>'
        '<div class="cap"><div class="ico">析</div><div class="h">分析报告</div><div class="s">洞察输出</div></div>'
        '</div>'
        '<div class="mid" id="mid">'
        '<div class="orb-wrap" id="orbWrap">'
        '<div class="orb" id="orb">'
        '<span class="badge-inline">CORE</span>'
        '<div class="h">数字员工「智能协同官」</div>'
        '<div class="s">SMART · ORCHESTRATION · HUB</div>'
        '</div></div></div>'
        '<div class="flow" id="flow">'
        '<div class="step n1"><span class="idx">1</span>数据采集</div>'
        '<div class="arrow a1">▶</div>'
        '<div class="step n2"><span class="idx">2</span>智能校验</div>'
        '<div class="arrow a2">▶</div>'
        '<div class="step n3"><span class="idx">3</span>深度分析</div>'
        '<div class="arrow a3">▶</div>'
        '<div class="step n4"><span class="idx">4</span>报告触达</div>'
        '<div class="arrow a4">▶</div>'
        '<div class="step n5"><span class="idx">5</span>持续改进</div>'
        '</div>'
        '<div class="loop-zone">'
        '<svg class="loopback" viewBox="0 0 1104 22" preserveAspectRatio="none">'
        '<path d="M 1060 4 C 1060 20, 44 20, 44 4"/>'
        '<polygon class="arrow-head" points="44,0 38,10 50,10"/>'
        '</svg>'
        '<div class="loopcap">采集 — 校验 — 分析 — 触达 — 改进 · 持续正向循环</div>'
        '</div>'
        '<svg class="connector" id="connector" preserveAspectRatio="none">'
        '<defs>'
        # 渐变 stop 全部走主题 --fs-* token,连线颜色跟随色卡(accent/cyan/teal
        # 皆由 build-theme.py 从用户主色 OKLCH 派生,所以换任何客户配色都成立)。
        # SVG <stop stop-color> 支持 CSS custom properties(现代 Chromium 已实现)。
        '<linearGradient id="lineGrad" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="360">'
        '<stop offset="0%"   stop-color="var(--fs-accent)" stop-opacity=".95"/>'
        '<stop offset="50%"  stop-color="var(--fs-cyan)"   stop-opacity=".95"/>'
        '<stop offset="100%" stop-color="var(--fs-teal)"   stop-opacity=".95"/>'
        '</linearGradient>'
        '</defs>'
        '<g id="lineHost"></g>'
        '</svg>'
        '<svg class="sparks" id="sparks" preserveAspectRatio="none">'
        '<g id="sparkHost"></g>'
        '</svg>'
        '</div>'
        + E2_DRAW_JS
    ),
}

ORDER = ["a", "b", "c", "d", "e", "e2", "f", "g"]

# 页脚品牌文字(内容页不放 LOGO 图,改文字)
# 品牌串拆成「企业名称」前缀 + 固定后缀:企业名称由 Step 1 确认闸门注入
# (--company-name / 环境变量 DECK_COMPANY_NAME),缺省保持占位「企业名称」以向后兼容;
# 后缀恒定不变。BRAND_FOOT 仍作为模块级默认常量导出(向后兼容),但 page() 渲染时
# 会通过 current_brand_foot() 读取运行期注入的企业名称,保证逐页 render 与整卷 compose
# 都拿到正确企业名称(单一样式源不变,只是让署名前缀可注入)。
DEFAULT_COMPANY_NAME = "企业名称"
BRAND_SUFFIX = " × 飞书 · AI 先锋大赛"


def brand_foot(company_name=None):
    """拼出页脚署名:<企业名称> × 飞书 · AI 先锋大赛"""
    name = (company_name or DEFAULT_COMPANY_NAME).strip() or DEFAULT_COMPANY_NAME
    return name + BRAND_SUFFIX


def current_brand_foot():
    """运行期取当前生效的页脚署名:优先环境变量 DECK_COMPANY_NAME,否则占位。"""
    return brand_foot(os.environ.get("DECK_COMPANY_NAME"))


BRAND_FOOT = brand_foot()

# 内容页样式:全部走 --fs-* token,自动跟随浅/深。中性色仅限确认物料外壳。
CONTENT_CSS = """
  /* ============ 内容页 shell(所有模块共享,继承 corner 视觉语言) ============ */
  .page { position:relative; width:1280px; height:720px; border-radius:16px; overflow:hidden;
          background:var(--fs-grad-mesh-page, var(--fs-grad-mesh)); isolation:isolate;
          box-shadow:0 24px 60px -12px rgba(0,0,0,.34), 0 2px 8px rgba(0,0,0,.10);
          display:flex; flex-direction:column; padding:66px 88px 52px;
          font-family:"FZLanTingHei-R-GB18030","方正兰亭黑_GB18030","FZLanTingHeiGB",
                      system-ui,"Noto Sans SC","PingFang SC",sans-serif;
          color:var(--fs-text); }
  .page::before { content:""; position:absolute; inset:0; z-index:1; pointer-events:none;
          background:var(--fs-grad-sheen); mix-blend-mode:screen; opacity:.8; }
  .page::after { content:""; position:absolute; inset:0; z-index:6; pointer-events:none;
          border-radius:16px; box-shadow:inset 0 1px 0 rgba(255,255,255,.2),
          inset 0 0 0 1px var(--fs-glass-border); }
  .page > * { position:relative; z-index:3; }
  .page .eyebrow { font-size:13px; letter-spacing:.3em; text-transform:uppercase;
          font-weight:700; color:var(--fs-accent); display:inline-flex; align-items:center;
          gap:10px; }
  .page .eyebrow::before { content:""; width:2px; height:14px; border-radius:2px;
          background:var(--fs-grad-keyline); }
  .page h2.ptitle { font-size:26px; font-weight:800; margin-top:15px; letter-spacing:-.01em;
          color:var(--fs-text); line-height:1.2; }
  .page .ptick { width:101px; height:3px; border-radius:3px; margin-top:15px;
          background:var(--fs-grad-keyline); box-shadow:0 0 12px var(--fs-glow-accent); }
  .page .content { flex:1; margin-top:30px; min-height:0; display:flex; }
  .page .pfoot { display:flex; align-items:center; justify-content:space-between;
          font-size:12px; color:var(--fs-text-65); margin-top:18px; }
  .page .pfoot .brand { letter-spacing:.04em; }
  .page .pfoot .pageno { font-variant-numeric:tabular-nums; letter-spacing:.08em; }
  .page .pfoot .pageno b { color:var(--fs-accent); }

  /* ---------------- a) 小故事 / 情境切入:左大引语 + 右梯形复合素描 ---------------- */
  /* 左半:pull-quote(大引号 + 引语 + 署名);右半:梯形复合页面风格的素描故事背景。 */
  .m-a { flex:1; display:flex; align-items:stretch; gap:48px; position:relative; }
  /* 左半:pull-quote —— 支持两种「不显空」的排布方式(用户可选,由 .m-a 修饰类切换):
     公共几何(两种方式都遵守的边界):
     · .quote align-self:stretch 吃满 .m-a 全高(= 右侧素描图全高),position:relative 作定位基准。
     · 引号左右锚点恒定:开引号左边 = 标题左边(left:0);闭引号右边 = 右图最左边再隔 1 字(伸进 gap)。
     · 引语与右图水平居中(justify-content:center → 引语中线 = 素描图中线);署名 .by 绝对定位左下角。

     [方式 2 · fill] 固定引号位置 + 文字字体动态填充:
     · 开引号顶 = 右图上边(top:9px)、闭引号底 = 右图下边(bottom:9px)——引号钉死在图的上下边。
     · 中间引语字号由取材器按字数动态计算(内联 font-size),把文字区域填满,不显空。

     [方式 1 · hug(.m-a.hug · 默认)] 引号随文字动态贴合 + 上下不越界:
     · 引号回到正常流,紧贴引语上下(开引号在引语正上、闭引号在引语正下),整组垂直居中。
     · 文字少 → 引号靠拢;文字多 → 引号张开,但整组恒在 .quote(=图高)内,永不超出图的上下边。 */
  .m-a .quote { flex:1 1 auto; min-width:0; align-self:stretch; position:relative;
         display:flex; flex-direction:column; justify-content:center; align-items:flex-start; }
  .m-a .qmark { position:absolute; font-size:104px; line-height:.8; font-weight:800;
         color:var(--fs-accent); opacity:.22; letter-spacing:-.02em; }
  /* 方式 2(默认):引号钉死在右图上下边 */
  .m-a .qmark.open { top:9px; left:0; }
  .m-a .qmark.close { bottom:9px; right:-27px; }
  /* 引语字号采取自适应策略(LEAD_FIT_JS 会按 quote 容器高度在 [22,48]px 之间动态调节);
     短句 -> 更大字号,长段 -> 更小字号。此处保留 CSS 基线仅作首帧兜底(与 .m-d .pcol .lead
     的视觉规范同源:较大字号、粗体、-1% 字距、行高 1.45)。 */
  .m-a .lead { font-size:34px; line-height:1.45; font-weight:700;
         color:var(--fs-text); letter-spacing:-.01em; }
  .m-a .lead .kw { color:var(--fs-accent); font-weight:800; }
  /* 署名抽出为绝对定位(左下角),不影响引语与右图的垂直居中 */
  .m-a .by { position:absolute; left:0; bottom:8px; font-size:15px;
         color:var(--fs-text-65); font-weight:600; }

  /* 方式 1 · hug:引号随文字贴合、整组居中、上下不越界 */
  .m-a.hug .quote { justify-content:center; align-items:stretch; }
  .m-a.hug .qmark { position:static; line-height:.55; }
  .m-a.hug .qmark.open { align-self:flex-start; margin:0 0 -12px -2px; }
  .m-a.hug .qmark.close { align-self:flex-end; margin:-4px -16px 0 0; }
  /* 署名仍绝对定位左下角,不参与「引号+引语」整组的垂直居中(否则会把中线顶偏) */
  .m-a.hug .by { position:absolute; left:0; bottom:8px; margin-top:0; }
  /* 右半:梯形复合素描面板 —— 严格几何约束(用户硬约束):
     · 高(长)= 标题下方到页码上方 = .content 全高。.m-a flex:1 撑满 .content,
       本面板 align-self:stretch 吃满 .m-a 全高 → 顶到标题下、底到页码上。
     · 宽 = 页面(1280px)的 1/3 ~ 2/5 之间。取 462px(≈0.361·1280,落在 [426,512] 区间内),
       flex:0 0 462px 固定不伸缩,严格锁死宽度。
     错位叠影(复合页面层次)+ accent 描边底板 + 色卡主色单色素描(不再灰度/叠色)。 */
  .m-a .sketch { flex:0 0 462px; align-self:stretch; position:relative; }
  /* 错位第二张梯形卡:营造「复合页面」的叠层纵深 */
  .m-a .sketch::before { content:""; position:absolute; inset:22px -12px 6px 26px;
         clip-path:polygon(15% 0,100% 0,85% 100%,0 100%);
         background:var(--fs-glass); border:1px solid var(--fs-glass-border); opacity:.55; }
  /* accent 描边底板:比画面略大,露出一圈作梯形描边 */
  .m-a .sketch .plate { position:absolute; inset:6px 0 6px 8px;
         clip-path:polygon(13% 0,100% 0,87% 100%,0 100%);
         background:var(--fs-grad-keyline); box-shadow:0 18px 44px -16px var(--fs-glow-accent); }
  /* 梯形画框:承载素描,内缩露出 accent 边 */
  .m-a .sketch .frame { position:absolute; inset:9px 3px 9px 11px;
         clip-path:polygon(13% 0,100% 0,87% 100%,0 100%);
         background:var(--fs-bg-1); overflow:hidden; }
  /* 素描本体已用色卡主色作画(单色铅笔),不再强制灰度/叠色;仅轻微提对比保线稿清晰。 */
  .m-a .sketch .frame img { width:100%; height:100%; object-fit:cover; display:block;
         filter:contrast(1.04); }
  /* 缺图占位(确认物料 / 无素描时的回退) */
  .m-a .sketch .frame .ph { position:absolute; inset:0; display:flex; align-items:center;
         justify-content:center; text-align:center; padding:0 12%; font-size:13px;
         letter-spacing:.08em; color:var(--fs-text-48);
         background-image:repeating-linear-gradient(-38deg,transparent 0 16px,
           var(--fs-hairline) 16px 17px); }

  /* ---------------- b) 团队介绍:稀疏信息版(跨部门联合战队) ---------------- */
  /* 结构固定、重心居中偏上:team-hero(队名主角 左 + 跨部门带 右,固定高) →
     team-tagline(一句话介绍,固定) → roster(花名册,固定 margin-top,不吊底)。
     队长/队员同尺寸同形制卡片,仅一枚轻量身份徽章区分,不放大队长。
     配色 100% 跟随色卡(glass / grad-keyline / grad-title / glow-*),零写死 hex。 */
  .m-b { flex:1; display:flex; flex-direction:column; }

  /* 上半:队名主角(左) + 跨部门联合带(右)——**固定高度**,保证下方一句话/花名册
     位置恒定不随部门数(2→5)或队名长短上下窜动。5 部门带自动换行仍容纳于此高度内。 */
  .m-b .team-hero { display:flex; align-items:flex-start; justify-content:space-between;
         gap:48px; height:118px; }
  .m-b .name-wrap { flex:0 1 auto; max-width:46%; min-width:0; }
  .m-b .name-wrap .tlabel { font-size:13px; letter-spacing:.22em;
         color:var(--fs-text-48); font-weight:700; }
  .m-b .tname { font-size:58px; font-weight:800; line-height:1.04; letter-spacing:.01em;
         margin-top:10px; white-space:nowrap; background:var(--fs-grad-title);
         -webkit-background-clip:text; background-clip:text;
         -webkit-text-fill-color:transparent; }

  /* 跨部门联合带:右上定位;支持最多 ~5 个部门,自动换行右对齐(≤2 行,容于 hero 固定高) */
  .m-b .depts-wrap { flex:1 1 auto; display:flex; flex-direction:column;
         align-items:flex-end; gap:8px; padding-top:6px; max-width:52%; }
  .m-b .depts-wrap .dlabel { font-size:12px; letter-spacing:.18em;
         color:var(--fs-text-40); font-weight:700; }
  .m-b .depts { display:flex; align-items:center; gap:8px 10px; flex-wrap:wrap;
         justify-content:flex-end; }
  .m-b .dept { display:inline-flex; align-items:center; gap:8px; padding:9px 16px;
         border-radius:999px; background:var(--fs-glass);
         border:1px solid var(--fs-glass-border);
         -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
         box-shadow:0 8px 22px -12px rgba(0,0,0,.24);
         font-size:16px; font-weight:800; color:var(--fs-text); white-space:nowrap; }
  .m-b .dept .dot { width:8px; height:8px; border-radius:50%;
         background:var(--fs-grad-keyline); box-shadow:0 0 9px var(--fs-glow-primary); }
  .m-b .plus { font-size:16px; font-weight:800; color:var(--fs-text-40); }

  /* 一句话介绍:外层 .team-tagline 固定高度(预留 2 行)以锁死花名册位置不随文字长短窜动;
     竖线 + 文字放在内层 .tag-inner,竖线**贴合实际文字高度**(短句 1 行即 1 行高,不撑满预留框)。 */
  .m-b .team-tagline { margin-top:20px; height:26px; }
  .m-b .team-tagline .tag-inner { font-size:16px; color:var(--fs-text-65);
         line-height:1.6; padding-left:16px; border-left:3px solid transparent;
         border-image:var(--fs-grad-keyline) 1; max-width:80%;
         max-height:26px; overflow:hidden; display:-webkit-box; -webkit-line-clamp:1;
         -webkit-box-orient:vertical; }

  /* 花名册:固定位置(固定 margin-top,不吊底)。队长 + 队员统一同尺寸同形制卡片,
     一行平铺 flex:1 均分,仅用一枚轻量身份徽章区分身份——不放大队长。 */
  .m-b .roster { margin-top:44px; display:flex; align-items:stretch; gap:18px; }
  .m-b .rcard { flex:1 1 0; border-radius:16px; padding:22px 16px 20px;
         display:flex; flex-direction:column; align-items:center; text-align:center;
         background:var(--fs-glass); border:1px solid var(--fs-glass-border);
         -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
         box-shadow:0 6px 20px -10px rgba(0,0,0,.2); }

  /* 身份徽章:队长实心主色胶囊、队员描边胶囊——仅此一处区分,权重克制 */
  .m-b .badge-role { font-size:12px; font-weight:800; letter-spacing:.12em;
         padding:6px 16px; border-radius:999px; white-space:nowrap; }
  .m-b .badge-role.captain { color:#fff; background:var(--fs-grad-keyline);
         box-shadow:0 4px 12px -3px var(--fs-glow-primary); }
  .m-b .badge-role.member { color:var(--fs-accent); background:transparent;
         border:1px solid var(--fs-glass-border); }

  /* 头像 = 默认「素描人像」(预置 6 张亚洲面孔,取材器内联为 data:URI,填满圆盘);
     用户可在浏览器里点头像上传替换(见 .ava 的 <label>/<input>,纯客户端 FileReader)。
     无图时优雅回退到确定性首字徽章 .mono(渐变盘 + 白色首字,纯 CSS 零依赖)。 */
  .m-b .ava { position:relative; width:64px; height:64px; border-radius:50%;
         margin:15px 0 12px; display:block; cursor:pointer; overflow:hidden;
         flex:0 0 auto; background:var(--fs-grad-keyline);
         box-shadow:0 0 16px var(--fs-glow-primary); }
  .m-b .ava img { width:100%; height:100%; object-fit:cover; border-radius:50%;
         display:block; }
  .m-b .ava .mono { position:absolute; inset:0; border-radius:50%;
         display:flex; align-items:center; justify-content:center;
         color:#fff; font-size:26px; font-weight:800;
         background:var(--fs-grad-keyline); letter-spacing:.02em; }
  .m-b .ava .up { position:absolute; left:0; right:0; bottom:0; height:22px;
         line-height:22px; font-size:12px; font-weight:700; letter-spacing:.06em;
         text-align:center; color:#fff; background:rgba(0,0,0,.42);
         opacity:0; transition:opacity .15s ease; }
  .m-b .ava:hover .up { opacity:1; }
  .m-b .ava input[type=file] { position:absolute; inset:0; opacity:0;
         width:100%; height:100%; cursor:pointer; }
  .m-b .rname { font-size:16px; font-weight:700; color:var(--fs-text); }
  .m-b .rsub { font-size:12px; color:var(--fs-text-48); margin-top:6px;
         letter-spacing:.04em; }

  /* ---------------- c) 背景 Why:左案例背景段落 + 右数字卡片(3–5,含动效) ---------------- */
  /* align-items:flex-start 顶对齐:左段落 / 右卡片区 top 恒定,内容长短只向下生长、不垂直居中窜动 */
  .m-c { flex:1; display:flex; gap:60px; align-items:flex-start; padding-top:34px; }
  /* 左:案例背景(精炼,≤3 段),关键词 .kw 高亮。
     v0.2.11-r8:align-self:stretch + min-height:0 + overflow:hidden 让 .lead 吃满内容区
     高度、成为 LEAD_FIT_JS 的高度预算 —— 长段落溢出时收缩分支才有可比较的 clientHeight
     可依(此前 flex-start 下 .lead 自适应高度、scrollHeight 恒等 clientHeight,收缩永不触发)。 */
  .m-c .lead { flex:0 0 50%; align-self:stretch; min-height:0; overflow:hidden; }
  /* 段落字号采取自适应策略(LEAD_FIT_JS 会按 .m-c .lead 容器高度在 [17,28]px 之间动态调节);
     短段 -> 更大字号,长段 -> 更小字号。CSS 基线仅作首帧兜底。 */
  .m-c .lead p { font-size:22px; line-height:1.72; font-weight:500; color:var(--fs-text-72);
         letter-spacing:-.005em; }
  .m-c .lead p + p { margin-top:16px; }
  .m-c .lead .kw { color:var(--fs-text); font-weight:800; }
  /* 右:数字卡片区(3–5 张,纵向一列,top 固定顶对齐)。列拉伸占满内容区高度,卡片本身
     flex:0 1 auto——常见 3 张时取自然高度、顶对齐、下方留白(与 proto 一致的疏朗质感);
     4–5 张挤到超出可用高度时才等比收缩以塞下,绝不溢出页脚(min-height:0 允许收缩)。 */
  .m-c .cards { flex:1; display:flex; flex-direction:column; gap:16px; align-self:stretch; }
  .m-c .stat { position:relative; display:flex; align-items:center; gap:22px; overflow:hidden;
         background:var(--fs-glass); border:1px solid var(--fs-glass-border); border-radius:16px;
         padding:20px 26px; flex:0 1 auto; min-height:0;
         -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
         box-shadow:0 10px 30px -14px var(--fs-glow-accent);
         opacity:0; transform:translateY(16px);
         animation:mcCardIn .7s cubic-bezier(.22,.9,.32,1) forwards; }
  .m-c .stat:nth-child(1) { animation-delay:.15s; }
  .m-c .stat:nth-child(2) { animation-delay:.32s; }
  .m-c .stat:nth-child(3) { animation-delay:.49s; }
  .m-c .stat:nth-child(4) { animation-delay:.66s; }
  .m-c .stat:nth-child(5) { animation-delay:.83s; }
  .m-c .stat::before { content:""; position:absolute; left:0; top:0; bottom:0; width:4px;
         background:var(--fs-grad-keyline); }
  /* 数字卡:放大关键数字(渐变色)。用 --fs-grad-title(主题已定义);proto 里的 --fs-grad-num
     未在 theme token 中定义,直接沿用会导致数字透明不可见,故此处保留 title 渐变。 */
  .m-c .stat .num { flex:0 0 auto; min-width:118px; font-weight:800; line-height:.9;
         letter-spacing:-.03em; display:flex; align-items:baseline;
         background:var(--fs-grad-title); -webkit-background-clip:text; background-clip:text;
         -webkit-text-fill-color:transparent; }
  .m-c .stat .num .v { font-size:68px; }
  .m-c .stat .num .u { font-size:28px; font-weight:800; margin-left:3px; }
  .m-c .stat .meta { flex:1; min-width:0; }
  .m-c .stat .meta .t { font-size:15px; font-weight:800; color:var(--fs-text); line-height:1.35; }
  .m-c .stat .meta .d { font-size:12.5px; color:var(--fs-text-48); margin-top:5px; line-height:1.45; }
  /* 文字卡(无数字兜底):无 .num,但 .meta .t 内用 .kw 高亮重点 */
  .m-c .stat.txt .meta .t .kw { color:var(--fs-accent); }
  @keyframes mcCardIn { to { opacity:1; transform:translateY(0); } }

  /* ---------------- d) 痛点 · 场景1(文档痛点带截图):左文右图 ----------------
     标题即痛点(由 shell 的 h2.ptitle 承载,全宽在上)。左列(定宽 40%):巨号 .bignum
     ——**痛点序号 01/02/03…**(该痛点在所有痛点页中的第几个,零填充两位,静态渐变字;
     **不是**内容指标,内容数字走 .lead/.kpts 内联 stat)→ 一句话重点描述(放大、.kw
     高亮)→ 该痛点 key point 玻璃底板(margin-top:auto 沉到左列底部、与右图底边对齐,
     消除下方空白);右列(v0.2.11):截图容器 .shots.s{k} 支持 1–4 张自适应网格,
     镜像 .m-f 的 shots 版式,每格 object-fit:contain 不裁切/不变形。
     配色全走令牌,零写死 hex。 */
  .m-d { flex:1; display:flex; align-items:stretch; gap:44px; }
  .m-d .pcol { flex:0 0 40%; display:flex; flex-direction:column; min-width:0; }
  .m-d .pcol .bignum { font-size:52px; font-weight:800; line-height:.9; letter-spacing:-.03em;
         background:var(--fs-grad-title); -webkit-background-clip:text; background-clip:text;
         -webkit-text-fill-color:transparent; opacity:.92; }
  .m-d .pcol .lead { font-size:21px; line-height:1.55; color:var(--fs-text); margin-top:16px;
         font-weight:600; }
  .m-d .pcol .lead .kw { color:var(--fs-accent); font-weight:800; }
  .m-d .pcol .kpts { list-style:none; margin-top:auto; margin-bottom:auto; padding:24px 26px;
         background:var(--fs-glass); border:1px solid var(--fs-glass-border); border-radius:16px;
         -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
         box-shadow:0 10px 30px -14px var(--fs-glow-accent);
         display:flex; flex-direction:column; gap:15px; }
  .m-d .pcol .kpts li { font-size:16.5px; line-height:1.5; color:var(--fs-text-72);
         padding-left:26px; position:relative; }
  .m-d .pcol .kpts li::before { content:""; position:absolute; left:0; top:8px; width:10px; height:10px;
         border-radius:2px; background:var(--fs-grad-keyline);
         box-shadow:0 0 8px var(--fs-glow-accent); }
  /* 右列:方案痛点截图(v0.2.11 对齐 v9.8.9 多图逻辑)。张数 1–4 自适应:.shots.s{k}
     决定网格。1 图铺满居中;2 图上下均分;3 图特殊——首两张并排一行,第三张独占底
     行铺满(不留 2×2 的空位);4 图 2×2。每格 object-fit:contain 不裁切/不变形,
     圆角 + 轻投影提亮;占位态 .ph 自带虚线框以示区域。 */
  .m-d .shots { flex:1; min-width:0; min-height:0; display:grid; gap:16px;
         grid-template-columns:1fr; grid-auto-rows:1fr; }
  .m-d .shots.s2 { grid-template-columns:1fr; grid-template-rows:1fr 1fr; }
  .m-d .shots.s4 { grid-template-columns:1fr 1fr; grid-template-rows:1fr 1fr; }
  /* 3 图:2 列 2 行,第三张跨两列铺满底行,消除末位留白 */
  .m-d .shots.s3 { grid-template-columns:1fr 1fr; grid-template-rows:1fr 1fr; }
  .m-d .shots.s3 .shot:nth-child(3) { grid-column:1 / -1; }
  .m-d .shot { min-width:0; min-height:0; display:flex;
         align-items:center; justify-content:center; }
  .m-d .shot img { max-width:100%; max-height:100%; width:auto; height:auto;
         object-fit:contain; display:block; border-radius:14px;
         box-shadow:0 18px 40px -20px var(--fs-glow-accent); }
  .m-d .shots.s1 .shot .ph { width:92%; aspect-ratio:16/9; }
  .m-d .shot .ph { width:100%; height:100%; display:flex;
         align-items:center; justify-content:center;
         font-size:14px; color:var(--fs-text-48); letter-spacing:.08em;
         border-radius:14px; border:1px dashed var(--fs-hairline); }

  /* 缺料硬警告(v0.2.5):红字/红边框/闪烁,visually impossible to miss */
  .page .ph.err { color:#d63030 !important; border-color:#d63030 !important;
         border-style:solid !important; border-width:2px !important;
         background:rgba(214,48,48,.06); font-weight:800 !important;
         letter-spacing:.02em !important; text-transform:none !important;
         animation:phErrPulse 1.8s ease-in-out infinite; }
  @keyframes phErrPulse { 0%,100% { box-shadow:0 0 0 0 rgba(214,48,48,.35); }
         50% { box-shadow:0 0 0 6px rgba(214,48,48,0); } }

  /* ---------------- d) 痛点 · 场景2(文档痛点无截图):上下布局 ----------------
     标题即痛点(由 shell 的 h2.ptitle 承载,全宽在上)。上半(≈1/3):1–2 句话重点描述
     (放大、.kw 高亮);下半(≈2/3):自适应卡片网格 .cards,2–8 张,按张数自动定列数、
     **最多 2 行**,末行左对齐、等高、均匀间距,绝不溢出页脚(网格列数由取材器按张数写进
     内联 grid-template-columns:≤3 张单行 n 列,≥4 张两行 ⌈n/2⌉ 列)。卡片:大数字
     (count-up 渐变)→ 重点标题 → 一句补充;无数字卡为纯文字(标题 + 补充),对齐一致。
     卡片错峰入场(复用 mcCardIn)+ hover 微光。配色全走令牌,零写死 hex。 */
  .m-d2 { flex:1; display:flex; flex-direction:column; gap:22px; min-height:0; }
  /* 上半:固定占内容区约 1/3 的带(reserve),句子顶对齐。固定带 → 无论 1 句还是 2 句,
     下半卡片网格的起始 top 都不漂移(位置固定),下半恒得 ≈2/3 → 2–8 张永远 ≤2 行。 */
  .m-d2 .intro { flex:0 0 30%; min-height:0; display:flex; flex-direction:column;
         justify-content:flex-start; }
  /* 标题正下方巨号 .bignum —— **痛点序号** 01/02/03…(零填充两位,静态渐变字,不 count-up),
     与场景 1(.m-d .pcol .bignum)复用同一视觉规范(var(--fs-grad-title) 渐变、52px/800)。
     置于 intro 固定 30% 高度带的**首元素**(标题下方、一句话之上)→ 不改变下半卡片网格 .cards
     的起始位置与高度(零版式回归)。序号取值同 module d:--seq > kicker 末尾数字 > --bignum。 */
  .m-d2 .intro .bignum { flex:0 0 auto; font-size:52px; font-weight:800; line-height:.9;
         letter-spacing:-.03em; margin-bottom:8px;
         background:var(--fs-grad-title); -webkit-background-clip:text; background-clip:text;
         -webkit-text-fill-color:transparent; opacity:.92; }
  .m-d2 .intro p { font-size:22px; line-height:1.55; color:var(--fs-text); font-weight:600;
         letter-spacing:-.005em; max-width:96%; }
  .m-d2 .intro p + p { margin-top:10px; }
  .m-d2 .intro .kw { color:var(--fs-accent); font-weight:800; }
  /* 卡片网格:列数由取材器按张数内联(grid-template-columns),此处只定通用行为——
     等高(grid-auto-rows:1fr)、均匀间距、末行左对齐(grid 自左向右天然左对齐)。 */
  .m-d2 .cards { flex:1; min-height:0; display:grid; gap:18px; grid-auto-rows:1fr;
         align-content:stretch; }
  .m-d2 .card { position:relative; overflow:hidden; display:flex; flex-direction:column;
         gap:9px; background:var(--fs-glass); border:1px solid var(--fs-glass-border);
         border-radius:16px; padding:22px 24px; min-width:0; min-height:0;
         -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
         box-shadow:0 10px 30px -14px var(--fs-glow-accent);
         opacity:0; transform:translateY(14px);
         animation:mcCardIn .7s cubic-bezier(.22,.9,.32,1) forwards;
         transition:transform .25s ease, box-shadow .25s ease; }
  .m-d2 .card:nth-child(1) { animation-delay:.10s; }
  .m-d2 .card:nth-child(2) { animation-delay:.19s; }
  .m-d2 .card:nth-child(3) { animation-delay:.28s; }
  .m-d2 .card:nth-child(4) { animation-delay:.37s; }
  .m-d2 .card:nth-child(5) { animation-delay:.46s; }
  .m-d2 .card:nth-child(6) { animation-delay:.55s; }
  .m-d2 .card:nth-child(7) { animation-delay:.64s; }
  .m-d2 .card:nth-child(8) { animation-delay:.73s; }
  .m-d2 .card::before { content:""; position:absolute; left:0; top:0; bottom:0; width:4px;
         background:var(--fs-grad-keyline); opacity:.85; transition:opacity .25s ease; }
  /* hover 微光:整卡轻抬 + 左侧重点线加亮(不循环,静态时优雅、悬停时提亮) */
  .m-d2 .card:hover { transform:translateY(-4px);
         box-shadow:0 20px 46px -16px var(--fs-glow-accent); }
  .m-d2 .card:hover::before { opacity:1; }
  /* 数字(渐变、count-up),沿用 --fs-grad-title(--fs-grad-num 未定义) */
  .m-d2 .card .num { flex:0 0 auto; font-weight:800; line-height:.9; letter-spacing:-.03em;
         display:flex; align-items:baseline;
         background:var(--fs-grad-title); -webkit-background-clip:text; background-clip:text;
         -webkit-text-fill-color:transparent; }
  .m-d2 .card .num .v { font-size:46px; }
  .m-d2 .card .num .u { font-size:20px; font-weight:800; margin-left:3px; }
  .m-d2 .card .t { font-size:16px; font-weight:800; color:var(--fs-text); line-height:1.38; }
  .m-d2 .card .t .kw { color:var(--fs-accent); }
  .m-d2 .card .d { font-size:13px; color:var(--fs-text-48); line-height:1.5; margin-top:auto; }
  /* 纯文字卡 .card.txt(C+D:能量化就上数字,纯文字则退化为"短词焦点"):
     顶部一个 2–4 字"短词精华".key —— 与数字 .num .v 视觉**同高**、同 var(--fs-grad-title) 渐变、
     顶对齐,充当"准数字"焦点;下面只接补充 .d(短词即标题的提炼,不再单列重复标题层)。
     注:中文方块字在同 px 下墨迹高度 ≈ 数字的 1/0.783(数字墨迹仅占 em 的 ~78%),
     故 .key 字号 = 数字字号 × 0.783 才能视觉等高:46×0.783≈36、66×0.783≈52。 */
  .m-d2 .card.txt .key { flex:0 0 auto; font-weight:800; line-height:1; letter-spacing:-.02em;
         font-size:36px;
         background:var(--fs-grad-title); -webkit-background-clip:text; background-clip:text;
         -webkit-text-fill-color:transparent; }
  /* 单行场景(≤3 张,取材器给 .cards 加 .single):卡片顶位置不变、高度降到约 2/3
     (align-content:start 顶对齐 + grid-auto-rows 显式约 2/3,只向下收、顶不漂),
     字体整体放大,数字放大幅度最大(> 普通文字)。多行场景不带 .single,维持原满高/常规字号。 */
  .m-d2 .cards.single { align-content:start; grid-auto-rows:66%; }
  .m-d2 .cards.single .card .num .v { font-size:66px; }
  .m-d2 .cards.single .card .num .u { font-size:27px; }
  .m-d2 .cards.single .card .t { font-size:21px; line-height:1.34; }
  .m-d2 .cards.single .card .d { font-size:16px; line-height:1.5; }
  .m-d2 .cards.single .card.txt .key { font-size:50px; }

  /* ---------------- e) 方案全景 · 上文 + 下(左截图 · 右总结卡片)----------------
     标题即方案要旨(shell h2.ptitle 全宽在上)。
     上半 .intro = 紧凑说明带(顶对齐,高度随文自适应):1–2 句方案文字说明(放大、.kw 高亮
     关键词);下半 .ebody = 横向两栏:左 .shotwrap>.shot = 该方案的**大截图**(随图片本身
     长宽自适应贴合 contain,任意长宽比不裁切不溢出,圆角+轻投影,无底板,占位态 .ph 同款轻框),
     右 .esum = 对截图内容的 **3–4 点总结卡片**——每点即后续方案细节页的标题,带**错峰入场动效**
     (复用 mcCardIn:opacity 0→1 + translateY 上移归位)。配色全走令牌,零写死 hex。 */
  .m-e { flex:1; display:flex; flex-direction:column; gap:16px; min-height:0; }
  .m-e .intro { flex:0 0 auto; display:flex; flex-direction:column;
         justify-content:flex-start; }
  .m-e .intro p { font-size:21px; line-height:1.5; color:var(--fs-text); font-weight:600;
         letter-spacing:-.005em; max-width:98%; }
  .m-e .intro p + p { margin-top:8px; }
  .m-e .intro .kw { color:var(--fs-accent); font-weight:800; }
  /* 下半两栏:左截图(弹性主体)+ 右总结卡片(定宽) */
  .m-e .ebody { flex:1; min-height:0; display:flex; gap:26px; align-items:stretch; }
  .m-e .shotwrap { flex:1; min-width:0; min-height:0; display:flex;
         align-items:center; justify-content:center; }
  .m-e .shot { width:100%; height:100%; min-width:0; min-height:0;
         display:flex; align-items:center; justify-content:center; }
  .m-e .shot img { max-width:100%; max-height:100%; width:auto; height:auto;
         object-fit:contain; display:block; border-radius:14px;
         box-shadow:0 18px 40px -20px var(--fs-glow-accent); }
  .m-e .shot .ph { width:92%; aspect-ratio:16/9; display:flex;
         align-items:center; justify-content:center;
         font-size:14px; color:var(--fs-text-48); letter-spacing:.08em;
         border-radius:14px; border:1px dashed var(--fs-hairline); }
  /* 右:方案要点总结卡片(3–4 点,即后续细节页标题),错峰入场 */
  .m-e .esum { flex:0 0 34%; max-width:360px; min-width:0; align-self:stretch;
         display:flex; flex-direction:column; gap:14px; }
  /* 卡片长宽一致:column 弹性列天然等宽,再以 flex:1 1 0 均分列高 → 每张等高,
     与文字长短无关(min-height:0 允许收缩,align-items:center 让短文本纵向居中) */
  .m-e .esum .epoint { position:relative; flex:1 1 0; min-height:0;
         display:flex; align-items:center; gap:14px;
         padding:15px 18px 15px 20px; border-radius:14px;
         background:var(--fs-glass); border:1px solid var(--fs-glass-border);
         -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
         opacity:0; transform:translateY(16px);
         animation:mcCardIn .7s cubic-bezier(.22,.9,.32,1) forwards; }
  .m-e .esum .epoint:nth-child(1) { animation-delay:.18s; }
  .m-e .esum .epoint:nth-child(2) { animation-delay:.34s; }
  .m-e .esum .epoint:nth-child(3) { animation-delay:.50s; }
  .m-e .esum .epoint:nth-child(4) { animation-delay:.66s; }
  .m-e .esum .epoint::before { content:""; position:absolute; left:0; top:0; bottom:0; width:4px;
         border-radius:14px 0 0 14px; background:var(--fs-grad-keyline);
         box-shadow:0 0 10px var(--fs-glow-accent); }
  .m-e .esum .epoint .idx { flex:0 0 auto; font-size:15px; font-weight:800; line-height:1.35;
         color:var(--fs-accent); font-variant-numeric:tabular-nums; }
  .m-e .esum .epoint .etxt { flex:1; min-width:0; font-size:14.5px; font-weight:700;
         line-height:1.4; color:var(--fs-text); }

  /* ---------------- e2) 架构详图 · 协同闭环 (独立一等模块 · 子技能 page-architecture) ----------------
     由 build_material_e2.py 驱动、由 verify_e2_content_position.py 3 轮把关。
     整体为 3 层纵向堆叠 + 中央 CORE + 底部回环:
       · 顶:5 张能力卡 .cap-row (等宽,capIn 错峰入场)
       · 中:.mid 弹性区 + .orb-wrap 绝对居中的 CORE 徽标 (orbIn + halo + spin)
       · 底:5 步 pill flow (stepIn/stepPing 错峰) + 4 个箭头
       · 尾:.loop-zone 独立回环虚线 (dashFlow) + loopcap 一行
     两层 SVG(.connector z=2 · .sparks z=5)由 e-2 专属 JS 精确绘制:
       userSpaceOnUse 渐变 · 竖直路径 wiggle · orb 动效结束后 setTimeout(draw,2150) 重绘。
     配色 100% 走 --fs-* token,零硬编 hex(除渐变 stop 的 fallback 三色)。
     数量硬约束: caps==5 · steps==5 · loopback==1 · orb==1(build_material_e2.py 强制)。 */
  /* v9.1 修:改 flex → grid 显式锁 5 段行序 —— intro / cap-row / mid(orb) / flow / loop-zone,
     避免以前 .mid{flex:1} 弹簧过大把 flow 挤到中上部;grid 明确 flow 恒在倒数第二段、
     loop-zone 恒在末段,与 verify_e2_content_position 新增的 y-order 硬闸门契约对齐。 */
  .m-e2 { flex:1; position:relative; display:grid;
          grid-template-rows: auto auto minmax(140px, 1fr) auto auto;
          row-gap:0; min-height:0; }
  .m-e2 .mid { min-height:0; position:relative; overflow:visible; }
  /* ---- 说明句:紧贴标题下的一句话,强调闭环三大主体 ---- */
  .m-e2 .intro { margin-top:-4px; font-size:15px; line-height:1.55;
         color:var(--fs-text-72); max-width:960px;
         opacity:1; transform:translateY(6px);
         animation:e2FadeUp .55s ease-out .15s forwards; }
  .m-e2 .intro .kw { color:var(--fs-accent); font-weight:800; }
  /* ---- 顶部 5 张能力卡 ---- */
  .m-e2 .cap-row { margin-top:14px; display:grid; grid-template-columns:repeat(5,1fr);
         gap:14px; z-index:4; }
  .m-e2 .cap-row .cap { position:relative; background:var(--fs-glass); border-radius:12px;
         padding:12px 10px 10px; text-align:center;
         box-shadow:0 1px 0 rgba(255,255,255,.9) inset, 0 8px 24px rgba(20,40,30,.08);
         opacity:1; transform:translateY(14px);
         animation:capIn .55s ease-out forwards; }
  .m-e2 .cap-row .cap::before { content:""; position:absolute; inset:0; border-radius:12px; padding:1.4px;
         background:var(--fs-grad-keyline);
         -webkit-mask:linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
         -webkit-mask-composite:xor; mask-composite:exclude; opacity:.85; pointer-events:none; }
  .m-e2 .cap-row .cap:nth-child(1) { animation-delay:.50s; }
  .m-e2 .cap-row .cap:nth-child(2) { animation-delay:.62s; }
  .m-e2 .cap-row .cap:nth-child(3) { animation-delay:.74s; }
  .m-e2 .cap-row .cap:nth-child(4) { animation-delay:.86s; }
  .m-e2 .cap-row .cap:nth-child(5) { animation-delay:.98s; }
  .m-e2 .cap-row .cap .ico { width:26px; height:26px; margin:2px auto 6px; border-radius:8px;
         background:var(--fs-grad-keyline); display:flex; align-items:center; justify-content:center;
         color:#fff; font-weight:800; font-size:13px; box-shadow:0 4px 12px var(--fs-glow-primary); }
  .m-e2 .cap-row .cap .h { font-size:14.5px; font-weight:700; color:var(--fs-text); line-height:1.3; }
  .m-e2 .cap-row .cap .s { margin-top:3px; font-size:11px; color:var(--fs-text-48); letter-spacing:.02em; }
  /* ---- 中央 CORE orb (在 .mid 内绝对居中) ---- */
  .m-e2 .orb-wrap { position:absolute; left:50%; top:50%; transform:translate(-50%,-50%);
         z-index:4; }
  .m-e2 .orb { position:relative; width:296px; height:110px; border-radius:14px;
         background:linear-gradient(135deg,var(--fs-blue) 0%,var(--fs-cyan) 60%,var(--fs-purple) 100%);
         color:#fff; display:flex; flex-direction:column;
         align-items:center; justify-content:center;
         box-shadow:0 18px 50px rgba(20,40,30,.28), 0 0 0 1px rgba(255,255,255,.25) inset;
         opacity:1; transform:scale(.9);
         animation:orbIn .8s cubic-bezier(.2,.9,.3,1.25) 1.15s forwards;
         z-index:4; overflow:hidden; }
  .m-e2 .orb::before { content:""; position:absolute; inset:0; border-radius:14px;
         background:radial-gradient(closest-side, rgba(255,255,255,.38), transparent 65%);
         z-index:0; animation:halo 3.2s ease-in-out 1.6s infinite; pointer-events:none; }
  .m-e2 .orb::after { content:""; position:absolute; inset:6px; border-radius:10px;
         background:conic-gradient(from 0deg, transparent 0deg, rgba(255,255,255,.5) 30deg, transparent 60deg, transparent 360deg);
         -webkit-mask:radial-gradient(farthest-side, transparent calc(100% - 2.5px), #000 calc(100% - 2.5px));
         mask:radial-gradient(farthest-side, transparent calc(100% - 2.5px), #000 calc(100% - 2.5px));
         opacity:.55; animation:spin 5s linear 1.6s infinite; pointer-events:none; }
  .m-e2 .orb .badge-inline { display:inline-block; background:rgba(255,255,255,.22);
         color:#fff; padding:2px 10px; border-radius:99px;
         font-size:10px; font-weight:800; letter-spacing:.22em; margin-bottom:6px;
         border:1px solid rgba(255,255,255,.35); position:relative; z-index:1; }
  .m-e2 .orb .h { font-size:18px; font-weight:800; letter-spacing:.5px; position:relative; z-index:1; }
  .m-e2 .orb .s { margin-top:4px; font-size:10.5px; opacity:.9; letter-spacing:.22em; position:relative; z-index:1; }
  /* ---- 连线 SVG:两层(lines under · sparks over) ---- */
  .m-e2 .connector { position:absolute; inset:0; width:100%; height:100%;
         z-index:2; pointer-events:none; }
  .m-e2 .sparks    { position:absolute; inset:0; width:100%; height:100%;
         z-index:5; pointer-events:none; }
  .m-e2 .connector .ln { fill:none; stroke:var(--fs-accent); stroke:url(#lineGrad); stroke-width:1.6; stroke-linecap:round;
         opacity:.9; animation:lnFade .7s ease-out forwards;
         filter:drop-shadow(0 0 4px var(--fs-glow-accent)); }
  /* ---- v0.2.9: 连线本身 dash-flow,让管道看起来是有电流的 ---- */
  .m-e2 .connector .ln.ln-live { stroke-dasharray:6 6;
         animation:lnFade .7s ease-out forwards, lnFlow 1.8s linear infinite; }
  .m-e2 .connector .ln.l1 { animation-delay:1.05s, 1.75s; }
  .m-e2 .connector .ln.l2 { animation-delay:1.15s, 1.85s; }
  .m-e2 .connector .ln.l3 { animation-delay:1.25s, 1.95s; }
  .m-e2 .connector .ln.l4 { animation-delay:1.35s, 2.05s; }
  .m-e2 .connector .ln.l5 { animation-delay:1.45s, 2.15s; }
  .m-e2 .sparks .spark { fill:var(--fs-accent); opacity:0;
         filter:drop-shadow(0 0 6px var(--fs-glow-accent)); }
  /* ---- 底部 5 步流转 ---- */
  .m-e2 .flow { display:flex; align-items:center; justify-content:space-between;
         gap:6px; z-index:3; }
  .m-e2 .flow .step { position:relative; flex:1; background:var(--fs-glass); border-radius:999px;
         padding:10px 6px; text-align:center; font-size:13.5px; font-weight:700;
         color:var(--fs-text);
         box-shadow:0 1px 0 rgba(255,255,255,.9) inset, 0 6px 20px rgba(20,40,30,.08);
         opacity:1; transform:translateY(10px); }
  .m-e2 .flow .step::before { content:""; position:absolute; inset:0; border-radius:999px; padding:1.3px;
         background:var(--fs-grad-keyline);
         -webkit-mask:linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
         -webkit-mask-composite:xor; mask-composite:exclude; opacity:.65; pointer-events:none; }
  .m-e2 .flow .step .idx { display:inline-block; width:20px; height:20px; line-height:20px; border-radius:50%;
         background:var(--fs-grad-keyline); color:#fff; font-size:11px; font-weight:800;
         margin-right:6px; vertical-align:middle; }
  .m-e2 .flow .step.n1 { animation:stepIn .5s ease-out 2.15s forwards, stepPing 1.2s ease-out 2.45s; }
  .m-e2 .flow .step.n2 { animation:stepIn .5s ease-out 2.35s forwards, stepPing 1.2s ease-out 2.65s; }
  .m-e2 .flow .step.n3 { animation:stepIn .5s ease-out 2.55s forwards, stepPing 1.2s ease-out 2.85s; }
  .m-e2 .flow .step.n4 { animation:stepIn .5s ease-out 2.75s forwards, stepPing 1.2s ease-out 3.05s; }
  .m-e2 .flow .step.n5 { animation:stepIn .5s ease-out 2.95s forwards, stepPing 1.2s ease-out 3.25s; }
  /* v0.2.9: JS 每 ~4s 追加 .pulsing 触发 stepPing 循环脉冲,让 5 步始终"呼吸" */
  /* v0.2.11-r4 修:e2 全模块元素(intro/cap/orb/step/arrow/loopback/loopcap/ln)原本
     基态 opacity:0,可见性完全依赖最长 3.5s 的错峰入场动画。一旦(a)处于 delay 窗口、
     (b)deck:nav 触发 REPLAY_ANIM_JS 清空并重跑动画、(c)后台标签页/快速翻页被浏览器
     节流暂停动画,元素就永久停在 opacity:0 不可见;而唯一的兜底(animation-duration:.001s)
     被关在 @media(prefers-reduced-motion:reduce) 里,正常浏览不触发。改法:所有元素基态
     opacity 一律 1(内容默认可见),入场 keyframes 只保留 transform 位移/缩放分量
     (to{opacity:1} 与基态一致 → 全程 opacity=1),动画不再决定可见性。 */
  /* v0.2.11-r3 修:.pulsing 的 `animation:stepPing !important` 简写会整条覆盖掉
     step 原本的 `stepIn …forwards`(那段负责把 opacity 0→1 并保持);而 stepPing
     只动 box-shadow,不含 opacity,于是脉冲一起(3.2s 后)5 个步骤就回落到基态
     opacity:0 永久消失。补 opacity/transform 普通属性(特异性高于基态、不受 stepPing
     动画影响)锁住可见态,让呼吸脉冲期间步骤始终显示。 */
  .m-e2 .flow .step.pulsing { opacity:1; transform:none;
         animation:stepPing 1.2s ease-out !important; }
  .m-e2 .flow .arrow { color:var(--fs-accent); font-size:15px; font-weight:800;
         opacity:1; animation:arrowIn .3s ease-out forwards; }
  .m-e2 .flow .arrow.a1 { animation-delay:2.28s; }
  .m-e2 .flow .arrow.a2 { animation-delay:2.48s; }
  .m-e2 .flow .arrow.a3 { animation-delay:2.68s; }
  .m-e2 .flow .arrow.a4 { animation-delay:2.88s; }
  /* ---- 底部回环虚线(loop-zone 独立于 flow / pfoot) ---- */
  .m-e2 .loop-zone { position:relative; height:40px; margin-top:16px; }
  .m-e2 .loopback  { position:absolute; left:0; right:0; top:0; height:22px;
         pointer-events:none; z-index:1;
         opacity:1; animation:capIn .7s ease-out 3.25s forwards; }
  .m-e2 .loopback path { fill:none; stroke:var(--fs-accent); stroke-width:1.4;
         stroke-dasharray:5 5; animation:dashFlow 2.6s linear infinite; }
  .m-e2 .loopback .arrow-head { fill:var(--fs-accent); }
  .m-e2 .loopcap { position:absolute; left:0; right:0; bottom:0; text-align:center;
         font-size:10.5px; color:var(--fs-text-48); letter-spacing:.22em; font-weight:600;
         opacity:1; transform:translateY(6px);
         animation:e2FadeUp .6s ease-out 3.5s forwards; }
  /* ---- e-2 专属 keyframes(名称与他模块不冲突) ---- */
  @keyframes capIn      { to { opacity:1; transform:translateY(0); } }
  @keyframes orbIn      { to { opacity:1; transform:scale(1); } }
  @keyframes halo       { 0%,100% { opacity:.35; } 50% { opacity:.72; } }
  @keyframes spin       { to { transform:rotate(360deg); } }
  @keyframes lnFade     { from { opacity:0; stroke-width:.5; } to { opacity:.9; stroke-width:1.6; } }
  @keyframes stepIn     { to { opacity:1; transform:translateY(0); } }
  @keyframes stepPing   {
       0%  { box-shadow:0 1px 0 rgba(255,255,255,.9) inset, 0 0 0 0 var(--fs-glow-accent); }
       100%{ box-shadow:0 1px 0 rgba(255,255,255,.9) inset, 0 0 0 14px transparent; }
  }
  @keyframes arrowIn    { to { opacity:1; } }
  @keyframes dashFlow   { to { stroke-dashoffset:-80; } }
  /* v0.2.9: 连线电流感,配合 .ln-live 让 cap→orb / orb→step 管道自身在流 */
  @keyframes lnFlow     { to { stroke-dashoffset:-48; } }
  @keyframes e2FadeUp   { to { opacity:1; transform:translateY(0); } }
  @media (prefers-reduced-motion:reduce) {
    .m-e2 * { animation-duration:.001s !important; animation-delay:0s !important; }
  }

  /* ---------------- f) 细节:左能力卡片(错峰入场)+ 右截图,镜像 e ---------------- */
  /* 与 e(方案全景)同源:上 .intro 一句话 + 下 .fbody 两栏,但左右镜像——
     e 是左截图 + 右卡片,f 是左卡片 + 右截图。卡片样式/动效完全复用 e 的玻璃卡 + mcCardIn
     错峰入场 + flex:1 1 0 等高。配色全走令牌,零写死 hex。f 标题取自 e 某张卡片内容。 */
  .m-f { flex:1; display:flex; flex-direction:column; gap:16px; min-height:0; }
  .m-f .intro { flex:0 0 auto; display:flex; flex-direction:column;
         justify-content:flex-start; }
  .m-f .intro p { font-size:21px; line-height:1.5; color:var(--fs-text); font-weight:600;
         letter-spacing:-.005em; max-width:98%; }
  .m-f .intro p + p { margin-top:8px; }
  .m-f .intro .kw { color:var(--fs-accent); font-weight:800; }
  /* 下半两栏(镜像 e):左数字卡片(定宽)+ 右截图(弹性主体) */
  .m-f .fbody { flex:1; min-height:0; display:flex; gap:26px; align-items:stretch; }
  /* 左:数字导向卡片(2–6 张自适应),错峰入场;column 弹性列天然等宽 + flex:1 1 0 均分列高
     → 无论几张都等高、随列高自动收缩;张数由 .fsum.n{k} 声明,只调字号/间距不改结构 */
  .m-f .fsum { flex:0 0 34%; max-width:360px; min-width:0; align-self:stretch;
         display:flex; flex-direction:column; gap:14px; }
  .m-f .fsum .fpoint { position:relative; overflow:hidden; flex:1 1 0; min-height:0;
         display:flex; flex-direction:column; gap:6px; justify-content:center;
         padding:16px 20px 16px 22px; border-radius:14px;
         background:var(--fs-glass); border:1px solid var(--fs-glass-border);
         -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
         box-shadow:0 10px 30px -14px var(--fs-glow-accent);
         opacity:0; transform:translateY(16px);
         animation:mcCardIn .7s cubic-bezier(.22,.9,.32,1) forwards;
         transition:transform .25s ease, box-shadow .25s ease; }
  /* 错峰入场:支持到 6 张 */
  .m-f .fsum .fpoint:nth-child(1) { animation-delay:.14s; }
  .m-f .fsum .fpoint:nth-child(2) { animation-delay:.26s; }
  .m-f .fsum .fpoint:nth-child(3) { animation-delay:.38s; }
  .m-f .fsum .fpoint:nth-child(4) { animation-delay:.50s; }
  .m-f .fsum .fpoint:nth-child(5) { animation-delay:.62s; }
  .m-f .fsum .fpoint:nth-child(6) { animation-delay:.74s; }
  .m-f .fsum .fpoint:hover { transform:translateY(-4px);
         box-shadow:0 20px 46px -16px var(--fs-glow-accent); }
  .m-f .fsum .fpoint::before { content:""; position:absolute; left:0; top:0; bottom:0; width:4px;
         border-radius:14px 0 0 14px; background:var(--fs-grad-keyline);
         box-shadow:0 0 10px var(--fs-glow-accent); }
  /* 大数字(渐变、count-up),沿用 --fs-grad-title,与 d2 同形制。
     line-height:1 + block 收紧墨迹盒,避免 .9 行高下数字被裁。 */
  .m-f .fsum .fpoint .num { flex:0 0 auto; font-weight:800; line-height:1;
         letter-spacing:-.03em; display:flex; align-items:baseline;
         background:var(--fs-grad-title); -webkit-background-clip:text; background-clip:text;
         -webkit-text-fill-color:transparent; }
  .m-f .fsum .fpoint .num .v { font-size:44px; }
  .m-f .fsum .fpoint .num .u { font-size:19px; font-weight:800; margin-left:3px; }
  .m-f .fsum .fpoint .t { font-size:16px; font-weight:800; color:var(--fs-text); line-height:1.35; }
  .m-f .fsum .fpoint .t .kw { color:var(--fs-accent); }
  .m-f .fsum .fpoint .d { font-size:13px; color:var(--fs-text-48); line-height:1.5; }
  /* 张数自适应完整梯度(n2→n6):卡片越多→单卡越矮→数字/标题/补充字号 + 内距 + 间距同步收紧,
     保证从 2 到 6 张每一档「数字 + 标题 + 补充」的竖向堆叠都能落进单卡高度、绝不溢出。
     数字随张数递减:52 → 44 → 37 → 32 → 28。 */
  .m-f .fsum.n2 { gap:16px; }
  .m-f .fsum.n2 .fpoint .num .v { font-size:52px; }
  .m-f .fsum.n2 .fpoint .num .u { font-size:22px; }
  .m-f .fsum.n2 .fpoint .t { font-size:17px; }
  /* n3 用默认字号(44px),仅显式声明以固化梯度 */
  .m-f .fsum.n3 { gap:14px; }
  .m-f .fsum.n3 .fpoint .num .v { font-size:44px; }
  .m-f .fsum.n3 .fpoint .num .u { font-size:19px; }
  .m-f .fsum.n3 .fpoint .t { font-size:16px; }
  .m-f .fsum.n4 { gap:12px; }
  .m-f .fsum.n4 .fpoint { padding:12px 17px 12px 19px; gap:5px; }
  .m-f .fsum.n4 .fpoint .num .v { font-size:37px; }
  .m-f .fsum.n4 .fpoint .num .u { font-size:17px; }
  .m-f .fsum.n4 .fpoint .t { font-size:15px; line-height:1.32; }
  .m-f .fsum.n4 .fpoint .d { font-size:12.5px; line-height:1.42; }
  .m-f .fsum.n5 { gap:10px; }
  .m-f .fsum.n5 .fpoint { padding:8px 16px 8px 18px; gap:3px; }
  .m-f .fsum.n5 .fpoint .num .v { font-size:30px; }
  .m-f .fsum.n5 .fpoint .num .u { font-size:15px; }
  .m-f .fsum.n5 .fpoint .t { font-size:13.5px; line-height:1.24; }
  .m-f .fsum.n5 .fpoint .d { font-size:12px; line-height:1.32; }
  .m-f .fsum.n6 { gap:8px; }
  .m-f .fsum.n6 .fpoint { padding:6px 15px 6px 17px; gap:2px; }
  .m-f .fsum.n6 .fpoint .num .v { font-size:26px; }
  .m-f .fsum.n6 .fpoint .num .u { font-size:13px; }
  .m-f .fsum.n6 .fpoint .t { font-size:12.5px; line-height:1.2; }
  .m-f .fsum.n6 .fpoint .d { font-size:12px; line-height:1.3; }
  /* 右:方案细节截图(弹性主体,镜像 e 到右列)。张数 1–4 自适应:.shots.s{k} 决定网格。
     单图铺满居中;2 图上下均分;4 图 2×2;3 图特殊——首两张并排一行,第三张独占底行铺满
     (不留 2×2 的空位)。每格保形 object-fit:contain。 */
  .m-f .shots { flex:1; min-width:0; min-height:0; display:grid; gap:16px;
         grid-template-columns:1fr; grid-auto-rows:1fr; }
  .m-f .shots.s2 { grid-template-columns:1fr; grid-template-rows:1fr 1fr; }
  .m-f .shots.s4 { grid-template-columns:1fr 1fr; grid-template-rows:1fr 1fr; }
  /* 3 图:2 列 2 行,第三张跨两列铺满底行,消除末位留白 */
  .m-f .shots.s3 { grid-template-columns:1fr 1fr; grid-template-rows:1fr 1fr; }
  .m-f .shots.s3 .shot:nth-child(3) { grid-column:1 / -1; }
  .m-f .shot { min-width:0; min-height:0; display:flex;
         align-items:center; justify-content:center; }
  .m-f .shot img { max-width:100%; max-height:100%; width:auto; height:auto;
         object-fit:contain; display:block; border-radius:14px;
         box-shadow:0 18px 40px -20px var(--fs-glow-accent); }
  .m-f .shots.s1 .shot .ph { width:92%; aspect-ratio:16/9; }
  .m-f .shot .ph { width:100%; height:100%; display:flex;
         align-items:center; justify-content:center;
         font-size:14px; color:var(--fs-text-48); letter-spacing:.08em;
         border-radius:14px; border:1px dashed var(--fs-hairline); }

  /* ---------------- g) 总结升华与行动:上·impact 值卡带 + 下·closing 总结 ----------------
     价值总览页:上半 1–8 张玻璃卡(大百分比 count-up 0→N + 指标名 + 从X到Y 变化叙事,
     mcCardIn 错峰入场),下半 1(必选)–2(可选)行总结(主句渐变描字,closingIn fade+up)。
     .impact 张数由 .n{k} 驱动版式:
        n1        单张 hero-stat,居中,字号最大(84)
        n2–n4     单行 flex,均分列宽,字号 62/54/46
        n5–n6     单行 flex,tighter gap,字号 40/34
        n7–n8     grid 4 列 2 行(7=4+3, 8=4+4),字号 34,padding 收窄
     数字/单位/箭头字号随张数收敛,overflow:hidden 防溢出。配色全走 --fs-* 令牌,零写死 hex。 */
  .m-g { flex:1; display:flex; flex-direction:column; justify-content:center;
         gap:32px; align-items:stretch; }

  /* ===== 上·impact 值卡带 ===== */
  /* 默认单行 flex(n1–n6 都走这一套,只在 n1 / n7 / n8 上切 grid) */
  .m-g .impact { display:flex; gap:16px; align-items:stretch; }
  /* n1:单卡居中 hero-stat,不撑满整行,给一个上限,视觉重心居中 */
  .m-g .impact.n1 { justify-content:center; }
  .m-g .impact.n1 .card { flex:0 1 560px; max-width:560px; padding:36px 32px 32px; gap:14px; }
  /* n5–n6:单行 flex 保持,gap 收窄 */
  .m-g .impact.n5, .m-g .impact.n6 { gap:12px; }
  .m-g .impact.n5 .card, .m-g .impact.n6 .card { padding:20px 16px 18px; gap:8px; }
  /* n7–n8:切 grid 4 列 2 行(7=4+3, 8=4+4) */
  .m-g .impact.n7, .m-g .impact.n8 { display:grid;
         grid-template-columns:repeat(4, minmax(0, 1fr)); gap:12px; }
  .m-g .impact.n7 .card, .m-g .impact.n8 .card { padding:16px 14px 14px; gap:6px; }

  .m-g .impact .card { flex:1 1 0; min-width:0; position:relative;
         background:var(--fs-glass); border:1px solid var(--fs-glass-border);
         border-radius:16px; padding:24px 22px 22px; overflow:hidden;
         -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
         box-shadow:0 12px 28px -18px var(--fs-glow-primary);
         display:flex; flex-direction:column; gap:10px;
         opacity:0; transform:translateY(14px);
         animation:mcCardIn .7s cubic-bezier(.22,.9,.32,1) forwards; }
  /* 错峰入场(0.14→0.72s,与 e/f 同源节奏,扩到 8 张) */
  .m-g .impact .card:nth-child(1){ animation-delay:.14s; }
  .m-g .impact .card:nth-child(2){ animation-delay:.22s; }
  .m-g .impact .card:nth-child(3){ animation-delay:.30s; }
  .m-g .impact .card:nth-child(4){ animation-delay:.38s; }
  .m-g .impact .card:nth-child(5){ animation-delay:.46s; }
  .m-g .impact .card:nth-child(6){ animation-delay:.54s; }
  .m-g .impact .card:nth-child(7){ animation-delay:.62s; }
  .m-g .impact .card:nth-child(8){ animation-delay:.70s; }
  /* 卡片顶部一道 accent hairline,与封面同款收笔线 */
  .m-g .impact .card::before { content:""; position:absolute; left:22px; right:22px; top:0;
         height:2px; background:var(--fs-grad-keyline);
         box-shadow:0 0 10px var(--fs-glow-accent); }
  /* n7/n8 卡片较窄,hairline 内缩少一些,避免看起来"两头留白过大" */
  .m-g .impact.n7 .card::before, .m-g .impact.n8 .card::before { left:14px; right:14px; }
  /* 大数字前动词前缀(提升/达到/降低/保持…),accent 色小字量词,让数字有含义 */
  .m-g .impact .card .prefix { display:block; font-size:14px; font-weight:800;
         letter-spacing:.06em; color:var(--fs-accent); text-transform:none;
         line-height:1.2; margin-bottom:2px; }
  .m-g .impact.n1 .card .prefix { font-size:18px; letter-spacing:.08em; margin-bottom:4px; }
  .m-g .impact.n5 .card .prefix, .m-g .impact.n6 .card .prefix,
  .m-g .impact.n7 .card .prefix, .m-g .impact.n8 .card .prefix { font-size:12px; letter-spacing:.05em; }
  /* 大数字(渐变描字 + count-up),随张数降档 */
  .m-g .impact .card .pct { line-height:1; letter-spacing:-.01em;
         font-weight:900; white-space:nowrap; overflow:hidden;
         background:var(--fs-grad-title); -webkit-background-clip:text;
         background-clip:text; color:transparent;
         display:flex; align-items:baseline; gap:6px; }
  .m-g .impact .card .pct .arrow { font-weight:800; opacity:.9; }
  .m-g .impact .card .pct .v { display:inline-block; }
  /* 单位(% / × / 倍 等):加粗、贴紧数字,与数字同色渐变描字 */
  .m-g .impact .card .pct .u { font-weight:900;
         padding-left:2px; opacity:1; letter-spacing:-.01em; }
  /* 张数降档 · .pct 主字号 + 内联 .arrow/.u 的绝对 px(避免 em 相对量被静态 lint 误判)
     · arrow ≈ .55 × pct,u ≈ .58 × pct,一律 ≥ 12px 落地。
     1→84 / 2→62 / 3→54 / 4→46 / 5→40 / 6→34 / 7→34 / 8→34 */
  .m-g .impact.n1 .card .pct { font-size:84px; gap:8px; }
  .m-g .impact.n1 .card .pct .arrow { font-size:46px; }
  .m-g .impact.n1 .card .pct .u { font-size:48px; }
  .m-g .impact.n2 .card .pct { font-size:62px; }
  .m-g .impact.n2 .card .pct .arrow { font-size:34px; }
  .m-g .impact.n2 .card .pct .u { font-size:36px; }
  .m-g .impact.n3 .card .pct { font-size:54px; }
  .m-g .impact.n3 .card .pct .arrow { font-size:30px; }
  .m-g .impact.n3 .card .pct .u { font-size:32px; }
  .m-g .impact.n4 .card .pct { font-size:46px; }
  .m-g .impact.n4 .card .pct .arrow { font-size:26px; }
  .m-g .impact.n4 .card .pct .u { font-size:27px; }
  .m-g .impact.n5 .card .pct { font-size:40px; }
  .m-g .impact.n5 .card .pct .arrow { font-size:22px; }
  .m-g .impact.n5 .card .pct .u { font-size:23px; }
  .m-g .impact.n6 .card .pct { font-size:34px; }
  .m-g .impact.n6 .card .pct .arrow { font-size:19px; }
  .m-g .impact.n6 .card .pct .u { font-size:20px; }
  .m-g .impact.n7 .card .pct { font-size:34px; }
  .m-g .impact.n7 .card .pct .arrow { font-size:19px; }
  .m-g .impact.n7 .card .pct .u { font-size:20px; }
  .m-g .impact.n8 .card .pct { font-size:34px; }
  .m-g .impact.n8 .card .pct .arrow { font-size:19px; }
  .m-g .impact.n8 .card .pct .u { font-size:20px; }
  /* 指标名 */
  .m-g .impact .card .t { font-size:16px; font-weight:800; color:var(--fs-text);
         letter-spacing:.01em; }
  .m-g .impact.n1 .card .t { font-size:22px; }
  .m-g .impact.n5 .card .t, .m-g .impact.n6 .card .t,
  .m-g .impact.n7 .card .t, .m-g .impact.n8 .card .t { font-size:14px; }
  /* 从 X → Y 变化叙事;.kw 高亮箭头/数字 */
  .m-g .impact .card .d { font-size:13px; line-height:1.55; color:var(--fs-text-72); }
  .m-g .impact.n1 .card .d { font-size:15px; }
  .m-g .impact.n5 .card .d, .m-g .impact.n6 .card .d,
  .m-g .impact.n7 .card .d, .m-g .impact.n8 .card .d { font-size:12px; line-height:1.5; }
  .m-g .impact .card .d .kw { color:var(--fs-accent); font-weight:700; }

  /* ===== 下·closing 总结 ===== */
  .m-g .closing { text-align:center; padding:8px 12px 0;
         opacity:0; transform:translateY(10px);
         animation:closingIn .9s cubic-bezier(.22,.9,.32,1) .82s forwards; }
  .m-g .closing .cmain { display:block; font-size:26px; font-weight:900; line-height:1.35;
         letter-spacing:.005em;
         background:var(--fs-grad-title); -webkit-background-clip:text;
         background-clip:text; color:transparent; }
  .m-g .closing .csub { display:block; margin-top:10px;
         font-size:15px; font-weight:600; line-height:1.55; color:var(--fs-text-72); }
  .m-g .closing .kw { color:var(--fs-accent); font-weight:800; }
  @keyframes closingIn { to { opacity:1; transform:translateY(0); } }
  @media (prefers-reduced-motion:reduce) {
    .m-g .impact .card, .m-g .closing { animation:none; opacity:1; transform:none; }
  }
"""


def page(mode_cls, mod, page_no, total):
    """Wrap one module's content in the shared content-page shell.

    演讲者模式(Presenter View)备注打通:若模块 dict 带 'notes' 键(由 render_page /
    compose_deck 把 material['notes'] 合并进来),则把它写成幻灯片根节点的 data-notes
    属性——只做属性承载,**绝不渲染进 eyebrow/title/content 等正文可见区域**。演讲者窗口
    读取该属性展示备注;正常观看态与校验器都不受影响(仅多一个惰性属性)。缺省无 notes 键
    → 不产生 data-notes,与改造前逐字一致。"""
    m = MODULES[mod]
    _notes = m.get("notes")
    notes_attr = (f' data-notes="{_html.escape(str(_notes), quote=True)}"'
                  if _notes else "")
    return f"""
      <div class="{mode_cls} page"{notes_attr}>
        <div class="eyebrow">{m['kicker']}</div>
        <h2 class="ptitle">{m['title']}</h2>
        <div class="ptick"></div>
        <div class="content">{m['body']}</div>
        <div class="pfoot">
          <div class="brand">{current_brand_foot()}</div>
          <div class="pageno"><b>{page_no:02d}</b> / {total:02d}</div>
        </div>
      </div>"""


def build_content_html(data, modules, mode=None):
    """mode=None → 浅/深双模并排(确认物料);mode='light'|'dark' → 只出锁定的一套模式。"""
    tbm = data["tokens_by_mode"]
    name = data["palette"].get("name", "theme")

    def scope(cls, toks):
        body = "\n".join(f"    {k}: {v};" for k, v in toks.items())
        return f"  .{cls} {{\n{body}\n  }}"

    m_light = scope("m-light", tbm["light"])
    m_dark = scope("m-dark", tbm["dark"])

    total = len(modules) + 1  # +封面
    cap = {"a": "a · 小故事切入", "b": "b · 团队介绍", "c": "c · 背景 Why",
           "d": "d · 痛点剖析", "d2": "d · 痛点剖析(卡片)",
           "e": "e · 方案全景(截图 + 总结卡片)", "e2": "e2 · 架构详图/协同闭环(5 cap + CORE + 5 flow + loop)",
           "f": "f · 方案细节(左大数字卡片 + 右细节截图)",
           "g": "g · 价值总览(上·大百分比 impact 卡带 + 下·渐变描字总结)"}

    if mode in ("light", "dark"):
        # 单模锁定:每页只出所选那一套,<html> 挂 data-theme 作全局单模声明
        mode_cls = "m-" + mode
        rows = ""
        for i, mod in enumerate(modules):
            no = i + 2
            rows += f"""
      <div class="modrow">
        <div class="modcap">{cap[mod]}</div>
        <div class="cell">{page(mode_cls, mod, no, total)}</div>
      </div>"""
        cn = {"light": "浅色", "dark": "深色"}[mode]
        return f"""<!doctype html><html lang="zh-CN" data-theme="{mode}"><head><meta charset="utf-8">
<style>
{m_light}
{m_dark}
  * {{ box-sizing:border-box; margin:0; padding:0; }}
  body {{ font-family:system-ui,"Noto Sans SC","PingFang SC",sans-serif;
          background:#EEF1F6; color:#1A1F2B; padding:44px 40px; }}
  .wrap {{ max-width:1400px; margin:0 auto; }}
  h1.sec {{ font-size:24px; margin-bottom:4px; }}
  h1.sec .name {{ color:#5B6472; font-weight:600; }}
  p.hint {{ font-size:14px; color:#6B7280; margin-bottom:30px; line-height:1.5; }}
  .modrow {{ margin-bottom:40px; }}
  .modcap {{ font-size:16px; font-weight:700; color:#334155; margin-bottom:14px;
             padding-left:12px; border-left:4px solid #C57708; }}
{CONTENT_CSS}
</style></head>
<body><div class="wrap">
  <h1 class="sec">内容页模版({cn}锁定) <span class="name">· {name} · 基于 corner 风格</span></h1>
  <p class="hint">整份 deck 锁定为「{cn}」一套模式,a/b/c/d/e/e2/f/g 每一类内容页都沿用这一套;
     内容页不放 LOGO 图,左下角页脚展示「{BRAND_FOOT}」。</p>
  {rows}
</div>
</body></html>"""

    rows = ""
    for i, mod in enumerate(modules):
        no = i + 2  # 封面是 01,内容页从 02 起
        rows += f"""
      <div class="modrow">
        <div class="modcap">{cap[mod]}</div>
        <div class="pair">
          <div class="cell"><div class="cellcap">浅色</div>{page('m-light', mod, no, total)}</div>
          <div class="cell"><div class="cellcap">深色</div>{page('m-dark', mod, no, total)}</div>
        </div>
      </div>"""

    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<style>
{m_light}
{m_dark}
  * {{ box-sizing:border-box; margin:0; padding:0; }}
  body {{ font-family:system-ui,"Noto Sans SC","PingFang SC",sans-serif;
          background:#EEF1F6; color:#1A1F2B; padding:44px 40px; }}
  .wrap {{ max-width:2760px; margin:0 auto; }}
  h1.sec {{ font-size:24px; margin-bottom:4px; }}
  h1.sec .name {{ color:#5B6472; font-weight:600; }}
  p.hint {{ font-size:14px; color:#6B7280; margin-bottom:30px; line-height:1.5; }}
  .modrow {{ margin-bottom:40px; }}
  .modcap {{ font-size:16px; font-weight:700; color:#334155; margin-bottom:14px;
             padding-left:12px; border-left:4px solid #C57708; }}
  .pair {{ display:grid; grid-template-columns:1fr 1fr; gap:28px; }}
  .cell .cellcap {{ font-size:13px; color:#64748B; margin-bottom:8px; font-weight:600; }}
{CONTENT_CSS}
</style></head>
<body><div class="wrap">
  <h1 class="sec">内容页模版确认 <span class="name">· {name} · 基于 corner 风格</span></h1>
  <p class="hint">下面是 a,b,c,d,e,e2,f,g 共 8 类模块的内容页版式,均继承封面 corner 的视觉语言(mesh 流光底 ·
     accent 起笔线 · 同一套配色 token · 浅/深两套);内容页不放 LOGO 图,左下角页脚展示
     「{BRAND_FOOT}」。<b>注意:这是浅/深双模对照物料,供你二选一;确认后整份 deck 只锁定其中一套。</b>
     请逐类确认版式并告诉我要哪一套(浅色 / 深色),回复「可以 / 确认」或指出要调整的模块。</p>
  {rows}
</div>
</body></html>"""


def shoot_png(html_path, png_path):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch(args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])
        pg = b.new_page(viewport={"width": 2760, "height": 1600}, device_scale_factor=1)
        pg.goto("file://" + os.path.abspath(html_path))
        # 等动效收敛再截图:数字 count-up(起始 300ms + 逐张错峰 idx*170ms,最多 8 张到
        # ~1490ms + 时长 1100ms)与卡片错峰入场(最长 .73s 延迟 + .7s)均在 ~2.6s 内跑完。
        # 确认物料必须呈现终值(数字落位、卡片全部入场),故等 2800ms 留足余量。
        pg.wait_for_timeout(2800)
        pg.screenshot(path=png_path, full_page=True)
        b.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("palette")
    ap.add_argument("--out", required=True, help="HTML 中间产物路径;PNG 为同名 .png")
    ap.add_argument("--module", choices=ORDER, help="只渲染某一类模块(默认全部 a,b,c,d,e,e2,f,g)")
    ap.add_argument("--mode", choices=["light", "dark"],
                    help="锁定单模:只出所选那一套(默认不传 = 浅/深双模对照确认物料)")
    ap.add_argument("--company-name", default=None,
                    help="企业名称(Step 1 确认后传入),替换页脚署名前缀;缺省占位「企业名称」")
    ap.add_argument("--no-shoot", action="store_true")
    args = ap.parse_args()

    if args.company_name:
        os.environ["DECK_COMPANY_NAME"] = args.company_name
    data = json.load(open(args.palette))
    modules = [args.module] if args.module else ORDER
    html = build_content_html(data, modules, mode=args.mode)
    with open(args.out, "w") as f:
        f.write(html)
    print("wrote", args.out)

    if not args.no_shoot:
        png = os.path.splitext(args.out)[0] + ".png"
        shoot_png(args.out, png)
        print("PNG 确认物料:", png)


if __name__ == "__main__":
    main()
