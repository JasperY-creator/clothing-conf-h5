#!/usr/bin/env python3
"""
preview-theme.py — 生成「确认色卡 PNG」(Step 2 产出 / Step 3 确认物料)

读 build-theme.py 产出的 palette.json,渲染一张自包含 HTML 后**截成 PNG**。
PNG 才是交给用户确认的物料(不是 HTML)。一张图里包含三块:

  ① 色彩血缘条 (lineage): 你的【输入主色 / Logo 主色】→ 派生出的 Primary / Accent /
     4 阶背景,每块标注 OKLCH 色相 H°,用来【和输入主色做对比】,证明整套配色
     (含浅色背景)确实是从你的颜色派生的、同色相、带你的品牌色调,而非纯白。
  ② 4 阶色板卡片 (色块 + Hex + 用途 + WCAG 对比度)。
  ③ 浅色(默认) + 深色 两页 16:9 封面样张并排,直接看两套观感。

用法:
  python3 preview-theme.py themes/acme/palette.json --title "标题" --author "发起人" \
      --out themes/acme/preview.html
  # 默认就会截图产出同名 .png;若确实只要 HTML 不要图,可加 --no-shoot
"""
import argparse
import json
import math
import os
import re
import sys

# CJK 字符检测(用于标题字号自适应的字宽估算)
CJK_FIT = re.compile(r"[　-ヿ㐀-䶿一-鿿＀-￯]")


# ---- OKLCH hue helper (mirror build-theme.py, for lineage annotation) ------
def _s2l(c):
    c = c / 255
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _hex_rgb(h):
    h = h.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _hue(hexc):
    r, g, b = [_s2l(x) for x in _hex_rgb(hexc)]
    l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
    m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
    s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    l_, m_, s_ = l ** (1 / 3), m ** (1 / 3), s ** (1 / 3)
    a = 1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_
    bb = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_
    return round(math.degrees(math.atan2(bb, a)) % 360)


# ---- BRAND SIGNATURE -------------------------------------------------------
# 品牌署名串 = 「企业名称」前缀 + 固定后缀。企业名称由 Step 1 确认闸门注入
# (--company-name),缺省保持占位「企业名称」以向后兼容;后缀恒定不变。
DEFAULT_COMPANY_NAME = "企业名称"
BRAND_SUFFIX = " × 飞书 · AI 先锋大赛"


def brand_kicker(company_name=None):
    """拼出封面 kicker / 页脚署名:<企业名称> × 飞书 · AI 先锋大赛"""
    name = (company_name or DEFAULT_COMPANY_NAME).strip() or DEFAULT_COMPANY_NAME
    return name + BRAND_SUFFIX


# ---- COVER LAYOUT PRESETS --------------------------------------------------
# Each value is the inner HTML of one 16:9 cover. Placeholders {title}/{author}/
# {date} get filled at render time. CSS for every preset lives in COVER_CSS,
# scoped by the `.cover-<name>` wrapper class so all presets can coexist.
# Pick one per deck via palette.json's "cover_layout" (default "editorial").

# Feishu flying-bird motif — faint LINEWORK version. Traced from the official 飞书 logo
# (assets/trace_bird.py) and rendered as OUTLINE only (stroke, no fill). Placed at very low
# opacity + a soft radial mask by the .bird CSS so it reads as a "若隐若现" (barely-there)
# designed line-art device woven into the background — not a copy-pasted solid logo. Stroke uses
# theme tokens (accent + a gradient) so it follows any palette; amber here is only the demo.
# vector-effect keeps the hairline stroke crisp at any scale.
BIRD_SVG = (
    '<svg class="bird-svg" viewBox="-4 -6 110 96" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
    '<defs><linearGradient id="birdg" x1="0" y1="0" x2="1" y2="1">'
    '<stop offset="0" stop-color="var(--fs-cyan)"/><stop offset="1" stop-color="var(--fs-accent)"/>'
    '</linearGradient></defs>'
    '<g fill="none" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke">'
    # back wing outline (gradient stroke, hairline)
    '<path d="M37.13,79.83 L26.98,79.33 L17.08,77.1 L6.19,72.4 L0.62,68.32 L-0.12,66.58 L-0.12,24.01 '
    'L0.25,23.39 L0.99,23.39 L9.9,32.05 L17.82,38.49 L29.46,46.16 L38.86,51.11 L49.01,44.43 L65.1,29.08 '
    'L72.03,25.12 L79.7,22.9 L89.11,22.65 L95.05,23.89 L100.12,25.99 L94.93,32.92 L87.5,48.02 L83.54,54.46 '
    'L78.34,60.89 L73.27,65.72 L66.58,70.67 L56.93,75.62 L48.27,78.34 L37.13,79.83 Z" '
    'stroke="url(#birdg)" stroke-width="1.6"/>'
    # front wing outline (accent stroke, hairline)
    '<path d="M51.98,41.71 L44.43,29.95 L37.25,20.79 L25.74,9.03 L16.21,1.49 L15.72,0.74 L16.34,-0.12 '
    'L61.14,-0.12 L64.23,1.98 L70.92,12.38 L73.64,18.81 L75.12,24.01 L68.56,26.86 L65.1,29.08 L51.98,41.71 Z" '
    'stroke="var(--fs-accent)" stroke-width="1.6"/>'
    '</g></svg>'
)

COVER_PRESETS = {
    # 1) corner (默认) — 「底部英雄」编辑式构图:英雄级巨标题锚在左下为绝对主角。
    #    右侧一枚若隐若现的飞书飞鸟线稿(theme-token 描边、跟随配色)作设计图案。
    "corner": (
        '<div class="cover">'
        '<div class="bloom"></div>'
        '<div class="bird">{bird}</div>'
        # 背景飞书 logo 的「点亮呼吸」动效:整只飞鸟线稿随节拍从淡到亮循环起伏(birdLit),
        # 配 token 辉光 drop-shadow,呈现「被点亮 / 通电」质感,而非一条淡色死线稿。
        '<div class="cobrand">{cobrand}</div>'
        '<div class="body">'
        '<div class="kicker">{kicker}</div>'
        '<div class="title-zone"><h2 data-fit style="font-size:{title_px}px">{title}</h2></div>'
        '<div class="rule"></div>'
        '<div class="foot">{author}<span class="dot">·</span>{date}</div>'
        '</div></div>'
    ),
    # 1b) corner-atlas — 瑞士编辑式:标题锚在上三分之一(与 corner 底锚形成真实构图差异),
    #    一条通栏基线作网格锚,基线下用「栏目标签 : 值」的版权页式 meta 行组织信息。无序号、无大字。
    "corner-atlas": (
        '<div class="cover">'
        '<div class="bloom"></div>'
        '<div class="cobrand">{cobrand}</div>'
        '<div class="body">'
        '<div class="kicker">{kicker}</div>'
        '<h2>{title}</h2>'
        '<div class="baseline"></div>'
        '<div class="colophon">'
        '<div class="col"><span class="lbl">主讲</span><span class="val">{author}</span></div>'
        '<div class="col"><span class="lbl">日期</span><span class="val">{date}</span></div>'
        '<div class="col"><span class="lbl">类别</span><span class="val">企业内实践</span></div>'
        '</div>'
        '</div></div>'
    ),
    # 2) beam — 斜切光束:玻璃 masthead + 两道发光光束横贯 + bloom,动感科技。
    "beam": (
        '<div class="cover">'
        '<div class="bloom"></div><div class="beam"></div><div class="beam b2"></div>'
        '<div class="grain"></div>'
        '<div class="cobrand">{cobrand}</div>'
        '<div class="body">'
        '<div class="kicker">{kicker}</div>'
        '<h2>{title}</h2>'
        '<div class="keyline"></div>'
        '<div class="foot">{author}<span class="dot">·</span>{date}</div>'
        '</div></div>'
    ),
    # 3) column — 左竖栏:全高发光渐变栏 + 竖排卷标,玻璃 masthead,主体右移,编辑感。
    "column": (
        '<div class="cover">'
        '<div class="bloom"></div><div class="colbar"></div>'
        '<span class="vlabel">AI CASE STUDY</span>'
        '<div class="cobrand">{cobrand}</div>'
        '<div class="body">'
        '<div class="kicker">{kicker}</div>'
        '<h2>{title}</h2>'
        '<div class="keyline"></div>'
        '<div class="foot">{author}<span class="dot">·</span>{date}</div>'
        '</div></div>'
    ),
    # 4) frame — 内框证书感:玻璃 masthead 下嵌一圈发光细框 + 居中 bloom,标题居中偏下。
    "frame": (
        '<div class="cover center">'
        '<div class="bloom"></div><div class="frm"></div>'
        '<div class="cobrand">{cobrand}</div>'
        '<div class="body">'
        '<div class="kicker">{kicker}</div>'
        '<h2>{title}</h2>'
        '<div class="keyline"></div>'
        '<div class="foot">{author}<span class="dot">·</span>{date}</div>'
        '</div></div>'
    ),
    # 5) spotlight — 聚光舞台:玻璃 masthead + 顶部 bloom 聚光,标题居中,发布会/主题汇报感。
    "spotlight": (
        '<div class="cover center">'
        '<div class="bloom"></div>'
        '<div class="cobrand">{cobrand}</div>'
        '<div class="body">'
        '<div class="kicker chip">{kicker}</div>'
        '<h2>{title}</h2>'
        '<div class="keyline"></div>'
        '<div class="foot">{author}<span class="dot">·</span>{date}</div>'
        '</div></div>'
    ),
    # 6) editorial — 杂志感:玻璃 masthead + 右下渐变巨号 ghost 序号 + 左侧发光竖 keyline。
    "editorial": (
        '<div class="cover"><div class="bloom"></div><div class="idx">01</div>'
        '<div class="cobrand">{cobrand}</div>'
        '<div class="body">'
        '<div class="kicker">{kicker}</div>'
        '<h2>{title}</h2>'
        '<div class="keyline"></div>'
        '<div class="foot">{author}<span class="dot">·</span>{date}</div>'
        '</div></div>'
    ),
    # 7) split — 左文右色:玻璃 masthead + 右 1/3 竖幅玻璃色带(bloom+流光+点阵),标题压分界线左。
    "split": (
        '<div class="cover"><div class="panel"><div class="panel-glow"></div>'
        '<div class="panel-grain"></div></div>'
        '<div class="cobrand">{cobrand}</div>'
        '<div class="body">'
        '<div class="kicker">{kicker}</div>'
        '<h2>{title}</h2>'
        '<div class="foot">{author}<span class="dot">·</span>{date}</div>'
        '</div></div>'
    ),
}

# Shared + per-preset cover CSS. Uses theme tokens (--fs-*) so it recolors with
# the confirmed palette and flips with light/dark automatically.
COVER_CSS = """
  /* ============ COVER SHELL (shared) — CEO-grade premium base ============
     底不再是平铺纯色,而是多光源 mesh 渐变(--fs-grad-mesh)+ 顶部一道 sheen 流光带
     + 角落 bloom 体积光;标题走三色渐变裁切;masthead 玻璃拟态。所有效果 100% 由主题色
     派生,换任何客户主色都成立 —— 这次演示恰好是琥珀。 */
  .cover-wrap { border-radius:18px; overflow:hidden; aspect-ratio:16/9; position:relative;
                background:var(--fs-grad-mesh);
                box-shadow:0 24px 60px -12px rgba(0,0,0,.34), 0 2px 8px rgba(0,0,0,.10);
                isolation:isolate; }
  /* 顶部丝绸流光带(sheen):斜向高亮扫过,带出绸缎质感 */
  .cover-wrap::before { content:""; position:absolute; inset:0; z-index:1; pointer-events:none;
                background:var(--fs-grad-sheen); mix-blend-mode:screen; opacity:.9; }
  /* 内描边高光:一圈极细内发光,让边缘"发亮"更精致 */
  .cover-wrap::after { content:""; position:absolute; inset:0; z-index:6; pointer-events:none;
                border-radius:18px; box-shadow:inset 0 1px 0 rgba(255,255,255,.22),
                inset 0 0 0 1px var(--fs-glass-border); }
  .cover { position:absolute; inset:0; }
  /* bloom 体积光(共享装饰层,各 preset 定位不同) */
  .cover .bloom { position:absolute; width:64%; height:96%; z-index:1; pointer-events:none;
                background:var(--fs-grad-bloom); filter:blur(6px); }
  /* 细腻点阵纹理(共享),用主色着色、单侧渐隐,不喧宾夺主 */
  .cover .grain { position:absolute; inset:0; z-index:1; opacity:.5;
      background-image:radial-gradient(var(--fs-glow-accent) .6px, transparent .7px);
      background-size:22px 22px;
      -webkit-mask-image:linear-gradient(125deg, transparent 48%, #000 100%);
              mask-image:linear-gradient(125deg, transparent 48%, #000 100%); }

  .cover .body { position:absolute; inset:0; padding:9% 8% 8.5%; display:flex;
                 flex-direction:column; justify-content:flex-end; z-index:3; }
  .cover .kicker { font-size:11px; letter-spacing:.36em; text-transform:uppercase;
                   font-weight:700; margin-bottom:16px; color:var(--fs-accent);
                   display:inline-flex; align-items:center; gap:10px; }
  .cover .kicker::before { content:""; width:2px; height:13px; border-radius:2px;
                   background:var(--fs-grad-keyline); display:inline-block; }
  /* 渐变裁切标题:三色渐变上色(main→primary→accent),质感的关键一环 */
  .cover h2 { font-size:36px; line-height:1.12; font-weight:800; letter-spacing:-.02em;
              max-width:82%;
              background:var(--fs-grad-title); -webkit-background-clip:text;
              background-clip:text; -webkit-text-fill-color:transparent; color:transparent;
              padding-bottom:.04em; }
  .cover .keyline { width:64px; height:4px; border-radius:3px; margin:22px 0 16px;
                    background:var(--fs-grad-keyline);
                    box-shadow:0 0 16px var(--fs-glow-accent); }
  .cover .foot { font-size:13px; color:var(--fs-text-65); font-weight:500; letter-spacing:.01em; }
  .cover .foot .dot { margin:0 8px; color:var(--fs-text-40); }

  /* ============ GLASS MASTHEAD (shared) ============
     通栏「信笺抬头带」升级为玻璃拟态:半透明玻璃 + backdrop blur + 内高光 + 底部渐变
     hairline。它承载「公司 LOGO × 飞书」双标 + 右侧 AI 先锋大赛 小标,是版面构图的一
     部分。LOGO 采「无托卡·裸标」:直接落在玻璃抬头带上,公司标与飞书标间用一根细竖线
     (.x)分隔,更干净通透。玻璃带本身的半透明底 + blur 已给浅色/透明底 LOGO 足够反差。 */
  .cover .cobrand { position:absolute; top:0; left:0; right:0; height:14.5%; z-index:5;
      display:flex; align-items:center; padding:0 7%;
      background:var(--fs-glass);
      -webkit-backdrop-filter:blur(14px) saturate(1.3); backdrop-filter:blur(14px) saturate(1.3);
      border-bottom:1px solid var(--fs-glass-border);
      box-shadow:inset 0 1px 0 rgba(255,255,255,.3), 0 6px 20px -8px rgba(0,0,0,.25); }
  /* 底部一道 accent 渐变发光 hairline,替代生硬的灰线 */
  .cover .cobrand::after { content:""; position:absolute; left:0; right:0; bottom:0; height:1.5px;
      background:var(--fs-grad-keyline); opacity:.55; }
  .cover .cobrand .lockup { display:flex; align-items:center; gap:14px;
      background:none; border:none; box-shadow:none; padding:0; }
  .cover .cobrand img, .cover .cobrand svg { height:22px; width:auto; max-width:122px;
      object-fit:contain; display:block; }
  .cover .cobrand .x { width:1px; height:20px; background:var(--fs-hairline); }
  .cover .cobrand .ph { height:22px; min-width:78px; border-radius:5px;
      border:1.3px dashed rgba(100,116,139,.55); color:rgba(71,85,105,.9);
      font-size:9.5px; letter-spacing:.05em; display:flex; align-items:center;
      justify-content:center; padding:0 9px; }
  .cover .cobrand .mh-meta { margin-left:auto; font-size:12px; letter-spacing:.16em;
      font-weight:700; color:var(--fs-text-65);
      display:flex; align-items:center; gap:9px; }

  /* ===================== 1) corner family — 编辑式构图,不放「大字/序号」装饰 =====================
     核心转变:标题从「左下角小标注(36px)」升级为「英雄级主角」,靠版式结构(spine 轴线 /
     通栏基线 / 版权页式 meta)与比例、留白出设计感,而非往角上堆图形。两套构图锚点不同:
     corner 锚底、corner-atlas 锚上三分之一,形成真实的构图差异。 */

  /* ---- 1a) corner(默认):底部英雄标题 + 右侧「若隐若现」飞书飞鸟线稿(无左侧竖线) ---- */
  .cover-corner .bloom { right:-18%; top:-6%; bottom:auto; height:74%; opacity:.9; }
  /* 飞书飞鸟线稿:从官方 logo 描摹的双翼,只描边不填色(theme-token 上色)。整体极低透明 +
     边缘径向柔化遮罩,让它「若隐若现」融进背景,而非一条抢眼的实线;跟随浅/深与配色。 */
  .cover-corner .bird { position:absolute; right:4%; top:28%; width:30%; z-index:1;
      opacity:.16; pointer-events:none; user-select:none;
      -webkit-mask-image:radial-gradient(72% 72% at 60% 45%, #000 42%, transparent 88%);
              mask-image:radial-gradient(72% 72% at 60% 45%, #000 42%, transparent 88%);
      /* 「点亮感」:整只 logo 有一层辉光呼吸 —— 底透明度从淡到亮循环起伏,呈现「被点亮 /
         通电」质感,而非一条淡色死线稿。辉光色 100% 取主题 token(--fs-glow-*)。 */
      animation:birdLit 5.6s ease-in-out infinite; }
  .cover-corner .bird .bird-svg { width:100%; height:auto; display:block;
      transform:rotate(-4deg);
      /* 描边外挂 token 辉光,强化「通电点亮」质感(非填色,仍是线稿) */
      filter:drop-shadow(0 0 3px var(--fs-glow-accent))
             drop-shadow(0 0 7px var(--fs-glow-primary)); }
  /* ---- 背景飞书 logo「点亮呼吸」动效 ----
     整只飞鸟线稿随节拍从淡到亮循环起伏(birdLit),配 token drop-shadow 辉光,
     呈现「被点亮 / 通电」质感,而非一条淡色死线稿。辉光/描边色 100% 取主题 token。
     尊重 prefers-reduced-motion:reduce → 冻结在确定姿态(供封面严格一致的像素校验)。 */
  /* logo「点亮呼吸」:底透明度在淡↔亮之间起伏 */
  @keyframes birdLit {
      0%,100% { opacity:.16; }
      50%     { opacity:.42; } }
  /* 严格一致像素校验/无障碍:降级则冻结在确定姿态(点亮定值),两次截图完全一致 */
  @media (prefers-reduced-motion:reduce) {
      .cover-corner .bird { animation:none; opacity:.32; } }
  .cover-corner .body { padding:0 9% 9% 11%; justify-content:flex-end; }
  .cover-corner .kicker { margin-bottom:20px; }
  /* 标题固定占位区:高度固定(与两行 40px 标题等高),字号在内部自适应,不影响下方
     rule / foot 的位置。字号由 title_px 内联给出(build_html 按字数算),这里做上限与
     行为约束;title-zone 用 flex 让标题底对齐,保证基线稳定。 */
  .cover-corner .title-zone { height:106px; display:flex; align-items:flex-end;
      margin-bottom:22px; overflow:hidden; }
  .cover-corner h2 { line-height:1.14; letter-spacing:-.03em; max-width:none;
      width:fit-content; margin:0; white-space:nowrap; }
  /* 标题与脚注之间一道细线,左端一截 accent 起笔,用线建立秩序 */
  .cover-corner .rule { position:relative; width:100%; height:1px; background:var(--fs-hairline);
      margin-bottom:16px; }
  .cover-corner .rule::before { content:""; position:absolute; left:0; top:-1px; width:101px;
      height:3px; border-radius:3px; background:var(--fs-grad-keyline);
      box-shadow:0 0 12px var(--fs-glow-accent); }

  /* ---- 1b) corner-atlas:瑞士编辑式 —— 标题锚上三分之一 + 通栏基线 + 版权页式 meta 行 ---- */
  .cover-corner-atlas .bloom { right:-14%; bottom:-16%; top:auto; height:66%; opacity:.85; }
  .cover-corner-atlas .body { padding:calc(14.5% + 7%) 9% 8%; justify-content:flex-start; }
  .cover-corner-atlas h2 { font-size:40px; line-height:1.14; letter-spacing:-.028em;
      max-width:92%; margin-bottom:24px; text-wrap:balance; }
  /* 通栏基线:标题与版权页 meta 之间一道贯穿细线,左端一截 accent 起笔 —— 强网格秩序 */
  .cover-corner-atlas .baseline { position:relative; width:100%; height:1px;
      background:var(--fs-hairline); margin-bottom:20px; }
  .cover-corner-atlas .baseline::before { content:""; position:absolute; left:0; top:-1px;
      width:96px; height:3px; border-radius:3px; background:var(--fs-grad-keyline);
      box-shadow:0 0 12px var(--fs-glow-accent); }
  /* 版权页式 meta:三栏「标签 / 值」,像书籍版权页/杂志刊头,把信息网格化而非一行小灰字 */
  .cover-corner-atlas .colophon { display:flex; gap:56px; }
  .cover-corner-atlas .colophon .col { display:flex; flex-direction:column; gap:6px; }
  .cover-corner-atlas .colophon .lbl { font-size:9.5px; letter-spacing:.28em;
      text-transform:uppercase; font-weight:700; color:var(--fs-accent); }
  .cover-corner-atlas .colophon .val { font-size:14px; font-weight:600; color:var(--fs-text-72);
      letter-spacing:.01em; }

  /* 2) beam: two soft light-beams sweeping across (blurred, glowing) */
  .cover-beam .beam { position:absolute; left:-25%; right:-25%; height:30%; top:26%;
      z-index:1; transform:rotate(-15deg); transform-origin:center;
      background:linear-gradient(90deg, transparent, var(--fs-glow-primary), transparent);
      filter:blur(14px); opacity:.9; }
  .cover-beam .beam.b2 { top:56%; height:20%; opacity:.6;
      background:linear-gradient(90deg, transparent, var(--fs-glow-accent), transparent); }
  .cover-beam .bloom { left:-20%; top:-24%; height:80%; }
  .cover-beam h2 { max-width:82%; }

  /* 3) column: full-height gradient bar (glowing) + vertical label */
  .cover-column .colbar { position:absolute; top:14.5%; left:0; bottom:0; width:9%;
      background:var(--fs-grad-keyline); z-index:2;
      box-shadow:6px 0 28px -6px var(--fs-glow-primary); }
  .cover-column .colbar::after { content:""; position:absolute; inset:0;
      background:var(--fs-grad-sheen); mix-blend-mode:overlay; opacity:.6; }
  .cover-column .vlabel { position:absolute; left:0; bottom:8%; width:9%; z-index:3;
      writing-mode:vertical-rl; text-orientation:mixed; transform:rotate(180deg);
      text-align:center; font-size:9.5px; letter-spacing:.34em; text-transform:uppercase;
      color:#fff; font-weight:700; opacity:.95; }
  .cover-column .bloom { right:-14%; bottom:-24%; }
  .cover-column .body { padding-left:16%; }
  .cover-column h2 { max-width:84%; font-size:33px; }

  /* 4) frame: inset glowing border below masthead + centered bloom */
  .cover-frame .frm { position:absolute; left:4%; right:4%; top:calc(14.5% + 4.5%);
      bottom:6%; border:1px solid var(--fs-glass-border); border-radius:8px; z-index:2;
      box-shadow:inset 0 0 40px var(--fs-glow-primary); }
  .cover-frame .bloom { left:50%; top:56%; transform:translate(-50%,-50%);
      width:78%; height:78%; }
  .cover-frame .body { align-items:center; text-align:center; justify-content:center;
      padding:calc(14.5% + 5%) 11% 7%; }
  .cover-frame h2 { max-width:80%; }
  .cover-frame .kicker { justify-content:center; }
  .cover-frame .keyline { margin-left:auto; margin-right:auto; }

  /* 5) spotlight: top bloom spotlight, centered dramatic */
  .cover-spotlight .bloom { left:50%; top:-16%; transform:translateX(-50%);
      width:92%; height:86%; }
  .cover-spotlight .body { align-items:center; text-align:center; justify-content:center;
      padding-top:14.5%; }
  .cover-spotlight h2 { max-width:80%; font-size:42px; }
  .cover-spotlight .kicker { justify-content:center; }
  .cover-spotlight .kicker.chip::before { display:none; }
  .cover-spotlight .kicker.chip { border:1px solid var(--fs-glass-border); border-radius:999px;
      padding:7px 18px; background:var(--fs-glass);
      -webkit-backdrop-filter:blur(8px); backdrop-filter:blur(8px);
      box-shadow:0 2px 10px var(--fs-glow-accent); }
  .cover-spotlight .keyline { margin-left:auto; margin-right:auto; }

  /* 6) editorial: giant gradient ghost numeral + left glowing keyline */
  .cover-editorial .idx { position:absolute; right:4%; bottom:-8%; z-index:1;
      font-size:300px; font-weight:800; line-height:.8; letter-spacing:-.05em;
      user-select:none; background:var(--fs-grad-title); -webkit-background-clip:text;
      background-clip:text; -webkit-text-fill-color:transparent; opacity:.14; }
  .cover-editorial::before { content:""; position:absolute; left:8%; top:calc(14.5% + 6%);
      bottom:9%; width:3px; border-radius:3px; background:var(--fs-grad-keyline); z-index:2;
      box-shadow:0 0 18px var(--fs-glow-accent); }
  .cover-editorial .bloom { right:-10%; bottom:-20%; }
  .cover-editorial .body { padding-left:12%; }
  .cover-editorial .keyline { display:none; }
  .cover-editorial h2 { max-width:86%; }

  /* 7) split: right glass color panel (mesh + bloom + grain), title on the seam */
  .cover-split .panel { position:absolute; top:0; right:0; bottom:0; width:34%; z-index:2;
      background:var(--fs-grad-keyline); overflow:hidden;
      box-shadow:-8px 0 30px -10px var(--fs-glow-primary); }
  .cover-split .panel::before { content:""; position:absolute; inset:0;
      background:var(--fs-grad-sheen); mix-blend-mode:overlay; opacity:.7; }
  .cover-split .panel-glow { position:absolute; right:-30%; top:-20%; width:120%; height:80%;
      background:var(--fs-grad-bloom); filter:blur(10px); opacity:.9; }
  .cover-split .panel-grain { position:absolute; inset:0; opacity:.35;
      background-image:radial-gradient(rgba(255,255,255,.65) .7px, transparent .8px);
      background-size:16px 16px; }
  .cover-split .body { padding-right:38%; }
  .cover-split h2 { max-width:100%; font-size:33px; }
"""


def _read_text(path):
    try:
        with open(path, encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


def _img_data_uri(path):
    """Inline an image file as a data: URI so the cover is self-contained."""
    import base64
    import mimetypes
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except OSError:
        return None
    mime = mimetypes.guess_type(path)[0] or "image/png"
    b64 = base64.b64encode(raw).decode("ascii")
    return f"data:{mime};base64,{b64}"


def build_cobrand(company_logo, feishu_logo):
    """Left-top co-brand lockup: [company logo] × [Feishu logo].

    company_logo: path to the user's uploaded company logo (png/svg/jpg). If
      None/missing -> a dashed placeholder box ('公司 LOGO') is shown instead,
      i.e. the slot is pre-reserved even before a logo exists.
    feishu_logo: path to the bundled official Feishu logo (png/svg). Pick the
      light- or dark-text variant via feishu_logo_for_mode() before calling.
    """
    # company side
    if company_logo:
        if company_logo.lower().endswith(".svg"):
            svg = _read_text(company_logo)
            comp = svg if svg else '<div class="ph">公司 LOGO</div>'
        else:
            uri = _img_data_uri(company_logo)
            comp = f'<img src="{uri}" alt="company logo">' if uri else '<div class="ph">公司 LOGO</div>'
    else:
        comp = '<div class="ph">公司 LOGO</div>'
    # feishu side (bundled official logo; svg inlined, raster -> data URI)
    if feishu_logo and feishu_logo.lower().endswith(".svg"):
        fs_svg = _read_text(feishu_logo)
        fs = fs_svg if fs_svg else '<div class="ph">飞书 Feishu</div>'
    elif feishu_logo:
        uri = _img_data_uri(feishu_logo)
        fs = f'<img src="{uri}" alt="Feishu">' if uri else '<div class="ph">飞书 Feishu</div>'
    else:
        fs = '<div class="ph">飞书 Feishu</div>'
    return (f'<div class="lockup">{comp}<div class="x"></div>{fs}</div>'
            f'<div class="mh-meta">AI 先锋大赛</div>')


def feishu_logo_for_mode(base, mode):
    """Official Feishu logo has BLACK text; on dark covers use the white-text
    variant (<stem>-dark<ext>) if it exists. Falls back to base otherwise."""
    if not base:
        return base
    if mode != "dark":
        return base
    stem, ext = os.path.splitext(base)
    dark = f"{stem}-dark{ext}"
    return dark if os.path.exists(dark) else base


def _line_units(line):
    """视觉宽度(以 CJK 字宽为 1 单位):CJK/全角=1.0,ASCII 字母数字/空格≈0.56。
    用于按字数估算标题占宽,驱动字号自适应。"""
    import unicodedata
    u = 0.0
    for ch in line:
        if CJK_FIT.match(ch) or unicodedata.east_asian_width(ch) in ("W", "F"):
            u += 1.0
        else:
            u += 0.56
    return u


def fit_title_px(title, base_px=40, min_px=22, base_units=10.0):
    """文字内容『位置固定、字号按实际字数自适应』的核心:
    标题位置(title-zone)固定,只让字号在区内自适应。按最长一行的视觉宽度反推字号——
    base_px 号可容纳约 base_units 个 CJK 字宽;更长则等比缩小,下限 min_px。
    <br> 视为换行,分别量宽取最大。"""
    lines = re.split(r"<br\s*/?>", title, flags=re.I)
    widest = max((_line_units(l) for l in lines), default=0.0)
    if widest <= base_units:
        return base_px
    px = int(base_px * base_units / widest)
    return max(min_px, min(base_px, px))



def build_html(data, title, author, date, company_name=None):
    palette = data["palette"]
    tbm = data["tokens_by_mode"]
    wbm = data["wcag_by_mode"]
    default_mode = data.get("default_mode", palette.get("default_mode", "light"))

    name = palette.get("name", "theme")
    # the raw user input color (identical in both modes' core.primary)
    input_hex = palette["primary"]
    input_src = "Logo 提取主色" if data.get("logo_candidates") else "指定主色"
    in_h = _hue(input_hex)

    # scope each mode's tokens under a class so BOTH can render in one static sheet
    def scope(cls, toks):
        body = "\n".join(f"    {k}: {v};" for k, v in toks.items())
        return f"  .{cls} {{\n{body}\n  }}"

    m_light = scope("m-light", tbm["light"])
    m_dark = scope("m-dark", tbm["dark"])

    # ---- lineage chips: input primary -> derived stops (light mode) ----
    lt = tbm["light"]
    lin_stops = [
        ("Primary 主色", lt["--fs-blue"]),
        ("Accent 强调", lt["--fs-cyan"]),
        ("bg-0 背景", lt["--fs-bg-0"]),
        ("bg-1", lt["--fs-bg-1"]),
        ("bg-2", lt["--fs-bg-2"]),
        ("bg-3", lt["--fs-bg-3"]),
    ]
    lin_html = ""
    for lab, hx in lin_stops:
        lin_html += (
            f'<div class="lchip"><div class="sw" style="background:{hx}"></div>'
            f'<div class="lc-lab">{lab}</div><code>{hx}</code>'
            f'<em>H={_hue(hx)}°</em></div>'
        )

    # ---- 4-tier swatch cards, rendered per mode ----
    def swatch_cards(core, w):
        rows = [
            ("Primary 主品牌色", core["primary"], "主标题 · 核心按钮 · 关键强调", w["primary_on_bg0"]),
            ("Accent 辅助强调色", core["accent"], "次级按钮 · 高亮标签 · 徽章 · 交互态", w["accent_on_bg0"]),
            ("Background 背景基调", core["background"], "页面大面积背景底色", None),
            ("Text 正文灰阶", core["text"], "主副标题 · 正文内容", w["text_on_bg0"]),
        ]
        out = ""
        for cname, hx, use, ratio in rows:
            rt = "底色" if ratio is None else f"对比度 {ratio}"
            out += (
                f'<div class="card"><div class="chip" style="background:{hx}"></div>'
                f'<div class="meta"><div class="cname">{cname}</div>'
                f'<div class="chex">{hx}</div><div class="cuse">{use}</div>'
                f'<div class="cwcag">{rt}</div></div></div>'
            )
        return out

    light_cards = swatch_cards(palette["light"], wbm["light"])

    # cover layout preset: one of COVER_PRESETS keys (see references/cover-presets.md).
    # default 'corner' — co-brand lockup (company × Feishu) + glow, AI-case report cover.
    layout = data.get("cover_layout", "corner")
    cover_markup = COVER_PRESETS.get(layout, COVER_PRESETS["corner"])

    # 封面 kicker 署名:企业名称由 --company-name / 环境变量 DECK_COMPANY_NAME /
    # data["company_name"] 注入,缺省占位。SoT 优先级(v9.1):环境变量 > 显式参数 > data,
    # 与 preview-content.py 统一以环境变量为单一真源,保证 cover/内页 kicker 一致。
    _env_company = os.environ.get("DECK_COMPANY_NAME")
    _picked_company = (_env_company if _env_company
                       else (company_name if company_name is not None
                             else data.get("company_name")))
    kicker_txt = brand_kicker(_picked_company)

    # co-brand lockup: company logo (user's; None -> placeholder slot) × Feishu logo (bundled)
    company_logo = data.get("company_logo")   # path, set by caller after Step 1 confirm
    feishu_logo = data.get("feishu_logo", os.path.join(os.path.dirname(__file__), "feishu-logo.png"))
    # 「无托卡·裸标」后 LOGO 直接落玻璃带上,不再有浅色安全片,所以必须按模式取飞书标:
    # 浅色带用黑字原版、深色带用白字版(feishu_logo_for_mode),否则黑字飞书标在近透明的
    # 深色玻璃带上会看不清。故 cobrand 改为 per-mode 生成。
    cobrand_by_mode = {
        m: build_cobrand(company_logo, feishu_logo_for_mode(feishu_logo, m))
        for m in ("light", "dark")
    }

    def cover(mode_cls, label, mode):
        # supply every placeholder any preset might use; missing ones are harmless
        # title_px: 位置固定、字号按实际字数自适应(见 fit_title_px)
        fields = {"title": title, "author": author, "date": date,
                  "cobrand": cobrand_by_mode[mode], "kicker": kicker_txt,
                  "bird": BIRD_SVG, "title_px": fit_title_px(title)}
        inner = cover_markup.format(**fields)
        return f"""
      <div class="cover-col">
        <div class="cover-cap">{label}</div>
        <div class="{mode_cls} cover-wrap cover-{layout}">{inner}</div>
      </div>"""

    covers = cover("m-light", "浅色基调 · 默认", "light") + cover("m-dark", "深色基调", "dark")

    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<style>
{m_light}
{m_dark}
  * {{ box-sizing:border-box; margin:0; padding:0; }}
  body {{ font-family: system-ui,"Noto Sans SC","PingFang SC",sans-serif;
          background:#EEF1F6; color:#1A1F2B; padding:44px 40px; }}
  .wrap {{ max-width:1180px; margin:0 auto; }}
  h1.sec {{ font-size:22px; margin-bottom:4px; }}
  h1.sec .name {{ color:#5B6472; font-weight:600; }}
  p.hint {{ font-size:13.5px; color:#6B7280; margin-bottom:22px; line-height:1.5; }}

  /* ---- lineage strip: input primary vs derived ---- */
  .lineage {{ background:#fff; border:1px solid #E3E7EE; border-radius:16px;
              padding:22px 24px; margin-bottom:16px;
              display:flex; align-items:center; gap:22px; flex-wrap:nowrap; }}
  .lin-in {{ display:flex; align-items:center; gap:14px; flex:0 0 auto; }}
  .lin-in .big {{ width:88px; height:88px; border-radius:14px;
                  box-shadow:0 6px 18px rgba(0,0,0,.14); }}
  .lin-in .lab b {{ display:block; font-size:15px; color:#1A1F2B; }}
  .lin-in .lab span {{ display:block; font-size:11px; letter-spacing:.15em;
                       color:#9AA2AF; margin:2px 0 6px; }}
  .lin-in .lab code {{ font-family:"SF Mono",Menlo,monospace; font-size:14px;
                       color:#1A1F2B; font-weight:600; }}
  .lin-in .lab em {{ display:block; font-style:normal; font-size:12px;
                     color:#6B7280; margin-top:3px; }}
  .lin-arrow {{ flex:0 0 auto; font-size:13px; color:#9AA2AF; font-weight:600;
                white-space:nowrap; }}
  .lin-out {{ display:flex; gap:12px; flex:1 1 auto; }}
  .lchip {{ text-align:center; flex:1 1 0; min-width:0; }}
  .lchip .sw {{ height:56px; border-radius:10px; border:1px solid #E3E7EE; }}
  .lchip .lc-lab {{ font-size:11.5px; color:#4B5563; margin:6px 0 2px; }}
  .lchip code {{ font-family:"SF Mono",Menlo,monospace; font-size:11px; color:#1A1F2B; }}
  .lchip em {{ display:block; font-style:normal; font-size:10.5px; color:#9AA2AF; margin-top:1px; }}
  .lineage-note {{ font-size:13px; color:#2F855A; background:#EAF7EF; border:1px solid #CDEBD8;
                   border-radius:10px; padding:10px 14px; margin-bottom:34px; }}

  /* ---- 4-tier swatch cards ---- */
  .grid {{ display:grid; grid-template-columns:repeat(4,1fr); gap:16px; margin-bottom:38px; }}
  .card {{ background:#fff; border:1px solid #E3E7EE; border-radius:14px; overflow:hidden; }}
  .chip {{ height:92px; }}
  .meta {{ padding:14px 16px; }}
  .cname {{ font-size:15px; font-weight:600; }}
  .chex {{ font-family:"SF Mono",Menlo,monospace; font-size:13px; color:#8A92A0; margin:3px 0 8px; }}
  .cuse {{ font-size:13px; color:#5B6472; line-height:1.4; min-height:36px; }}
  .cwcag {{ font-size:12px; color:#3C6BE0; margin-top:8px; font-weight:600; }}

  /* ---- two cover samples side by side ---- */
  .covers {{ display:grid; grid-template-columns:1fr 1fr; gap:20px; }}
  .cover-cap {{ font-size:13.5px; font-weight:600; color:#4B5563; margin-bottom:10px; }}
{COVER_CSS}
</style></head>
<body><div class="wrap">
  <h1 class="sec">配色方案确认 <span class="name">· {name}</span></h1>
  <p class="hint">以下配色 100% 由你的{input_src}派生。请确认后回复「可以 / 确认」进入出片,
     或用文字描述要怎么微调(如「辅助色再淡点」「背景暖一点」「主色换成 #XXXXXX」)。</p>

  <div class="lineage">
    <div class="lin-in">
      <div class="big" style="background:{input_hex}"></div>
      <div class="lab"><b>你的输入主色</b><span>{input_src.upper()}</span>
        <code>{input_hex}</code><em>OKLCH H={in_h}°</em></div>
    </div>
    <div class="lin-arrow">同色相<br>派生 →</div>
    <div class="lin-out">{lin_html}</div>
  </div>
  <p class="lineage-note">✓ 对比:浅色背景 bg-0~bg-3 与你的输入主色<b>同色相(H≈{in_h}°)</b>,
     所以整套<b>浅色基调也带你的品牌色调</b>(不是纯白),配色确实源于你的颜色。</p>

  <h1 class="sec">4 阶色板(浅色基调)</h1>
  <p class="hint">色块 + Hex + 用途 + WCAG 对比度。深/浅两套主色、辅助色一致,仅背景与文字明暗相反。</p>
  <div class="grid">{light_cards}</div>

  <h1 class="sec">封面样张 · 浅色(默认) + 深色</h1>
  <p class="hint">同一份配色,套到真实 16:9 deck 封面上的实际观感。生成的 deck 里默认浅色,同时内置深色一套。</p>
  <div class="covers">{covers}</div>
</div>
</body></html>"""


def shoot_png(html_path, png_path):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch(args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"])
        pg = b.new_page(viewport={"width": 1280, "height": 1600}, device_scale_factor=2)
        pg.goto("file://" + os.path.abspath(html_path))
        pg.wait_for_timeout(400)
        pg.screenshot(path=png_path, full_page=True)
        b.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("palette")
    ap.add_argument("--title", default="标题占位 · 第二行")
    ap.add_argument("--author", default="发起人")
    ap.add_argument("--date", default="2026.07.27")
    ap.add_argument("--out", required=True, help="HTML 中间产物路径;PNG 为同名 .png,即确认物料")
    ap.add_argument("--cover-layout", choices=list(COVER_PRESETS.keys()),
                    help="封面版式预设(不传则读 palette.json 的 cover_layout,再兜底 corner)")
    ap.add_argument("--company-logo",
                    help="用户公司 LOGO 路径(Step 1 确认后传入);不传则封面显示占位框")
    ap.add_argument("--company-name", default=None,
                    help="企业名称(Step 1 确认后传入),替换封面 kicker 前缀;缺省占位「企业名称」")
    ap.add_argument("--feishu-logo",
                    help="飞书 LOGO 路径(默认用 assets/feishu-logo.png,不需上传;"
                         "深色模式自动切 feishu-logo-dark.png 白字版)")
    ap.add_argument("--no-shoot", action="store_true", help="只写 HTML,不截 PNG(默认会截)")
    args = ap.parse_args()

    data = json.load(open(args.palette))
    if args.cover_layout:
        data["cover_layout"] = args.cover_layout
    if args.company_logo:
        data["company_logo"] = args.company_logo
    if args.company_name:
        data["company_name"] = args.company_name
        # SoT 统一(v9.1):同步写入环境变量 DECK_COMPANY_NAME,让下游 preview-content
        # 与本脚本内 build_html 共用同一份企业名称;env 缺省时才回落 data。
        os.environ["DECK_COMPANY_NAME"] = args.company_name
    if args.feishu_logo:
        data["feishu_logo"] = args.feishu_logo
    html = build_html(data, args.title, args.author, args.date, args.company_name)
    with open(args.out, "w") as f:
        f.write(html)
    print("wrote", args.out)

    if not args.no_shoot:
        png = os.path.splitext(args.out)[0] + ".png"
        try:
            shoot_png(args.out, png)
        except Exception as e:
            # 截图硬失败 → 让 agent 拿到非 0 退出码,禁止「静默改姿势」用 HTML 部署替代
            print("FATAL: shoot_png failed — {}".format(e), file=sys.stderr)
            print("HINT: 按 references/preview-rendering.md 修 Playwright / Chromium / 系统库依赖后重试", file=sys.stderr)
            print("STRICT: PNG 是 Step 3 唯一合法确认物料。禁止把 preview.html 用 lark-apps / miaoda 部署成公网 URL 替代 PNG——", file=sys.stderr)
            print("        用户端要看到内联渲染的图,不是可点开的 HTML 链接;违反此条 = Step 3 校验不通过、闸门不开。", file=sys.stderr)
            sys.exit(1)
        print("PNG 确认物料:", png)


if __name__ == "__main__":
    main()
