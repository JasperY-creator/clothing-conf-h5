#!/usr/bin/env python3
"""
lint-slides.py — 出片排版规范自动校验器 (stdlib-only, 无第三方依赖)

对照 references/production-spec.md 里【■ 强校验】那批规则,静态扫描生成的 deck HTML。
每页扫一遍 + 全局扫一遍,打印分级报告:
  · ERROR  → 硬伤,必须修 (退出码 1)
  · WARN   → 疑似(可能误报),顺带核一眼,不阻断 (除非 --strict)

format 校验全自动:唯一门禁 = 本脚本退出码,ERROR 清零即通过,不需要人工两三轮把关。
每页生成后 / 全 deck 输出前各跑一次,有 ERROR 就改完重跑到 0。□ 类版式/语义项属
「生成注意事项」,不在本脚本强判范围。

用法
----
python3 assets/lint-slides.py deck.html                 # 校验整份
python3 assets/lint-slides.py deck.html --page 3        # 只看第 3 页(1-based)
python3 assets/lint-slides.py deck.html --strict        # WARN 也计入退出码
python3 assets/lint-slides.py deck.html --lang zh|en    # 强制页面主语言(默认自动判定)

页面切分:按 <section> / <div class~="slide|page|deck-page"> / 注释 <!-- page --> 识别;
识别不到就整篇当一页。
"""
import argparse
import re
import sys
from html.parser import HTMLParser

# ---- font family accepted names (方正兰亭黑) --------------------------------
FONT_OK = re.compile(r"(方正兰亭黑|FZLanTingHei|FZLanTing|LanTingHei)", re.I)

# ---- CJK detection ----------------------------------------------------------
CJK = re.compile(r"[一-鿿　-〿＀-￯]")


class TextExtractor(HTMLParser):
    """Collect visible text and inline style/size signals, skipping script/style."""
    SKIP = {"script", "style", "head", "title"}

    def __init__(self):
        super().__init__()
        self.skip_depth = 0
        self.text_parts = []
        self.title_sizes = []   # font-size px found on heading-ish tags
        self.body_sizes = []    # font-size px on normal text tags

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip_depth += 1

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip_depth > 0:
            self.skip_depth -= 1

    def handle_data(self, data):
        if self.skip_depth == 0 and data.strip():
            self.text_parts.append(data)

    def text(self):
        return "".join(self.text_parts)


def split_pages(html):
    """Return list of (label, html_fragment). Best-effort page segmentation."""
    # 1) explicit <section ...> blocks
    secs = re.findall(r"<section\b[^>]*>.*?</section>", html, re.S | re.I)
    if len(secs) >= 2:
        return [(f"page {i+1}", s) for i, s in enumerate(secs)]
    # 2) div with slide/page-ish class
    divs = re.findall(
        r'<div\b[^>]*class="[^"]*\b(?:slide|page|deck-page|cover)\b[^"]*"[^>]*>.*?</div>',
        html, re.S | re.I)
    if len(divs) >= 2:
        return [(f"page {i+1}", d) for i, d in enumerate(divs)]
    return [("page 1", html)]


def font_sizes_px(fragment):
    """All font-size declarations converted to px (pt*1.333 -> px)."""
    out = []
    for val, unit in re.findall(r"font-size\s*:\s*([\d.]+)\s*(px|pt|rem|em)", fragment, re.I):
        v = float(val)
        u = unit.lower()
        if u == "pt":
            v = v * 96 / 72
        elif u in ("rem", "em"):
            v = v * 16
        out.append(round(v, 1))
    return out


def _css_has_aspect(html):
    return bool(re.search(r"aspect-ratio\s*:\s*16\s*/\s*9", html)) or \
        bool(re.search(r"width\s*:\s*1280px[\s\S]{0,80}height\s*:\s*720px", html))


def _css_has_font(html):
    fams = re.findall(r"font-family\s*:\s*([^;}]+)", html, re.I)
    return any(FONT_OK.search(f) for f in fams)


def check_page(idx, label, frag, lang, full_html):
    errors, warns = [], []
    text = TextExtractor()
    try:
        text.feed(frag)
    except Exception:
        pass
    body = text.text()

    def e(code, msg):
        errors.append(f"[P{idx}] {code}: {msg}")

    def w(code, msg):
        warns.append(f"[P{idx}] {code}: {msg}")

    # --- P1 aspect ratio (inline OR via global CSS class) ---
    if not _css_has_aspect(frag) and not _css_has_aspect(full_html):
        w("P1", "未见 aspect-ratio:16/9 或 1280x720,请确认页面为 16:9")

    # --- F1 font family (inline OR via global CSS on body/root) ---
    fams = re.findall(r"font-family\s*:\s*([^;}]+)", frag, re.I)
    if not any(FONT_OK.search(f) for f in fams) and not _css_has_font(full_html):
        w("F1", "未检出方正兰亭黑字体族(请确认标题/正文用方正兰亭黑)")

    # --- font sizes ---
    sizes = font_sizes_px(frag)
    for s in sizes:
        if s < 12:
            e("F4", f"出现字号 {s}px < 12px(正文最小 12,通常 14–16)")
    # body-size sanity: sizes that aren't title(26)/footnote(10) should be 14-16
    body_like = [s for s in sizes if s not in (26.0,) and 12 <= s <= 40 and abs(s-10) > 0.5]
    distinct_body = sorted(set(s for s in body_like if 12 <= s <= 24))
    if len(distinct_body) > 2:
        w("F6", f"同页正文字号种类偏多 {distinct_body},建议同页统一字号")
    for s in distinct_body:
        if not (14 <= s <= 16) and s not in (26.0, 10.0):
            w("F3", f"正文字号 {s}px 不在 14–16 常用区间")

    # --- B1 bullet / dash glyphs ---
    # if a list-like structure uses hyphen/en/em dash as a bullet marker -> warn
    if re.search(r"(^|\n)\s*[-–—]\s+\S", body):
        w("B1", "疑似用 - / – / — 当项目符号;bullet 用 •(U+2022)、dash 层级用 ‒(U+2012)")

    # --- S1 double spaces ---
    # ignore leading indentation; flag mid-text double spaces
    for line in body.splitlines():
        st = line.strip()
        if re.search(r"\S  +\S", st):
            e("S1", "正文出现连续 ≥2 空格")
            break

    # --- S2 slash spacing --- "/" 后需空格
    for m in re.finditer(r"\S/(?=\S)", body):
        seg = body[max(0, m.start()-6):m.end()+6]
        # skip URLs and dates
        if re.search(r"https?:|://|\d/\d", seg):
            continue
        w("S2", f"「/」后建议加空格:…{seg.strip()}…")
        break

    # --- S3 bracket spacing (english bracket needs leading space) ---
    if re.search(r"[A-Za-z0-9]\([A-Za-z]", body):
        w("S3", "英文括号前建议加空格,如「字体 (华文楷体)」")
    if re.search(r"[一-鿿]\s+[(（]", body):
        w("S3", "中文括号前不应有空格")

    # --- N1 thousands separator on 4+ digit integers ---
    for m in re.finditer(r"(?<![\d.,])\d{4,}(?![\d.])", body):
        num = m.group(0)
        ctx = body[max(0, m.start()-3):m.end()+2]
        # skip years (19xx/20xx), 年份带E, and things already inside a bigger grouped number
        if re.fullmatch(r"(19|20)\d{2}", num):
            continue
        if "E" in body[m.end():m.end()+1]:
            continue
        w("N1", f"数字 {num} ≥4 位建议加千分号(年份/带E除外)")
        break

    # --- N2 magnitude abbrev must be lowercase ---
    if re.search(r"\d\s?(K|MN|BN|Mn|Bn|Kn)\b", body):
        w("N2", "量级缩写应小写 k/mn/bn")

    # --- A1 e.g. / i.e. comma ---
    for tok in ("e.g.", "i.e."):
        for m in re.finditer(re.escape(tok), body):
            after = body[m.end():m.end()+1]
            if after and after != ",":
                e("A1", f"{tok} 后需加逗号(如 {tok}, …)")
                break

    # --- A2 e.g. + etc. same sentence ---
    # protect abbreviation dots before splitting on sentence terminators
    prot = body
    for tok in ("e.g.", "i.e.", "etc.", "vs.", "cf."):
        prot = prot.replace(tok, tok.replace(".", "\x00"))
    for sent in re.split(r"[.。!?!?\n]", prot):
        s = sent.replace("\x00", ".")
        if "e.g." in s and "etc." in s:
            e("A2", "同句中 e.g. 与 etc. 不能同时使用")
            break

    return errors, warns


def check_global(html):
    errors, warns = [], []
    # F2 title 26 present somewhere
    if not any(abs(s-26) < 0.5 for s in font_sizes_px(html)):
        warns.append("[G] F2: 全局未检出 26px 标题字号(请确认标题为 26)")
    # F5 footnote 10 present
    if not any(abs(s-10) < 0.5 for s in font_sizes_px(html)):
        warns.append("[G] F5: 全局未检出 10px 脚注/来源字号")
    return errors, warns


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("html")
    ap.add_argument("--page", type=int, help="只校验第 N 页(1-based)")
    ap.add_argument("--strict", action="store_true", help="WARN 也计入退出码")
    ap.add_argument("--lang", choices=["zh", "en"], help="强制页面主语言")
    args = ap.parse_args()

    try:
        with open(args.html, encoding="utf-8") as f:
            html = f.read()
    except FileNotFoundError:
        sys.exit(f"[lint-slides] 找不到文件:{args.html}")
    except OSError as e:
        sys.exit(f"[lint-slides] 读取文件失败:{args.html}({e})")

    pages = split_pages(html)
    all_err, all_warn = [], []

    ge, gw = check_global(html)
    all_err += ge
    all_warn += gw

    for i, (label, frag) in enumerate(pages, 1):
        if args.page and i != args.page:
            continue
        lang = args.lang or ("zh" if len(CJK.findall(frag)) >= 10 else "en")
        e, w = check_page(i, label, frag, lang, html)
        all_err += e
        all_warn += w

    print(f"扫描 {len(pages)} 页 · ERROR {len(all_err)} · WARN {len(all_warn)}")
    print("-" * 60)
    for x in all_err:
        print("  ✗", x)
    for x in all_warn:
        print("  ⚠", x)
    if not all_err and not all_warn:
        print("  ✓ 全部机器可校验项通过")
    print("-" * 60)

    fail = bool(all_err) or (args.strict and bool(all_warn))
    if fail:
        print("校验未通过 → 修正后重跑(本轮不得进入下一步/最终输出)。")
        sys.exit(1)
    print("机器校验通过 ✓(□ 类版式/语义项为生成注意事项,非强校验,见 production-spec.md)")
    sys.exit(0)


if __name__ == "__main__":
    main()
