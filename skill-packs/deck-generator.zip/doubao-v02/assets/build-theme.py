#!/usr/bin/env python3
"""
build-theme.py — 视觉基调派生引擎 (Step 0 的技术心脏 · OKLCH 感知色阶版)

把 "一张 Logo" 或 "用户给的主色" 扩展成一整套 deck 引擎能吃的 CSS token。
配色 100% 由用户输入决定,不预设任何品牌色。派生在 OKLCH 感知均匀色彩空间中
用【固定站点公式】完成,保证:
  · 确定性  —— 同一输入永远同一结果 (KMeans seeded + 纯公式)
  · 高级度  —— 感知均匀 + 色度受控 + sRGB 色域裁剪,任何 Logo 质量一致
  · 可达性  —— 正文/强调色做 WCAG 对比度兜底

用法
----
python3 build-theme.py --logo logo.png            --name acme --out themes/acme
python3 build-theme.py --primary "#3C7FFF"          --name acme --out themes/acme
python3 build-theme.py --primary "#0E7C5A" --mode light --name acme --out themes/acme

产物: themes/<name>/{palette.json, theme.css, brand.json}
"""

import argparse
import colorsys
import json
import math
import os

# ============================================================ sRGB <-> OKLCH
# Björn Ottosson's OKLab. OKLCH = OKLab in cylindrical (L, C, H) form.
# L: perceptual lightness 0..1 · C: chroma 0..~0.37 · H: hue degrees 0..360

def _srgb_to_lin(c):
    c = c / 255
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _lin_to_srgb(c):
    c = 12.92 * c if c <= 0.0031308 else 1.055 * (c ** (1 / 2.4)) - 0.055
    return max(0, min(255, round(c * 255)))


def rgb_to_oklab(rgb):
    r, g, b = [_srgb_to_lin(x) for x in rgb]
    l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
    m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
    s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    l_, m_, s_ = l ** (1 / 3), m ** (1 / 3), s ** (1 / 3)
    return (0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_,
            1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_,
            0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_)


def oklab_to_rgb(L, a, b):
    l_ = L + 0.3963377774 * a + 0.2158037573 * b
    m_ = L - 0.1055613458 * a - 0.0638541728 * b
    s_ = L - 0.0894841775 * a - 1.2914855480 * b
    l, m, s = l_ ** 3, m_ ** 3, s_ ** 3
    r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    bb = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
    return (_lin_to_srgb(r), _lin_to_srgb(g), _lin_to_srgb(bb))


def rgb_to_oklch(rgb):
    L, a, b = rgb_to_oklab(rgb)
    return L, math.hypot(a, b), math.degrees(math.atan2(b, a)) % 360


def _in_gamut(L, C, H):
    a = C * math.cos(math.radians(H))
    b = C * math.sin(math.radians(H))
    l_ = L + 0.3963377774 * a + 0.2158037573 * b
    m_ = L - 0.1055613458 * a - 0.0638541728 * b
    s_ = L - 0.0894841775 * a - 1.2914855480 * b
    l, m, s = l_ ** 3, m_ ** 3, s_ ** 3
    r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    bb = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
    eps = 0.0008
    return all(-eps <= x <= 1 + eps for x in (r, g, bb))


def oklch_hex(L, C, H):
    """OKLCH -> sRGB hex, reducing chroma until in-gamut (no ugly clipping)."""
    lo, hi = 0.0, C
    if not _in_gamut(L, C, H):
        for _ in range(24):
            mid = (lo + hi) / 2
            if _in_gamut(L, mid, H):
                lo = mid
            else:
                hi = mid
        C = lo
    a = C * math.cos(math.radians(H))
    b = C * math.sin(math.radians(H))
    return rgb_hex(oklab_to_rgb(L, a, b))


# ============================================================ small utils

def hex_to_rgb(h):
    # v0.2.11-r1:校验格式,非法颜色抛带上下文的 ValueError,
    #   由 main 捕获成友好报错(ap.error),而不是裸 int(...,16) 栈。
    raw = h
    h = h.strip().lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    if len(h) != 6 or any(c not in "0123456789abcdefABCDEF" for c in h):
        raise ValueError(
            f"非法颜色值 {raw!r}:应为 #RGB 或 #RRGGBB 十六进制(如 #2B5CFF)")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_hex(rgb):
    return "#" + "".join(f"{max(0, min(255, round(c))):02X}" for c in rgb)


def hex_rgb(h):
    return hex_to_rgb(h)


def rgba(rgb, a):
    r, g, b = [round(c) for c in rgb]
    return f"rgba({r},{g},{b},{a})"


# ============================================================ WCAG

def _lin(c):
    c = c / 255
    return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4


def luminance(rgb):
    r, g, b = rgb
    return 0.2126 * _lin(r) + 0.7152 * _lin(g) + 0.0722 * _lin(b)


def contrast(rgb1, rgb2):
    l1, l2 = luminance(rgb1), luminance(rgb2)
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def ensure_contrast_oklch(L, C, H, bg_rgb, target, lighten):
    """Nudge OKLCH lightness of a color until it meets `target` contrast vs bg."""
    step = 0.02 * (1 if lighten else -1)
    for _ in range(60):
        cand = hex_rgb(oklch_hex(L, C, H))
        if contrast(cand, bg_rgb) >= target:
            return L
        L = max(0.0, min(1.0, L + step))
        if L <= 0 or L >= 1:
            break
    return L


# ============================================================ logo extract

def extract_primary_from_logo(path, k=6):
    """Deterministic KMeans (if sklearn available) OR PIL.quantize fallback;
    drop near-white/black/transparent; pick most brand-worthy cluster
    (count * saturation * mid-lightness). Runs identically on any Python 3.9+
    with Pillow — sklearn is optional so this works in Doubao sandbox."""
    from PIL import Image
    import numpy as np

    img = Image.open(path).convert("RGBA")
    img.thumbnail((200, 200))
    arr = np.asarray(img).reshape(-1, 4)
    op = arr[arr[:, 3] > 200][:, :3].astype(float)
    if len(op) == 0:
        raise SystemExit("logo has no opaque pixels")
    mx, mn = op.max(1), op.min(1)
    keep = (mx < 245) & (mn > 12)
    pool = op[keep] if keep.sum() > 30 else op
    if len(pool) < k:
        k = max(1, len(pool))

    # 尝试 sklearn KMeans;失败则回退到 PIL.quantize(纯 Pillow 实现)
    centers = None
    labels = None
    try:
        from sklearn.cluster import KMeans  # type: ignore
        km = KMeans(n_clusters=k, n_init=4, random_state=0).fit(pool)
        centers = km.cluster_centers_
        labels = km.labels_
    except Exception:
        # ---- Fallback:PIL median-cut quantize ----
        # 把 pool 重排成 (N, 3) 的伪图,用 quantize 提取 k 个主色
        h_side = int(np.ceil(np.sqrt(len(pool))))
        padded = np.zeros((h_side * h_side, 3), dtype=np.uint8)
        padded[:len(pool)] = pool.astype(np.uint8)
        fake_img = Image.fromarray(padded.reshape(h_side, h_side, 3), "RGB")
        quant = fake_img.quantize(colors=k, method=Image.Quantize.MEDIANCUT)
        palette = quant.getpalette()[:k * 3]
        centers = np.array([palette[i*3:i*3+3] for i in range(k)], dtype=float)
        # 用最近邻分配 labels(纯 numpy,无外部依赖)
        dists = np.linalg.norm(pool[:, None, :] - centers[None, :, :], axis=2)
        labels = dists.argmin(axis=1)

    best, best_score, cands = None, -1, []
    for i, c in enumerate(centers):
        cnt = int((labels == i).sum())
        h, l, s = colorsys.rgb_to_hls(*[x / 255 for x in c])
        score = cnt * (0.35 + s) * (1 - abs(l - 0.5))
        cands.append((rgb_hex(tuple(c)), round(s, 2), round(l, 2), cnt, int(round(score))))
        if score > best_score:
            best_score, best = score, tuple(c)
    cands.sort(key=lambda x: -x[4])
    return best, cands


# ============================================================ OKLCH tone stops
# The house style. Fixed perceptual stations → deterministic + consistently
# high-end for ANY logo. Each station = (L, chroma-cap, hue-offset-from-primary).

def build_mode(primary, accent_rgb, mode):
    """Build one mode's tokens + 4-color summary + WCAG report."""
    dark = mode == "dark"
    pL, pC, pH = rgb_to_oklch(primary)

    # Accent: +25° hue, high-end = MODERATE chroma (capped), fixed perceptual L.
    if accent_rgb is not None:
        aL, aC, aH = rgb_to_oklch(accent_rgb)
    else:
        aH = (pH + 25) % 360
        aC = min(0.16, max(0.10, pC * 0.9))
        aL = 0.62

    # ---- fixed stations ----
    if dark:
        bg0 = oklch_hex(0.16, min(0.020, pC * 0.20), pH)
        bg1 = oklch_hex(0.19, min(0.028, pC * 0.25), pH)
        bg2 = oklch_hex(0.24, min(0.036, pC * 0.30), pH)
        bg3 = oklch_hex(0.30, min(0.044, pC * 0.32), pH)
        text_L, text_C = 0.97, min(0.010, pC * 0.10)
        tint_rgb = (255, 255, 255)
    else:
        # light-mode backgrounds carry a VISIBLE brand tint (hue = primary H),
        # so the palette reads as "derived from your logo", not plain white.
        bg0 = oklch_hex(0.975, min(0.022, pC * 0.30), pH)
        bg1 = oklch_hex(0.955, min(0.030, pC * 0.38), pH)
        bg2 = oklch_hex(0.925, min(0.040, pC * 0.45), pH)
        bg3 = oklch_hex(0.885, min(0.050, pC * 0.50), pH)
        text_L, text_C = 0.28, min(0.030, pC * 0.20)
        tint_rgb = (17, 17, 17)

    # v9.8.5 —— 浅色模式内页专用底(非封面页):比封面 bg0 再淡一档,
    # 红色系(H∈[340°,20°))多加一档降淡,避免暖红页面读起来"糊/闷"。
    # 说明:仅 light 模式派生 page 系专用底;dark 模式沿用旧值(暗底不需要区分)。
    if dark:
        bg0_page = bg0
        bg1_page = bg1
        bg2_page = bg2
    else:
        # 红色相判定:H 落在 340°-360° 或 0°-20° 视为暖红家族(含品牌红/朱/橙红)
        is_red_family = (pH >= 340.0) or (pH <= 20.0)
        # 内页 bg0:光度 +0.010(通用) / +0.017(红色系);chroma 同步再压 20%
        lift_L = 0.017 if is_red_family else 0.010
        c_scale = 0.80 if is_red_family else 0.85
        bg0_page = oklch_hex(min(0.995, 0.975 + lift_L),
                             min(0.022, pC * 0.30) * c_scale, pH)
        bg1_page = oklch_hex(min(0.995, 0.955 + lift_L),
                             min(0.030, pC * 0.38) * c_scale, pH)
        bg2_page = oklch_hex(min(0.995, 0.925 + lift_L),
                             min(0.040, pC * 0.45) * c_scale, pH)

    bg0_rgb = hex_rgb(bg0)

    # WCAG floors (perceptual nudge in OKLCH, then re-emit)
    text_L = ensure_contrast_oklch(text_L, text_C, pH, bg0_rgb, 7.0, lighten=dark)
    text = oklch_hex(text_L, text_C, pH)
    primary_L2 = ensure_contrast_oklch(pL, pC, pH, bg0_rgb, 3.0, lighten=dark)
    primary_ui = oklch_hex(primary_L2, pC, pH)
    accent_L2 = ensure_contrast_oklch(aL, aC, aH, bg0_rgb, 3.0, lighten=dark)
    accent_ui = oklch_hex(accent_L2, aC, aH)

    def tint(a):
        return rgba(tint_rgb, a)

    # ---- premium layers (mesh / bloom / sheen / gradient-title / glass / glow) ----
    # 全部由主题色派生 —— 换成任何客户的主色都成立,这不是写死的暖色。
    tert_col = hex_rgb(oklch_hex(0.60, min(0.15, pC), (pH + 45) % 360))
    quart_col = hex_rgb(oklch_hex(0.64, min(0.14, aC), (aH + 20) % 360))
    accent_rgb_ui = hex_rgb(accent_ui)
    sheen_col = hex_rgb(oklch_hex(0.94, min(0.06, pC * 0.5), pH))  # bright light-sweep
    if dark:
        title_a = oklch_hex(0.97, min(0.03, pC * 0.20), pH)
        title_b = oklch_hex(0.86, min(0.13, pC * 0.75), pH)
        title_c = accent_ui
        glass = "linear-gradient(155deg, rgba(255,255,255,.09) 0%, rgba(255,255,255,.02) 100%)"
        glass_brd = "rgba(255,255,255,.14)"
        sheen_a, mesh_a1, mesh_a2, mesh_a3, mesh_a4, bloom_a = 0.16, 0.22, 0.20, 0.18, 0.14, 0.34
        # dark 沿用同一套 mesh α(暗底不需要 page 专用降淡)
        pg_a1, pg_a2, pg_a3, pg_a4 = mesh_a1, mesh_a2, mesh_a3, mesh_a4
    else:
        title_a = text
        title_b = primary_ui
        title_c = accent_ui
        glass = "linear-gradient(155deg, rgba(255,255,255,.92) 0%, rgba(255,255,255,.55) 100%)"
        glass_brd = "rgba(15,23,42,.08)"
        sheen_a, mesh_a1, mesh_a2, mesh_a3, mesh_a4, bloom_a = 0.5, 0.16, 0.14, 0.13, 0.10, 0.24
        # v9.8.5 —— 内页 mesh 光斑 α 相对封面再降 40%(红色系 -55%),
        # 与内页背景 bg_page 一起落实"内页比封面更淡"的用户诉求。
        pg_scale = 0.45 if ((pH >= 340.0) or (pH <= 20.0)) else 0.60
        pg_a1 = mesh_a1 * pg_scale
        pg_a2 = mesh_a2 * pg_scale
        pg_a3 = mesh_a3 * pg_scale
        pg_a4 = mesh_a4 * pg_scale

    tokens = {
        "--fs-bg-0": bg0, "--fs-bg-1": bg1, "--fs-bg-2": bg2, "--fs-bg-3": bg3,
        # v9.8.5 —— 内页专用底(仅 .page 使用,.cover-wrap 仍走 bg-0 / mesh)。
        # 浅色模式下比 bg-0 再淡一档;红色系(H∈[340°,20°))多加一档降淡。
        # 暗色沿用 bg-0/1/2(不区分)。
        "--fs-bg-page": bg0_page,
        "--fs-bg-page-1": bg1_page,
        "--fs-bg-page-2": bg2_page,
        "--fs-blue": primary_ui, "--fs-accent": primary_ui,
        "--fs-cyan": accent_ui,
        "--fs-teal": oklch_hex(0.70, min(0.13, aC), (aH + 15) % 360),
        "--fs-purple": oklch_hex(0.60, min(0.15, pC), (pH + 40) % 360),
        "--fs-violet": oklch_hex(0.66, min(0.14, aC), (aH + 30) % 360),
        "--fs-orange": oklch_hex(0.68, min(0.15, aC), (aH - 40) % 360),
        "--fs-text": text,
        "--fs-text-72": tint(0.72 if dark else 0.82),
        "--fs-text-65": tint(0.65 if dark else 0.70),
        "--fs-text-48": tint(0.48 if dark else 0.55),
        "--fs-text-40": tint(0.40 if dark else 0.45),
        "--fs-text-16": tint(0.16 if dark else 0.20),
        "--fs-hairline": tint(0.10 if dark else 0.12),
        "--fs-divider": tint(0.20 if dark else 0.18),
        "--fs-grad-hero": f"radial-gradient(120% 100% at 0% 0%, {bg2} 0%, {bg1} 38%, {bg0} 78%)",
        "--fs-grad-section": f"radial-gradient(140% 110% at 100% 0%, {bg3} 0%, {bg1} 50%, {bg0} 100%)",
        "--fs-grad-keyline": f"linear-gradient(90deg, {accent_ui} 0%, {primary_ui} 50%, {oklch_hex(0.60, min(0.15, pC), (pH+40)%360)} 100%)",
        "--fs-grad-glow-blue": f"radial-gradient(80% 60% at 50% 50%, {rgba(primary,0.22)}, transparent 60%)",
        # ---- PREMIUM LAYERS (CEO-grade: mesh / bloom / sheen / gradient-title / glass) ----
        # 多光源 mesh 渐变底:四个色相各异的光斑柔化叠加,替代平铺纯色,产生"高级流光底"。
        "--fs-grad-mesh": (
            f"radial-gradient(60% 80% at 12% 8%, {rgba(primary, mesh_a1)} 0%, transparent 55%),"
            f"radial-gradient(55% 70% at 88% 12%, {rgba(accent_rgb_ui, mesh_a2)} 0%, transparent 52%),"
            f"radial-gradient(70% 75% at 78% 92%, {rgba(tert_col, mesh_a3)} 0%, transparent 58%),"
            f"radial-gradient(60% 65% at 20% 95%, {rgba(quart_col, mesh_a4)} 0%, transparent 55%),"
            f"linear-gradient(135deg, {bg1} 0%, {bg0} 60%)"
        ),
        # v9.8.5 —— 内页专用 mesh(浅色 α 降 40%,红色系降 55%),底色换 bg_page,
        # 让所有非封面页比封面更淡、更透气;暗色沿用同一套(不区分)。
        "--fs-grad-mesh-page": (
            f"radial-gradient(60% 80% at 12% 8%, {rgba(primary, pg_a1)} 0%, transparent 55%),"
            f"radial-gradient(55% 70% at 88% 12%, {rgba(accent_rgb_ui, pg_a2)} 0%, transparent 52%),"
            f"radial-gradient(70% 75% at 78% 92%, {rgba(tert_col, pg_a3)} 0%, transparent 58%),"
            f"radial-gradient(60% 65% at 20% 95%, {rgba(quart_col, pg_a4)} 0%, transparent 55%),"
            f"linear-gradient(135deg, {bg1_page} 0%, {bg0_page} 60%)"
        ),
        # 大面积柔光 bloom(光晕):压在角落做体积光。
        "--fs-grad-bloom": f"radial-gradient(closest-side, {rgba(accent_rgb_ui, bloom_a)} 0%, {rgba(primary, bloom_a*0.6)} 45%, transparent 75%)",
        # 流光 sheen:一条高亮斜向扫光,配合动画/静态高光带出"绸缎质感"。
        "--fs-grad-sheen": f"linear-gradient(105deg, transparent 30%, {rgba(sheen_col, sheen_a)} 48%, {rgba(sheen_col, sheen_a*0.4)} 52%, transparent 70%)",
        # 渐变标题:标题文字走三色渐变(main→primary→accent),用 background-clip:text 上色。
        "--fs-grad-title": f"linear-gradient(100deg, {title_a} 0%, {title_b} 62%, {title_c} 100%)",
        # 玻璃拟态托层(masthead / 卡片):半透明 + 内高光,配 backdrop-filter。
        "--fs-glass": glass,
        "--fs-glass-border": glass_brd,
        # 单色光晕(供描边环/点缀),主色与辅色两种。
        "--fs-glow-primary": rgba(primary, 0.55 if dark else 0.35),
        "--fs-glow-accent": rgba(accent_rgb_ui, 0.55 if dark else 0.35),
    }

    report = {
        "text_on_bg0": round(contrast(hex_rgb(text), bg0_rgb), 2),
        "primary_on_bg0": round(contrast(hex_rgb(primary_ui), bg0_rgb), 2),
        "accent_on_bg0": round(contrast(hex_rgb(accent_ui), bg0_rgb), 2),
        "white_on_primary": round(contrast((255, 255, 255), primary), 2),
    }
    report["passes_AA_body"] = bool(report["text_on_bg0"] >= 4.5)

    core = {
        "primary": rgb_hex(primary),
        "accent": oklch_hex(aL, aC, aH),
        "background": bg0,
        "text": text,
    }
    return core, tokens, report


def build_palette(primary, accent_rgb=None, mode=None, name="theme"):
    """Build BOTH modes. Default is light unless --mode overrides it.
    Returns (palette, tokens_by_mode, wcag_by_mode)."""
    default_mode = mode or "light"

    modes = {}
    for m in ("light", "dark"):
        core, toks, rep = build_mode(primary, accent_rgb, m)
        modes[m] = {"core": core, "tokens": toks, "wcag": rep}

    dflt = modes[default_mode]
    palette = {
        "name": name,
        "default_mode": default_mode,
        "modes": ["light", "dark"],
        # top-level 4-color = the DEFAULT mode's, kept for backward compat
        "primary": dflt["core"]["primary"],
        "accent": dflt["core"]["accent"],
        "background": dflt["core"]["background"],
        "text": dflt["core"]["text"],
        "light": modes["light"]["core"],
        "dark": modes["dark"]["core"],
    }
    tokens_by_mode = {m: modes[m]["tokens"] for m in ("light", "dark")}
    wcag_by_mode = {m: modes[m]["wcag"] for m in ("light", "dark")}
    return palette, tokens_by_mode, wcag_by_mode


# ============================================================ emit

CSS_TMPL = """/* ============================================================
   theme: {name}  ·  default: {mode}  ·  space: OKLCH perceptual stops
   Light + Dark shipped together — one-click runtime toggle, zero re-render.
   Flip by setting the attribute on <html>:  data-theme="light" | "dark".
   Bare :root = the default mode (used when no attribute is set).
   Generated by build-theme.py — DO NOT hand-edit; re-run to regenerate.
   Overrides base :root tokens; inject AFTER the base stylesheet.
   ============================================================ */
:root {{
{default_body}
}}
:root[data-theme="light"] {{
{light_body}
}}
:root[data-theme="dark"] {{
{dark_body}
}}
"""


def _fmt(tokens):
    return "\n".join(f"  {k}: {v};" for k, v in tokens.items())


def emit_css(name, default_mode, tokens_by_mode):
    return CSS_TMPL.format(
        name=name, mode=default_mode,
        default_body=_fmt(tokens_by_mode[default_mode]),
        light_body=_fmt(tokens_by_mode["light"]),
        dark_body=_fmt(tokens_by_mode["dark"]),
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--logo")
    ap.add_argument("--primary")
    ap.add_argument("--accent")
    ap.add_argument("--mode", choices=["dark", "light"])
    ap.add_argument("--name", default="theme")
    ap.add_argument("--out", required=True)
    ap.add_argument("--wordmark", default="")
    args = ap.parse_args()

    cands = None
    try:
        if args.logo:
            primary, cands = extract_primary_from_logo(args.logo)
        elif args.primary:
            primary = hex_to_rgb(args.primary)
        else:
            ap.error("need --logo or --primary")

        accent_rgb = hex_to_rgb(args.accent) if args.accent else None
    except ValueError as e:
        ap.error(str(e))
    palette, tokens_by_mode, wcag_by_mode = build_palette(
        primary, accent_rgb, args.mode, args.name)
    default_mode = palette["default_mode"]

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "theme.css"), "w") as f:
        f.write(emit_css(args.name, default_mode, tokens_by_mode))

    full = {
        "palette": palette,
        "default_mode": default_mode,
        "tokens": tokens_by_mode[default_mode],   # default-mode tokens (compat)
        "tokens_by_mode": tokens_by_mode,
        "wcag": wcag_by_mode[default_mode],        # default-mode wcag (compat)
        "wcag_by_mode": wcag_by_mode,
    }
    if cands:
        full["logo_candidates"] = cands
    with open(os.path.join(args.out, "palette.json"), "w") as f:
        json.dump(full, f, ensure_ascii=False, indent=2)

    with open(os.path.join(args.out, "brand.json"), "w") as f:
        json.dump({
            "wordmark": args.wordmark,
            "logo": os.path.basename(args.logo) if args.logo else "",
            "font_cjk": 'system-ui,"Noto Sans SC","PingFang SC","Microsoft YaHei",sans-serif',
            "font_latin": '"Inter","Helvetica Neue",Arial,sans-serif',
        }, f, ensure_ascii=False, indent=2)

    print(json.dumps({"name": args.name, "default_mode": default_mode,
                      "palette": palette, "wcag_by_mode": wcag_by_mode,
                      "out": args.out},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
