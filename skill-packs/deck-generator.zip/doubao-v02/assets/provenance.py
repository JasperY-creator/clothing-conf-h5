#!/usr/bin/env python3
"""
provenance.py — page-base 共享:material JSON 出处签发与校验(P0 修复)

背景
----
v8.6 已删所有旁路开关,强制 Path A(agent → nanodraw → sketch_gate → build_material →
verify_img → G3),但仍缺一环:**composer 无法证明拿到手的 material JSON 是不是
由 build_material.py 产出**。任何人 vim 一份 JSON 也能被 update 进渲染管线,绕过
所有闸门。本模块补上"素材出处"这一根链条:
  · build_material.py 出片时,末尾必须调 stamp() 在 JSON 里烙 `_provenance`;
  · render_page / compose_deck 消费前必须调 verify() 断言存在且模块名匹配,
    缺失或伪造(模块不匹配)一律 sys.exit=1 并打印 Path A 复现指引。

签发格式
--------
```json
{
  ...material fields...,
  "_provenance": {
    "produced_by": "build_material.py",     // 生产者脚本
    "module": "a",                           // 模块字母(a/b/c/d/d2/e/e2/f/g)
    "version": "9.1",                        // skill 版本
    "gates_passed": ["sketch_gate_g1", "sketch_gate_g2", "verify_img"],
    "argv_sha": "abc123...",                 // sys.argv 的 sha256(可选)
    "produced_at": "2026-08-01T10:30:00Z"    // ISO 时间戳
  }
}
```

对外只有两个函数:
  stamp(material, module, gates, extra=None) -> None(就地写入 material dict)
  verify(material, expected_module, source_path=None) -> None(不通过即 sys.exit=1)

DECK_ALLOW_DEBUG=1 时 verify 只 WARN 不 exit,用于本地调试;正式出片必须不设。
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from typing import Optional

SKILL_VERSION = "9.1"

# Path A 复现指引 —— 按模块字母定制的错误提示。self_check FAIL 与 provenance 缺失都会走这里。
_PATH_A_HINTS = {
    "a": (
        "模块 a(page-story · 破题):\n"
        "  1) agent 依 references/nanodraw-brief-story.md 生成 4:3 素描 prompt,\n"
        "     调 mira_nanodraw.generate_pictures 出图 → sketch.png;\n"
        "  2) sketch_gate.py 对 sketch.png 做 G1 提示词硬化 + G2 像素闸门(灰度纯度/边缘密度);\n"
        "  3) subskills/page-story/assets/build_material.py --sketch sketch.png ...\n"
        "     该脚本会做 G2 源图体检 + verify_img 3 轮渲染后语义体检。"
    ),
    "b": (
        "模块 b(page-team · 团队介绍):\n"
        "  1) 每位成员一次 nanodraw 出头像 4:5 竖版 avatar_*.png;\n"
        "  2) subskills/page-team/assets/build_material.py --roster roster.json ... 会做:\n"
        "     · verify_img 3 轮头像真图判据(canvas 采样,拒占位/空帧/纯色/首字符);\n"
        "     · verify_content_position 3 轮版式(标题/队名/一句话/花名册/部门带位置)。\n"
        "  任一 FAIL 即回到步骤 1 换头像或修文案。"
    ),
    "c": (
        "模块 c(page-background · 背景):\n"
        "  subskills/page-background/assets/build_material.py --palette --page-no --total ...\n"
        "  该脚本会做几何 lint + 单模合所选。"
    ),
    "d": (
        "模块 d(page-pain · 痛点 · 引用体):\n"
        "  subskills/page-pain/assets/build_material.py --quote ... --by ...\n"
        "  引用不得夹杂标题风格文字,quote 结束需自然收束。"
    ),
    "d2": (
        "模块 d2(page-pain 变体 · 大数字聚焦):\n"
        "  subskills/page-pain/assets/build_material_s2.py --big-number ... --context ...\n"
    ),
    "e": (
        "模块 e(page-overview · 方案全景):\n"
        "  subskills/page-overview/assets/build_material.py --point ... --point ...\n"
        "  会同时落 <deck>.e-points.json(供模块 f 严格取标题闭环)。\n"
        "  points 顺序即 f 的展开顺序,一一对应。"
    ),
    "e2": (
        "模块 e2(page-architecture · 架构):\n"
        "  subskills/page-architecture/assets/build_material_e2.py ...\n"
    ),
    "f": (
        "模块 f(page-detail · 方案细节图文):\n"
        "  1) 先跑模块 e 得到 <deck>.e-points.json;\n"
        "  2) subskills/page-detail/assets/build_material.py \\\n"
        "       --title '<必须完全等于 e-points 里某一条>' \\\n"
        "       --e-points-manifest <deck>.e-points.json \\\n"
        "       --shot-url <飞书云文档鉴权链接> --shot-token <lark-doc/lark-drive 回执>\n"
        "  截图必须走 lark-doc/lark-drive 鉴权下载,禁止占位图;标题必须命中 e 卡片,\n"
        "  否则 exit=1(实现 e→f 一一闭环)。"
    ),
    "g": (
        "模块 g(page-close · 收束):\n"
        "  subskills/page-close/assets/build_material.py --headline ... --cta ...\n"
    ),
}


def path_a_hint(module: str) -> str:
    """返回该模块的 Path A 复现指引(用于 exit 消息与 self_check FAIL 分类打印)。"""
    return _PATH_A_HINTS.get(module, f"模块 {module}:走 subskills/page-{module}/assets/build_material.py。")


def stamp(material: dict, module: str, gates_passed: list, extra: Optional[dict] = None) -> None:
    """在 material dict 就地烙 `_provenance` 字段。build_material.py 落盘前必须调。

    参数
    ----
    material : dict          # 该页物料 dict(会被就地修改)
    module   : str           # 模块字母 a/b/c/d/d2/e/e2/f/g,必须与文件所在子技能一致
    gates_passed : list[str] # 已通过的闸门标识,如 ["sketch_gate_g1","sketch_gate_g2","verify_img"]
    extra    : dict|None     # 可选扩展字段(如截图 md5 清单、e-points hash 等)

    v9.4:自动透传环境变量 `DECK_PLAN_CONFIRMED_V2=1` 到 `_provenance.plan_confirmed_v2`,
    对应 deck-planner Step 4「框架二次确认闸门」通过后由 agent/CLI 注入的环境标记;
    未通过 → material 落盘时 plan_confirmed_v2=False,下游 verify() 会硬拦渲染。
    """
    if not isinstance(material, dict):
        raise TypeError("stamp() 只接受 dict 型 material")
    argv_sha = hashlib.sha256(("\x00".join(sys.argv)).encode("utf-8")).hexdigest()[:16]
    plan_ok = os.environ.get("DECK_PLAN_CONFIRMED_V2", "").strip() in ("1", "true", "yes")
    prov = {
        "produced_by": "build_material.py",
        "module": module,
        "version": SKILL_VERSION,
        "gates_passed": list(gates_passed or []),
        "argv_sha": argv_sha,
        "produced_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "plan_confirmed_v2": plan_ok,
    }
    if extra:
        prov["extra"] = extra
    material["_provenance"] = prov


def _debug_allowed() -> bool:
    """DECK_ALLOW_DEBUG=1 时校验只 WARN 不 exit(仅用于本地调试)。"""
    return os.environ.get("DECK_ALLOW_DEBUG", "").strip() in ("1", "true", "yes")


def _internal_measure() -> bool:
    """DECK_INTERNAL_MEASURE=1 表示当前 render_page/compose_deck 是被**校验器内部**调用,
    只为量位置/几何(--no-shoot --no-selfcheck),不落交付产物。此时:
      · provenance verify 跳过(校验器现拼 material dict,无 build_material 出处);
      · render_page 的 --no-shoot/--no-selfcheck 允许放行(不要求 DECK_ALLOW_DEBUG=1)。
    该 env 只由项目内部校验器 subprocess 传入,不做用户级 CLI 开关;不与 DECK_ALLOW_DEBUG 混用。
    """
    return os.environ.get("DECK_INTERNAL_MEASURE", "").strip() in ("1", "true", "yes")


def verify(material: dict, expected_module: str, source_path: Optional[str] = None) -> None:
    """消费前对 material 做出处校验。缺失或模块不匹配即 sys.exit=1(除非 DECK_ALLOW_DEBUG=1)。

    render_page / compose_deck 在拿到 material JSON 后、update 到 MODULES 前必须调。

    v9.4 追加断言:`_provenance.plan_confirmed_v2 == True`,对应 deck-planner Step 4
    「框架二次确认闸门」通过后由 agent/CLI 注入 `DECK_PLAN_CONFIRMED_V2=1` 环境变量;
    未标 True 表示 agent 跳过了 Step 4 直接调 build_material,拒绝渲染。
    DECK_ALLOW_DEBUG=1 时降级为 WARN。
    """
    # 校验器内部量位置的调用:material 是校验器现拼的,没有 _provenance,允许放行。
    if _internal_measure():
        return
    src = f"({source_path})" if source_path else ""
    if not isinstance(material, dict) or "_provenance" not in material:
        msg = (
            f"[provenance] material JSON 缺 _provenance{src}——检测到手写/裸 JSON 绕过闸门。\n"
            "  正式出片禁止手写 material,必须由 build_material.py 产出。\n\n"
            + path_a_hint(expected_module)
        )
        if _debug_allowed():
            print("⚠ [provenance][DEBUG] " + msg, file=sys.stderr)
            return
        sys.exit(msg)

    prov = material["_provenance"]
    got_mod = prov.get("module")
    if got_mod != expected_module:
        msg = (
            f"[provenance] material JSON _provenance.module={got_mod!r} 与期望 "
            f"{expected_module!r} 不匹配{src}——material 与目标模块不一致,拒绝渲染。\n\n"
            + path_a_hint(expected_module)
        )
        if _debug_allowed():
            print("⚠ [provenance][DEBUG] " + msg, file=sys.stderr)
            return
        sys.exit(msg)

    # v9.4:Step 4 框架二次确认闸门未通过 → 硬拦
    if not prov.get("plan_confirmed_v2", False):
        msg = (
            f"[provenance] material JSON _provenance.plan_confirmed_v2=False{src}——"
            "检测到 agent 跳过了 deck-planner Step 4「框架二次确认闸门」直接调 build_material。\n"
            "  正确顺序:Step 3「生成」信号 → Step 4 摊出框架表格 + 收到用户「确认」 →\n"
            "  在环境里 `export DECK_PLAN_CONFIRMED_V2=1`(表示已拿到用户框架层确认)→ 再跑 build_material。\n"
            "  未做 Step 4 的 deck,一旦框架错就是整份返工;这条闸门就是防这个。"
        )
        if _debug_allowed():
            print("⚠ [provenance][DEBUG] " + msg, file=sys.stderr)
            return
        sys.exit(msg)


def load_and_verify(path: str, expected_module: str) -> dict:
    """便利函数:读 JSON + verify + 返回 material dict。"""
    if not os.path.exists(path):
        sys.exit(f"[provenance] 找不到 material:{path}")
    try:
        with open(path, encoding="utf-8") as f:
            material = json.load(f)
    except json.JSONDecodeError as e:
        sys.exit(f"[provenance] material JSON 解析失败:{path}({e})")
    verify(material, expected_module, source_path=path)
    return material


# self_check 失败时,按模块分类打印 Path A 复现指引(compose_deck.py 会调)
def failure_hints_by_modules(failed_modules: list) -> str:
    """给一组失败模块字母,产出合并后的 Path A 复现指引文本(供 compose_deck exit=1 时打印)。"""
    seen = []
    out = []
    for m in failed_modules:
        if m in seen:
            continue
        seen.append(m)
        out.append(path_a_hint(m))
    return "\n\n".join(out)
