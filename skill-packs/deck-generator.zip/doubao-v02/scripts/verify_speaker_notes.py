#!/usr/bin/env python3
"""
verify_speaker_notes.py — 演讲稿备注 6 闸 3 轮硬校验

6 闸:
  ① 覆盖率:所有 .page / .cover-wrap 都有 data-notes 且非空
  ② 整页 ≥ 80 字
  ③ 数字回声:页面里出现的大数字(如 "3 倍" "50%")必须在备注中重复
  ④ 禁术语:RAG / embedding / prompt / vector / LLM / token / fine-tune / 向量数据库 / 提示词工程
  ⑤ 占位残留:[待生成] / [待填]
  ⑥ 3 轮字节一致(纯解析,天然一致;若有随机因素这里能抓到)

支持两种输入:
  - 单页 HTML(pages/xx_*.html):body 里有一个 .page/.cover-wrap
  - 整卷 deck.html(compose 后):内含多个 .deck-frame,每帧内含一个 .page 或 .cover-wrap
    只统计 .deck-frame 内的 slide 根节点,自动跳过 .deck-nav / .deck-noteedit / .deck-presenter 等 shell chrome。

用法:
    python3 scripts/verify_speaker_notes.py deck.html --rounds 3

退出码:0=全过;1=有失败
"""

import argparse, re, sys, hashlib
from pathlib import Path

FORBIDDEN = ["RAG", "embedding", "prompt", "vector", "LLM", "token",
             "fine-tune", "向量数据库", "提示词工程"]
PLACEHOLDER = ["[待生成]", "[待填]", "TODO", "TBD"]


def _split_by_frame(html):
    """整卷 deck:切成一个个 .deck-frame 段;单页 HTML:整份当一段。"""
    frames = re.findall(
        r'<div class="deck-frame[^"]*"[^>]*>(.*?)(?=<div class="deck-frame|</div>\s*</div>\s*<nav|</div>\s*<nav|</body)',
        html, re.S)
    if frames:
        return frames
    return [html]


def _find_slide_root(frame_html):
    """在一段 frame HTML 里定位真正的 slide 根节点(.page 或 .cover-wrap)。"""
    # 优先 .page(内页),其次 .cover-wrap(封面)
    for cls in ("page", "cover-wrap"):
        m = re.search(rf'<div class="[^"]*\b{cls}\b[^"]*"([^>]*)>(.*?)</div>\s*</div>\s*(?:$|<)',
                      frame_html, re.S)
        if m:
            return {"attrs": m.group(1), "body": m.group(2), "cls": cls}
        # 更宽松的匹配:仅抓属性和到下一个 .deck-* 前的正文
        m = re.search(rf'<div class="[^"]*\b{cls}\b[^"]*"([^>]*)>(.*)',
                      frame_html, re.S)
        if m:
            return {"attrs": m.group(1), "body": m.group(2), "cls": cls}
    return None


def analyze(deck_path):
    html = Path(deck_path).read_text(encoding="utf-8")
    pages = []
    for frame in _split_by_frame(html):
        root = _find_slide_root(frame)
        if not root:
            # frame 里没有 slide 根节点 → shell chrome,跳过
            continue
        attrs = root["attrs"]; body = root["body"]
        note_m = re.search(r'data-notes="([^"]*)"', attrs)
        note = note_m.group(1) if note_m else ""
        # 抽本页大数字
        numbers = re.findall(
            r'\d+(?:\.\d+)?\s*(?:倍|%|个|万|亿|人|天|小时|分钟)', body)
        pages.append({"note": note, "body_numbers": numbers, "root_cls": root["cls"]})
    return pages


def check_all(pages):
    errors = []
    for i, p in enumerate(pages, 1):
        tag = f"[Page {i:02d} · {p['root_cls']}]"
        note = p["note"]

        # 闸 ①:覆盖率
        if not note.strip():
            errors.append(f"{tag} 闸①覆盖率: data-notes 为空"); continue

        # 闸 ②:≥ 80 字
        if len(note) < 80:
            errors.append(f"{tag} 闸②字数: {len(note)} < 80")

        # 闸 ③:数字回声
        for num_expr in p["body_numbers"]:
            num_val = re.match(r"\d+(?:\.\d+)?", num_expr).group(0)
            if num_val not in note:
                errors.append(f"{tag} 闸③数字回声: 页面有『{num_expr}』但备注未复述该数字")

        # 闸 ④:禁术语
        for term in FORBIDDEN:
            if term.lower() in note.lower():
                errors.append(f"{tag} 闸④禁术语: 出现『{term}』")

        # 闸 ⑤:占位残留
        for ph in PLACEHOLDER:
            if ph in note:
                errors.append(f"{tag} 闸⑤占位残留: 出现『{ph}』")
    return errors


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--rounds", type=int, default=3)
    args = ap.parse_args()

    # 3 轮解析
    all_rounds = [analyze(args.deck) for _ in range(args.rounds)]
    hashes = [hashlib.md5(str(r).encode("utf-8")).hexdigest() for r in all_rounds]

    # 闸 ⑥:3 轮字节一致
    if len(set(hashes)) != 1:
        print(f"❌ 闸⑥ 3 轮不一致: {hashes}", file=sys.stderr); sys.exit(1)

    pages = all_rounds[0]
    if not pages:
        print("❌ 未找到任何 slide 根节点(.page / .cover-wrap)", file=sys.stderr); sys.exit(1)

    # 闸 ①-⑤
    errors = check_all(pages)
    if errors:
        print(f"❌ 演讲稿备注校验失败 ({len(errors)} 项):", file=sys.stderr)
        for e in errors: print(f"  - {e}", file=sys.stderr)
        sys.exit(1)

    print(f"✅ 演讲稿备注 6 闸 {args.rounds} 轮全过 ({len(pages)} 页)")
    sys.exit(0)


if __name__ == "__main__":
    main()
