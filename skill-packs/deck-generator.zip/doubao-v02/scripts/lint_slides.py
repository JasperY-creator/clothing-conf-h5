#!/usr/bin/env python3
"""
lint_slides.py — 排版规范校验(适配 v9.8.9 双种根容器 + 逐页 native 宽)

支持两种根容器(v9.8.9 惯例):
  - .cover-wrap   → 封面页,原生宽 580px
  - .page         → 内页,原生宽 1280px
每份自封装的单页 HTML 必须在 <body data-native-w="..."> 或
<meta name="deck-native-w" content="..."> 里声明自己的原生宽。

用法:
    python3 scripts/lint_slides.py pages/*.html
    python3 scripts/lint_slides.py deck.html

退出码:0=全过;1=有 ERROR
"""

import sys, re
from pathlib import Path

ERRORS = []
WARNINGS = []

# 若发现该字符串,视为 A7.3 inject-notes 已跑;否则 data-notes 缺失只 WARN,不 ERROR
_NOTES_STAMPED_MARK = 'data-notes="'


def check_file(path):
    html = Path(path).read_text(encoding="utf-8")
    tag = f"[{path}]"

    # 1. 必须有 .page 或 .cover-wrap 根容器(v9.8.9 允许两种)
    has_page = bool(re.search(r'<div class="[^"]*\bpage\b[^"]*"', html))
    has_cover = bool(re.search(r'<div class="[^"]*\bcover-wrap\b[^"]*"', html))
    if not (has_page or has_cover):
        ERRORS.append(f"{tag} 缺少 .page 或 .cover-wrap 根容器")

    # 2. data-notes:若整份 deck 已注入(见到过至少一处),要求每个 .page 都有;
    #    否则只提示为 WARN(A7.3 未跑,pre-flight 阶段合理)
    notes_stamped = _NOTES_STAMPED_MARK in html
    if has_page:
        for m in re.finditer(r'<div class="[^"]*\bpage\b[^"]*"([^>]*)>', html):
            if "data-notes" not in m.group(1):
                if notes_stamped:
                    ERRORS.append(f"{tag} .page 缺少 data-notes(部分页已注入,该页遗漏)")
                else:
                    WARNINGS.append(f"{tag} .page 尚未注入 data-notes(A7.3 后应齐全)")

    # 3. native 宽声明:优先 <meta>,其次 body[data-native-w];compose 后的 shell 可豁免
    native_m = re.search(
        r'<meta\s+name=["\']deck-native-w["\']\s+content=["\'](\d+(?:\.\d+)?)["\']',
        html)
    if not native_m:
        native_m = re.search(r'<body[^>]*data-native-w=["\'](\d+(?:\.\d+)?)["\']', html)
    is_composed = ".deck-stage" in html or ".deck-track" in html
    if not native_m and not is_composed:
        WARNINGS.append(f"{tag} 未声明 deck-native-w(compose 时会用默认 1280,可能错缩)")
    else:
        if native_m:
            nw = float(native_m.group(1))
            # 合法值只有 v9.8.9 的两档 native:cover=580, content=1280
            if abs(nw - 580) > 1 and abs(nw - 1280) > 1:
                WARNINGS.append(f"{tag} deck-native-w={nw} 非 v9.8.9 标准档 (580/1280)")

    # 4. 字号下限:仅在 <style> 里查 font-size:<20px 的规则(排除 SVG/JS 字面量)
    style_m = re.search(r"<style[^>]*>(.+?)</style>", html, re.S)
    if style_m:
        css = style_m.group(1)
        for m in re.finditer(r"font-size:\s*(\d+)px", css):
            sz = int(m.group(1))
            if sz < 20:
                WARNINGS.append(f"{tag} 存在小字号 {sz}px (v9.8.9 建议正文 ≥ 20px)")

    # 5. 检查占位符残留(硬拦)
    for placeholder in ["[待生成]", "[待填]", "TODO", "TBD"]:
        if placeholder in html:
            ERRORS.append(f"{tag} 存在占位符残留: {placeholder}")

    # 6. 检查空 alt(图片可访问性;仅 WARN)
    for m in re.finditer(r'<img[^>]*>', html):
        if "alt=" not in m.group(0):
            WARNINGS.append(f"{tag} <img> 缺少 alt")

    # 7. e2 架构闭环页:连线绘制引擎(E2_DRAW_JS)必须齐备(v0.2.11-r2 硬拦)
    #    e2 的「上→中 caps→orb / 中→下 orb→steps」连线是运行时 JS 动态画的;若
    #    --module-json 覆盖 body 时把默认 body 末尾的 E2_DRAW_JS 冲掉,页面结构还在、
    #    连线却永远不画。判据:检出 e2 页(.m-e2 或 id="march")就必须同时具备
    #    data-e2-drawn 标记 + id="lineHost" 挂载点 + pathA(上半段)+ pathB(下半段)。
    has_e2 = bool(re.search(r'\bm-e2\b', html)) or ('id="march"' in html)
    if has_e2:
        for need, why in (('data-e2-drawn', 'E2_DRAW_JS 未内联'),
                          ('id="lineHost"', '连线挂载点缺失'),
                          ('pathA', '上→中 caps→orb 连线生成器缺失'),
                          ('pathB', '中→下 orb→steps 连线生成器缺失')):
            if need not in html:
                ERRORS.append(f"{tag} e2 页缺连线引擎指纹 `{need}`({why})；"
                              f"多半是 --module-json 覆盖 e2 body 时丢了 E2_DRAW_JS")


def main():
    if len(sys.argv) < 2:
        print("用法: lint_slides.py <html files>", file=sys.stderr); sys.exit(2)
    for arg in sys.argv[1:]:
        paths = sorted(Path().glob(arg)) if "*" in arg else [Path(arg)]
        for p in paths:
            if p.exists():
                check_file(str(p))
            else:
                ERRORS.append(f"[{p}] 文件不存在")

    for w in WARNINGS: print(f"⚠️ WARN {w}")
    for e in ERRORS: print(f"❌ ERROR {e}", file=sys.stderr)
    print(f"\n结果: ERROR={len(ERRORS)}, WARN={len(WARNINGS)}")
    sys.exit(1 if ERRORS else 0)


if __name__ == "__main__":
    main()
