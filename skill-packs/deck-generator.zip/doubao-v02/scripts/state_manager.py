#!/usr/bin/env python3
"""
state_manager.py — deck_state.json 的读写 + 5 道闸门锁定

deck_state.json 是整个 skill 的唯一真相源,所有闸门状态、关键决策全落在这里。
下游脚本(render_page / accept_deck 等)启动时都会读这个文件,前置闸门未锁定就 exit 1。
"""

import argparse
import copy
import json
import os
import sys
from pathlib import Path
from datetime import datetime

STATE_FILE = "deck_state.json"

INITIAL_STATE = {
    "version": "0.2",
    "created_at": None,
    "step0": {"status": "pending", "theme_slug": None, "mode": None,
              "primary": None, "logo_path": None},
    "step1": {"status": "pending", "company_logo": None, "company_name": None},
    "step2": {"status": "pending", "plan_file": None, "source_doc": None},
    "step3": {"status": "pending"},
    "step4": {"status": "pending"},
}


def load_state(path=STATE_FILE):
    p = Path(path)
    if not p.exists():
        # v0.2.11-r1:深拷贝,避免嵌套 dict(step0 等)与 INITIAL_STATE 常量共享
        #   引用被后续写操作污染。
        state = copy.deepcopy(INITIAL_STATE)
        state["created_at"] = datetime.now().isoformat()
        save_state(state, path)
        return state
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def save_state(state, path=STATE_FILE):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def require_gates(state, gates):
    """检查前置闸门是否已锁定,任一未锁 → exit 1"""
    missing = []
    for gate in gates:
        expected = "confirmed" if gate in ("step0", "step1", "step2") else (
            "generated" if gate == "step3" else "plan_confirmed_v2"
        )
        actual = state.get(gate, {}).get("status")
        if actual != expected:
            missing.append(f"{gate}(需 {expected},当前 {actual})")
    if missing:
        print(f"❌ 前置闸门未锁定: {', '.join(missing)}", file=sys.stderr)
        print("请先完成对应的确认步骤,再重跑本脚本。", file=sys.stderr)
        sys.exit(1)


# ---------- 命令行子命令 ----------

def cmd_init(args):
    state = load_state()
    print(f"✅ deck_state.json 已初始化(或已存在): {STATE_FILE}")
    print(json.dumps(state, ensure_ascii=False, indent=2))


def cmd_lock_step0(args):
    state = load_state()
    state["step0"] = {
        "status": "confirmed",
        "theme_slug": args.theme_slug,
        "mode": args.mode,
        "primary": args.primary or state.get("step0", {}).get("primary"),
        "logo_path": args.logo_path or state.get("step0", {}).get("logo_path"),
    }
    save_state(state)
    print(f"✅ Step 0 已锁定: theme={args.theme_slug}, mode={args.mode}, "
          f"primary={state['step0']['primary'] or '(未提供)'}, "
          f"logo={state['step0']['logo_path'] or '(无)'}")


def cmd_lock_step1(args):
    state = load_state()
    require_gates(state, ["step0"])
    state["step1"] = {
        "status": "confirmed",
        "company_logo": args.company_logo if args.company_logo else None,
        "company_name": args.company_name,
    }
    save_state(state)
    print(f"✅ Step 1 已锁定: logo={args.company_logo or '(无)'}, name={args.company_name}")


def cmd_lock_step2(args):
    state = load_state()
    require_gates(state, ["step0", "step1"])
    plan_path = Path(args.plan_file)
    if not plan_path.exists():
        print(f"❌ plan file 不存在: {args.plan_file}", file=sys.stderr)
        sys.exit(1)
    state["step2"] = {
        "status": "confirmed",
        "plan_file": args.plan_file,
        "source_doc": args.source_doc,
    }
    save_state(state)
    print(f"✅ Step 2 已锁定: plan={args.plan_file}, source_doc={args.source_doc}")


def cmd_lock_step3(args):
    state = load_state()
    require_gates(state, ["step0", "step1", "step2"])
    state["step3"] = {"status": "generated"}
    save_state(state)
    print("✅ Step 3 已锁定: 用户已回「生成」")


def cmd_lock_step4(args):
    state = load_state()
    require_gates(state, ["step0", "step1", "step2", "step3"])
    state["step4"] = {"status": "plan_confirmed_v2"}
    save_state(state)
    print("✅ Step 4 已锁定: 用户已回「确认」,进入 Autopilot")


def cmd_get(args):
    state = load_state()
    # 支持嵌套 key,如 step0.mode
    keys = args.key.split(".")
    v = state
    for k in keys:
        if not isinstance(v, dict) or k not in v:
            print("", end="")
            sys.exit(0)
        v = v[k]
    print(v if v is not None else "")


def cmd_check(args):
    """校验前置闸门,给下游脚本调用"""
    state = load_state()
    require_gates(state, args.gates)
    print(f"✅ 前置闸门已锁定: {', '.join(args.gates)}")


def main():
    parser = argparse.ArgumentParser(description="deck_state.json 读写与闸门锁定")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init", help="初始化 deck_state.json").set_defaults(func=cmd_init)

    p = sub.add_parser("lock-step0", help="锁定 Step 0")
    p.add_argument("--theme-slug", required=True)
    p.add_argument("--mode", required=True, choices=["light", "dark"])
    p.add_argument("--primary", default="",
                   help="Step 0 派生用的主色 hex(如 #0057FF),存回 state 供 build-all 重建 theme")
    p.add_argument("--logo-path", default="",
                   help="Step 0 用的 logo 本地路径(可选,供后续参考)")
    p.set_defaults(func=cmd_lock_step0)

    p = sub.add_parser("lock-step1", help="锁定 Step 1")
    p.add_argument("--company-logo", default="")
    p.add_argument("--company-name", required=True)
    p.set_defaults(func=cmd_lock_step1)

    p = sub.add_parser("lock-step2", help="锁定 Step 2")
    p.add_argument("--plan-file", required=True)
    p.add_argument("--source-doc", required=True)
    p.set_defaults(func=cmd_lock_step2)

    p = sub.add_parser("lock-step3", help="锁定 Step 3(用户回「生成」)")
    p.set_defaults(func=cmd_lock_step3)

    p = sub.add_parser("lock-step4", help="锁定 Step 4(用户回「确认」)")
    p.set_defaults(func=cmd_lock_step4)

    p = sub.add_parser("get", help="读取指定 key(支持 step0.mode 嵌套)")
    p.add_argument("key")
    p.set_defaults(func=cmd_get)

    p = sub.add_parser("check", help="校验前置闸门,未锁 exit 1")
    p.add_argument("gates", nargs="+")
    p.set_defaults(func=cmd_check)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
