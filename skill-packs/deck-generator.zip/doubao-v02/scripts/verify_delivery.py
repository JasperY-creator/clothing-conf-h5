#!/usr/bin/env python3
"""
verify_delivery.py — 交付链接三方校验(HTTP 200 + md5 + 大小)

用法:
    python3 scripts/verify_delivery.py --file deck.html --url https://.../deck.html
"""

import argparse, hashlib, sys
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

def md5_bytes(b):
    return hashlib.md5(b).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--file", required=True)
    ap.add_argument("--url", required=True)
    args = ap.parse_args()

    local = Path(args.file).read_bytes()
    local_md5 = md5_bytes(local); local_size = len(local)

    try:
        req = Request(args.url, headers={"User-Agent": "Mozilla/5.0"})
        with urlopen(req, timeout=30) as resp:
            status = resp.status
            remote = resp.read()
    except HTTPError as e:
        print(f"❌ HTTP 错误 {e.code}: {args.url}", file=sys.stderr); sys.exit(1)
    except URLError as e:
        print(f"❌ 无法访问: {e.reason}", file=sys.stderr); sys.exit(1)

    remote_md5 = md5_bytes(remote); remote_size = len(remote)

    print(f"本地: size={local_size} md5={local_md5}")
    print(f"远程: size={remote_size} md5={remote_md5} status={status}")

    ok = (status == 200 and local_md5 == remote_md5 and local_size == remote_size)
    if not ok:
        problems = []
        if status != 200: problems.append(f"HTTP {status}")
        if local_md5 != remote_md5: problems.append("md5 不匹配")
        if local_size != remote_size: problems.append(f"大小不同 ({local_size} vs {remote_size})")
        print(f"❌ 校验失败: {', '.join(problems)}", file=sys.stderr)
        sys.exit(1)

    print(f"✅ 交付链接可达 + md5 匹配 + 大小一致")
    sys.exit(0)

if __name__ == "__main__":
    main()
