#!/usr/bin/env python3
"""
verify_layout.py — 页面内容位置 3 轮一致性校验(专治团队页,模块 b)

用户记忆铁律:模块 b(团队介绍)出片时,必须对
「标题/队名/一句话介绍/花名册/部门带」的固定位置与自适应做 3 轮一致性校验。

判定方法:
- 对同一 HTML 文件解析 3 次(纯静态解析,天然一致;若模型/生成器有随机因素这里能抓到)
- 提取关键锚点的存在性、数量、相对顺序,汇成签名
- 3 轮签名必须完全相同

用法:
    python3 scripts/verify_layout.py --page pages/02_team.html --rounds 3
"""

import argparse, hashlib, json, re, sys
from pathlib import Path

# v9.8.9 → v0.2 团队页(模块 b)真实产出结构:
#   .m-b .team-hero > .tname / .team-tagline / .depts > .dept*
#   .m-b .roster > .rcard*(每张 rcard 内含 .ava/.mono/.rname/.rsub)
#   页 shell(preview-content.page())提供 .eyebrow / .ptitle / .ptick / .pfoot
REQUIRED_ANCHORS = [
    ("ptitle",       "标题"),        # <h2 class="ptitle"> — 由 shell 承载
    ("tname",        "队名"),        # <div class="tname">
    ("team-tagline", "一句话介绍"),  # <div class="team-tagline">
    ("roster",       "花名册"),      # <div class="roster">
    ("depts",        "部门带"),      # <div class="depts">
]

# 严格 DOM 顺序:标题(shell 顶) → 队名(hero 左) → 部门带(hero 右)
# → 一句话介绍(hero 下方 tagline) → 花名册(底部)。
EXPECTED_ORDER = ["ptitle", "tname", "depts", "team-tagline", "roster"]


def extract_signature(html):
    """按类名扫锚点,返回位置/数量签名;花名册额外抓 rcard 数量。"""
    sig = {}
    for cls, label in REQUIRED_ANCHORS:
        pattern = rf'class="[^"]*\b{re.escape(cls)}\b[^"]*"'
        matches = re.findall(pattern, html)
        sig[label] = {"count": len(matches), "present": len(matches) > 0}

    # 花名册:抓 rcard 数量作为「队员数」冗余签名
    sig["花名册"]["rcard_count"] = len(re.findall(r'class="[^"]*\brcard\b[^"]*"', html))

    # 相对顺序签名:抓每个锚点首次出现的 byte-offset
    order = []
    for anchor_class in EXPECTED_ORDER:
        m = re.search(rf'class="[^"]*\b{re.escape(anchor_class)}\b', html)
        order.append((anchor_class, m.start() if m else -1))
    sig["order"] = [a for a, off in sorted(order, key=lambda x: x[1]) if off != -1]

    return sig


def hash_sig(sig):
    return hashlib.md5(json.dumps(sig, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--page", required=True)
    ap.add_argument("--rounds", type=int, default=3)
    args = ap.parse_args()

    html = Path(args.page).read_text(encoding="utf-8")
    sigs = [extract_signature(html) for _ in range(args.rounds)]
    hashes = [hash_sig(s) for s in sigs]

    print(f"📄 页面: {args.page}")
    print(f"📊 元素签名 (R1): ")
    for k, v in sigs[0].items():
        print(f"    {k}: {v}")

    # 缺失锚点检查
    missing = [label for _, label in REQUIRED_ANCHORS
               if not sigs[0].get(label, {}).get("present")]
    if missing:
        print(f"❌ 缺失锚点: {missing}", file=sys.stderr); sys.exit(1)

    # 相对顺序检查
    if sigs[0]["order"] != EXPECTED_ORDER:
        print(f"❌ 元素顺序错误: {sigs[0]['order']} 应为 {EXPECTED_ORDER}", file=sys.stderr)
        sys.exit(1)

    # 3 轮 hash 一致
    if len(set(hashes)) != 1:
        print(f"❌ {args.rounds} 轮签名不一致: {hashes}", file=sys.stderr); sys.exit(1)

    print(f"✅ 位置 {args.rounds} 轮一致 (hash={hashes[0][:12]}...)")
    print(f"✅ 所有必需锚点齐全 + 相对顺序正确")
    sys.exit(0)


if __name__ == "__main__":
    main()
