#!/usr/bin/env python3
"""
verify_avatars.py — 头像 3 轮多模态一致性判定

输入:3 份多模态返回 JSON,每份是 [{"name":"张三","valid":true,"reason":"..."}, ...]
输出:verdict.json,汇总每位队员 3 轮结果 + retry_list

规则:
- 3 轮 valid 全部为 true → PASS
- 任一轮为 false → 加入 retry_list
- 3 轮判定不一致(true/false 混合)→ 视为不稳定,也加入 retry_list

退出码:0=全通过;1=有失败(存在 retry_list)
"""

import argparse, json, sys
from pathlib import Path

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rounds", nargs=3, required=True, help="3 份多模态 JSON")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    rounds = [json.loads(Path(p).read_text(encoding="utf-8")) for p in args.rounds]
    # 统一按 name 索引
    def index(round_data):
        return {item["name"]: item for item in round_data}
    idx = [index(r) for r in rounds]

    all_names = set()
    for i in idx: all_names.update(i.keys())

    per_member = []
    retry_list = []
    for name in sorted(all_names):
        results = [idx[i].get(name, {"valid": False, "reason": "缺失"}) for i in range(3)]
        valids = [r["valid"] for r in results]
        all_true = all(valids)
        consistent = len(set(valids)) == 1
        entry = {
            "name": name,
            "rounds": results,
            "valids": valids,
            "consistent": consistent,
            "pass": all_true and consistent,
        }
        per_member.append(entry)
        if not entry["pass"]:
            retry_list.append(name)

    verdict = {
        "total": len(all_names),
        "passed": sum(1 for m in per_member if m["pass"]),
        "failed": len(retry_list),
        "retry_list": retry_list,
        "per_member": per_member,
    }
    Path(args.out).write_text(json.dumps(verdict, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"总数={verdict['total']} 通过={verdict['passed']} 失败={verdict['failed']}")
    if retry_list:
        print(f"❌ 需要重生成: {retry_list}", file=sys.stderr)
        sys.exit(1)
    print("✅ 所有头像 3 轮一致且通过")
    sys.exit(0)

if __name__ == "__main__":
    main()
