#!/usr/bin/env python3
"""
verify_single_mode.py — 单模一致性校验(R1/R2/R3 都要过)

规则:整份 deck 只允许 light 或 dark 一种模式。
判定基准:
  1. body 上必须挂 .m-<mode> class(v9.8.9 惯例);
  2. tokens_by_mode 在 :root 里给出 --fs-bg-0(页背景)、--fs-bg-page(内页浅底);
     两者亮度决定实际视觉模式;必须与 --mode 参数一致。

连跑 3 轮(R1/R2/R3),每轮结果必须相同 + 与目标模式一致才算过。

用法:
    python3 scripts/verify_single_mode.py deck.html --mode light
"""

import argparse, re, sys
from pathlib import Path


def brightness(hex6):
    r = int(hex6[1:3], 16); g = int(hex6[3:5], 16); b = int(hex6[5:7], 16)
    return (r*299 + g*587 + b*114) / 1000


def scan(html_path, expected_mode):
    """扫描 HTML,判定当前模式是否与预期一致"""
    html = Path(html_path).read_text(encoding="utf-8")

    # 1. body class 里应出现 .m-<expected_mode>
    body_cls_m = re.search(r'<body[^>]*class=["\']([^"\']+)["\']', html)
    body_cls = body_cls_m.group(1) if body_cls_m else ""
    class_ok = f"m-{expected_mode}" in body_cls
    # 若整卷是 compose 后的 shell(body 无 m-* 类),则退回 deck-scale/frame 上找
    if not class_ok:
        class_ok = bool(re.search(rf'class="[^"]*\bm-{expected_mode}\b', html))

    # 2. 从 .m-<expected_mode> scope 里抓 --fs-bg-0 决定视觉底色
    scope_bg = None
    scope_m = re.search(
        rf'\.m-{expected_mode}\s*\{{([^}}]+)\}}', html
    )
    if scope_m:
        bg_m = re.search(r"--fs-bg-0:\s*(#[0-9A-Fa-f]{6})", scope_m.group(1))
        if bg_m:
            scope_bg = bg_m.group(1).upper()

    # 3. 兜底:直接找第一处 --fs-bg-0
    if not scope_bg:
        bg_m = re.search(r"--fs-bg-0:\s*(#[0-9A-Fa-f]{6})", html)
        if bg_m:
            scope_bg = bg_m.group(1).upper()

    if not scope_bg:
        return {"ok": False, "reason": "找不到 --fs-bg-0 token(theme.css 未注入?)"}

    bright = brightness(scope_bg)
    detected = "light" if bright > 128 else "dark"
    ok = class_ok and (detected == expected_mode)
    reason = ""
    if not class_ok:
        reason = f"body class 缺 m-{expected_mode}(实际: {body_cls or 'n/a'})"
    elif detected != expected_mode:
        reason = f"--fs-bg-0={scope_bg} 亮度={bright:.0f} 判为 {detected},与目标 {expected_mode} 不符"
    return {"ok": ok, "detected": detected, "bg": scope_bg,
            "brightness": bright, "reason": reason}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--mode", required=True, choices=["light", "dark"])
    args = ap.parse_args()

    fail = False
    for f in args.files:
        results = [scan(f, args.mode) for _ in range(3)]
        all_ok = all(r["ok"] for r in results)
        consistent = len(set((r.get("detected"), r.get("bg")) for r in results)) == 1
        status = "✅" if (all_ok and consistent) else "❌"
        print(f"{status} {f}: R1/R2/R3 detected={[r.get('detected') for r in results]}, "
              f"bg={[r.get('bg') for r in results]}")
        if not (all_ok and consistent):
            for i, r in enumerate(results, 1):
                if not r["ok"]:
                    print(f"   R{i}: {r['reason']}", file=sys.stderr)
            fail = True

    sys.exit(1 if fail else 0)


if __name__ == "__main__":
    main()
