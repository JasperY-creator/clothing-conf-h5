#!/usr/bin/env python3
"""
accept_deck.py — 整卷验收总闸(deck-acceptance)

依次跑:
  1. lint_slides                  → ERROR=0
  2. verify_single_mode           → R1/R2/R3 全过
  3. deck.notes.json 存在(inject-notes 已跑)
  4. deck.speech.json 存在 + lark_doc_url 非空(演讲稿飞书文档已建)
  5. verify_speaker_notes 3 轮    → 6 闸全过
  6. verify_layout                → 团队页锚点 + 3 轮位置一致(如果找到 02_team.html)
  7. verify_avatars.verdict.json 存在 → failed=0 (若跑过头像生成)
  8. verify_screenshots           → d/d2/e/f 的 .shot 均为原图字节(无整页残留 / 偏黄 / 纯色)

全过 → 退出码 0(允许交付);任一失败 → 退出码 1

用法:
    python3 scripts/accept_deck.py deck.html --mode light
    python3 scripts/accept_deck.py deck.html --mode light --team-page out/02_team.html
"""

import argparse, json, subprocess, sys
from pathlib import Path

def run(cmd):
    print(f"\n$ {' '.join(cmd)}")
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.stdout: print(r.stdout)
    if r.stderr: print(r.stderr, file=sys.stderr)
    return r.returncode

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--mode", required=True, choices=["light", "dark"])
    ap.add_argument("--team-page", default="",
                    help="团队页 HTML 路径(可选);默认按 pages/02_team.html 和 <deck 同目录>/02_team.html 逐一探测")
    args = ap.parse_args()

    deck = args.deck
    scripts_dir = Path(__file__).parent
    problems = []

    # 1. lint
    if run(["python3", str(scripts_dir / "lint_slides.py"), deck]) != 0:
        problems.append("lint ERROR")

    # 2. single-mode
    if run(["python3", str(scripts_dir / "verify_single_mode.py"), deck, "--mode", args.mode]) != 0:
        problems.append("single-mode FAIL")

    # 3. notes.json 存在
    notes_json = deck.replace(".html", ".notes.json")
    if not Path(notes_json).exists():
        problems.append(f"缺 {notes_json}(inject-notes 未跑)")
    else:
        print(f"✅ 存在 {notes_json}")

    # 4. speech.json 存在 + lark_doc_url
    speech_json = deck.replace(".html", ".speech.json")
    if not Path(speech_json).exists():
        problems.append(f"缺 {speech_json}(record-speech-doc 未跑)")
    else:
        try:
            data = json.loads(Path(speech_json).read_text(encoding="utf-8"))
            if not data.get("lark_doc_url"):
                problems.append(f"{speech_json} 缺 lark_doc_url")
            else:
                print(f"✅ 演讲稿飞书文档: {data['lark_doc_url']}")
        except Exception as e:
            problems.append(f"{speech_json} 解析失败: {e}")

    # 5. speaker-notes 6 闸 3 轮
    if run(["python3", str(scripts_dir / "verify_speaker_notes.py"), deck, "--rounds", "3"]) != 0:
        problems.append("speaker-notes FAIL")

    # 6. layout(团队页):
    #    显式 --team-page 优先;否则依次探 pages/02_team.html、<deck 目录>/02_team.html。
    team_candidates = []
    if args.team_page:
        team_candidates.append(Path(args.team_page))
    team_candidates.append(Path("pages/02_team.html"))
    team_candidates.append(Path(deck).parent / "02_team.html")
    team_page = next((p for p in team_candidates if p.exists()), None)
    if team_page:
        if run(["python3", str(scripts_dir / "verify_layout.py"),
                "--page", str(team_page), "--rounds", "3"]) != 0:
            problems.append("layout FAIL")
    else:
        print("ℹ️ 未找到团队页 HTML(pages/02_team.html 或 --team-page),跳过 layout 校验")

    # 7. avatars verdict
    verdict = Path("avatars/verdict.json")
    if verdict.exists():
        try:
            v = json.loads(verdict.read_text(encoding="utf-8"))
            if v.get("failed", 0) > 0:
                problems.append(f"头像 verdict 有 {v['failed']} 张失败(可能已标 DEGRADED)")
            else:
                print(f"✅ 头像 verdict: {v['passed']}/{v['total']} 全过")
        except Exception as e:
            problems.append(f"avatars/verdict.json 解析失败: {e}")

    # 8. 云文档截图原图校验(v0.2.11-r2):d/d2/e/f 的 .shot 必须是原图字节,
    #    不得是整页截屏残留(底部大白带)/ 偏黄有损缩略图 / 纯色占位。
    #    查 deck 内联截图;若同目录存在 materials/screenshots 也一并查落盘原图。
    ss_cmd = ["python3", str(scripts_dir / "verify_screenshots.py"), deck]
    ss_dir_candidates = [Path("materials/screenshots"),
                         Path(deck).parent / "materials/screenshots",
                         Path(deck).parent.parent / "materials/screenshots"]
    ss_dir = next((d for d in ss_dir_candidates if d.is_dir()), None)
    if ss_dir:
        ss_cmd += ["--dir", str(ss_dir)]
    if run(ss_cmd) != 0:
        problems.append("screenshots FAIL(截图非原图:整页残留 / 偏黄 / 纯色占位)")

    print("\n" + "=" * 60)
    if problems:
        print(f"❌ 整卷验收失败 ({len(problems)} 项):")
        for p in problems: print(f"  - {p}")
        sys.exit(1)
    print("✅ 整卷验收通过,允许交付")
    sys.exit(0)

if __name__ == "__main__":
    main()
