#!/usr/bin/env python3
"""
render_page.py — 主渲染脚本(多子命令)

子命令:
  theme            : 从 primary hex 派生 4 阶 OKLCH 配色 + 出色板 + 出封面样张
  extract-plan     : 从 source.md 抽取 team/closing 信息,生成 plan.json
  cover            : 渲染封面页
  team             : 渲染团队页(模块 b)
  close            : 渲染收官页(模块 g)
  compose          : 拼装整卷 deck
  speech-plan      : 生成演讲稿骨架
  inject-notes     : 就地把 speech_plan.per_page_notes 写回 HTML 的 data-notes
  record-speech-doc: 记录飞书演讲稿文档 URL 到 deck.speech.json sidecar
"""

import argparse
import json
import os
import re
import sys
import math
import hashlib
from pathlib import Path

# ---------------- 通用工具 ----------------

def read_json(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def write_json(p, obj):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def read_text(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write_text(p, s):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)

# ---------------- theme 子命令:委托 v9.8.9 build-theme.py 派生 OKLCH 色板 ----------------
# v0.2:不再自己派生 4 阶,直接调 assets/build-theme.py 产 v9.8.9 shape 的
# palette.json(含 tokens_by_mode + wcag_by_mode),并用 preview-theme.build_html
# 出「浅+深双模封面对照」HTML 供后续截图确认。

import subprocess

def cmd_theme(args):
    primary = args.primary.strip()
    if not re.match(r"^#[0-9A-Fa-f]{6}$", primary):
        print(f"❌ primary 不是合法 hex: {primary}", file=sys.stderr); sys.exit(1)

    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    name = out_dir.name

    # 1) 委托 build-theme.py 产 v9.8.9 shape palette.json + theme.css
    bt = _ASSETS / "build-theme.py"
    cmd = [sys.executable, str(bt), "--primary", primary, "--name", name, "--out", str(out_dir)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(f"❌ build-theme.py 失败: {r.stderr}", file=sys.stderr); sys.exit(1)

    # 2) 用 preview-theme.build_html 出「浅+深双模封面对照 + 4 色卡片」HTML
    data = read_json(out_dir / "palette.json")
    if args.company_logo and Path(args.company_logo).exists():
        data["company_logo"] = args.company_logo
    # 让 preview-theme 挑我们 bundled 的 feishu logo
    data["feishu_logo"] = str(_ASSETS / "feishu-logo.png")
    preview_html = _pt().build_html(
        data,
        title="示例封面 · 你的主色派生",
        author="示例署名",
        date="2026",
        company_name="示例企业",
    )
    write_text(out_dir / "theme_preview.html", preview_html)
    print(f"✅ theme 已生成 (v9.8.9 shape): {out_dir}")
    print(f"   · palette.json  (tokens_by_mode + wcag_by_mode)")
    print(f"   · theme.css     (v9.8.9 双模 CSS)")
    print(f"   · theme_preview.html  (浅+深双模封面对照,交平台截图后给用户确认)")

# ---------------- extract-plan 子命令 ----------------

def cmd_extract_plan(args):
    md = read_text(args.source)
    plan = {
        "deck_title": _extract_title(md),
        "team": _extract_team(md),
        "closing": _extract_closing(md),
    }
    write_json(args.out, plan)
    print(f"✅ plan.json 已生成: {args.out}")
    print(json.dumps(plan, ensure_ascii=False, indent=2))

def _extract_title(md):
    for line in md.splitlines():
        s = line.strip()
        if s.startswith("# "):
            return s[2:].strip()
    return "未命名演示"

def _extract_team(md):
    # 找"团队"/"团队介绍"/"成员"章节
    m = re.search(r"#+\s*(团队(?:介绍)?|成员|Team)\s*\n(.+?)(?=\n#+\s|\Z)", md, re.S)
    body = m.group(2) if m else ""
    team_name = _grep_field(body, r"队名|团队名") or "示例团队"
    leader = _grep_field(body, r"队长|Leader") or ""
    dept = _grep_field(body, r"部门|Department|Departments") or ""
    # 部门可能是「A、B、C」/「A/B/C」/「A,B,C」多个,拆成列表;为空则空列表
    departments = [d.strip() for d in re.split(r"[/、,,\s]+", dept) if d.strip()] if dept else []
    one_liner = _grep_field(body, r"一句话|简介|Intro") or ""
    members = _grep_members(body)
    return {
        "team_name": team_name,
        "leader": leader,
        "members": members[:6],
        "department": dept,
        "departments": departments,
        "one_liner": one_liner,
    }

def _extract_closing(md):
    m = re.search(r"#+\s*(总结|收官|Conclusion|Summary)\s*\n(.+?)(?=\n#+\s|\Z)", md, re.S)
    body = m.group(2) if m else md[-500:]
    main = ""
    for line in body.splitlines():
        s = line.strip().lstrip("-*").strip()
        if s and not s.startswith("#"):
            main = s; break
    numbers = []
    for mm in re.finditer(r"(\d+(?:\.\d+)?)\s*(倍|%|个|万|亿|人|天|小时|分钟)?\s*(?:的\s*)?([一-龥A-Za-z]{2,10})?", body):
        val, unit, label = mm.group(1), mm.group(2) or "", mm.group(3) or ""
        if label and len(numbers) < 3:
            numbers.append({"value": val, "unit": unit, "label": label})
    return {"main_line": main or "感谢聆听", "sub_line": "", "impact_numbers": numbers}

def _grep_field(body, keys_pattern):
    m = re.search(rf"(?:{keys_pattern})[::\s]+(.+)", body)
    return m.group(1).strip() if m else None

def _grep_members(body):
    # 优先找"成员"字段后的列表
    m = re.search(r"(?:成员|队员|Members)[::\s]*(.+?)(?=\n\n|\Z)", body, re.S)
    if m:
        raw = m.group(1)
        parts = re.split(r"[、,,\n\s]+", raw)
        return [p.strip("-*·").strip() for p in parts if p.strip() and len(p.strip()) < 20][:6]
    return []

# ---------------- cover / team / close 渲染 ----------------
# v0.2:全面对齐 v9.8.9 输出标准。封面走 preview-theme.COVER_PRESETS(默认 corner)
# +内页走 preview-content.page() + MODULES,CSS = COVER_CSS + CONTENT_CSS,tokens 走
# tokens_by_mode(浅深各一套 --fs-* 变量)。豆包端渲染的每一页 HTML,肉眼与代码结构
# 都与 v9.8.9 逐字一致。

import importlib.util as _iu

_HERE = Path(__file__).resolve().parent
_ASSETS = _HERE.parent / "assets"

def _load_asset_module(mod_name, filename):
    """把带连字符文件名的 preview-theme.py / preview-content.py 作为模块加载。"""
    path = _ASSETS / filename
    spec = _iu.spec_from_file_location(mod_name, str(path))
    mod = _iu.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

# 惰性加载:cmd_theme 阶段还没有 palette 也可以先跑,这里在真正用时才 import。
_PT = None
_PC = None

def _pt():
    global _PT
    if _PT is None:
        _PT = _load_asset_module("preview_theme", "preview-theme.py")
    return _PT

def _pc():
    global _PC
    if _PC is None:
        _PC = _load_asset_module("preview_content", "preview-content.py")
    return _PC


def _load_theme(state):
    """加载 v9.8.9 标准的 palette.json(含 tokens_by_mode + wcag_by_mode)。"""
    slug = state["step0"]["theme_slug"]
    data = read_json(f"themes/{slug}/palette.json")
    return data, state["step0"]["mode"]


def _mode_scope_css(tbm):
    """把 tokens_by_mode 的两套 tokens 各自 scope 到 .m-light / .m-dark(v9.8.9 惯例)。"""
    def scope(cls, toks):
        body = "\n".join(f"    {k}: {v};" for k, v in toks.items())
        return f"  .{cls} {{\n{body}\n  }}"
    return scope("m-light", tbm["light"]) + "\n" + scope("m-dark", tbm["dark"])


def _stamp_empty_data_notes(page_html):
    """确保每个 .page 根节点上都有 data-notes 属性(允许为空),供 lint / inject-notes 定位。
    对 preview-content.page() 产出的第一个 <div class="... page ..."> 生效。"""
    if 'data-notes=' in page_html.split('>', 1)[0] if '>' in page_html else False:
        return page_html
    # 精准替换第一个 .page 开标签,加 data-notes=""
    return re.sub(
        r'(<div class="[^"]*\bpage\b[^"]*")(?![^>]*data-notes)',
        r'\1 data-notes=""',
        page_html, count=1
    )


# 原生尺寸(与 v9.8.9 compose_deck.py 完全一致,不可改):
COVER_NATIVE_W = 580.0    # cover-wrap 原生宽
CONTENT_NATIVE_W = 1280.0  # preview-content .page 原生宽

# ---------------- 单页 HTML 组装器(与 v9.8.9 视觉逐字一致) ----------------

def _standalone_page_html(mode, native_w, page_kind, palette_data, inner_html):
    """一份自封装 HTML:body class=m-{mode},含 tokens_by_mode + COVER_CSS + CONTENT_CSS,
    body 里直接放 inner_html(cover-wrap 或 .page)。data-native-w 供 compose 阶段读。
    """
    tbm = palette_data["tokens_by_mode"]
    mode_css = _mode_scope_css(tbm)
    PT = _pt(); PC = _pc()
    return f'''<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8"/>
<title>page-{page_kind}</title>
<meta name="deck-native-w" content="{native_w:.0f}"/>
<style>
* {{ box-sizing:border-box; margin:0; padding:0; }}
html,body {{ margin:0; padding:0; }}
body {{ font-family:"FZLanTingHei-R-GB18030","方正兰亭黑_GB18030","FZLanTingHeiGB",
        system-ui,"Noto Sans SC","PingFang SC","Microsoft YaHei",sans-serif;
        background:#000; }}
{mode_css}
{PT.COVER_CSS}
{PC.CONTENT_CSS}
</style></head>
<body class="m-{mode}" data-native-w="{native_w:.0f}">{inner_html}</body></html>'''


def cmd_cover(args):
    state = read_json(args.state); plan = read_json(args.plan)
    palette_data, mode = _load_theme(state)
    PT = _pt()
    company = state["step1"]["company_name"]
    logo = state["step1"].get("company_logo") or ""
    feishu_logo = str(_ASSETS / "feishu-logo.png")
    layout = state["step1"].get("cover_layout") or "corner"

    title = plan.get("deck_title", "未命名演示")
    author = state["step1"].get("author") or plan.get("team", {}).get("leader") or "汇报人"
    date = state["step1"].get("date") or ""

    markup = PT.COVER_PRESETS.get(layout, PT.COVER_PRESETS["corner"])
    cobrand = PT.build_cobrand(logo or None, PT.feishu_logo_for_mode(feishu_logo, mode))
    kicker = PT.brand_kicker(company)
    fields = {"title": title, "author": author, "date": date,
              "cobrand": cobrand, "bird": PT.BIRD_SVG, "kicker": kicker,
              "title_px": PT.fit_title_px(title)}
    inner = markup.format(**fields)
    # 预打 data-notes="" 空位,inject-notes 时按顺序写回;避免 lint 抓不到 cover-wrap 上的锚点
    # v0.2.11-r1:封面根节点补挂 m-{mode},与内页 `.m-<mode> page` 对齐,
    #   否则 assets/verify-single-mode.py 的 PAGE_TAG 会把 cover-wrap 当作一页却取不到
    #   模式标记,R2「逐页齐一」必判 FAIL(成卷自检与逐步验收结论打架)。
    cover_html = f'<div class="m-{mode} cover-wrap cover-{layout}" data-notes="">{inner}</div>'
    html = _standalone_page_html(mode, COVER_NATIVE_W, "cover", palette_data, cover_html)
    write_text(args.out, html)
    print(f"✅ cover 已渲染 (v9.8.9 · layout={layout} · mode={mode}): {args.out}")


def cmd_team(args):
    state = read_json(args.state); plan = read_json(args.plan)
    palette_data, mode = _load_theme(state)
    PC = _pc()
    team = plan["team"]
    avatars = read_json(args.avatars) if args.avatars and Path(args.avatars).exists() else []
    avatar_map = {a["name"]: a.get("url") or a.get("data_uri") or "" for a in avatars}

    company = state["step1"]["company_name"]
    # v0.2.5:优先取 plan.team.departments(list),回退到 department(str);
    # 全空 → 不渲染 .depts-wrap(避免空右框)。
    departments_field = team.get("departments")
    if isinstance(departments_field, list) and any(str(x).strip() for x in departments_field):
        depts = [str(d).strip() for d in departments_field if str(d).strip()]
    else:
        dept = team.get("department", "") or ""
        depts = [d.strip() for d in re.split(r"[/、,,\s]+", dept) if d.strip()]

    members = team.get("members") or []
    if team.get("leader") and team["leader"] not in members:
        members = [team["leader"]] + members
    members = members[:6]

    # 拼装花名册卡片:必须与 v9.8.9 .m-b .roster .rcard 一致(队长/队员 badge、素描/首字头像、上传)
    def _ava(idx, name, url):
        initial = (name or "")[:1] or "?"
        if url:
            return (f'<label class="ava">'
                    f'<img src="{url}" alt="{name}"/>'
                    f'<span class="mono" style="display:none">{initial}</span>'
                    f'<span class="up">上传</span>'
                    f'<input type="file" accept="image/*" onchange="__avaUp(this)"></label>')
        # 无外部头像 URL:退回 preview-content 的 sketch_uri(自带 6 张亚洲素描) + 首字兜底
        return PC.ava_html(idx, initial)

    roster_html = ""
    for i, name in enumerate(members):
        is_captain = (name == team.get("leader"))
        role_cls = "captain" if is_captain else "member"
        role_txt = "队长 · CAPTAIN" if is_captain else "队员"
        url = avatar_map.get(name, "")
        sub = "发起人" if is_captain else ""
        roster_html += ('<div class="rcard">'
                        f'<span class="badge-role {role_cls}">{role_txt}</span>'
                        + _ava(i, name, url)
                        + f'<div class="rname">{name}</div>'
                        + f'<div class="rsub">{sub}</div>'
                        '</div>')

    depts_html = ""
    for i, d in enumerate(depts):
        depts_html += ('<span class="plus">+</span>' if i else "")
        depts_html += f'<span class="dept"><span class="dot"></span>{d}</span>'

    # v0.2.5:depts 为空 → 整块 .depts-wrap 不渲染,避免空右框
    depts_wrap_html = (
        '<div class="depts-wrap">'
          '<div class="dlabel">跨部门联合 · DEPARTMENTS</div>'
          f'<div class="depts">{depts_html}</div>'
        '</div>'
    ) if depts else ''

    body = (
        '<div class="m-b">'
          '<div class="team-hero">'
            '<div class="name-wrap">'
              '<div class="tlabel">TEAM NAME · 队名</div>'
              f'<div class="tname">{team.get("team_name","")}</div>'
            '</div>'
            + depts_wrap_html
          + '</div>'
          f'<div class="team-tagline">{team.get("one_liner","")}</div>'
          f'<div class="roster">{roster_html}</div>'
        '</div>'
        + PC.TEAM_UPLOAD_JS
        + PC.TEAM_FIT_JS
    )

    # 借道 preview-content.page():临时覆盖 MODULES['b'] body/kicker/title,复用它的 shell
    saved = PC.MODULES["b"]
    PC.MODULES["b"] = dict(saved, body=body, kicker="团队 · TEAM",
                           title=team.get("team_name") or saved["title"])
    try:
        # 设 company_name 让页脚 brand_foot 正确
        os.environ["DECK_COMPANY_NAME"] = company
        page_html = PC.page("m-" + mode, "b", args.page_no, args.total)
    finally:
        PC.MODULES["b"] = saved

    page_html = _stamp_empty_data_notes(page_html)
    html = _standalone_page_html(mode, CONTENT_NATIVE_W, "team", palette_data, page_html)
    write_text(args.out, html)
    print(f"✅ team 已渲染 (v9.8.9 · module=b · {len(members)} 人 · mode={mode}): {args.out}")


def cmd_close(args):
    state = read_json(args.state); plan = read_json(args.plan)
    palette_data, mode = _load_theme(state)
    PC = _pc()
    closing = plan.get("closing", {}) or {}
    company = state["step1"]["company_name"]

    numbers = (closing.get("impact_numbers") or [])[:4]
    n = max(2, min(4, len(numbers) or 4))
    cards = ""
    # v0.2.7 修 #4:左上角前缀取值优先级 —— 材料里显式 item["prefix"] > label 关键词扫描 >
    # 轮换池(提升/达到/降低/保持),彻底根治 v0.2.6 全部默认「提升」的 bug。
    _rot = ("提升", "达到", "降低", "保持")
    for idx, item in enumerate(numbers):
        val = str(item.get("value") or "").strip() or "0"
        unit = str(item.get("unit") or "").strip() or "%"
        label = str(item.get("label") or "").strip() or "指标"
        explicit = str(item.get("prefix") or "").strip()
        if explicit:
            prefix = explicit
        else:
            prefix = None
            for p in ("提升", "降低", "达到", "缩短", "扩大", "保持", "覆盖", "节省"):
                if p in label:
                    prefix = p; break
            if not prefix:
                # 无显式/关键词 → 轮换池,避免全部默认「提升」
                prefix = _rot[idx % len(_rot)]
        # arrow: 降低/缩短/节省 类向下,其余向上
        arrow = "↓" if prefix in ("降低", "缩短", "节省") else "↑"
        # 数字试着抽整数部分
        m = re.match(r"(-?\d+)(?:\.(\d+))?", val)
        to_int = m.group(1) if m else "0"
        tail = ("." + m.group(2) if m and m.group(2) else "")
        cards += ('<div class="card">'
                  f'<div class="prefix">{prefix}</div>'
                  f'<div class="pct"><span class="arrow">{arrow}</span>'
                  f'<span class="v" data-to="{to_int}">0</span>'
                  f'<span class="u">{tail}{unit}</span></div>'
                  f'<div class="t">{label}</div>'
                  '<div class="d"></div>'
                  '</div>')
    if not cards:
        # 兜底:出一张 impact 卡,保证版式不塌
        cards = ('<div class="card">'
                 '<div class="prefix">达到</div>'
                 '<div class="pct"><span class="arrow">↑</span>'
                 '<span class="v" data-to="100">0</span><span class="u">%</span></div>'
                 '<div class="t">目标达成</div>'
                 '<div class="d"></div>'
                 '</div>')
        n = 2

    main_line = closing.get("main_line") or "感谢聆听"
    sub_line = closing.get("sub_line") or ""

    body = (
        '<div class="m-g">'
          f'<div class="impact n{n}">{cards}</div>'
          '<div class="closing">'
            f'<span class="cmain">{main_line}</span>'
            + (f'<span class="csub">{sub_line}</span>' if sub_line else "")
          + '</div>'
        '</div>'
        + PC.BG_COUNT_JS
    )

    saved = PC.MODULES["g"]
    PC.MODULES["g"] = dict(saved, body=body, kicker="价值 · IMPACT AT A GLANCE",
                           title=plan.get("deck_title", saved["title"]))
    try:
        os.environ["DECK_COMPANY_NAME"] = company
        page_html = PC.page("m-" + mode, "g", args.page_no, args.total)
    finally:
        PC.MODULES["g"] = saved

    page_html = _stamp_empty_data_notes(page_html)
    html = _standalone_page_html(mode, CONTENT_NATIVE_W, "close", palette_data, page_html)
    write_text(args.out, html)
    print(f"✅ close 已渲染 (v9.8.9 · module=g · mode={mode}): {args.out}")


# ---------------- page 子命令:通用模块渲染(a/c/d/d2/e/e2/f) ----------------
# 复用 preview-content.MODULES,允许 --module-json 覆盖任意字段(kicker/title/body)。
# 这样 v0.2 不再局限 b/g,任意 v9.8.9 内页模块都能出片。
#
# module.json 示例:
# {
#   "mod": "e",
#   "kicker": "方案全景 · SOLUTION",
#   "title": "智能排班平台:一图看懂整体方案",
#   "body": "<div class=\"m-e\">...任意 v9.8.9 版式片段...</div>"
# }
# 若不提供 body,则直接复用 MODULES[mod] 的默认演示 body(方便看版式)。

_ALLOWED_MODS = {"a", "b", "c", "d", "d2", "e", "e2", "f", "g"}

def cmd_page(args):
    state = read_json(args.state); plan = read_json(args.plan)
    palette_data, mode = _load_theme(state)
    PC = _pc()
    company = state["step1"]["company_name"]

    mod = args.mod
    if mod not in _ALLOWED_MODS:
        print(f"❌ mod 必须是 {sorted(_ALLOWED_MODS)} 之一: {mod}", file=sys.stderr); sys.exit(1)

    override = {}
    if args.module_json and Path(args.module_json).exists():
        override = read_json(args.module_json)
        if override.get("mod") and override["mod"] != mod:
            print(f"⚠️ --mod={mod} 与 module.json.mod={override['mod']} 不一致,以 --mod 为准", file=sys.stderr)

    saved = PC.MODULES[mod]
    patched = dict(saved)
    for k in ("kicker", "title", "body"):
        if override.get(k):
            patched[k] = override[k]

    # v0.2.11-r2:根治「--module-json 覆盖 body 时把模块自带引擎脚本一并冲掉」——
    #   e2 默认 body = 版式 HTML + E2_DRAW_JS(连线绘制),c/d2/f/g 默认 body 也拼了
    #   BG_COUNT_JS(数字动效)。用户只提供内容 body 时,这些 <script> 会整块丢失,
    #   导致 e2 的「上→中 / 中→下」连线永远不画、数字不 count-up。
    #   修法:把默认 body 里内联的 <script>…</script> 逐块检查,凡覆盖 body 里没有的
    #   就补回到覆盖 body 末尾(按原顺序),保证引擎脚本恒在,同时不重复注入。
    if override.get("body"):
        default_body = saved.get("body", "")
        new_body = patched["body"]
        engine_scripts = re.findall(r'<script>.*?</script>', default_body, re.S)
        appended = []
        for sc in engine_scripts:
            if sc not in new_body:
                new_body += "\n" + sc
                appended.append(sc)
        patched["body"] = new_body
        if appended:
            print(f"ℹ️ module={mod}:--module-json 的 body 未含 {len(appended)} 段模块自带引擎脚本"
                  f"(如 e2 连线 / 数字动效),已自动补回,避免动效/连线丢失。",
                  file=sys.stderr)

    PC.MODULES[mod] = patched
    try:
        os.environ["DECK_COMPANY_NAME"] = company
        page_html = PC.page("m-" + mode, mod, args.page_no, args.total)
    finally:
        PC.MODULES[mod] = saved

    page_html = _stamp_empty_data_notes(page_html)
    html = _standalone_page_html(mode, CONTENT_NATIVE_W, f"mod-{mod}", palette_data, page_html)
    write_text(args.out, html)
    print(f"✅ page 已渲染 (v9.8.9 · module={mod} · mode={mode}): {args.out}")


# ---------------- build-all 子命令:一次性成卷 + 验收 ----------------
# 依次完成:
#   1) 若 palette 未生成 → 调 cmd_theme
#   2) render cover / team / [中间模块] / close
#   3) compose 成一卷 deck.html
#   4) (可选) 调 accept_deck.py 跑最终验收
#
# --extra 支持多次:--extra c=modc.json --extra e=mode.json ...
# 中间模块按 --extra 顺序插入到 team 与 close 之间。

def cmd_build_all(args):
    state = read_json(args.state); plan = read_json(args.plan)
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)

    # 1) theme(如果 themes/<slug>/palette.json 不存在)
    slug = state["step0"]["theme_slug"]
    theme_dir = Path("themes") / slug
    if not (theme_dir / "palette.json").exists():
        primary = state["step0"].get("primary")
        if not primary:
            # 兼容旧 state:退回默认蓝色,给出明确警告
            primary = "#0057FF"
            print(f"⚠️ themes/{slug}/palette.json 不存在,且 state.step0.primary 未提供,"
                  f"退回默认 primary={primary}(建议 lock-step0 时传 --primary 保真)",
                  file=sys.stderr)
        logo_path = state["step0"].get("logo_path") or state["step1"].get("company_logo") or ""
        theme_args = argparse.Namespace(primary=primary, company_logo=logo_path,
                                        out_dir=str(theme_dir))
        cmd_theme(theme_args)

    # 2) 渲染各页
    plan_path = args.plan
    state_path = args.state
    pages_paths = []

    # 组装页序:cover(1) + team(2) + extras(3..) + close(N)
    extras = []
    for spec in (args.extra or []):
        if "=" not in spec:
            print(f"❌ --extra 需 mod=json 形式: {spec}", file=sys.stderr); sys.exit(1)
        mod, jf = spec.split("=", 1)
        mod = mod.strip()
        if mod not in _ALLOWED_MODS - {"b", "g"}:
            print(f"❌ --extra 模块非法 (只允许 a/c/d/d2/e/e2/f): {mod}", file=sys.stderr); sys.exit(1)
        extras.append((mod, jf.strip()))
    total = 2 + len(extras) + 1

    # cover
    p = out_dir / "01_cover.html"
    cmd_cover(argparse.Namespace(state=state_path, plan=plan_path, out=str(p)))
    pages_paths.append(str(p))
    # team
    p = out_dir / "02_team.html"
    cmd_team(argparse.Namespace(state=state_path, plan=plan_path,
                                avatars=args.avatars or "", out=str(p),
                                page_no=2, total=total))
    pages_paths.append(str(p))
    # extras
    for i, (mod, jf) in enumerate(extras, start=3):
        p = out_dir / f"{i:02d}_mod-{mod}.html"
        cmd_page(argparse.Namespace(state=state_path, plan=plan_path,
                                    mod=mod, module_json=jf, out=str(p),
                                    page_no=i, total=total))
        pages_paths.append(str(p))
    # close
    p = out_dir / f"{total:02d}_close.html"
    cmd_close(argparse.Namespace(state=state_path, plan=plan_path, out=str(p),
                                 page_no=total, total=total))
    pages_paths.append(str(p))

    # 3) compose
    deck_out = out_dir / "deck.html"
    cmd_compose(argparse.Namespace(pages=pages_paths, out=str(deck_out)))
    print(f"\n📦 deck 已生成: {deck_out}  ({len(pages_paths)} 页)")

    # 4) 可选验收
    if args.accept:
        scripts_dir = Path(__file__).parent
        r = subprocess.run([sys.executable, str(scripts_dir / "accept_deck.py"),
                            str(deck_out), "--mode", state["step0"]["mode"]],
                           capture_output=False)
        if r.returncode != 0:
            # v0.2.11-r1:验收未过必须反映到退出码,否则自动化编排会把
            #   build-all --accept 误判为成功。仍打印告警,但以 accept 的
            #   returncode 退出,让调用方能据此判断。
            print("❌ accept_deck 未全过 —— build-all 以非零退出(交付前请复核)",
                  file=sys.stderr)
            sys.exit(r.returncode)


def _img_data_uri(path):
    import base64, mimetypes
    mime = mimetypes.guess_type(path)[0] or "image/png"
    b64 = base64.b64encode(Path(path).read_bytes()).decode("ascii")
    return f"data:{mime};base64,{b64}"

# ---------------- compose:v9.8.9 三模式 HTML shell ----------------
# 幻灯片浏览器式 HTML(**不是**竖排整卷):水平胶片带(.deck-track 内所有 .deck-frame
# 横向排布),整条被 .deck-stage 的 overflow:hidden 裁切、靠 translateX 平移切页。
# 所有页始终在 DOM、完整渲染、可见 —— 从左到右可见的胶片带。
# 底部 nav:‹ 圆钮 · 页码圆点(当前页高亮成胶囊)· › 圆钮 · N/M 计数 +
# 「✎ 编辑模式」/「⬇ 导出 HTML」/「🖥 演讲者模式」三个工具按钮。
# 三种模式:body.deck-editing(编辑)/ body.deck-speaker(演讲者面板)/ body.deck-projecting(投屏)。

DISPLAY_W = 1000.0
PAGE_NATIVE_W = 1920.0
ASPECT = 9.0 / 16.0

_SHELL_CSS = """
  * { box-sizing:border-box; margin:0; padding:0; }
  html,body { width:100%; }
  body { background:#0B0D12; min-height:100vh;
         padding:38px 24px 30px;
         font-family:system-ui,"Noto Sans SC","PingFang SC",sans-serif;
         color:rgba(255,255,255,.82);
         display:flex; flex-direction:column; align-items:center;
         justify-content:center; gap:24px; }
  .deck-stage { position:relative; overflow:hidden; border-radius:20px;
                box-shadow:0 30px 80px -24px rgba(0,0,0,.62),
                           0 0 0 1px rgba(255,255,255,.05); background:#000; }
  .deck-track { display:flex; gap:0; height:100%;
                transform:translateX(0);
                transition:transform .55s cubic-bezier(.6,.02,.1,1);
                will-change:transform; }
  .deck-frame { flex:0 0 auto; position:relative; overflow:hidden;
                border-radius:0; box-shadow:none; }
  .deck-scale { transform-origin:top left; }
  .deck-nav { display:flex; align-items:center; gap:18px; padding:6px 12px;
              flex-wrap:wrap; justify-content:center; }
  .deck-arrow { width:44px; height:44px; border-radius:50%;
                display:flex; align-items:center; justify-content:center;
                font-size:22px; line-height:1; cursor:pointer;
                background:rgba(255,255,255,.06);
                border:1px solid rgba(255,255,255,.14);
                color:rgba(255,255,255,.82);
                transition:border-color .25s, box-shadow .25s, color .25s,
                           background .25s, transform .12s; }
  .deck-arrow:hover:not(:disabled) { border-color:#7BE0C6;
                box-shadow:0 0 0 3px rgba(123,224,198,.18); color:#fff;
                background:rgba(255,255,255,.10); }
  .deck-arrow:active:not(:disabled) { transform:scale(.9); }
  .deck-arrow:disabled { opacity:.26; cursor:default; }
  .deck-dots { display:flex; align-items:center; gap:9px; }
  .deck-dot { width:9px; height:9px; padding:0; border:none; border-radius:50%;
              cursor:pointer; background:rgba(255,255,255,.22);
              transition:width .32s cubic-bezier(.6,.02,.1,1),
                         background .3s, box-shadow .3s, border-radius .3s; }
  .deck-dot:hover { background:rgba(255,255,255,.42); }
  .deck-dot.is-active { width:26px; border-radius:6px;
              background:#7BE0C6; box-shadow:0 0 0 3px rgba(123,224,198,.18); }
  .deck-count { font-size:13px; letter-spacing:.16em;
              font-variant-numeric:tabular-nums; min-width:60px; text-align:center;
              color:rgba(255,255,255,.5); }
  @media (prefers-reduced-motion:reduce) { .deck-track { transition:none; } }
"""

_EDIT_CSS = """
  .deck-tool { height:34px; padding:0 14px; border-radius:17px; font-size:13px; line-height:1;
        cursor:pointer; white-space:nowrap;
        background:rgba(255,255,255,.06); border:1px solid rgba(255,255,255,.14);
        color:rgba(255,255,255,.82);
        transition:border-color .25s, box-shadow .25s, color .25s, background .25s; }
  .deck-tool:hover { border-color:#7BE0C6; box-shadow:0 0 0 3px rgba(123,224,198,.18);
        color:#fff; background:rgba(255,255,255,.10); }
  .deck-edit.is-on { border-color:#7BE0C6; box-shadow:0 0 0 3px rgba(123,224,198,.18);
        color:#fff; background:rgba(255,255,255,.12); }
  .deck-editing [data-edt] { outline:1px dashed #7BE0C6; outline-offset:2px;
        border-radius:3px; cursor:text; }
  .deck-editing [data-edt]:focus { outline:2px solid #7BE0C6;
        background:rgba(255,255,255,.05); }
  /* v0.2.7 修 #1:封面标题在编辑态强制关掉渐变裁字,恢复实心色,避免 contenteditable
     叠加 -webkit-text-fill-color:transparent 时文字整块消失。 */
  body.deck-editing .cover h2 {
        -webkit-text-fill-color: var(--fs-text, #fff) !important;
        color: var(--fs-text, #fff) !important;
        background: none !important;
        background-clip: initial !important;
        -webkit-background-clip: initial !important; }
  /* v0.2.7 修 #2/#3:图片位在编辑态露上传/删除控件;痛点(d)/方案细节(f)一位多图。 */
  .deck-editing [data-edimg] { position:relative; }
  .deck-imgbar { position:absolute; z-index:30; left:8px; top:8px;
        display:flex; gap:6px; flex-wrap:wrap; }
  .deck-imgbtn { font-size:12px; line-height:1; padding:6px 9px; border-radius:8px;
        cursor:pointer; white-space:nowrap;
        background:rgba(0,0,0,.58); border:1px solid rgba(255,255,255,.34); color:#fff;
        font-family:system-ui,"Noto Sans SC","PingFang SC",sans-serif; }
  .deck-imgbtn:hover { border-color:#7BE0C6; box-shadow:0 0 0 3px rgba(123,224,198,.18); }
  .deck-multi { display:flex; flex-wrap:wrap; gap:12px; width:100%; height:100%;
        align-items:center; align-content:center; justify-content:center; overflow:auto; }
  .deck-multi .deck-thumb { position:relative; flex:0 1 auto;
        max-width:47%; max-height:47%; }
  .deck-multi .deck-thumb img { max-width:100%; max-height:100%; width:auto; height:auto;
        object-fit:contain; display:block; border-radius:12px;
        box-shadow:0 14px 32px -18px rgba(123,224,198,.35); }
  .deck-thumbdel { position:absolute; top:-8px; right:-8px; width:22px; height:22px;
        border-radius:50%; font-size:12px; line-height:1; cursor:pointer; padding:0;
        display:flex; align-items:center; justify-content:center;
        background:rgba(0,0,0,.7); border:1px solid rgba(255,255,255,.5); color:#fff; }
  .deck-thumbdel:hover { border-color:#7BE0C6; box-shadow:0 0 0 3px rgba(123,224,198,.18); }
  .deck-noteedit { display:none; }
  body.deck-editing .deck-noteedit {
        display:flex; flex-direction:column; position:fixed; right:20px; bottom:86px;
        width:330px; max-width:calc(100vw - 40px); z-index:60;
        background:rgba(18,20,26,.95); border:1px solid rgba(255,255,255,.16);
        border-radius:12px; box-shadow:0 18px 50px -20px rgba(0,0,0,.72); }
  .deck-noteedit-hd { display:flex; align-items:center; justify-content:space-between;
        gap:10px; padding:9px 12px; cursor:pointer; font-size:13px; line-height:1.2;
        color:rgba(255,255,255,.82); border-bottom:1px solid rgba(255,255,255,.1);
        user-select:none; }
  .deck-noteedit-hd b { color:#7BE0C6; font-variant-numeric:tabular-nums; }
  .deck-noteedit-caret { font-size:12px; color:rgba(255,255,255,.5); transition:transform .2s; }
  .deck-noteedit.is-collapsed .deck-noteedit-caret { transform:rotate(-90deg); }
  .deck-noteedit.is-collapsed .deck-noteedit-body { display:none; }
  .deck-noteedit-body { padding:10px 12px 12px; }
  .deck-noteedit-box { min-height:74px; max-height:168px; overflow:auto;
        font-size:13px; line-height:1.6; color:#fff; background:rgba(255,255,255,.05);
        border:1px solid rgba(255,255,255,.14); border-radius:8px; padding:8px 10px;
        outline:none; white-space:pre-wrap; word-break:break-word; }
  .deck-noteedit-box:focus { border-color:#7BE0C6; box-shadow:0 0 0 3px rgba(123,224,198,.18); }
  .deck-noteedit-box:empty:before { content:attr(data-ph); color:rgba(255,255,255,.4); }
  .deck-noteedit-hint { font-size:12px; color:rgba(255,255,255,.42); margin-top:7px; }
"""

_PRESENTER_CSS = """
  body.deck-projecting .deck-nav { opacity:0; pointer-events:none; }
  body.deck-projecting { cursor:none; }
  /* v0.2.11-r5: 真·全屏——投屏时舞台原生仍是 1000×562.5px,若只 requestFullscreen
     整页,幻灯片会缩在黑底正中的小方块里,并非铺满屏幕。这里把 body 铺满视口纯黑
     letterbox 居中,舞台去圆角/阴影,由 JS(fitProjector)按 min(vw/1000,vh/562.5)
     等比 scale 铺满。transform:scale 均匀缩放整棵舞台子树(含 e2 连线 SVG);连线坐标
     与 viewBox 同取自 getBoundingClientRect,对缩放同比、数学上不变 → 不错位、无需重绘。 */
  body.deck-projecting { padding:0; margin:0; background:#000; gap:0;
        width:100vw; height:100vh; min-height:100vh; overflow:hidden;
        justify-content:center; align-items:center; }
  body.deck-projecting .deck-stage { border-radius:0; box-shadow:none;
        transform-origin:center center; }
  .deck-presenter { display:none; }
  body.deck-speaker { padding:0; background:#0B0D12; display:block; }
  body.deck-speaker .deck-stage,
  body.deck-speaker .deck-nav { display:none !important; }
  body.deck-speaker .deck-presenter {
    display:flex; flex-direction:column; position:fixed; inset:0;
    padding:22px 26px 16px; gap:16px; color:rgba(255,255,255,.9); z-index:9000; }
  .deck-pv-main { flex:1 1 auto; display:flex; gap:22px; min-height:0; }
  .deck-pv-col { display:flex; flex-direction:column; min-width:0; min-height:0; }
  .deck-pv-col.deck-pv-left { flex:1.55 1 0; }
  .deck-pv-col.deck-pv-right { flex:1 1 0; }
  .deck-pv-label { font-size:13px; letter-spacing:.14em; text-transform:uppercase;
    color:rgba(255,255,255,.5); margin-bottom:8px; }
  .deck-pv-label b { color:#7BE0C6; font-variant-numeric:tabular-nums; }
  .deck-pv-stage { position:relative; flex:0 0 auto; overflow:hidden; border-radius:14px;
    background:#000; box-shadow:0 20px 60px -24px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.06); }
  .deck-pv-scale { position:absolute; top:0; left:0; transform-origin:top left; }
  .deck-pv-notes-wrap { flex:1 1 auto; display:flex; flex-direction:column;
    margin-top:14px; min-height:0; }
  .deck-pv-notes { flex:1 1 auto; overflow:auto; font-size:17px; line-height:1.7;
    color:rgba(255,255,255,.92); background:rgba(255,255,255,.05);
    border:1px solid rgba(255,255,255,.1); border-radius:12px; padding:14px 16px;
    white-space:pre-wrap; }
  .deck-pv-notes.is-empty { color:rgba(255,255,255,.4); font-style:italic; }
  .deck-pv-bar { flex:0 0 auto; display:flex; align-items:center; gap:16px; }
  .deck-pv-timer { font-size:26px; font-variant-numeric:tabular-nums; letter-spacing:.04em;
    color:#fff; margin-left:auto; }
"""

_DECK_JS = r"""<script>
(function(){
  var track=document.getElementById('deckTrack');
  if(!track)return;
  var frames=Array.prototype.slice.call(track.children);
  var dots=Array.prototype.slice.call(document.querySelectorAll('.deck-dot'));
  var prev=document.getElementById('deckPrev');
  var next=document.getElementById('deckNext');
  var count=document.getElementById('deckCount');
  var N=frames.length, cur=0;
  function pad(n){return (n<10?'0':'')+n;}
  function render(){
    track.style.transform='translateX(-'+frames[cur].offsetLeft+'px)';
    for(var i=0;i<dots.length;i++){dots[i].classList.toggle('is-active',i===cur);}
    if(prev)prev.disabled=(cur===0);
    if(next)next.disabled=(cur===N-1);
    if(count)count.textContent=pad(cur+1)+' / '+pad(N);
  }
  function go(i){if(i<0||i>=N||i===cur)return;cur=i;render();
    try{document.dispatchEvent(new CustomEvent('deck:nav',{detail:{idx:cur,total:N}}));}catch(e){}}
  if(prev)prev.addEventListener('click',function(){go(cur-1);});
  if(next)next.addEventListener('click',function(){go(cur+1);});
  for(var k=0;k<dots.length;k++){(function(idx){
    dots[idx].addEventListener('click',function(){go(idx);});})(k);}
  document.addEventListener('keydown',function(e){
    if(document.body.classList.contains('deck-editing'))return;
    if(e.key==='ArrowRight'||e.key==='PageDown'){go(cur+1);}
    else if(e.key==='ArrowLeft'||e.key==='PageUp'){go(cur-1);}
  });
  render();
  window.__deck={go:go,frames:frames,total:N,cur:function(){return cur;}};
  try{document.dispatchEvent(new CustomEvent('deck:ready',{detail:{idx:cur,total:N}}));}catch(e){}
})();
</script>"""

_EDIT_JS = r"""<script>
(function(){
  // v0.2.7 修 #2/#3:对齐 v9.8.9 图片位编辑契约。
  // 所有页面的图片位都支持上传/编辑/清空;痛点(.m-d/.m-d2)与方案细节(.m-f)一位多图(+加图/✕删除)。
  var IMG_SEL='.m-a .sketch .frame,.m-d .shot,.m-d2 .shot,.m-e .shot,.m-f .shots .shot';
  var MULTI_SEL='.m-d,.m-d2,.m-f';
  var body=document.body;
  var frames=Array.prototype.slice.call(document.querySelectorAll('.deck-frame'));
  if(!frames.length)return;
  var editBtn=document.getElementById('deckEdit');
  var exportBtn=document.getElementById('deckExport');
  var ORIG={};   // eid -> 原始 innerHTML(清空时复原)
  var IMGS={};   // eid -> [src,...] 当前图片列表
  var editing=false, saveTimer=null;
  function hash(s){var h=5381,i=s.length;while(i){h=(h*33)^s.charCodeAt(--i);}return (h>>>0).toString(36);}
  var deckId='deckedit:'+hash((document.title||'')+'|'+frames.length);
  function load(){try{var r=localStorage.getItem(deckId);return r?JSON.parse(r):null;}catch(e){return null;}}
  function collect(){
    var texts={};
    for(var i=0;i<frames.length;i++){
      var ts=frames[i].querySelectorAll('[data-edt]');
      for(var j=0;j<ts.length;j++){texts[ts[j].getAttribute('data-edt')]=ts[j].innerHTML;}
    }
    var notes={};
    for(var n=0;n<frames.length;n++){var rt=slideRoot(n);
      if(rt){var nv=rt.getAttribute('data-notes');if(nv!=null&&nv!=='')notes[n]=nv;}}
    return {v:1,texts:texts,notes:notes,imgs:IMGS};
  }
  function save(){try{localStorage.setItem(deckId,JSON.stringify(collect()));}catch(e){
    if(window.console)console.warn('[deck-edit] 保存失败(可能超 localStorage 配额):',e);}}
  function scheduleSave(){clearTimeout(saveTimer);saveTimer=setTimeout(save,400);}
  var noteEdit=document.getElementById('deckNoteEdit');
  var noteHd=document.getElementById('deckNoteHd');
  var noteBox=document.getElementById('deckNoteBox');
  var notePage=document.getElementById('deckNotePage');
  var noteBC=null; try{noteBC=new BroadcastChannel('deck-sync');}catch(e){noteBC=null;}
  function slideRoot(i){return frames[i]?frames[i].querySelector('.page,.cover-wrap,.cover'):null;}
  function curIdx(){return (window.__deck&&window.__deck.cur)?window.__deck.cur():0;}
  function pad2(n){return (n<10?'0':'')+n;}
  function noteLoadBox(){
    if(!noteBox)return;
    var i=curIdx(), rt=slideRoot(i);
    noteBox.textContent=rt?(rt.getAttribute('data-notes')||''):'';
    if(notePage)notePage.textContent=pad2(i+1);
  }
  function noteWriteBack(){
    if(!noteBox)return;
    var i=curIdx(), rt=slideRoot(i);if(!rt)return;
    var txt=noteBox.innerText.replace(/ /g,' ');
    if(txt&&txt.trim()!=='')rt.setAttribute('data-notes',txt);else rt.removeAttribute('data-notes');
    scheduleSave();
    if(noteBC){try{noteBC.postMessage({note:{idx:i,text:txt}});}catch(e){}}
  }
  if(noteBox)noteBox.addEventListener('input',function(){if(editing)noteWriteBack();});
  if(noteHd)noteHd.addEventListener('click',function(){
    if(noteEdit)noteEdit.classList.toggle('is-collapsed');});
  document.addEventListener('deck:nav',function(){if(editing)noteLoadBox();});
  function hasDirectText(el){
    var n=el.firstChild;
    while(n){if(n.nodeType===3&&n.nodeValue&&n.nodeValue.trim())return true;n=n.nextSibling;}
    return false;
  }
  // ---- 打标记:图片位先标(便于文字扫描跳过其子树)----
  frames.forEach(function(frame,fi){
    var slots=frame.querySelectorAll(IMG_SEL);
    for(var k=0;k<slots.length;k++){
      var s=slots[k], eid='i'+fi+'-'+k;
      s.setAttribute('data-edimg',eid);
      if(s.closest(MULTI_SEL))s.setAttribute('data-edmulti','1');
      ORIG[eid]=s.innerHTML;
    }
    var all=frame.querySelectorAll('*'), c=0;
    for(var a=0;a<all.length;a++){
      var el=all[a], cn=(typeof el.className==='string')?el.className:'';
      if(cn.indexOf('deck-')===0)continue;
      if(el.closest('[data-edimg]'))continue;
      if(el.closest('.num'))continue;
      if(!hasDirectText(el))continue;
      if(el.parentElement&&el.parentElement.closest('[data-edt]'))continue;
      el.setAttribute('data-edt','t'+fi+'-'+(c++));
    }
  });
  function imgTag(src){return '<img src="'+src+'" alt="">';}
  function renderSlot(slot){
    var eid=slot.getAttribute('data-edimg'), list=IMGS[eid];
    if(!list)return;
    if(!list.length){slot.innerHTML=ORIG[eid];return;}
    if(slot.getAttribute('data-edmulti')&&list.length>1){
      var h='<div class="deck-multi">';
      for(var i=0;i<list.length;i++){h+='<span class="deck-thumb">'+imgTag(list[i])+'</span>';}
      slot.innerHTML=h+'</div>';
    }else{slot.innerHTML=imgTag(list[0]);}
  }
  function seed(slot){
    var eid=slot.getAttribute('data-edimg');
    if(IMGS[eid])return IMGS[eid];
    var imgs=slot.querySelectorAll('img'), l=[];
    for(var i=0;i<imgs.length;i++)l.push(imgs[i].src);
    IMGS[eid]=l;return l;
  }
  function pickFiles(multi,cb){
    var inp=document.createElement('input');
    inp.type='file';inp.accept='image/*';if(multi)inp.multiple=true;inp.style.display='none';
    body.appendChild(inp);
    inp.addEventListener('change',function(){
      var fs=inp.files;if(!fs||!fs.length){body.removeChild(inp);return;}
      var arr=[],done=0;
      for(var i=0;i<fs.length;i++){(function(idx){
        var rd=new FileReader();
        rd.onload=function(e){arr[idx]=e.target.result;if(++done===fs.length){cb(arr);body.removeChild(inp);}};
        rd.readAsDataURL(fs[i]);
      })(i);}
    });
    inp.click();
  }
  function hasBar(slot){
    var kids=slot.children;
    for(var i=0;i<kids.length;i++){var c=''+(kids[i].className||'');if(c.indexOf('deck-imgbar')>=0)return true;}
    return false;
  }
  function addThumbDel(slot){
    var eid=slot.getAttribute('data-edimg');
    var thumbs=slot.querySelectorAll('.deck-thumb');
    for(var i=0;i<thumbs.length;i++){(function(th,idx){
      if(th.querySelector('.deck-thumbdel'))return;
      var x=document.createElement('button');x.type='button';x.className='deck-thumbdel';x.textContent='✕';
      x.addEventListener('click',function(ev){ev.stopPropagation();ev.preventDefault();
        var l=IMGS[eid]||seed(slot);l.splice(idx,1);IMGS[eid]=l;
        renderSlot(slot);addChrome(slot);save();});
      th.appendChild(x);
    })(thumbs[i],i);}
  }
  function addChrome(slot){
    if(!editing)return;
    if(hasBar(slot)){addThumbDel(slot);return;}
    var multi=!!slot.getAttribute('data-edmulti'), eid=slot.getAttribute('data-edimg');
    var bar=document.createElement('div');bar.className='deck-imgbar';
    var add=document.createElement('button');add.type='button';add.className='deck-imgbtn';
    add.textContent=multi?'＋ 加图':'⬆ 上传';
    add.addEventListener('click',function(ev){ev.stopPropagation();ev.preventDefault();
      pickFiles(multi,function(uris){
        var l=seed(slot);
        IMGS[eid]=multi?l.concat(uris):[uris[0]];
        renderSlot(slot);addChrome(slot);save();});
    });
    bar.appendChild(add);
    var del=document.createElement('button');del.type='button';del.className='deck-imgbtn';
    del.textContent=multi?'✕ 清空':'✕ 删除';
    del.addEventListener('click',function(ev){ev.stopPropagation();ev.preventDefault();
      IMGS[eid]=[];renderSlot(slot);addChrome(slot);save();});
    bar.appendChild(del);
    slot.appendChild(bar);
    addThumbDel(slot);
  }
  function removeChrome(){
    var junk=document.querySelectorAll('.deck-imgbar,.deck-thumbdel');
    for(var i=0;i<junk.length;i++){if(junk[i].parentNode)junk[i].parentNode.removeChild(junk[i]);}
  }
  function setEditing(on){
    editing=on;
    body.classList.toggle('deck-editing',on);
    if(editBtn){editBtn.classList.toggle('is-on',on);
      editBtn.setAttribute('aria-pressed',on?'true':'false');
      editBtn.textContent=on?'✓ 退出编辑':'✎ 编辑模式';}
    var ts=document.querySelectorAll('[data-edt]');
    for(var i=0;i<ts.length;i++){if(on)ts[i].setAttribute('contenteditable','true');else ts[i].removeAttribute('contenteditable');}
    var slots=document.querySelectorAll('[data-edimg]');
    if(on){for(var j=0;j<slots.length;j++)addChrome(slots[j]);}else{removeChrome();}
    if(noteBox){
      if(on){noteBox.setAttribute('contenteditable','true');noteLoadBox();}
      else{noteBox.removeAttribute('contenteditable');}
    }
  }
  if(editBtn)editBtn.addEventListener('click',function(){setEditing(!editing);});
  document.addEventListener('input',function(e){
    if(!editing)return;
    if(e.target&&e.target.closest&&e.target.closest('[data-edt]'))scheduleSave();
  });
  (function(){
    var st=load();if(!st)return;
    if(st.texts){for(var i=0;i<frames.length;i++){var ts=frames[i].querySelectorAll('[data-edt]');
      for(var j=0;j<ts.length;j++){var id=ts[j].getAttribute('data-edt');
        if(Object.prototype.hasOwnProperty.call(st.texts,id))ts[j].innerHTML=st.texts[id];}}}
    if(st.notes){for(var m=0;m<frames.length;m++){if(!Object.prototype.hasOwnProperty.call(st.notes,m))continue;
      var rt=slideRoot(m);if(!rt)continue;var nv=st.notes[m];
      if(nv&&(''+nv).trim()!=='')rt.setAttribute('data-notes',nv);else rt.removeAttribute('data-notes');}}
    if(st.imgs){for(var k in st.imgs){if(!Object.prototype.hasOwnProperty.call(st.imgs,k))continue;
      IMGS[k]=st.imgs[k];var slot=document.querySelector('[data-edimg="'+k+'"]');if(slot)renderSlot(slot);}}
  })();
  if(exportBtn)exportBtn.addEventListener('click',function(){
    var was=editing;if(was)setEditing(false);
    var clone=document.documentElement.cloneNode(true);
    var eds=clone.querySelectorAll('[contenteditable]');
    for(var i=0;i<eds.length;i++)eds[i].removeAttribute('contenteditable');
    var htmlStr='<!doctype html>\n'+clone.outerHTML;
    var blob=new Blob([htmlStr],{type:'text/html;charset=utf-8'});
    var a=document.createElement('a');a.href=URL.createObjectURL(blob);
    a.download=(document.title||'deck').replace(/[\\/:*?"<>|]+/g,'_').slice(0,80)+'.html';
    body.appendChild(a);a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);if(a.parentNode)body.removeChild(a);},0);
    if(was)setEditing(true);
  });
})();
</script>"""

_PRESENTER_JS = r"""<script>
(function(){
  var qs=new URLSearchParams(location.search);
  var role=qs.get('present')||(location.hash.match(/present=(\w+)/)||[])[1]||'';
  var CH='deck-sync';
  var bc=null; try{bc=new BroadcastChannel(CH);}catch(e){bc=null;}
  var suppress=false;
  function post(idx){
    if(bc){try{bc.postMessage({idx:idx});}catch(e){}}
    else{try{localStorage.setItem('deck-sync-idx',idx+':'+Date.now());}catch(e){}}
  }
  function onRemote(idx){
    if(!window.__deck)return; if(idx===window.__deck.cur())return;
    suppress=true; window.__deck.go(idx); suppress=false;
  }
  function onRemoteNote(nd){
    if(!nd||typeof nd.idx!=='number'||!window.__deck)return;
    var f=window.__deck.frames[nd.idx];if(f){var r=f.querySelector('.page,.cover-wrap,.cover');
      if(r){if(nd.text&&(''+nd.text).trim()!=='')r.setAttribute('data-notes',nd.text);
        else r.removeAttribute('data-notes');}}
    try{document.dispatchEvent(new CustomEvent('deck:noteupdate',{detail:nd}));}catch(e){}
  }
  if(bc){bc.onmessage=function(ev){if(!ev.data)return;
    if(typeof ev.data.idx==='number')onRemote(ev.data.idx);
    if(ev.data.note)onRemoteNote(ev.data.note);};}
  else{window.addEventListener('storage',function(e){
    if(e.key==='deck-sync-idx'&&e.newValue){onRemote(parseInt(e.newValue,10));}});}
  document.addEventListener('deck:nav',function(e){if(!suppress)post(e.detail.idx);});
  function enterFullscreen(){var el=document.documentElement;
    var fn=el.requestFullscreen||el.webkitRequestFullscreen||el.mozRequestFullScreen;
    if(!fn)return;
    try{var pr=fn.call(el);if(pr&&pr.catch){pr.catch(function(){});}}catch(e){}}
  // v0.2.11-r5: 把舞台按 16:9 等比铺满视口(letterbox 居中),让投屏成为真·全屏。
  //   舞台原生 1000×562.5px;k=min(vw/1000,vh/562.5) 取能放进视口的最大等比系数,
  //   scale(k) 后短边贴边、长边居中留黑边。transform 只缩放不改布局,e2 连线 SVG 随之
  //   同比缩放且坐标不变(见 CSS 注释),故无需重绘。off=true 时清除 transform 复位。
  function fitProjector(off){
    var st=document.querySelector('.deck-stage');
    if(!st)return;
    if(off){st.style.transform='';return;}
    var vw=window.innerWidth||document.documentElement.clientWidth;
    var vh=window.innerHeight||document.documentElement.clientHeight;
    var bw=st.offsetWidth||1000, bh=st.offsetHeight||(1000*0.5625);
    var k=Math.min(vw/bw, vh/bh);
    if(!isFinite(k)||k<=0)return;
    st.style.transform='scale('+k+')';
  }
  if(role==='projector'){
    document.body.classList.add('deck-projecting');
    fitProjector();
    document.addEventListener('click',function(){enterFullscreen();fitProjector();},{once:true});
    window.addEventListener('resize',function(){
      if(document.body.classList.contains('deck-projecting'))fitProjector();
    });
  }
  function buildSpeaker(){
    document.body.classList.add('deck-speaker');
    var frames=(window.__deck&&window.__deck.frames)||[];
    var total=(window.__deck&&window.__deck.total)||frames.length;
    var curStage=document.getElementById('pvCurStage');
    var nextStage=document.getElementById('pvNextStage');
    var notesEl=document.getElementById('pvNotes');
    var countEl=document.getElementById('pvCount');
    function notesOf(i){var f=frames[i];if(!f)return '';
      var n=f.querySelector('[data-notes]');return n?n.getAttribute('data-notes'):'';}
    function fillStage(stage,i){
      stage.innerHTML='';
      if(i<0||i>=frames.length){return;}
      var clone=frames[i].cloneNode(true);
      var wrap=document.createElement('div');wrap.className='deck-pv-scale';
      wrap.appendChild(clone);stage.appendChild(wrap);
      var sw=stage.clientWidth||stage.getBoundingClientRect().width;
      var fw=frames[i].getBoundingClientRect().width||1000;
      var k=sw/fw;
      wrap.style.transform='scale('+k+')';
      stage.style.height=(fw*0.5625*k)+'px';
    }
    function paint(){
      var i=window.__deck?window.__deck.cur():0;
      fillStage(curStage,i);
      fillStage(nextStage,i+1);
      var nt=notesOf(i);
      if(nt){notesEl.textContent=nt;notesEl.classList.remove('is-empty');}
      else{notesEl.textContent='（本页无备注）';notesEl.classList.add('is-empty');}
      var pad=function(n){return (n<10?'0':'')+n;};
      countEl.textContent=pad(i+1)+' / '+pad(total);
    }
    document.addEventListener('deck:nav',paint);
    window.addEventListener('resize',paint);
    document.addEventListener('deck:noteupdate',function(e){
      if(e.detail&&e.detail.idx===(window.__deck?window.__deck.cur():0)){
        var nt=notesOf(e.detail.idx);
        if(nt){notesEl.textContent=nt;notesEl.classList.remove('is-empty');}
        else{notesEl.textContent='（本页无备注）';notesEl.classList.add('is-empty');}
      }});
    var t0=Date.now();
    function fmt(ms){var s=Math.floor(ms/1000);
      return ('0'+Math.floor(s/3600)).slice(-2)+':'+('0'+Math.floor(s%3600/60)).slice(-2)+':'+('0'+(s%60)).slice(-2);}
    if(window.__pvTimer){clearInterval(window.__pvTimer);}
    window.__pvTimer=setInterval(function(){var el=document.getElementById('pvTimer');if(el)el.textContent=fmt(Date.now()-t0);},250);
    var rst=document.getElementById('pvReset');if(rst)rst.addEventListener('click',function(){t0=Date.now();});
    var pp=document.getElementById('pvPrev'),pn=document.getElementById('pvNext');
    if(pp)pp.addEventListener('click',function(){if(window.__deck)window.__deck.go(window.__deck.cur()-1);});
    if(pn)pn.addEventListener('click',function(){if(window.__deck)window.__deck.go(window.__deck.cur()+1);});
    paint();
    post(window.__deck?window.__deck.cur():0);
  }
  if(role==='speaker'){
    if(window.__deck)buildSpeaker();
    else document.addEventListener('deck:ready',buildSpeaker,{once:true});
  }
  function speakerInPlace(on){
    if(on){
      document.body.classList.add('deck-speaker');
      if(window.__deck){ buildSpeaker(); }
      else{ document.addEventListener('deck:ready',buildSpeaker,{once:true}); }
    }else{
      document.body.classList.remove('deck-speaker');
      document.body.classList.remove('deck-projecting');
      fitProjector(true);
      var stages=['pvCurStage','pvNextStage'];
      for(var i=0;i<stages.length;i++){
        var el=document.getElementById(stages[i]);
        if(el){ while(el.firstChild) el.removeChild(el.firstChild); }
      }
      try{ if(window.__pvTimer){ clearInterval(window.__pvTimer); window.__pvTimer=null; } }catch(e){}
    }
  }
  function launchProjector(){
    document.body.classList.add('deck-projecting');
    // v0.2.11-r7: 修 Shift+P「有概率不进全屏」的焦点竞态。旧顺序先 enterFullscreen() 再
    //   window.open(),弹出的 speaker 窗口在 requestFullscreen Promise 未 settle 时抢走
    //   焦点,浏览器中止「pending 且已失焦」的全屏请求 → 概率性失败。修法:先开 speaker
    //   窗口 → 立刻 blur 它并 window.focus() 抢回投屏窗口 → 下一帧焦点回来后再请求全屏。
    fitProjector();
    var u=location.href.split('#')[0];
    u+= (u.indexOf('?')>=0?'&':'?')+'present=speaker';
    var w=window.open(u,'deckSpeaker','width=1280,height=800');
    if(!w){
      try{alert('演讲者窗口被浏览器弹窗拦截。已回退到「单窗口就地演讲者模式」。\n如需双屏,请允许本站弹出窗口后按 Shift+P 重试。');}catch(e){}
      document.body.classList.remove('deck-projecting');
      fitProjector(true);
      try{document.exitFullscreen&&document.exitFullscreen();}catch(e){}
      speakerInPlace(true);
      return;
    }
    try{w.blur();}catch(e){}
    try{window.focus();}catch(e){}
    requestAnimationFrame(function(){
      try{window.focus();}catch(e){}
      enterFullscreen();
      fitProjector();
    });
    setTimeout(function(){post(window.__deck?window.__deck.cur():0);},400);
  }
  function launch(dualWindow){
    if(role)return;
    if(document.body.classList.contains('deck-speaker')||
       document.body.classList.contains('deck-projecting')){
      speakerInPlace(false);
      try{document.exitFullscreen&&document.exitFullscreen();}catch(e){}
      return;
    }
    if(dualWindow){ launchProjector(); }
    else         { speakerInPlace(true); }
  }
  document.addEventListener('keydown',function(e){
    if(document.body.classList.contains('deck-editing'))return;
    if(role)return;
    if(e.key==='Escape'){
      if(document.body.classList.contains('deck-speaker')||
         document.body.classList.contains('deck-projecting')){
        speakerInPlace(false);
        try{document.exitFullscreen&&document.exitFullscreen();}catch(e){}
        e.preventDefault();
      }
      return;
    }
    if(e.key==='s'||e.key==='S'||e.key==='p'||e.key==='P'){
      launch(!!e.shiftKey);
    }
  });
  document.addEventListener('fullscreenchange',function(){
    if(document.fullscreenElement){
      if(document.body.classList.contains('deck-projecting'))fitProjector();
    }else{
      document.body.classList.remove('deck-projecting');
      fitProjector(true);
    }
  });
  var btn=document.getElementById('deckPresent');
  if(btn){
    btn.title='演讲者模式(S/P 就地;Shift+S/P 双窗口投屏;再按或 Esc 退出)';
    btn.addEventListener('click',function(ev){
      if(document.body.classList.contains('deck-editing'))return;
      launch(!!ev.shiftKey);
    });
  }
})();
</script>"""


def _extract_body(html):
    m = re.search(r"<body[^>]*>(.+?)</body>", html, re.S)
    return m.group(1) if m else html


def _extract_native_w(html, default=CONTENT_NATIVE_W):
    """从页 HTML 抓 native 宽:优先 <meta name=deck-native-w>,其次 body[data-native-w]。"""
    m = re.search(r'<meta\s+name=["\']deck-native-w["\']\s+content=["\'](\d+(?:\.\d+)?)["\']', html)
    if not m:
        m = re.search(r'<body[^>]*data-native-w=["\'](\d+(?:\.\d+)?)["\']', html)
    return float(m.group(1)) if m else default


def _extract_body_class(html):
    m = re.search(r'<body[^>]*class=["\']([^"\']+)["\']', html)
    return m.group(1) if m else ""


def _extract_head_style(html):
    """收集 <style>…</style> 与 <link rel=stylesheet …/>,合并成一段 CSS 供整卷共享。"""
    styles = "\n".join(m.group(1) for m in re.finditer(r"<style[^>]*>(.+?)</style>", html, re.S))
    links = "\n".join(m.group(0) for m in re.finditer(r'<link\s[^>]*rel=["\']stylesheet["\'][^>]*/?>', html))
    return styles, links


def _frame_wrap(body, native_w, body_class=""):
    """把一页原生 (native_w × native_w*ASPECT) 内容等比缩放到 DISPLAY_W。
    body_class 会作为 .deck-scale 的额外类(如 m-light / m-dark),让页 CSS 生效。"""
    scale = DISPLAY_W / native_w
    nh = native_w * ASPECT
    cls = ("deck-scale " + body_class).strip()
    return (
        f'<div class="deck-frame" style="width:{DISPLAY_W:.2f}px;height:{DISPLAY_W*ASPECT:.2f}px">'
        f'<div class="{cls}" style="width:{native_w:.2f}px;height:{nh:.2f}px;transform:scale({scale:.5f})">'
        f'{body}</div></div>'
    )


def cmd_compose(args):
    if not args.pages:
        print("❌ 无输入页", file=sys.stderr); sys.exit(1)
    PC = _pc()

    parts = [read_text(p) for p in args.pages]
    all_styles = []
    all_links = []
    frames_data = []  # list of (body, native_w, body_class)
    title_first = ""
    for html in parts:
        s, lk = _extract_head_style(html)
        if s: all_styles.append(s)
        if lk: all_links.append(lk)
        native_w = _extract_native_w(html)
        body_class = _extract_body_class(html)
        frames_data.append((_extract_body(html), native_w, body_class))
        if not title_first:
            tm = re.search(r"<title[^>]*>(.+?)</title>", html, re.S)
            if tm: title_first = tm.group(1).strip()

    total = len(frames_data)
    stage_h = DISPLAY_W * ASPECT
    track_w = DISPLAY_W * total

    # v0.2.11-r1:从各页 body_class 推断整卷模式,挂到 shell <html data-theme> 上,
    #   作为「全局单模声明」——assets/verify-single-mode.py 的 global_mode() 会优先读它,
    #   使成卷 shell 的单模判定与逐步验收一致(此前 shell 无任何模式标记,gmode=None)。
    _shell_modes = set()
    for _b, _nw, _cls in frames_data:
        mm = re.search(r'\bm-(light|dark)\b', _cls or "")
        if mm:
            _shell_modes.add(mm.group(1))
    shell_mode = next(iter(_shell_modes)) if len(_shell_modes) == 1 else "light"

    frames = "\n".join(_frame_wrap(b, nw, cls) for (b, nw, cls) in frames_data)

    dots = "".join(
        f'<button class="deck-dot" type="button" aria-label="第 {i+1} 页"></button>'
        for i in range(total)
    )
    nav = (
        '<nav class="deck-nav" aria-label="幻灯片导航">'
        '<button class="deck-arrow" id="deckPrev" type="button" aria-label="上一页">‹</button>'
        f'<div class="deck-dots">{dots}</div>'
        '<button class="deck-arrow" id="deckNext" type="button" aria-label="下一页">›</button>'
        f'<div class="deck-count" id="deckCount">01 / {total:02d}</div>'
        '<button class="deck-tool deck-edit" id="deckEdit" type="button" '
        'aria-pressed="false">✎ 编辑模式</button>'
        '<button class="deck-tool deck-export" id="deckExport" type="button">⬇ 导出 HTML</button>'
        '<button class="deck-tool deck-present" id="deckPresent" type="button" '
        'title="演讲者模式:S/P 单窗口就地;Shift+S/P 双屏投屏;再按或 Esc 退出">🖥 演讲者模式</button>'
        '</nav>'
    )

    presenter = (
        '<div class="deck-presenter" id="deckPresenter" aria-hidden="true">'
        '<div class="deck-pv-main">'
        '<div class="deck-pv-col deck-pv-left">'
        '<div class="deck-pv-label">当前页 · <b id="pvCount">— / —</b></div>'
        '<div class="deck-pv-stage" id="pvCurStage"></div>'
        '</div>'
        '<div class="deck-pv-col deck-pv-right">'
        '<div class="deck-pv-label">下一页预览</div>'
        '<div class="deck-pv-stage" id="pvNextStage"></div>'
        '<div class="deck-pv-notes-wrap">'
        '<div class="deck-pv-label">本页备注</div>'
        '<div class="deck-pv-notes is-empty" id="pvNotes">（本页无备注）</div>'
        '</div>'
        '</div>'
        '</div>'
        '<div class="deck-pv-bar">'
        '<button class="deck-tool" id="pvPrev" type="button">‹ 上一页</button>'
        '<button class="deck-tool" id="pvNext" type="button">下一页 ›</button>'
        '<button class="deck-tool" id="pvReset" type="button">重置计时</button>'
        '<div class="deck-pv-timer" id="pvTimer">00:00:00</div>'
        '</div>'
        '</div>'
    )

    noteedit = (
        '<div class="deck-noteedit is-collapsed" id="deckNoteEdit" aria-hidden="true">'
        '<div class="deck-noteedit-hd" id="deckNoteHd">'
        '<span>📝 本页备注 · 第 <b id="deckNotePage">01</b> 页</span>'
        '<span class="deck-noteedit-caret">▾</span>'
        '</div>'
        '<div class="deck-noteedit-body">'
        '<div class="deck-noteedit-box" id="deckNoteBox" contenteditable="false" '
        'data-ph="在此输入/修改本页演讲者备注…"></div>'
        '<div class="deck-noteedit-hint">改动实时写回本页 data-notes、存本地并同步演讲者窗口;'
        '随「⬇ 导出 HTML」一并固化。</div>'
        '</div>'
        '</div>'
    )

    stage = (
        f'<div class="deck-stage" style="width:{DISPLAY_W:.0f}px;height:{stage_h:.2f}px">'
        f'<div class="deck-track" id="deckTrack" style="width:{track_w:.0f}px">'
        f'{frames}</div></div>'
    )

    merged_page_styles = "\n".join(all_styles)
    merged_links = "\n".join(all_links)
    title_out = title_first or "deck"
    _REPLAY_ANIM_JS = PC.REPLAY_ANIM_JS

    doc = f'''<!doctype html>
<html lang="zh-CN" data-theme="{shell_mode}"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title_out} · deck</title>
{merged_links}
<style>
{merged_page_styles}
{_SHELL_CSS}
{_EDIT_CSS}
{_PRESENTER_CSS}
</style>
</head>
<body>
{stage}
{nav}
{presenter}
{noteedit}
{_DECK_JS}
{_EDIT_JS}
{_PRESENTER_JS}
{_REPLAY_ANIM_JS}
</body></html>'''
    write_text(args.out, doc)
    print(f"✅ deck 已拼装(三模式 HTML shell): {args.out} ({total} 页)")
    print(f"   · 水平胶片带(可见的从左到右)  ✓")
    print(f"   · 编辑模式 / 演讲者模式 / 投屏模式  ✓")
    print(f"   · 备注编辑 + localStorage + 导出 HTML  ✓")

# ---------------- speech-plan 骨架 ----------------

def cmd_speech_plan(args):
    # per_page_notes 的键(01/02/…)自动根据整卷 HTML 里的实际页数生成,
    # 避免硬编码 3 页;若未指定 --deck,退回 --pages 数值或默认 3。
    n_pages = args.pages
    if args.deck and Path(args.deck).exists():
        html = read_text(args.deck)
        # 统计 slide 根节点:.page 与 .cover-wrap
        n_pages = len(re.findall(
            r'<div class="[^"]*\b(?:page|cover-wrap)\b[^"]*"', html))
        if n_pages == 0:
            print(f"⚠️ 未从 {args.deck} 抓到任何 slide 根节点,退回 --pages={args.pages}",
                  file=sys.stderr)
            n_pages = args.pages
    n_pages = max(1, n_pages)
    per_page = {f"{i+1:02d}": "" for i in range(n_pages)}

    plan_deck = {
        "deck_title": args.deck_title,
        "company_name": args.company_name,
        "duration": args.duration,
        "role": args.role,
        "structure": args.structure,
        "text": "",
        "per_page_notes": per_page,
        "titles": [],
        "qna": [],
        "segments": [],
    }
    write_json(args.out, plan_deck)
    print(f"✅ speech-plan 骨架已生成: {args.out} (页数={n_pages})")
    print("下一步:SKILL.md 编排填 per_page_notes / segments / titles / qna,每段 ≥80 字。")

# ---------------- inject-notes:把 per_page_notes 写回 HTML data-notes ----------------

def cmd_inject_notes(args):
    deck_html = read_text(args.deck)
    speech = read_json(args.speech)
    notes = speech.get("per_page_notes", {})
    # 定位每个 slide 根节点(.page 或 .cover-wrap),按 DOM 顺序注入。
    # 依赖各页在 render 时已预打 data-notes=""(见 _stamp_empty_data_notes / cmd_cover)。
    pat = re.compile(
        r'(<div class="[^"]*\b(?:page|cover-wrap)\b[^"]*"[^>]*data-notes=")([^"]*)(")'
    )
    matches = list(pat.finditer(deck_html))
    if not matches:
        print("❌ 找不到 data-notes 锚点(cover-wrap / page 都无预打属性?)", file=sys.stderr); sys.exit(1)

    # 按 key 排序:"01","02","03",…
    keys = sorted(notes.keys())
    if len(matches) != len(keys):
        # v0.2.11-r1:页数错配是真实的编排错误(某些页备注会被静默丢弃,
        #   演讲者面板缺备注),必须以非零退出,不再"按位对齐取小"糊过去。
        print(f"❌ 页数不匹配: HTML {len(matches)} 页(cover+page)vs "
              f"per_page_notes {len(keys)} 条。请让 speech-plan 的 per_page_notes "
              f"键数与整卷页数严格一致后重跑。", file=sys.stderr)
        sys.exit(1)

    out = deck_html; offset = 0
    written = 0
    for i, m in enumerate(matches):
        if i >= len(keys): break
        note = notes[keys[i]].replace('"', '&quot;').replace('\n', ' ')
        start = m.start() + offset
        end = m.end() + offset
        replacement = m.group(1) + note + m.group(3)
        out = out[:start] + replacement + out[end:]
        offset += len(replacement) - (end - start)
        written += 1

    write_text(args.deck, out)
    sidecar = {"pages": [{"index": keys[i], "notes": notes[keys[i]],
                          "length": len(notes[keys[i]])} for i in range(written)]}
    write_json(args.deck.replace(".html", ".notes.json"), sidecar)
    print(f"✅ 已注入 {written} 页备注,sidecar: {args.deck.replace('.html','.notes.json')}")

# ---------------- record-speech-doc ----------------

def cmd_record_speech_doc(args):
    sidecar = {
        "lark_doc_url": args.lark_url,
        "title": args.title,
        "deck_file": args.deck,
    }
    out = args.deck.replace(".html", ".speech.json")
    write_json(out, sidecar)
    print(f"✅ 演讲稿 sidecar 已记录: {out}")

# ---------------- main ----------------

def main():
    ap = argparse.ArgumentParser(description="doubao-html-deck-generator 主渲染脚本")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("theme"); p.add_argument("--primary", required=True); p.add_argument("--company-logo", default=""); p.add_argument("--out-dir", required=True); p.set_defaults(func=cmd_theme)

    p = sub.add_parser("extract-plan"); p.add_argument("--source", required=True); p.add_argument("--out", required=True); p.set_defaults(func=cmd_extract_plan)

    p = sub.add_parser("cover"); p.add_argument("--state", required=True); p.add_argument("--plan", required=True); p.add_argument("--out", required=True); p.set_defaults(func=cmd_cover)

    p = sub.add_parser("team"); p.add_argument("--state", required=True); p.add_argument("--plan", required=True); p.add_argument("--avatars", default=""); p.add_argument("--out", required=True); p.add_argument("--page-no", type=int, default=2); p.add_argument("--total", type=int, default=3); p.set_defaults(func=cmd_team)

    p = sub.add_parser("close"); p.add_argument("--state", required=True); p.add_argument("--plan", required=True); p.add_argument("--out", required=True); p.add_argument("--page-no", type=int, default=3); p.add_argument("--total", type=int, default=3); p.set_defaults(func=cmd_close)

    p = sub.add_parser("compose"); p.add_argument("--pages", nargs="+", required=True); p.add_argument("--out", required=True); p.set_defaults(func=cmd_compose)

    p = sub.add_parser("speech-plan"); p.add_argument("--deck", default="",
        help="整卷 deck.html 路径;若给了,per_page_notes 键按实际页数自动生成"); \
        p.add_argument("--duration", type=int, default=3); p.add_argument("--role", default="汇报人"); \
        p.add_argument("--structure", default="story"); p.add_argument("--company-name", required=True); \
        p.add_argument("--deck-title", required=True); p.add_argument("--pages", type=int, default=3,
        help="页数兜底值;仅当 --deck 未指定或无效时生效"); \
        p.add_argument("--out", required=True); p.set_defaults(func=cmd_speech_plan)

    p = sub.add_parser("inject-notes"); p.add_argument("deck"); p.add_argument("speech"); p.set_defaults(func=cmd_inject_notes)

    p = sub.add_parser("record-speech-doc"); p.add_argument("--deck", required=True); p.add_argument("--lark-url", required=True); p.add_argument("--title", required=True); p.set_defaults(func=cmd_record_speech_doc)

    p = sub.add_parser("page"); p.add_argument("--state", required=True); p.add_argument("--plan", required=True); p.add_argument("--mod", required=True, choices=sorted(_ALLOWED_MODS)); p.add_argument("--module-json", default=""); p.add_argument("--out", required=True); p.add_argument("--page-no", type=int, default=1); p.add_argument("--total", type=int, default=1); p.set_defaults(func=cmd_page)

    p = sub.add_parser("build-all"); p.add_argument("--state", required=True); p.add_argument("--plan", required=True); p.add_argument("--avatars", default=""); p.add_argument("--out-dir", required=True); p.add_argument("--extra", action="append", default=[], help="中间模块,格式 mod=module.json,可多次;顺序即出片顺序"); p.add_argument("--accept", action="store_true", help="调 accept_deck.py 跑最终验收"); p.set_defaults(func=cmd_build_all)

    args = ap.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
