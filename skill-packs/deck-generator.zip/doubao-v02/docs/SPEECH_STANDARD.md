# 演讲稿标准(v0.1)

## 飞书文档标题(硬闸)

**严格套模板**:

```
{企业名}效率先锋演讲稿 - {演讲标题}
```

- `{企业名}` 读自 `deck_state.json.step1.company_name`
- `{演讲标题}` 读自 `plan.json.deck_title`

**示例**:
- `ACME效率先锋演讲稿 - 智能客服系统升级方案`
- `字节跳动效率先锋演讲稿 - AI 编码助手落地实践`

## 每页备注(data-notes)标准

- **形态**:一段完整的口语化演讲稿正文,**不是要点列表**,不是提纲。
- **字数**:每页 ≥ 80 字(硬闸)。
- **数字回声**:页面出现的大数字(如"效率提升 3 倍""覆盖 50% 团队")必须在备注中原样复述——演讲者面板照念时不会漏掉关键数字。
- **禁术语**:RAG / embedding / prompt / vector / LLM / token / fine-tune / 向量数据库 / 提示词工程。
- **禁占位符**:`[待生成]` `[待填]` `TODO` `TBD`。
- **风格**:第一人称"我们",场景化描述,面向业务听众。

## 飞书演讲稿文档三段结构

1. **演讲全文**(`speech_plan.segments[*].text` 拼接) — 3 分钟连贯讲稿,分自然段。
2. **关键话术**(`speech_plan.titles`) — 每页的转场句 / 亮点句,便于随手查看。
3. **Q&A 预案**(`speech_plan.qna`) — 3-5 个可能被追问的问题 + 建议回答。

## 交付前硬闸

`accept_deck.py` 会检查:
- `deck.notes.json` 存在(inject-notes 已跑)
- `deck.speech.json` 存在且 `lark_doc_url` 非空
- `verify_speaker_notes.py --rounds 3` 6 闸全过

任一失败:整卷验收阻断,不允许交付。
