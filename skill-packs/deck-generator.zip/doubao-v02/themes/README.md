---
name: current-example
description: 示例主题(占位) — 真实主题由 `render_page.py theme` 从 Logo 主色派生生成。
---

# 示例主题目录

`themes/current/` 是运行时目录,由 `python3 scripts/render_page.py theme --primary #XXXXXX --company-logo <path> --out-dir themes/current` 自动创建填充:

- `palette.json` — 4 阶 OKLCH 配色 + light/dark 双 token
- `swatch.svg` / `swatch.png` — 色板图
- `cover_light.svg` / `cover_light.png` — 浅色封面样张
- `cover_dark.svg` / `cover_dark.png` — 深色封面样张

**不要手动编辑这里的文件**;它们每次运行都会被覆盖。
