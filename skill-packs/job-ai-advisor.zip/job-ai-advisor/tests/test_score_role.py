from __future__ import annotations

import importlib.util
import unittest
from copy import deepcopy
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("score_role", ROOT / "scripts" / "score_role.py")
score_role = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(score_role)


def rated_step(
    *,
    name: str = "整理数据",
    share: float | None = 100,
    human: float | None = 1,
    risk: float | None = 1,
    readiness_value: float = 5,
    work_fact: str = "recent_example",
    ai_capability: str = "current_source",
) -> dict:
    return {
        "name": name,
        "step_share_pct": share,
        "current_ai_usage_pct": 0,
        "capability": {
            "digital_io": 5,
            "instruction_clarity": 5,
            "output_verifiability": 5,
            "model_tool_fit": 5,
            "context_independence": 5,
        },
        "readiness": {
            "data_access": readiness_value,
            "tool_access": readiness_value,
            "process_stability": readiness_value,
            "privacy_safety": readiness_value,
            "adoption_support": readiness_value,
        },
        "human_centrality": human,
        "risk_level": risk,
        "evidence": {
            "work_fact": work_fact,
            "ai_capability": ai_capability,
            "notes": [],
            "sources": [],
        },
        "conditions": [],
        "human_role": "人工验收",
    }


def unknown_step(name: str = "尚未评估") -> dict:
    return {
        "name": name,
        "step_share_pct": 100,
        "current_ai_usage_pct": None,
        "capability": {},
        "readiness": {},
        "human_centrality": None,
        "risk_level": None,
        "evidence": {
            "work_fact": "user_confirmed",
            "ai_capability": "analyst_inference",
            "notes": [],
            "sources": [],
        },
        "conditions": [],
        "human_role": "待确认",
    }


def assessment(tasks: list[dict]) -> dict:
    return {
        "schema_version": "2.0",
        "meta": {"company": "示例公司", "role": "示例岗位", "mode": "medium"},
        "overview": {"summary": "示例", "thesis": "示例"},
        "profile": {},
        "tasks": tasks,
        "maturity": {},
        "workers": [],
        "division": {},
        "transition": {},
        "plan": [],
        "risks": [],
        "sources": [],
        "unknowns": [],
    }


class ScoreRoleTests(unittest.TestCase):
    def test_high_human_centrality_and_risk_override_high_capability(self) -> None:
        data = assessment(
            [{"name": "高风险任务", "time_share_pct": 100, "steps": [rated_step(human=5, risk=5)]}]
        )
        result = score_role.score_assessment(data)
        step = result["tasks"][0]["steps"][0]["assessment"]
        self.assertEqual(step["category"], "human_led")
        self.assertEqual(step["category_label"], "人主导")

    def test_unknown_half_of_role_produces_range_instead_of_inflated_point(self) -> None:
        data = assessment(
            [
                {"name": "已知直接执行", "time_share_pct": 50, "steps": [rated_step()]},
                {"name": "未知工作", "time_share_pct": 50, "steps": [unknown_step()]},
            ]
        )
        result = score_role.score_assessment(data)
        metric = result["role_summary"]["current_replaceable_pct"]
        self.assertEqual(metric["low"], 50.0)
        self.assertEqual(metric["high"], 100.0)
        self.assertEqual(result["role_summary"]["assessed_work_coverage_pct"], 50.0)
        self.assertEqual(result["role_summary"]["confidence"], "低")

    def test_invalid_task_time_total_is_rejected(self) -> None:
        data = assessment(
            [
                {"name": "任务 A", "time_share_pct": 80, "steps": [rated_step()]},
                {"name": "任务 B", "time_share_pct": 80, "steps": [rated_step()]},
            ]
        )
        with self.assertRaisesRegex(ValueError, "exceeds 105"):
            score_role.score_assessment(data)

    def test_legacy_or_misspelled_scoring_fields_are_rejected(self) -> None:
        step = rated_step()
        step["ratings"] = step.pop("capability")
        data = assessment([{"name": "任务", "time_share_pct": 100, "steps": [step]}])
        with self.assertRaisesRegex(ValueError, "unexpected fields: ratings"):
            score_role.score_assessment(data)

    def test_low_readiness_becomes_conditional_not_direct(self) -> None:
        data = assessment(
            [
                {
                    "name": "技术可行但尚未就绪",
                    "time_share_pct": 100,
                    "steps": [rated_step(readiness_value=1)],
                }
            ]
        )
        result = score_role.score_assessment(data)
        self.assertEqual(result["tasks"][0]["steps"][0]["assessment"]["category"], "conditional")

    def test_public_job_inference_cannot_enter_formal_classification(self) -> None:
        data = assessment(
            [
                {
                    "name": "仅公开资料推测",
                    "time_share_pct": 100,
                    "steps": [rated_step(work_fact="public_inference")],
                }
            ]
        )
        result = score_role.score_assessment(data)
        self.assertEqual(
            result["tasks"][0]["steps"][0]["assessment"]["category"],
            "insufficient_evidence",
        )

    def test_near_one_hundred_complete_distribution_is_normalized(self) -> None:
        data = assessment(
            [
                {"name": "任务 A", "time_share_pct": 49, "steps": [rated_step()]},
                {"name": "任务 B", "time_share_pct": 49, "steps": [rated_step()]},
            ]
        )
        result = score_role.score_assessment(data)
        shares = [task["normalized_time_share_pct"] for task in result["tasks"]]
        self.assertEqual(shares, [50.0, 50.0])
        self.assertTrue(result["role_summary"]["time_distribution"]["normalized"])

    def test_input_is_not_mutated(self) -> None:
        data = assessment([{"name": "任务", "time_share_pct": 100, "steps": [rated_step()]}])
        before = deepcopy(data)
        score_role.score_assessment(data)
        self.assertEqual(data, before)


if __name__ == "__main__":
    unittest.main()
