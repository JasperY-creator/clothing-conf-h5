from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

SCORE_SPEC = importlib.util.spec_from_file_location("score_role", ROOT / "scripts" / "score_role.py")
score_role = importlib.util.module_from_spec(SCORE_SPEC)
assert SCORE_SPEC.loader is not None
SCORE_SPEC.loader.exec_module(score_role)

HTML_SPEC = importlib.util.spec_from_file_location(
    "generate_html_report", ROOT / "scripts" / "generate_html_report.py"
)
html_report = importlib.util.module_from_spec(HTML_SPEC)
assert HTML_SPEC.loader is not None
HTML_SPEC.loader.exec_module(html_report)


def unknown_assessment() -> dict:
    return {
        "schema_version": "2.0",
        "meta": {"company": "示例公司", "role": "示例岗位", "mode": "light"},
        "overview": {"summary": "阶段性报告", "thesis": "先补足证据"},
        "profile": {},
        "tasks": [
            {
                "name": "尚未评估的任务",
                "time_share_pct": 100,
                "steps": [
                    {
                        "name": "未知步骤",
                        "step_share_pct": 100,
                        "current_ai_usage_pct": None,
                        "capability": {},
                        "readiness": {},
                        "human_centrality": None,
                        "risk_level": None,
                        "evidence": {
                            "work_fact": "user_confirmed",
                            "ai_capability": "analyst_inference",
                            "notes": [],
                            "sources": [],
                        },
                        "conditions": [],
                        "human_role": "待确认",
                    }
                ],
            }
        ],
        "maturity": {},
        "workers": [],
        "division": {},
        "transition": {},
        "plan": [],
        "risks": [],
        "sources": [],
        "unknowns": ["AI 能力与风险尚未评估"],
    }


class HtmlReportTests(unittest.TestCase):
    def test_missing_metric_is_rendered_as_unknown_not_zero(self) -> None:
        self.assertEqual(html_report.range_text(None), "待确认")
        row = html_report.task_rows(
            [
                {
                    "name": "缺失分数",
                    "normalized_time_share_pct": None,
                    "assessment": {
                        "category": "insufficient_evidence",
                        "category_label": "证据不足",
                        "current_replaceable_pct": None,
                        "steps": [],
                    },
                }
            ]
        )
        self.assertIn("待确认", row)
        self.assertNotIn("<strong>0%</strong>", row)
        self.assertNotIn("待确认%", row)

    def test_missing_radar_dimensions_do_not_create_default_scores(self) -> None:
        radar = html_report.radar_svg(None)
        self.assertIn("维度证据不足", radar)
        self.assertNotIn("任务结构化", radar)
        self.assertNotIn('value="50"', radar)

    def test_unscored_input_is_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "score_role.py"):
            html_report.build_html(unknown_assessment())

    def test_scored_unknown_assessment_renders_honest_interval(self) -> None:
        scored = score_role.score_assessment(unknown_assessment())
        html = html_report.build_html(scored)
        self.assertIn("0–100%", html)
        self.assertIn("维度证据不足", html)
        self.assertIn("证据不足", html)
        self.assertIn("AI 能力与风险尚未评估", html)
        self.assertNotIn("<script src=", html)
        self.assertNotIn("<link ", html)
        self.assertNotIn("cdn", html.lower())


if __name__ == "__main__":
    unittest.main()
