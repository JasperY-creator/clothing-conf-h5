# V2 结构化评估数据

`scripts/score_role.py` 接受 UTF-8 JSON。评分输入、评分输出和 HTML 报告使用同一条数据链，禁止在 HTML 阶段另填一套分数。

## 最小输入示例

```json
{
  "schema_version": "2.0",
  "meta": {
    "company": "示例公司",
    "role": "客户成功经理",
    "team": "企业客户部",
    "mode": "medium",
    "date": "2026-08-27",
    "audience": "个人"
  },
  "overview": {
    "summary": "基于已确认工作生成的岗位 AI 替代与增强分析。",
    "thesis": "让 AI 接管可验收的执行步骤，人保留客户判断和责任。"
  },
  "profile": {
    "responsibilities": ["推动客户采用产品"],
    "outputs": ["客户复盘与行动计划"],
    "capabilities": ["业务判断与客户沟通"],
    "pain_points": ["资料汇总耗时"],
    "why_ai": "存在大量数字化、可验收的准备工作。"
  },
  "tasks": [
    {
      "id": "t1",
      "name": "汇总客户使用数据并生成复盘初稿",
      "time_share_pct": 40,
      "frequency": "每周",
      "duration": "每次约 4 小时",
      "inputs": ["使用数据", "工单记录"],
      "outputs": ["客户复盘初稿"],
      "quality_standard": "数据准确、异常有来源、结论可追溯",
      "steps": [
        {
          "id": "t1-s1",
          "name": "拉取并整理客户使用数据",
          "step_share_pct": 45,
          "current_ai_usage_pct": 0,
          "capability": {
            "digital_io": 5,
            "instruction_clarity": 4,
            "output_verifiability": 5,
            "model_tool_fit": 4,
            "context_independence": 4
          },
          "readiness": {
            "data_access": 4,
            "tool_access": 3,
            "process_stability": 4,
            "privacy_safety": 4,
            "adoption_support": 3
          },
          "human_centrality": 1,
          "risk_level": 2,
          "evidence": {
            "work_fact": "recent_example",
            "ai_capability": "current_source",
            "notes": ["用户描述了最近一次周报流程"],
            "sources": [{"title": "工具官方文档", "url": "https://example.com", "date": "2026-08-27"}]
          },
          "conditions": ["仅使用已授权数据"],
          "human_role": "抽查异常数据和最终验收"
        },
        {
          "id": "t1-s2",
          "name": "判断异常原因并提出客户建议",
          "step_share_pct": 55,
          "current_ai_usage_pct": null,
          "capability": {
            "digital_io": 4,
            "instruction_clarity": 2,
            "output_verifiability": 2,
            "model_tool_fit": 3,
            "context_independence": 1
          },
          "readiness": {
            "data_access": 3,
            "tool_access": 3,
            "process_stability": 2,
            "privacy_safety": 4,
            "adoption_support": 3
          },
          "human_centrality": 5,
          "risk_level": 3,
          "evidence": {
            "work_fact": "recent_example",
            "ai_capability": "analyst_inference",
            "notes": ["需要结合客户关系和历史承诺"],
            "sources": []
          },
          "conditions": [],
          "human_role": "判断原因、决定建议并对客户承诺"
        }
      ]
    },
    {
      "id": "t-other",
      "name": "其他已确认工作",
      "time_share_pct": 60,
      "steps": [
        {
          "id": "t-other-s1",
          "name": "尚未拆解的其他步骤",
          "step_share_pct": 100,
          "current_ai_usage_pct": null,
          "capability": {},
          "readiness": {},
          "human_centrality": null,
          "risk_level": null,
          "evidence": {
            "work_fact": "user_confirmed",
            "ai_capability": "analyst_inference",
            "notes": ["待下一轮拆解"],
            "sources": []
          },
          "conditions": [],
          "human_role": "待确认"
        }
      ]
    }
  ],
  "maturity": {
    "usage_frequency": 2,
    "workflow_integration": 1,
    "standardization": 1,
    "quality_evaluation": 2,
    "data_tool_readiness": 2,
    "learning_loop": 1
  },
  "workers": [],
  "division": {"ai": [], "human": [], "principle": "责任不外包。"},
  "transition": {"old_role": "", "new_role": "", "gains": []},
  "plan": [],
  "risks": [],
  "sources": [],
  "unknowns": []
}
```

## 字段规则

- `schema_version` 必须为 `2.0`。
- `meta.mode` 使用 `light`、`medium` 或 `deep`；也兼容轻度、中等、深度。
- `time_share_pct` 和 `step_share_pct` 为 0–100 数字或 `null`。
- 用户只给区间时，将原始区间保存在 `time_share_range_pct: {"low": 10, "high": 20}`，精确值保持 `null`；脚本将其视为未解析时间，不使用中点伪造单点。
- 完整任务或步骤分配合计必须在 95–105；脚本归一化为 100。存在 `null` 时保留未解析比例。
- 评分字段为 0–5 数字或 `null`。空对象表示尚未判断。
- `current_ai_usage_pct` 是员工确认的当前 AI 参与比例，不是潜力评分。
- `evidence.work_fact` 与 `evidence.ai_capability` 分开记录。
- `overview` 只能写叙述，不应预填替代率、总分或任务分类。

## 运行

```bash
python3 scripts/score_role.py assessment.json --output scored-report.json
python3 scripts/generate_html_report.py --input scored-report.json --output report.html
```

评分输出会保留原始叙述字段，并新增：

- `scoring`
- 每个步骤的 `assessment`
- 每个任务的 `assessment`
- `role_summary`
- `maturity_assessment`

不要手工修改这些计算字段后再生成 HTML；事实变化时修改原始输入并重新运行评分脚本。
