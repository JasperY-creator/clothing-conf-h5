#!/usr/bin/env python3
"""Validate and score a V2 job AI replacement-and-augmentation assessment."""

from __future__ import annotations

import argparse
import json
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "2.0"
SCORING_VERSION = "2.0"

CAPABILITY_WEIGHTS = {
    "digital_io": 15,
    "instruction_clarity": 20,
    "output_verifiability": 20,
    "model_tool_fit": 30,
    "context_independence": 15,
}
CAPABILITY_CRITICAL = {"model_tool_fit", "output_verifiability"}

READINESS_WEIGHTS = {
    "data_access": 25,
    "tool_access": 20,
    "process_stability": 15,
    "privacy_safety": 25,
    "adoption_support": 15,
}
READINESS_CRITICAL = {"data_access", "privacy_safety"}

MATURITY_WEIGHTS = {
    "usage_frequency": 20,
    "workflow_integration": 20,
    "standardization": 15,
    "quality_evaluation": 20,
    "data_tool_readiness": 15,
    "learning_loop": 10,
}

CATEGORY_LABELS = {
    "direct_now": "现在可执行",
    "conditional": "条件成熟可执行",
    "augment": "AI 增强",
    "human_led": "人主导",
    "insufficient_evidence": "证据不足",
    "mixed": "混合型任务",
}

WORK_FACT_STRENGTH = {
    "public_inference": 1,
    "user_confirmed": 2,
    "recent_example": 3,
    "artifact": 4,
}
AI_CAPABILITY_STRENGTH = {
    "analyst_inference": 1,
    "current_source": 2,
    "benchmark": 3,
    "pilot": 4,
}

TOP_LEVEL_KEYS = {
    "schema_version",
    "meta",
    "overview",
    "profile",
    "tasks",
    "maturity",
    "workers",
    "division",
    "transition",
    "plan",
    "risks",
    "sources",
    "unknowns",
}
TASK_KEYS = {
    "id",
    "name",
    "description",
    "time_share_pct",
    "time_share_range_pct",
    "frequency",
    "duration",
    "inputs",
    "outputs",
    "quality_standard",
    "collaborators",
    "notes",
    "steps",
}
STEP_KEYS = {
    "id",
    "name",
    "description",
    "step_share_pct",
    "step_share_range_pct",
    "current_ai_usage_pct",
    "capability",
    "readiness",
    "human_centrality",
    "risk_level",
    "evidence",
    "conditions",
    "human_role",
    "ai_output",
    "failure_modes",
    "notes",
}
OVERVIEW_KEYS = {"summary", "thesis"}

DIMENSION_LABELS = {
    "digital_io": "输入输出数字化",
    "instruction_clarity": "步骤可说明",
    "output_verifiability": "产出可验收",
    "model_tool_fit": "当前 AI 能力匹配",
    "context_independence": "低情境依赖",
}


def ensure_object(value: Any, label: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be an object")
    return value


def ensure_allowed_keys(value: dict[str, Any], allowed: set[str], label: str) -> None:
    unexpected = sorted(set(value) - allowed)
    if unexpected:
        raise ValueError(f"{label} contains unexpected fields: {', '.join(unexpected)}")


def validate_number(value: Any, label: str, minimum: float, maximum: float) -> float | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be a number from {minimum:g} to {maximum:g}, or null")
    number = float(value)
    if number < minimum or number > maximum:
        raise ValueError(f"{label} must be between {minimum:g} and {maximum:g}")
    return number


def validate_range(value: Any, label: str) -> dict[str, float] | None:
    if value is None:
        return None
    obj = ensure_object(value, label)
    ensure_allowed_keys(obj, {"low", "high"}, label)
    low = validate_number(obj.get("low"), f"{label}.low", 0, 100)
    high = validate_number(obj.get("high"), f"{label}.high", 0, 100)
    if low is None or high is None:
        raise ValueError(f"{label}.low and {label}.high are required")
    if low > high:
        raise ValueError(f"{label}.low cannot exceed {label}.high")
    return {"low": low, "high": high}


def validate_string_list(value: Any, label: str) -> list[Any]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValueError(f"{label} must be a list")
    return value


def weighted_score(
    ratings_value: Any,
    weights: dict[str, int],
    critical: set[str],
    label: str,
) -> dict[str, Any]:
    ratings = ensure_object(ratings_value if ratings_value is not None else {}, label)
    ensure_allowed_keys(ratings, set(weights), label)
    total = 0.0
    known_weight = 0
    known_count = 0
    known_values: dict[str, float] = {}
    for key, weight in weights.items():
        value = validate_number(ratings.get(key), f"{label}.{key}", 0, 5)
        if value is not None:
            known_values[key] = value
            total += value / 5 * weight
            known_weight += weight
            known_count += 1
    coverage = known_weight / sum(weights.values()) * 100
    critical_known = critical.issubset(known_values)
    score = round(total / known_weight * 100, 1) if known_weight and coverage >= 70 and critical_known else None
    return {
        "score": score,
        "known_dimensions": known_count,
        "total_dimensions": len(weights),
        "known_weight_pct": round(coverage, 1),
        "critical_dimensions_known": critical_known,
        "ratings": known_values,
    }


def validate_evidence(value: Any, label: str) -> dict[str, Any]:
    evidence = ensure_object(value if value is not None else {}, label)
    ensure_allowed_keys(evidence, {"work_fact", "ai_capability", "notes", "sources"}, label)
    work_fact = evidence.get("work_fact")
    ai_capability = evidence.get("ai_capability")
    if work_fact is not None and work_fact not in WORK_FACT_STRENGTH:
        raise ValueError(f"{label}.work_fact has an unsupported value")
    if ai_capability is not None and ai_capability not in AI_CAPABILITY_STRENGTH:
        raise ValueError(f"{label}.ai_capability has an unsupported value")
    notes = validate_string_list(evidence.get("notes"), f"{label}.notes")
    sources = validate_string_list(evidence.get("sources"), f"{label}.sources")
    for index, source in enumerate(sources):
        if not isinstance(source, dict):
            raise ValueError(f"{label}.sources[{index}] must be an object")
    return {
        "work_fact": work_fact,
        "ai_capability": ai_capability,
        "work_fact_strength": WORK_FACT_STRENGTH.get(work_fact, 0),
        "ai_capability_strength": AI_CAPABILITY_STRENGTH.get(ai_capability, 0),
        "notes": notes,
        "sources": sources,
    }


def classify_step(
    capability: dict[str, Any],
    readiness: dict[str, Any],
    human_centrality: float | None,
    risk_level: float | None,
    evidence: dict[str, Any],
) -> tuple[str, str]:
    if (
        capability["score"] is None
        or readiness["score"] is None
        or human_centrality is None
        or risk_level is None
        or evidence["work_fact_strength"] < 2
    ):
        return "insufficient_evidence", "关键评分或用户确认的工作事实不足"
    if human_centrality >= 4 or risk_level >= 4:
        return "human_led", "人的核心责任或风险达到门控阈值"
    if capability["score"] >= 70 and human_centrality <= 2 and risk_level <= 2:
        if readiness["score"] >= 60 and evidence["ai_capability_strength"] >= 2:
            return "direct_now", "当前 AI 能力、落地条件与风险边界均满足"
        return "conditional", "AI 能力匹配，但落地条件或当前能力证据尚未满足"
    if capability["score"] >= 45:
        return "augment", "AI 可承担部分动作，但人仍需实质参与"
    return "human_led", "当前 AI 能力匹配有限，或该步骤应由人主导"


def step_confidence(category: str, capability: dict[str, Any], readiness: dict[str, Any], evidence: dict[str, Any]) -> str:
    if category == "insufficient_evidence":
        return "低"
    full_scoring = capability["known_weight_pct"] >= 95 and readiness["known_weight_pct"] >= 95
    if (
        full_scoring
        and evidence["work_fact_strength"] >= 3
        and evidence["ai_capability_strength"] >= 3
    ):
        return "高"
    if evidence["work_fact_strength"] >= 2 and evidence["ai_capability_strength"] >= 2:
        return "中"
    return "低"


def assess_step(step_value: Any, task_index: int, step_index: int) -> dict[str, Any]:
    label = f"tasks[{task_index}].steps[{step_index}]"
    step = ensure_object(step_value, label)
    ensure_allowed_keys(step, STEP_KEYS, label)
    if not isinstance(step.get("name"), str) or not step["name"].strip():
        raise ValueError(f"{label}.name must be a non-empty string")
    validate_range(step.get("step_share_range_pct"), f"{label}.step_share_range_pct")
    current_usage = validate_number(step.get("current_ai_usage_pct"), f"{label}.current_ai_usage_pct", 0, 100)
    capability = weighted_score(step.get("capability", {}), CAPABILITY_WEIGHTS, CAPABILITY_CRITICAL, f"{label}.capability")
    readiness = weighted_score(step.get("readiness", {}), READINESS_WEIGHTS, READINESS_CRITICAL, f"{label}.readiness")
    human = validate_number(step.get("human_centrality"), f"{label}.human_centrality", 0, 5)
    risk = validate_number(step.get("risk_level"), f"{label}.risk_level", 0, 5)
    evidence = validate_evidence(step.get("evidence", {}), f"{label}.evidence")
    validate_string_list(step.get("conditions"), f"{label}.conditions")
    validate_string_list(step.get("failure_modes"), f"{label}.failure_modes")
    category, reason = classify_step(capability, readiness, human, risk, evidence)
    confidence = step_confidence(category, capability, readiness, evidence)

    result = deepcopy(step)
    result["current_ai_usage_pct"] = current_usage
    result["assessment"] = {
        "category": category,
        "category_label": CATEGORY_LABELS[category],
        "confidence": confidence,
        "decision_reason": reason,
        "capability": {key: value for key, value in capability.items() if key != "ratings"},
        "readiness": {key: value for key, value in readiness.items() if key != "ratings"},
        "human_centrality": human,
        "risk_level": risk,
        "evidence": {
            "work_fact": evidence["work_fact"],
            "ai_capability": evidence["ai_capability"],
            "work_fact_strength": evidence["work_fact_strength"],
            "ai_capability_strength": evidence["ai_capability_strength"],
        },
    }
    return result


def normalize_distribution(items: list[dict[str, Any]], key: str, label: str) -> dict[str, Any]:
    values: list[float | None] = []
    for index, item in enumerate(items):
        values.append(validate_number(item.get(key), f"{label}[{index}].{key}", 0, 100))
    known_total = sum(value for value in values if value is not None)
    unknown_count = sum(value is None for value in values)
    if known_total > 105:
        raise ValueError(f"{label}.{key} known values total {known_total:g}%, which exceeds 105%")
    if unknown_count == 0:
        if known_total < 95 or known_total > 105:
            raise ValueError(f"{label}.{key} values must total 95%–105%; got {known_total:g}%")
        if known_total == 0:
            raise ValueError(f"{label}.{key} values cannot all be zero")
        normalized = [round(value / known_total * 100, 6) for value in values if value is not None]
        return {
            "values": normalized,
            "known_coverage_pct": 100.0,
            "unresolved_pct": 0.0,
            "input_total_pct": round(known_total, 1),
            "normalized": abs(known_total - 100) > 1e-9,
        }
    if known_total > 100:
        raise ValueError(f"{label}.{key} known values cannot exceed 100% when unknown values remain")
    return {
        "values": values,
        "known_coverage_pct": round(known_total, 1),
        "unresolved_pct": round(100 - known_total, 1),
        "input_total_pct": round(known_total, 1),
        "normalized": False,
    }


def range_metric(low: float, high: float) -> dict[str, Any]:
    low_value = round(max(0.0, min(100.0, low)), 1)
    high_value = round(max(low_value, min(100.0, high)), 1)
    return {
        "low": low_value,
        "high": high_value,
        "is_range": abs(high_value - low_value) >= 0.1,
    }


def aggregate_scored_metric(
    rows: list[tuple[float, float | None, float]],
    minimum_coverage: float = 70,
) -> dict[str, Any]:
    numerator = 0.0
    coverage = 0.0
    for outer_share, score, inner_coverage in rows:
        if score is None:
            continue
        effective_share = outer_share * inner_coverage / 100
        numerator += score * effective_share
        coverage += effective_share
    value = round(numerator / coverage, 1) if coverage >= minimum_coverage else None
    return {"score": value, "coverage_pct": round(coverage, 1)}


def assess_task(task_value: Any, task_index: int) -> dict[str, Any]:
    label = f"tasks[{task_index}]"
    task = ensure_object(task_value, label)
    ensure_allowed_keys(task, TASK_KEYS, label)
    if not isinstance(task.get("name"), str) or not task["name"].strip():
        raise ValueError(f"{label}.name must be a non-empty string")
    validate_range(task.get("time_share_range_pct"), f"{label}.time_share_range_pct")
    steps_value = task.get("steps")
    if not isinstance(steps_value, list) or not steps_value:
        raise ValueError(f"{label}.steps must be a non-empty list")
    steps = [assess_step(step, task_index, index) for index, step in enumerate(steps_value)]
    distribution = normalize_distribution(steps, "step_share_pct", f"{label}.steps")

    categories = {key: 0.0 for key in ("direct_now", "conditional", "augment", "human_led")}
    unknown_share = distribution["unresolved_pct"]
    assessed_share = 0.0
    evidence_share = 0.0
    current_usage_low = 0.0
    current_usage_unknown = distribution["unresolved_pct"]
    capability_rows: list[tuple[float, float | None, float]] = []
    readiness_rows: list[tuple[float, float | None, float]] = []

    for step, share in zip(steps, distribution["values"]):
        step["normalized_step_share_pct"] = round(share, 1) if share is not None else None
        if share is None:
            continue
        assessment = step["assessment"]
        category = assessment["category"]
        if category == "insufficient_evidence":
            unknown_share += share
        else:
            categories[category] += share
            assessed_share += share
            if (
                assessment["evidence"]["work_fact_strength"] >= 2
                and assessment["evidence"]["ai_capability_strength"] >= 2
            ):
                evidence_share += share
        usage = step.get("current_ai_usage_pct")
        if usage is None:
            current_usage_unknown += share
        else:
            current_usage_low += share * usage / 100
        capability_rows.append((share, assessment["capability"]["score"], 100.0))
        readiness_rows.append((share, assessment["readiness"]["score"], 100.0))

    unknown_share = min(100.0, unknown_share)
    direct = categories["direct_now"]
    conditional = direct + categories["conditional"]
    augmentable = conditional + categories["augment"]
    human_led = categories["human_led"]
    capability_summary = aggregate_scored_metric(capability_rows)
    readiness_summary = aggregate_scored_metric(readiness_rows)

    if assessed_share < 60:
        dominant = "insufficient_evidence"
    else:
        dominant_key, dominant_value = max(categories.items(), key=lambda item: item[1])
        dominant = dominant_key if dominant_value >= 60 else "mixed"

    result = deepcopy(task)
    result["steps"] = steps
    result["assessment"] = {
        "time_distribution": distribution,
        "category": dominant,
        "category_label": CATEGORY_LABELS[dominant],
        "category_distribution_pct": {key: round(value, 1) for key, value in categories.items()},
        "current_ai_usage_pct": range_metric(current_usage_low, current_usage_low + current_usage_unknown),
        "current_replaceable_pct": range_metric(direct, direct + unknown_share),
        "conditional_replaceable_pct": range_metric(conditional, conditional + unknown_share),
        "ai_augmentable_pct": range_metric(augmentable, augmentable + unknown_share),
        "human_led_pct": range_metric(human_led, human_led + unknown_share),
        "assessed_step_coverage_pct": round(assessed_share, 1),
        "evidence_coverage_pct": round(evidence_share, 1),
        "capability_score": capability_summary,
        "readiness_score": readiness_summary,
    }
    return result


def role_dimension_scores(tasks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    dimensions: list[dict[str, Any]] = []
    for key, label in DIMENSION_LABELS.items():
        numerator = 0.0
        coverage = 0.0
        for task in tasks:
            task_share = task.get("normalized_time_share_pct")
            if task_share is None:
                continue
            for step in task["steps"]:
                step_share = step.get("normalized_step_share_pct")
                value = step.get("capability", {}).get(key)
                if step_share is None or value is None:
                    continue
                rating = validate_number(value, f"capability.{key}", 0, 5)
                role_share = task_share * step_share / 100
                numerator += rating / 5 * 100 * role_share
                coverage += role_share
        dimensions.append(
            {
                "key": key,
                "label": label,
                "value": round(numerator / coverage, 1) if coverage >= 70 else None,
                "coverage_pct": round(coverage, 1),
            }
        )
    return dimensions


def role_summary(tasks: list[dict[str, Any]], distribution: dict[str, Any]) -> dict[str, Any]:
    lower = {
        "current_ai_usage_pct": 0.0,
        "current_replaceable_pct": 0.0,
        "conditional_replaceable_pct": 0.0,
        "ai_augmentable_pct": 0.0,
        "human_led_pct": 0.0,
    }
    upper = dict(lower)
    assessed_coverage = 0.0
    evidence_coverage = 0.0
    direct_validation_gap = 0.0
    capability_rows: list[tuple[float, float | None, float]] = []
    readiness_rows: list[tuple[float, float | None, float]] = []

    for task, task_share in zip(tasks, distribution["values"]):
        task["normalized_time_share_pct"] = round(task_share, 1) if task_share is not None else None
        if task_share is None:
            continue
        assessment = task["assessment"]
        for key in lower:
            metric = assessment[key]
            lower[key] += task_share * metric["low"] / 100
            upper[key] += task_share * metric["high"] / 100
        assessed_coverage += task_share * assessment["assessed_step_coverage_pct"] / 100
        evidence_coverage += task_share * assessment["evidence_coverage_pct"] / 100
        capability_rows.append(
            (
                task_share,
                assessment["capability_score"]["score"],
                assessment["capability_score"]["coverage_pct"],
            )
        )
        readiness_rows.append(
            (
                task_share,
                assessment["readiness_score"]["score"],
                assessment["readiness_score"]["coverage_pct"],
            )
        )
        for step in task["steps"]:
            if step["assessment"]["category"] != "direct_now":
                continue
            step_share = step.get("normalized_step_share_pct")
            if step_share is None:
                continue
            evidence = step["assessment"]["evidence"]
            if evidence["work_fact_strength"] < 3 or evidence["ai_capability_strength"] < 3:
                direct_validation_gap += task_share * step_share / 100

    unresolved_task_share = distribution["unresolved_pct"]
    for key in upper:
        upper[key] += unresolved_task_share

    time_coverage = distribution["known_coverage_pct"]
    capability = aggregate_scored_metric(capability_rows)
    readiness = aggregate_scored_metric(readiness_rows)
    if (
        time_coverage >= 95
        and assessed_coverage >= 85
        and evidence_coverage >= 70
        and direct_validation_gap <= 5
    ):
        confidence = "高"
    elif time_coverage >= 75 and assessed_coverage >= 60 and evidence_coverage >= 40:
        confidence = "中"
    else:
        confidence = "低"

    formal_report_ready = time_coverage >= 95 and assessed_coverage >= 80 and evidence_coverage >= 40
    return {
        "current_ai_usage_pct": range_metric(lower["current_ai_usage_pct"], upper["current_ai_usage_pct"]),
        "current_replaceable_pct": range_metric(lower["current_replaceable_pct"], upper["current_replaceable_pct"]),
        "conditional_replaceable_pct": range_metric(
            lower["conditional_replaceable_pct"], upper["conditional_replaceable_pct"]
        ),
        "ai_augmentable_pct": range_metric(lower["ai_augmentable_pct"], upper["ai_augmentable_pct"]),
        "human_led_pct": range_metric(lower["human_led_pct"], upper["human_led_pct"]),
        "task_time_coverage_pct": round(time_coverage, 1),
        "assessed_work_coverage_pct": round(assessed_coverage, 1),
        "evidence_coverage_pct": round(evidence_coverage, 1),
        "direct_validation_gap_pct": round(direct_validation_gap, 1),
        "capability_score": capability,
        "readiness_score": readiness,
        "confidence": confidence,
        "formal_report_ready": formal_report_ready,
        "dimensions": role_dimension_scores(tasks),
        "time_distribution": distribution,
    }


def maturity_assessment(value: Any) -> dict[str, Any]:
    result = weighted_score(value if value is not None else {}, MATURITY_WEIGHTS, set(), "maturity")
    return {key: value for key, value in result.items() if key != "ratings"}


def score_assessment(data_value: Any) -> dict[str, Any]:
    data = ensure_object(data_value, "root")
    ensure_allowed_keys(data, TOP_LEVEL_KEYS, "root")
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"schema_version must be {SCHEMA_VERSION}")
    overview = ensure_object(data.get("overview", {}), "overview")
    ensure_allowed_keys(overview, OVERVIEW_KEYS, "overview")
    tasks_value = data.get("tasks")
    if not isinstance(tasks_value, list) or not tasks_value:
        raise ValueError("tasks must be a non-empty list")
    tasks = [assess_task(task, index) for index, task in enumerate(tasks_value)]
    distribution = normalize_distribution(tasks, "time_share_pct", "tasks")
    summary = role_summary(tasks, distribution)

    result = deepcopy(data)
    result["tasks"] = tasks
    result["scoring"] = {
        "version": SCORING_VERSION,
        "method": "step-level evidence-gated replacement and augmentation ranges",
        "category_labels": CATEGORY_LABELS,
    }
    result["role_summary"] = summary
    result["maturity_assessment"] = maturity_assessment(data.get("maturity", {}))
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", help="V2 assessment JSON path, or - for stdin")
    parser.add_argument("--output", help="write scored JSON to this path; omit for stdout")
    args = parser.parse_args()

    try:
        raw = sys.stdin.read() if args.input == "-" else Path(args.input).read_text(encoding="utf-8")
        scored = score_assessment(json.loads(raw))
        rendered = json.dumps(scored, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            output = Path(args.output)
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(rendered, encoding="utf-8")
            print(f"scored {output} ({output.stat().st_size} bytes)")
        else:
            sys.stdout.write(rendered)
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"score_role.py: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
