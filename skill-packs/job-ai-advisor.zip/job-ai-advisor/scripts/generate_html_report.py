#!/usr/bin/env python3
"""Generate an offline HTML report from score_role.py V2 output."""

from __future__ import annotations

import argparse
import json
import math
import sys
from html import escape
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "2.0"
SCORING_VERSION = "2.0"

MODE_LABELS = {
    "light": "轻度",
    "medium": "中等",
    "deep": "深度",
    "轻度": "轻度",
    "中等": "中等",
    "深度": "深度",
}

EVIDENCE_LABELS = {
    "public_inference": "公开推测",
    "user_confirmed": "用户确认",
    "recent_example": "近期实例",
    "artifact": "工作样本",
    "analyst_inference": "分析推断",
    "current_source": "当前能力来源",
    "benchmark": "可复核基准",
    "pilot": "本次小样",
}

CATEGORY_TONES = {
    "direct_now": "direct",
    "conditional": "conditional",
    "augment": "augment",
    "human_led": "human",
    "insufficient_evidence": "unknown",
    "mixed": "mixed",
}


def h(value: Any) -> str:
    return escape("" if value is None else str(value), quote=True)


def is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def number_text(value: Any) -> str:
    if not is_number(value):
        return ""
    return f"{float(value):.1f}".rstrip("0").rstrip(".")


def pct(value: Any) -> str:
    return f"{number_text(value)}%" if is_number(value) else "待确认"


def range_text(metric: Any) -> str:
    if not isinstance(metric, dict):
        return "待确认"
    low = metric.get("low")
    high = metric.get("high")
    if not is_number(low) or not is_number(high):
        return "待确认"
    if abs(float(high) - float(low)) < 0.1:
        return f"{number_text(low)}%"
    return f"{number_text(low)}–{number_text(high)}%"


def score_text(metric: Any) -> str:
    if not isinstance(metric, dict) or not is_number(metric.get("score")):
        return "待确认"
    return f"{float(metric['score']):.0f}/100"


def safe_url(value: Any) -> str:
    url = str(value or "")
    return url if url.startswith(("https://", "http://")) else "#"


def list_items(values: Any, cls: str = "") -> str:
    if not isinstance(values, list):
        return ""
    return "".join(f'<li class="{h(cls)}">{h(value)}</li>' for value in values if value not in (None, ""))


def metric_card(label: str, metric: Any, note: str, accent: str) -> str:
    return f"""<article class="metric-card {h(accent)}">
      <span>{h(label)}</span>
      <strong>{h(range_text(metric))}</strong>
      <p>{h(note)}</p>
    </article>"""


def range_bar(metric: Any, tone: str = "direct") -> str:
    if not isinstance(metric, dict):
        return '<div class="range-empty">待确认</div>'
    low = metric.get("low")
    high = metric.get("high")
    if not is_number(low) or not is_number(high):
        return '<div class="range-empty">待确认</div>'
    low_value = max(0.0, min(100.0, float(low)))
    high_value = max(low_value, min(100.0, float(high)))
    return f"""<div class="range-track" aria-label="{h(range_text(metric))}">
      <span class="range-high {h(tone)}" data-value="{high_value:.1f}"></span>
      <span class="range-low {h(tone)}" data-value="{low_value:.1f}"></span>
    </div>"""


def radar_svg(dimensions: Any) -> str:
    if not isinstance(dimensions, list):
        dimensions = []
    dims = [
        item
        for item in dimensions
        if isinstance(item, dict)
        and is_number(item.get("value"))
        and is_number(item.get("coverage_pct"))
        and float(item["coverage_pct"]) >= 70
    ][:6]
    if len(dims) < 3:
        return """<div class="empty-chart">
          <strong>维度证据不足</strong>
          <p>至少三个技术维度覆盖 70% 的岗位时间后才绘制雷达图。</p>
        </div>"""

    count = len(dims)
    cx, cy, radius = 150, 136, 90

    def point(index: int, distance: float) -> tuple[float, float]:
        angle = -math.pi / 2 + 2 * math.pi * index / count
        return cx + distance * math.cos(angle), cy + distance * math.sin(angle)

    def polygon(distance: float) -> str:
        return " ".join(f"{x:.1f},{y:.1f}" for x, y in (point(i, distance) for i in range(count)))

    rings = "".join(
        f'<polygon points="{polygon(radius * ratio)}" class="radar-ring" />'
        for ratio in (0.25, 0.5, 0.75, 1)
    )
    axes = "".join(
        f'<line x1="{cx}" y1="{cy}" x2="{point(i, radius)[0]:.1f}" y2="{point(i, radius)[1]:.1f}" class="radar-axis" />'
        for i in range(count)
    )
    value_points = " ".join(
        f"{x:.1f},{y:.1f}"
        for x, y in (
            point(index, radius * max(0.0, min(100.0, float(dimension["value"]))) / 100)
            for index, dimension in enumerate(dims)
        )
    )
    labels = []
    for index, dimension in enumerate(dims):
        x, y = point(index, radius + 25)
        anchor = "middle" if abs(x - cx) < 24 else ("start" if x > cx else "end")
        labels.append(
            f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="{anchor}" class="radar-label">'
            f'{h(dimension.get("label", "维度"))}</text>'
        )
    return f"""<svg class="radar" viewBox="0 0 300 275" role="img" aria-label="有证据支持的 AI 技术能力维度">
      {rings}{axes}<polygon points="{value_points}" class="radar-value" />{''.join(labels)}
    </svg>"""


def display_share(item: dict[str, Any], normalized_key: str, range_key: str) -> str:
    normalized = item.get(normalized_key)
    if is_number(normalized):
        return pct(normalized)
    value_range = item.get(range_key)
    if isinstance(value_range, dict) and is_number(value_range.get("low")) and is_number(value_range.get("high")):
        return range_text(value_range)
    return "待确认"


def evidence_text(step: dict[str, Any]) -> str:
    evidence = step.get("evidence", {})
    if not isinstance(evidence, dict):
        return "证据待补充"
    work = EVIDENCE_LABELS.get(evidence.get("work_fact"), "工作事实待补充")
    capability = EVIDENCE_LABELS.get(evidence.get("ai_capability"), "AI 能力待补充")
    return f"{work} · {capability}"


def step_rows(steps: Any) -> str:
    if not isinstance(steps, list) or not steps:
        return '<p class="muted">尚未拆解步骤。</p>'
    rows: list[str] = []
    for step in steps:
        if not isinstance(step, dict):
            continue
        assessment = step.get("assessment", {})
        category = assessment.get("category", "insufficient_evidence")
        label = assessment.get("category_label", "证据不足")
        tone = CATEGORY_TONES.get(category, "unknown")
        conditions = step.get("conditions", [])
        condition_text = "；".join(str(value) for value in conditions) if isinstance(conditions, list) and conditions else "无已确认条件"
        ai_output = step.get("ai_output") or assessment.get("decision_reason") or "待补充"
        human_role = step.get("human_role") or "待确认"
        rows.append(
            f"""<article class="step-row">
              <div class="step-title"><div><b>{h(step.get("name", "未命名步骤"))}</b>
                <small>步骤占比 {h(display_share(step, "normalized_step_share_pct", "step_share_range_pct"))} · {h(assessment.get("confidence", "低"))}置信度</small>
              </div><span class="tag {h(tone)}">{h(label)}</span></div>
              <div class="step-grid">
                <p><small>AI 判断/产出</small>{h(ai_output)}</p>
                <p><small>人保留</small>{h(human_role)}</p>
                <p><small>条件</small>{h(condition_text)}</p>
                <p><small>证据</small>{h(evidence_text(step))}</p>
              </div>
            </article>"""
        )
    return "".join(rows)


def task_rows(tasks: Any) -> str:
    if not isinstance(tasks, list) or not tasks:
        return '<p class="muted">暂无任务信息。</p>'
    rows: list[str] = []
    for task in tasks:
        if not isinstance(task, dict):
            continue
        assessment = task.get("assessment", {})
        metric = assessment.get("current_replaceable_pct")
        category = assessment.get("category", "insufficient_evidence")
        tone = CATEGORY_TONES.get(category, "unknown")
        rows.append(
            f"""<article class="task-card">
              <header class="task-head">
                <div><span class="task-share">岗位时间 {h(display_share(task, "normalized_time_share_pct", "time_share_range_pct"))}</span>
                  <h3>{h(task.get("name", "未命名任务"))}</h3>
                </div>
                <div class="task-result"><span class="tag {h(tone)}">{h(assessment.get("category_label", "证据不足"))}</span>
                  <strong>{h(range_text(metric))}</strong><small>现在可替代</small>
                </div>
              </header>
              {range_bar(metric, tone)}
              <div class="task-metrics">
                <span>条件成熟可替代 <b>{h(range_text(assessment.get("conditional_replaceable_pct")))}</b></span>
                <span>AI 增强覆盖 <b>{h(range_text(assessment.get("ai_augmentable_pct")))}</b></span>
                <span>步骤评估覆盖 <b>{h(pct(assessment.get("assessed_step_coverage_pct")))}</b></span>
                <span>证据覆盖 <b>{h(pct(assessment.get("evidence_coverage_pct")))}</b></span>
              </div>
              <div class="step-list">{step_rows(task.get("steps", []))}</div>
            </article>"""
        )
    return "".join(rows)


def worker_cards(workers: Any) -> str:
    if not isinstance(workers, list) or not workers:
        return '<p class="muted">证据充分后再设计数字员工；当前暂无方案。</p>'
    cards: list[str] = []
    for index, worker in enumerate(workers[:5], 1):
        if not isinstance(worker, dict):
            continue
        cards.append(
            f"""<article class="worker-card">
              <button class="worker-toggle" type="button" aria-expanded="false">
                <span class="worker-index">{index:02d}</span>
                <span><b>{h(worker.get("name", "数字员工"))}</b><small>{h(worker.get("specialty", ""))}</small></span>
                <span class="chevron">＋</span>
              </button>
              <div class="worker-detail" hidden>
                <p class="worker-value">{h(worker.get("value", ""))}</p>
                <ul>{list_items(worker.get("duties", []))}</ul>
                <div class="boundary">
                  <div><small>AI 产出</small><p>{h(worker.get("ai_output", "待补充"))}</p></div>
                  <div><small>人验收/保留</small><p>{h(worker.get("human_output", "待补充"))}</p></div>
                </div>
                <span class="release">{h(worker.get("time_release", "时间收益待验证"))}</span>
              </div>
            </article>"""
        )
    return "".join(cards)


def plan_tabs(plan: Any) -> str:
    if not isinstance(plan, list) or not plan:
        return '<p class="muted">信息充分后再生成试点计划。</p>'
    tabs: list[str] = []
    panels: list[str] = []
    for index, week in enumerate(plan[:12], 1):
        if not isinstance(week, dict):
            continue
        active = " active" if index == 1 else ""
        selected = "true" if index == 1 else "false"
        tabs.append(
            f'<button class="week-tab{active}" type="button" data-week="{index}" aria-selected="{selected}">'
            f'{h(week.get("label", f"第 {week.get("week", index)} 周"))}</button>'
        )
        panels.append(
            f"""<article class="week-panel{active}" data-panel="{index}" {"hidden" if index != 1 else ""}>
              <span class="week-kicker">{h(week.get("theme", "试点推进"))}</span>
              <h3>{h(week.get("goal", "待补充目标"))}</h3>
              <ol>{list_items(week.get("steps", []))}</ol>
              <div class="milestone"><span>验收/里程碑</span>{h(week.get("milestone", "待补充"))}</div>
            </article>"""
        )
    return f'<div class="week-tabs">{"".join(tabs)}</div>{"".join(panels)}'


def source_rows(sources: Any) -> str:
    if not isinstance(sources, list) or not sources:
        return '<li><span class="muted">暂无公开来源；相关结论应保持待验证。</span></li>'
    rows: list[str] = []
    for source in sources:
        if not isinstance(source, dict):
            continue
        rows.append(
            f'<li><a href="{h(safe_url(source.get("url")))}" target="_blank" rel="noreferrer">'
            f'{h(source.get("title", "来源"))}</a><span>{h(source.get("detail", ""))}</span></li>'
        )
    return "".join(rows)


def validate_scored_data(data: Any) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValueError("input JSON must be an object")
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"schema_version must be {SCHEMA_VERSION}")
    scoring = data.get("scoring")
    if not isinstance(scoring, dict) or scoring.get("version") != SCORING_VERSION:
        raise ValueError("input must be generated by scripts/score_role.py V2")
    if not isinstance(data.get("role_summary"), dict):
        raise ValueError("role_summary is missing; run scripts/score_role.py first")
    return data


def build_html(data_value: Any) -> str:
    data = validate_scored_data(data_value)
    meta = data.get("meta", {}) if isinstance(data.get("meta"), dict) else {}
    overview = data.get("overview", {}) if isinstance(data.get("overview"), dict) else {}
    profile = data.get("profile", {}) if isinstance(data.get("profile"), dict) else {}
    summary = data["role_summary"]
    maturity = data.get("maturity_assessment", {})
    division = data.get("division", {}) if isinstance(data.get("division"), dict) else {}
    transition = data.get("transition", {}) if isinstance(data.get("transition"), dict) else {}
    company = meta.get("company", "未填写公司")
    role = meta.get("role", "未填写岗位")
    title = f"{company} · {role} 岗位 AI 替代与增强报告"
    mode = MODE_LABELS.get(meta.get("mode"), str(meta.get("mode", "中等")))
    confidence = summary.get("confidence", "低")
    report_summary = overview.get("summary", "这是基于当前已确认事实生成的阶段性岗位 AI 分析。")
    thesis = overview.get("thesis", "让 AI 接管可验收的执行步骤，人保留判断、关系和责任")
    dimensions = summary.get("dimensions", [])
    risks = data.get("risks", []) if isinstance(data.get("risks"), list) else []
    unknowns = data.get("unknowns", []) if isinstance(data.get("unknowns"), list) else []
    gains = transition.get("gains", []) if isinstance(transition.get("gains"), list) else []

    css = r"""
:root{--blue:#377cf6;--cyan:#16bfa6;--orange:#f28a2e;--red:#d95757;--ink:#142238;--muted:#66758a;--paper:#f4f7fb;--card:#fff;--line:#dfe7f1;--shadow:0 16px 42px rgba(43,72,108,.09);--radius:22px}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);color:var(--ink);font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;line-height:1.6}
.topbar{position:sticky;top:0;z-index:20;display:flex;align-items:center;gap:24px;min-height:68px;padding:0 5vw;background:rgba(255,255,255,.94);border-bottom:1px solid var(--line);backdrop-filter:blur(16px)}
.brand{font-weight:900;color:var(--blue);white-space:nowrap}.brand small{margin-left:8px;color:var(--muted);font-weight:600}.nav{display:flex;gap:5px;overflow:auto;margin-left:auto}.nav a{padding:7px 10px;border-radius:99px;color:var(--muted);font-size:12px;text-decoration:none;white-space:nowrap}.nav a.active,.nav a:hover{background:#eaf2ff;color:var(--blue)}
.container{width:min(1180px,90vw);margin:auto}.hero{padding:70px 0 50px}.hero-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:38px;align-items:center}.eyebrow{font-size:12px;letter-spacing:.14em;color:var(--blue);font-weight:900}.hero h1{font-size:clamp(36px,5.5vw,70px);line-height:1.06;letter-spacing:-.045em;margin:18px 0}.lead{font-size:18px;color:var(--muted);max-width:720px}.thesis{margin-top:24px;padding:17px 20px;background:#fff;border-left:4px solid var(--orange);border-radius:0 16px 16px 0;box-shadow:var(--shadow);font-weight:700}.hero-meta{font-size:12px;color:var(--muted);margin-top:18px}
.metric-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.metric-card{padding:19px;background:#fff;border-radius:20px;box-shadow:var(--shadow);border-top:4px solid var(--blue);min-height:150px}.metric-card.cyan{border-color:var(--cyan)}.metric-card.orange{border-color:var(--orange)}.metric-card.ink{border-color:var(--ink)}.metric-card span{font-size:12px;color:var(--muted)}.metric-card strong{display:block;font-size:38px;line-height:1.1;margin:13px 0 8px}.metric-card p{font-size:12px;color:var(--muted);margin:0}
.coverage-strip{display:flex;flex-wrap:wrap;gap:9px;margin-top:18px}.coverage-strip span{padding:8px 12px;background:#fff;border:1px solid var(--line);border-radius:99px;font-size:12px}.coverage-strip b{color:var(--blue)}
section{padding:64px 0;border-top:1px solid var(--line)}.section-head{display:flex;align-items:end;justify-content:space-between;gap:22px;margin-bottom:24px}.section-kicker{font-size:11px;letter-spacing:.14em;color:var(--blue);font-weight:900}.section-head h2{font-size:clamp(28px,4vw,44px);line-height:1.1;margin:7px 0 0}.section-head p{max-width:500px;margin:0;color:var(--muted)}
.profile-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:13px}.info-card{padding:22px;background:#fff;border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow)}.info-card h3{margin:0 0 10px;font-size:15px}.info-card ul,.worker-detail ul,.week-panel ol{padding-left:20px;margin:0}.info-card li,.worker-detail li,.week-panel li{margin:6px 0;color:var(--muted);font-size:13px}.why-ai{margin-top:15px;padding:22px;border-radius:var(--radius);background:linear-gradient(120deg,#eaf3ff,#e9fbf7)}
.task-layout{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(320px,.75fr);gap:26px;align-items:start}.task-list{display:grid;gap:15px}.task-card{padding:21px;background:#fff;border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow)}.task-head{display:flex;justify-content:space-between;gap:18px;align-items:start}.task-head h3{font-size:18px;line-height:1.3;margin:5px 0}.task-share{font-size:11px;color:var(--muted)}.task-result{text-align:right}.task-result strong{display:block;font-size:24px;color:var(--blue);margin-top:5px}.task-result small{font-size:10px;color:var(--muted)}
.tag{display:inline-block;padding:4px 9px;border-radius:99px;font-size:11px;font-weight:800}.tag.direct{background:#dcf8f2;color:#06786b}.tag.conditional{background:#fff0dd;color:#9c5005}.tag.augment{background:#e6efff;color:#245cc8}.tag.human{background:#f3eafa;color:#754497}.tag.unknown{background:#edf0f4;color:#66758a}.tag.mixed{background:#e8f4f8;color:#287084}
.range-track{position:relative;height:10px;margin:15px 0;background:#edf1f6;border-radius:99px;overflow:hidden}.range-high,.range-low{position:absolute;left:0;top:0;height:100%;width:0;border-radius:inherit;transition:width 1s cubic-bezier(.16,1,.3,1)}.range-high{opacity:.24}.range-low{opacity:1}.range-high.direct,.range-low.direct{background:var(--cyan)}.range-high.conditional,.range-low.conditional{background:var(--orange)}.range-high.augment,.range-low.augment{background:var(--blue)}.range-high.human,.range-low.human{background:#8c5bb1}.range-high.unknown,.range-low.unknown,.range-high.mixed,.range-low.mixed{background:#8190a4}.range-empty{font-size:12px;color:var(--muted);margin:12px 0}
.task-metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:12px 0}.task-metrics span{padding:9px;background:#f6f8fb;border-radius:12px;color:var(--muted);font-size:10px}.task-metrics b{display:block;color:var(--ink);font-size:13px}.step-list{display:grid;gap:8px;margin-top:14px}.step-row{padding:13px;border:1px solid var(--line);border-radius:15px;background:#fbfcfe}.step-title{display:flex;justify-content:space-between;gap:12px}.step-title b{font-size:13px}.step-title small{display:block;color:var(--muted);font-size:10px;margin-top:2px}.step-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}.step-grid p{margin:0;padding:9px;background:#fff;border-radius:10px;color:var(--muted);font-size:11px}.step-grid small{display:block;color:var(--blue);font-weight:900;margin-bottom:3px}
.chart-card{position:sticky;top:90px;padding:20px;background:#fff;border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow)}.radar{width:100%;height:auto}.radar-ring{fill:none;stroke:#dfe7f1}.radar-axis{stroke:#dfe7f1}.radar-value{fill:rgba(55,124,246,.18);stroke:var(--blue);stroke-width:3}.radar-label{font-size:10px;fill:var(--muted)}.empty-chart{padding:70px 25px;text-align:center;color:var(--muted)}.empty-chart strong{color:var(--ink)}.empty-chart p{font-size:12px}
.worker-list{display:grid;gap:10px}.worker-card{background:#fff;border:1px solid var(--line);border-radius:17px;overflow:hidden}.worker-toggle{width:100%;display:grid;grid-template-columns:42px 1fr 28px;gap:12px;align-items:center;padding:17px 20px;border:0;background:transparent;text-align:left;color:var(--ink);cursor:pointer}.worker-index{color:var(--blue);font-weight:900}.worker-toggle small{display:block;color:var(--muted)}.chevron{font-size:22px;color:var(--blue)}.worker-detail{padding:0 20px 20px}.worker-value{font-weight:700}.boundary,.division{display:grid;grid-template-columns:1fr 1fr;gap:12px}.boundary>div,.division-box{padding:16px;background:#f6f8fb;border-radius:15px}.boundary small{color:var(--blue);font-weight:900}.release{display:inline-block;margin-top:12px;padding:6px 10px;border-radius:99px;background:#dcf8f2;color:#06786b;font-size:11px}
.principle{margin-top:14px;padding:17px;background:var(--ink);color:#fff;border-radius:16px;text-align:center;font-weight:800}.transition{display:grid;grid-template-columns:1fr auto 1fr;gap:15px;align-items:stretch}.role-card{padding:22px;background:#fff;border:1px solid var(--line);border-radius:var(--radius)}.role-card.new{background:linear-gradient(135deg,#eaf3ff,#e9fbf7)}.arrow{display:grid;place-items:center;color:var(--blue);font-size:30px}.gain-list{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}.gain{padding:7px 11px;border-radius:99px;background:#fff;border:1px solid var(--line);font-size:11px}
.week-tabs{display:flex;gap:7px;overflow:auto;margin-bottom:12px}.week-tab{padding:9px 14px;border:1px solid var(--line);border-radius:99px;background:#fff;color:var(--muted);cursor:pointer;white-space:nowrap}.week-tab.active{background:var(--blue);border-color:var(--blue);color:#fff}.week-panel{padding:24px;background:#fff;border:1px solid var(--line);border-radius:var(--radius)}.week-kicker{font-size:11px;color:var(--blue);font-weight:900}.week-panel h3{font-size:22px}.milestone{margin-top:15px;padding:13px;background:#f6f8fb;border-radius:13px}.milestone span{display:block;color:var(--orange);font-size:10px;font-weight:900}
.source-list{list-style:none;padding:0}.source-list li{display:flex;justify-content:space-between;gap:16px;padding:12px 0;border-bottom:1px solid var(--line);font-size:12px}.source-list a{color:var(--blue);font-weight:800}.source-list span{color:var(--muted);text-align:right}.risk-grid{display:flex;flex-wrap:wrap;gap:8px}.risk{padding:7px 10px;border-radius:99px;background:#fff0df;color:#9c5005;font-size:11px}.unknown-box{margin-top:14px;padding:15px;background:#fff;border:1px dashed #bdc9d7;border-radius:14px}.muted{color:var(--muted)}.footer{padding:44px 0 56px;color:var(--muted);font-size:11px}
@media(max-width:920px){.hero-grid,.task-layout{grid-template-columns:1fr}.chart-card{position:static}.profile-grid{grid-template-columns:1fr 1fr}.nav{display:none}.task-metrics{grid-template-columns:1fr 1fr}}
@media(max-width:580px){.container{width:min(92vw,1180px)}.hero{padding-top:42px}.metric-grid,.profile-grid,.boundary,.division,.step-grid{grid-template-columns:1fr}.section-head{display:block}.section-head p{margin-top:10px}.transition{grid-template-columns:1fr}.arrow{transform:rotate(90deg)}.task-head{display:block}.task-result{text-align:left;margin-top:8px}.source-list li{display:block}.source-list span{display:block;text-align:left;margin-top:4px}.brand small{display:none}}
"""

    js = r"""
const links=[...document.querySelectorAll('.nav a')];
const sections=links.map(a=>document.querySelector(a.getAttribute('href'))).filter(Boolean);
const sectionObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){links.forEach(a=>a.classList.toggle('active',a.getAttribute('href')==='#'+entry.target.id));}}),{rootMargin:'-30% 0px -60% 0px'});
sections.forEach(section=>sectionObserver.observe(section));
const barObserver=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.style.width=entry.target.dataset.value+'%';barObserver.unobserve(entry.target);}}),{threshold:.2});
document.querySelectorAll('.range-high,.range-low').forEach(bar=>barObserver.observe(bar));
document.querySelectorAll('.worker-toggle').forEach(button=>button.addEventListener('click',()=>{const detail=button.nextElementSibling;const open=button.getAttribute('aria-expanded')==='true';button.setAttribute('aria-expanded',String(!open));detail.hidden=open;button.querySelector('.chevron').textContent=open?'＋':'－';}));
document.querySelectorAll('.week-tab').forEach(tab=>tab.addEventListener('click',()=>{const week=tab.dataset.week;document.querySelectorAll('.week-tab').forEach(item=>{const active=item===tab;item.classList.toggle('active',active);item.setAttribute('aria-selected',String(active));});document.querySelectorAll('.week-panel').forEach(panel=>{const active=panel.dataset.panel===week;panel.hidden=!active;panel.classList.toggle('active',active);});}));
"""

    nav = (
        ("overview", "总览"),
        ("profile", "岗位"),
        ("tasks", "步骤"),
        ("workers", "方案"),
        ("division", "分工"),
        ("transition", "变化"),
        ("plan", "计划"),
        ("sources", "证据"),
    )
    nav_html = "".join(f'<a href="#{anchor}">{label}</a>' for anchor, label in nav)
    readiness = summary.get("readiness_score", {})
    capability = summary.get("capability_score", {})
    formal_label = "可生成正式报告" if summary.get("formal_report_ready") else "阶段性报告"
    risk_html = "".join(f'<span class="risk">风险：{h(value)}</span>' for value in risks)
    unknown_html = (
        f'<div class="unknown-box"><b>待确认：</b>{h("；".join(str(value) for value in unknowns))}</div>'
        if unknowns
        else ""
    )

    return f"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{h(title)}</title><style>{css}</style></head><body>
<header class="topbar"><div class="brand">岗位 AI 分析<small>替代 · 增强 · 人主导</small></div><nav class="nav">{nav_html}</nav></header>
<main>
<section id="overview" class="hero"><div class="container">
  <div class="hero-grid"><div><span class="eyebrow">{h(mode)}模式 · {h(confidence)}置信度 · {h(formal_label)}</span>
    <h1>{h(title)}</h1><p class="lead">{h(report_summary)}</p><div class="thesis">核心命题：{h(thesis)}</div>
    <p class="hero-meta">评估日期：{h(meta.get("date", "未填写"))} · 团队：{h(meta.get("team", "未填写"))} · 结果描述工作步骤，不等于人员替代比例</p>
  </div><div class="metric-grid">
    {metric_card("现在可替代", summary.get("current_replaceable_pct"), "当前条件下可由 AI 执行，人负责验收", "cyan")}
    {metric_card("条件成熟可替代", summary.get("conditional_replaceable_pct"), "包含解决数据、权限、集成或验证后的机会", "orange")}
    {metric_card("AI 增强覆盖", summary.get("ai_augmentable_pct"), "包含执行、条件执行和协作增强步骤", "blue")}
    {metric_card("当前 AI 参与", summary.get("current_ai_usage_pct"), "来自员工确认的实际使用，不代表效果", "ink")}
  </div></div>
  <div class="coverage-strip">
    <span>任务时间覆盖 <b>{h(pct(summary.get("task_time_coverage_pct")))}</b></span>
    <span>已评估工作覆盖 <b>{h(pct(summary.get("assessed_work_coverage_pct")))}</b></span>
    <span>证据覆盖 <b>{h(pct(summary.get("evidence_coverage_pct")))}</b></span>
    <span>AI 技术匹配 <b>{h(score_text(capability))}</b></span>
    <span>落地准备度 <b>{h(score_text(readiness))}</b></span>
    <span>当前使用成熟度 <b>{h(score_text(maturity))}</b></span>
  </div>
</div></section>

<section id="profile"><div class="container"><div class="section-head"><div><span class="section-kicker">01 / ROLE CONTEXT</span><h2>公司与岗位背景</h2></div><p>公开资料帮助理解业务，但员工实际工作只以用户确认、近期实例、样本或试验为准。</p></div>
  <div class="profile-grid">
    <article class="info-card"><h3>核心职责</h3><ul>{list_items(profile.get("responsibilities", []))}</ul></article>
    <article class="info-card"><h3>主要产出</h3><ul>{list_items(profile.get("outputs", []))}</ul></article>
    <article class="info-card"><h3>人的能力</h3><ul>{list_items(profile.get("capabilities", []))}</ul></article>
    <article class="info-card"><h3>典型痛点</h3><ul>{list_items(profile.get("pain_points", []))}</ul></article>
  </div><div class="why-ai">{h(profile.get("why_ai", "待补充：为什么这个岗位值得进行 AI 替代与增强分析？"))}</div>
</div></section>

<section id="tasks"><div class="container"><div class="section-head"><div><span class="section-kicker">02 / STEP MAP</span><h2>工作步骤与 AI 边界</h2></div><p>实线为已确认下界，浅色为尚未评估部分可能形成的上界。区间越宽，越需要继续取证。</p></div>
  <div class="task-layout"><div class="task-list">{task_rows(data.get("tasks", []))}</div><aside class="chart-card">{radar_svg(dimensions)}</aside></div>
</div></section>

<section id="workers"><div class="container"><div class="section-head"><div><span class="section-kicker">03 / AI WORKFLOWS</span><h2>可落地的 AI 方案</h2></div><p>每个方案都要对应已确认步骤，并写清 AI 产出、人工验收和使用条件。</p></div><div class="worker-list">{worker_cards(data.get("workers", []))}</div></div></section>

<section id="division"><div class="container"><div class="section-head"><div><span class="section-kicker">04 / HUMAN + AI</span><h2>人机分工与责任</h2></div><p>AI 可以承担执行，人保留需要判断、关系、承诺和风险责任的部分。</p></div>
  <div class="division"><article class="division-box"><h3>AI 负责</h3><ul>{list_items(division.get("ai", []))}</ul></article><article class="division-box"><h3>人负责</h3><ul>{list_items(division.get("human", []))}</ul></article></div>
  <div class="principle">{h(division.get("principle", "责任不外包：最终判断、对外承诺和风险承担仍由人负责。"))}</div>
</div></section>

<section id="transition"><div class="container"><div class="section-head"><div><span class="section-kicker">05 / ROLE SHIFT</span><h2>岗位价值变化</h2></div><p>岗位时间被重新分配，不等于岗位或人员被替代。</p></div>
  <div class="transition"><article class="role-card"><h3>当前状态</h3><p>{h(transition.get("old_role", "待补充"))}</p></article><div class="arrow">→</div><article class="role-card new"><h3>目标状态</h3><p>{h(transition.get("new_role", "待补充"))}</p></article></div>
  <div class="gain-list">{"".join(f'<span class="gain">{h(value)}</span>' for value in gains)}</div>
</div></section>

<section id="plan"><div class="container"><div class="section-head"><div><span class="section-kicker">06 / PILOT PLAN</span><h2>试点与验证计划</h2></div><p>从高频、低风险、可验收的步骤开始，用真实结果修正能力判断。</p></div>{plan_tabs(data.get("plan", []))}</div></section>

<section id="sources"><div class="container"><div class="section-head"><div><span class="section-kicker">07 / EVIDENCE</span><h2>来源、不确定性与风险</h2></div><p>公司事实、工作事实和 AI 能力证据分开记录；缺口不会被自动填成分数。</p></div>
  <ul class="source-list">{source_rows(data.get("sources", []))}</ul><div class="risk-grid">{risk_html}</div>{unknown_html}
</div></section>
</main>
<footer class="footer container"><p>本报告用于个人工作方式探索，不作为绩效、招聘、裁撤、薪酬或人员替代决策依据。报告中的比例描述工作步骤，不等于岗位人数。</p><p>结果取决于任务事实、当前 AI 能力、数据权限、风险控制和试验效果；区间与未知项应在试点后更新。</p></footer>
<script>{js}</script></body></html>"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, help="score_role.py V2 output JSON")
    parser.add_argument("--output", required=True, help="output HTML path")
    args = parser.parse_args()
    try:
        data = json.loads(Path(args.input).read_text(encoding="utf-8"))
        html = build_html(data)
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(html, encoding="utf-8")
        print(f"generated {output} ({output.stat().st_size} bytes)")
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        print(f"generate_html_report.py: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
