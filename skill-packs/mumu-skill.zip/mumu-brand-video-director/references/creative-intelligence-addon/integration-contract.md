# Creative Intelligence 可选增强模块｜接入契约

本模块只在现有 18 步工作流的第 5 步“创意探索”内部提供辅助思维。不得新增、删除、替换、重排或重解释任何核心步骤；不得接管故事卡、完整故事、分镜、资产、提示词、生成、修复、声音、落版、QA 或归档。

## 运行边界

- 把本模块视为可拔除的参考层，不视为第二条工作流、第二个状态机或新的生产入口。
- 仅在 Brief、客户事实、活动意图和核心变化已经锁定，且尚未选定成熟创意方向时调用。
- 不因本模块新增用户问卷、确认门、工具调用、生成次数、项目状态字段或持久化依赖。
- 本模块只能提出候选判断；所有结果仍须经过原有轻量创意对抗、世界模拟、品牌不可替换性、Story Contract、资产 Gate 与统一 QA。
- 原始资料中关于 Story、Director、Production、运行状态机或 DirectorHandoff 的内容只作为来源附件保留，不在幕幕运行时执行。

## 调用模式

使用两态控制，默认 `off`：

- `off`：用户明确不需要创意增强时不调用。
- `on`：只有用户明确要求启用 Creative Intelligence、商业立意、品牌愿景、创意联想、母意象或创意算子增强时，才在创意探索阶段调用一次。

不得在 onboarding、事实研究、故事锁定后、分镜、资产、视频生成、局部修复、声音、落版、质检或归档阶段补调用。

## 最小调用顺序

1. 读取 `strategy-brain.md`，只补充“商业目的、旧认知→新认知、品牌立意、人类命题”的候选。
2. 需要愿景、概念纵深或母意象时读取 `imagination-brain.md`。
3. 需要变异时读取 `operator-library-64.md`，每个方向最多选择 2 个主算子和 1 个辅助算子。
4. 只有需要案例基因或相似风险检查时才读取 `case-index-01-100.jsonl`；按商业目的、人类命题、算子、媒介和生产风险检索 3–5 条，不按品牌/品类关键词寻找最像的剧情。
5. 读取 `qa-failsafe.md` 做原创、品牌回归和默认 AI 视觉检查。

不得一次加载完整案例库，也不得把案例名称、人物、道具、场景、标志动作或结尾作为生成模板。只允许迁移“商业问题 → 概念跃迁 → 算子 → 母意象 → 品牌回归”的抽象机制。

## 唯一允许的输出

把结果作为第 5 步的临时候选素材，不直接写入下游合同：

```yaml
creative_intelligence_suggestion:
  business_shift: "从___到___"
  brand_thesis: "我们不是在说___，而是在说___"
  human_thesis: []
  future_change: ""
  master_image: ""
  operators:
    primary: []
    auxiliary: []
  territory_seed: ""
  brand_return: ""
  similarity_risk: "low | medium | high"
```

原工作流可吸收、改写或完全丢弃这份临时候选。它不得覆盖已确认事实、活动目的、品牌资产、故事合同或 Production Master Plan。

## 失败开放与稳定性

出现任一情况时立即标记为 `skipped` 并继续原第 5 步，不重试、不阻断、不降级核心交付：

- 文件缺失、无法读取、格式异常或案例索引解析失败；
- 输出越过创意探索边界，开始改写故事、分镜、资产、生成或质检；
- 引入新的确认轮次、明显增加上下文负担或导致宿主不稳定；
- 方向收敛为案例换皮、默认科技视觉或与客户事实冲突；
- 任何异常影响原流程的确定性、时限或可执行性。

跳过时无需向用户展开内部错误；沿用原有 `meaning-network.md` 与 `creative-adversarial-lab.md` 完成创意探索。除非用户主动排查本模块，否则不要为了附件故障暂停项目。

## 资料导航

- 商业目的、品牌立意、人类命题：`strategy-brain.md`
- 未来想象、概念跃迁、母意象：`imagination-brain.md`
- 64 个创意算子：`operator-library-64.md`
- 100 案例基因索引：`case-index-01-100.jsonl`
- 案例来源与编号清单：`case-manifest.json`
- 原创与品牌回归检查：`qa-failsafe.md`
- 用户提供的 V1.1 原始整合包：`../../assets/source-attachments/mumu-creative-intelligence-v1.1-source.zip`。仅用于来源留存，不作为运行时必读文件。
