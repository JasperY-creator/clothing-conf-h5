# 幕幕 · 运行控制与状态机

本文件定义确认模式、项目状态、规则优先级、执行门、异常恢复和素材槽。任何能读取 Markdown 的智能体平台都可使用。

## 一、确认模式

| 模式 | 运行方式 |
|---|---|
| 标准模式（默认） | 按 Brief、主创意、故事与锚点、视频执行、最终交付分阶段确认 |
| 导演代理模式 | 用户明确授权后，幕幕代做低风险导演选择，保留红线确认 |
| 快速确认 | 把同一批锚点或同一批生成参数汇总为一次总确认 |

不可代理：客户事实、客户 Logo 官方文件及“Logo确认”、关键文字原文、企业名/活动主题/日期地点/产品 UI/法律文字、母题与主创意、时长/画幅/播放场景/是否对外、付费或大额度生成、最终商用。

## 二、唯一项目状态

平台支持文件时存 `project_state.json`；不支持则在对话中维护结构化摘要。

```json
{
  "project_id": "", "project_name": "", "owner": "",
  "mode": "standard", "quality_profile": "standard", "capability_level": "L3",
  "watermark_policy": "preserve_doubao_attribution",
  "host": {"name": "", "tenant": "", "detected_at": ""},
  "tools": {
    "reasoning": [], "image_generation": [], "image_edit": [],
    "video_generation": [], "video_extension": [], "video_repair": [],
    "multimodal_review": [], "ocr": [], "voice_generation": [],
    "music_generation": [], "music_library": [], "audio_analysis": [],
    "editing": [], "deterministic_compositing": [], "static_insertion": [], "web_or_knowledge_research": [],
    "max_duration_s": null,
    "max_reference_images": null,
    "downloadable": "unknown"
  },
  "model_bindings": {},
  "model_fallbacks": {},
  "project_paths": {"root": "", "manifest": "", "production_master_plan": ""},
  "brief": {
    "scene": "", "client": "", "industry": "",
    "cooperation_background": "", "relationship": "undecided", "audience": "",
    "core_message": "", "core_change": "", "duration": "", "aspect_ratio": "",
    "delivery_boundary": ""
  },
  "research": {
    "client_entity": {"legal_name": "", "brand": "", "sub_brand": "", "region": "", "confidence": ""},
    "brand_story": {
      "mode": "silent_official_first", "status": "not_started", "accessed_at": "",
      "sources": [], "story_cards": [], "continuity_theme": "", "confidence": ""
    },
    "product_truth": {
      "mode": "silent_auto", "status": "not_started", "accessed_at": "",
      "sources": [], "product_matrix": {}, "identity_cards": [],
      "selected_product_ids": [], "confidence": ""
    },
    "world_logic": {"mode": "silent_risk_based", "status": "not_started", "applicable_dimensions": [], "logic_cards": []}
  },
  "casting": {
    "market_context": "china_default", "people_default": "chinese_context",
    "exceptions": [], "character_cards": [],
    "wardrobe_mode": "undecided",
    "official_uniform_sources": [], "wardrobe_references": []
  },
  "creative": {
    "director_contract": {
      "event_type": "", "audience": "", "relationship": "undecided",
      "client_business_object": "", "core_change": "", "future_landing": "",
      "carrier": "", "date_location_required": false, "forbidden_claims": [],
      "status": "not_started"
    },
    "event_fusion": {
      "event_intent_card": {}, "narrative_route": "undecided",
      "fusion_formula": "", "information_budget": {
        "brand_truth": "", "event_purpose": "", "main_change": "", "future_landing": "",
        "optional_details": [], "removed_details": []
      }
    },
    "adversarial_lab": {
      "mode": "silent_light", "tension_card": {}, "active_lenses": [],
      "candidate_niches": [], "structural_bridges": [],
      "strongest_objections": [], "world_simulation_notes": [],
      "selected_synthesis": {}, "extra_questions": 0,
      "extra_generation_calls": 0
    },
    "feishu_doubao_binding": {
      "mode": "auto_on_when_applicable", "intensity": "story_functional",
      "reuse_existing_ai_beat": true, "extra_questions": 0,
      "extra_anchors": 0, "extra_generation_calls": 0,
      "doubao_in_signing_end_slate": false,
      "character_mode": "B_recommended_for_client_film",
      "action_required": true,
      "identity_reference_loaded": false,
      "native_reference_loaded": false,
      "client_co_created_design": {
        "client_role": "", "core_symbol": "", "design_metaphor": "", "silhouette": "",
        "brand_colors": [], "material": "", "signature_accessory": "",
        "verified_prop": "", "motion_signature": "", "reference_scope": "character_only", "forbidden": []
      }
    },
    "meaning_network": {
      "mode": "silent_light", "real_tension": "", "human_consequence": "",
      "core_theme": "", "brand_agency": "", "visual_carrier": "",
      "candidate_clusters": []
    },
    "brand_dna": {}, "film_theme": "", "style_route": "",
    "consistency_lock": {}, "selected_direction": "", "status": "待输入"
  },
  "story": {
    "thesis": "", "narrative_route": "", "causal_chain": [], "feishu_ai_role": "",
    "ending_state": "", "audio_intent": "",
    "story_contract": {
      "brand_truth": "", "subject": "", "initial_state": "",
      "goal_or_obstacle": "", "client_action": "", "ai_action": "",
      "visible_result": "", "carrier": "", "future_landing": "",
      "forbidden_claims": []
    },
    "status": "待输入"
  },
  "generation_route": "undecided",
  "storyboard_route": "sparse_keyframes",
  "story_units": [],
  "rhythm_plans": [],
  "storyboard": [],
  "story_anchor_board": [],
  "anchor_registry": [],
  "global_director_bible": {
    "visual_thesis": "", "lens_family": "", "camera_height": "",
    "composition": "", "movement_personality": "", "depth_of_field": "",
    "exposure": "", "light_ratio_direction": "", "color_temperature_arc": "",
    "material_response": "", "transition_grammar": "", "forbidden": [],
    "status": "not_started"
  },
  "handoff_cards": [],
  "event_copy": {
    "copy_id": "", "text": "", "event_name": "", "closing_statement": "",
    "display_event_name": false, "closing_statement_deleted_by_owner": false,
    "source": "undecided", "event_type": "", "confirmed": false, "forbidden_variants": []
  },
  "end_slate": {
    "required": false, "delivery_mode": "not_required",
    "render_method": "none", "deterministic_compositor_verified": false,
    "video_insertion_mode": "none", "platform_asset_manifest_verified": false,
    "safe_omission_confirmed": false, "omission_reason": "",
    "model_generated_readable_text": false, "theme": "light",
    "relation": "neutral", "logo_presentation": "none", "copy_id": "", "date": "", "location": "",
    "bridge": {}, "tail_duration_seconds": 0, "source_reference_route": "",
    "handoff_contract": {}, "seam_review_confirmed": false,
    "master_path": "", "clean_plate_path": "", "manifest_path": "",
    "overlay_path": "", "overlay_timeline_path": "", "veil_opacity": 228,
    "veil_path": "", "light_path": "", "logos_path": "", "message_path": "",
    "watermark_safe_area": [], "segment_review_confirmed": false,
    "preserve_doubao_attribution_watermark": true
  },
  "asset_readiness": {
    "preflight_gate": {"status": "not_started", "checked_at": "", "blocking_asset_ids": []},
    "asset_registry": [],
    "visual_lock_pending": [],
    "post_asset_pending": [],
    "client_logo": {
      "required": "unknown", "status": "not_requested",
      "file_name": "", "source": "", "variant": "",
      "intended_use": [], "owner_confirmed": false,
      "confirmed_at": "", "normalization_status": "not_started",
      "normalization_manifest": ""
    },
    "exact_text": {"status": "not_started", "cards": [], "pending_text_ids": [], "manifest": ""},
    "world_logic": {"status": "not_started", "pending_logic_ids": []},
    "product_truth": {"status": "not_started", "pending_product_ids": []},
    "casting_wardrobe": {"status": "not_started", "pending_reference_ids": []}
  },
  "long_video_prompts": [],
  "execution_gate": {
    "state": "DRAFT", "batch_id": "", "confirmed_signature": "",
    "confirmed_at": "", "execution_started_at": ""
  },
  "long_video_outputs": [],
  "segment_review": {
    "required": false, "u1_status": "not_started", "u2_status": "not_started",
    "owner_decision": "pending", "execution_order_verified": false,
    "handoff_reference_route": "", "handoff_contract": {},
    "seam_review_window_seconds": 2, "seam_qc_pass": false,
    "transition_type": "undecided", "transition_frames": 0, "ending_copy_presented": false,
    "client_logo_status_presented": false, "feishu_logo_status_presented": false
  },
  "repair_shots": [],
  "constraint_budget": {
    "risk_level": "unknown", "dimensions": {}, "hard_constraints": [],
    "mitigations": [], "recommended_storyboard_route": "sparse_keyframes",
    "decision_reason": "", "same_mode_failures": 0
  },
  "production_master_plan": {
    "revision": "", "source": "project_state", "read_only": true,
    "frozen_at": "", "status": "not_frozen", "supersedes": "",
    "snapshot_hash": ""
  },
  "qa_gates": {
    "fact_gate": "not_started", "story_gate": "not_started",
    "storyboard_gate": "not_started", "generation_gate": "not_started",
    "audio_gate": "not_started", "brand_finish_gate": "not_started",
    "final_gate": "not_started", "report_path": ""
  },
  "editing": {"timeline": [], "post_tasks": [], "exact_text_tasks": [], "default_segment_transition": "conditional_by_motion", "transition_frames": 0, "status": "待输入"},
  "audio": {
    "route": "undecided", "narration_required": true, "narration_waived_by_owner": false,
    "voice_plan": {}, "voice_reference_id": "",
    "music_direction": {}, "brand_sound_motif": {}, "cue_sheet": [],
    "narration_cues": [], "sound_bridge": [], "scratch_status": "not_started",
    "final_generation_status": "not_started", "mix_status": "待输入",
    "copyright_status": "unknown"
  },
  "decisions": [], "risks": [], "updated_at": ""
}
```

`generation_route` 允许：`long_story`、`micro_shot_repair`、`prompt_only`。新建 30–60 秒项目且宿主有可靠长视频能力时默认 `long_story`。

`creative.director_contract`、`story.story_contract`、`event_copy` 与 `end_slate` 构成单一合同链。V1.76 的签约、启动会与 AI 先锋活动优先 `delivery_mode=cinematic_narrative_tail`：从正片真实末段继续 4–6 秒动作、空间、材质、光线与声音，准确 Logo 与宣传语由确定性动态图层自然显现。默认路线异常时降级为 V1.75 `seedance_end_ui_overlay`，再使用 `deterministic_png` 或 `omitted_no_compositor`；不再存在签约海报垫图路线。所有路线固定 `model_generated_readable_text=false`，并为豆包官方归因水印保留安全区。

`storyboard` 的每一项按 `references/schemas/storyboard.schema.json` 记录镜头功能、前后状态和删除损失。`qa_gates` 只使用 `fact/story/storyboard/generation/audio/brand_finish/final` 七道统一门；自动检查可调用 `scripts/qa_project.py`。

`storyboard_route` 是独立的分镜子路线，允许：

- `sparse_keyframes`：默认。15/30 秒使用 2 张、45/60 秒使用 4 张独立关键帧，直接锁定世界、身份、交接和收束。
- `asset_assisted_sparse`：人物、豆包、英雄产品、跨时代或多场景一致性压力较高时，在同样 2/4 张预算内附加已登记身份、服装、产品或空间资产。
- `legacy_multigrid`：只有用户明确要求完整导演画册或排查阅读顺序时临时使用；整张拼图不得直接喂给 Seedance，也不得成为正式视频生成的前置依赖。

### Preflight Asset Gate 与单一事实源

第一张故事图前，把客户/平台 Logo、豆包身份与项目造型、核心人物、英雄产品、关键文字和必要 VI 逐项登记到 `asset_registry`。每项至少记录 `asset_id`、类型、来源、文件/路径、哈希、`reference_scope`、确认状态、允许用途、禁止变体和依赖单元。复用同一张品牌准确资产确认卡；不要为 Gate 新增一轮问卷。

缺少会改变主体身份、品牌真值或必要镜头的资产时，映射到既有 `HOLD_FOR_ASSETS / HOLD_FOR_LOGO / HOLD_FOR_TEXT_ASSET / PRODUCT_FACT_PENDING`，不新建循环状态。已确认资产必须在画册、单格、视频、修复和品牌落版中持续引用同一 ID；不得降级引用画册裁切图来替代可用的原始身份/产品资产。

`project_state` 始终是唯一可编辑事实源。故事、资产、时长、双层路由、摄影圣经、节奏、声音和执行参数锁定后，把必要字段冻结成 `production_master_plan` 修订版（`PMP-R01` 起）。它是只读执行快照，不得独立改写；发生有效修改时先更新 `project_state`，再生成 `PMP-R02…`，旧版本保留追溯。下游默认读取当前 PMP 与本单元必要资产，避免重复推理长规则。

## 三、阶段状态与执行门

内容阶段状态：待输入 / 待选择 / 已确认 / 需回修 / 已锁定。

视频执行门是独立状态机：

```text
DRAFT → PLAN_CONFIRMED
PLAN_CONFIRMED → WAIT_EXECUTION_AUTH                 （素材已齐）
PLAN_CONFIRMED → HOLD_FOR_ASSETS → WAIT_EXECUTION_AUTH（素材待补）
PLAN_CONFIRMED → PRODUCT_FACT_PENDING → WAIT_EXECUTION_AUTH（精确产品待核实或改用安全方案）
PLAN_CONFIRMED → WORLD_LOGIC_PENDING → WAIT_EXECUTION_AUTH（关键现实逻辑待核实或避开细节）
PLAN_CONFIRMED → HOLD_FOR_LOGO → WAIT_EXECUTION_AUTH （必要 Logo 待上传/确认）
PLAN_CONFIRMED → HOLD_FOR_TEXT_ASSET → WAIT_EXECUTION_AUTH（必要精确文字待确认或建立确定性图层）
WAIT_EXECUTION_AUTH → EXECUTE → REVIEW → COMPLETE
任一执行前状态 → BLOCKED                              （工具/权限阻塞）
REVIEW → REVISE_PROMPT / REBUILD_ANCHOR / MICRO_REPAIR → WAIT_EXECUTION_AUTH
```

规则：

1. 用户确认故事、方案或锚点后进入 `PLAN_CONFIRMED`；这不是视频执行授权。
2. 缺少会改变画风/主体/构图的主视觉、产品/IP 参考等素材时进入 `HOLD_FOR_ASSETS`。精确产品无法核实时进入 `PRODUCT_FACT_PENDING`；关键现实逻辑无法核实时进入 `WORLD_LOGIC_PENDING`。用户补充可靠材料，或导演改为不展示具体细节的安全方案后才继续。必要客户 Logo 未确认时进入 `HOLD_FOR_LOGO`；必要关键文字未确认或无法确定性实现时进入 `HOLD_FOR_TEXT_ASSET`。最终交付无条件受 Logo 与精确文字 QA 阻断。
3. 素材与参数齐备后冻结当前 PMP 并进入 `WAIT_EXECUTION_AUTH`，输出一次执行摘要：`batch_id`、PMP 修订号、宿主与模型绑定、叙事路线与信息预算、故事单元、视频/分镜双层路由、摄影圣经、动态节奏表与 Cue Sheet、Preflight Asset Gate、产品/世界逻辑、Logo/文字、风险与降级、Anchor 分类、分段交接、版本数、预计额度、输出目录和确定性后期层。
4. 只有 owner 明确回复“开始生成 / 按此执行 / 确认并开始生成”等执行授权后，才计算并保存本批 `confirmed_signature`，切到 `EXECUTE`。单独“确认方案”不触发。
5. 任何多段视频默认同属一个批次并只授权一次；授权后必须顺序执行，先生成并检查 U1，再以真实 U1 视频、尾视频、真实尾帧或共享 Handoff 生成 U2。只有实际参数或额度必须等前段返回才能确定时才拆批，不因顺序执行增加确认。
6. `EXECUTE` 状态必须调用宿主工具或明确报告工具/权限阻塞；不得再次询问同一份参数。
7. 仅当故事、事实、品牌素材、时长、比例、生成次数或预计额度改变时，生成新签名并重新请求授权。
8. 生成完成进入 `REVIEW`；拆段项目此时必须完成一次全片合并审片确认，展示各段结果、修改入口、实际接缝方式、动态尾声、宣传语和 Logo 状态。任何追加的付费重生成都必须形成新批次。

这条状态机用于消除“用户已确认，但智能体仍停留在确认话术”的死循环。

## 四、每轮输出与状态摘要

每轮优先四段：决策、素材、执行、质检。进入新阶段前复述：场景/时长/画幅、主创意与故事主张、生成路线、已确认锚点或结果、待确认素材、执行门状态、下一步唯一动作。

## 五、事件与最小回退

| 事件 | 最小回退 |
|---|---|
| 业务理解不准 | Brief / 品牌 DNA |
| 品牌故事来源、活动意义或叙事路线不对 | 品牌故事卡、活动意图卡与融合路线 |
| 母题或故事主张不对 | 创意方向 |
| 因果链看不懂 | 完整故事 |
| 任意片长拆分生硬 | 故事单元自然边界与动态 Handoff |
| 交接处人物/空间/光线/运动不连续 | 优先真实视频续写/尾视频/真实尾帧与动态交接卡，再重生成后段开头 |
| 缝合点前后 2 秒出现速度、焦段感、服装、背景或光色跳变 | 优先重做 U2 开头或真实尾帧/共享边界，不用闪白掩盖 |
| 整段风格/角色/世界失稳 | 相关锚点，再重生成整个故事单元 |
| 第一张关键帧前的核心身份/产品/Logo 资产缺失 | Preflight Asset Gate；补原始资产或改写不依赖该资产的安全方案 |
| 稀疏关键帧在复杂人物/产品项目中漂移 | `asset_assisted_sparse`；仍失败时跳过生图，把已确认身份/产品参考直接交给 Seedance |
| 电影化动态尾声或准确品牌层不稳 | 停止默认路线重试，降级到 `seedance_end_ui_overlay`；仍失败则 `deterministic_png / omitted_no_compositor`，始终跳过 Seedream 海报 |
| 豆包官方归因水印被遮挡、打码、模糊、裁切或覆盖 | 阻断交付；回到未破坏水印的源视频重新导出 |
| 整段故事无因果 | 长提示词或故事单元，不新增碎片 |
| 仅 5–10 秒孤立缺陷 | 短镜修复，首尾取自原片 |
| 客户 Logo 缺失、未确认或不准 | `HOLD_FOR_LOGO`；只接受 owner 确认的真实资产 |
| 客户实体、代表产品、包装或型号不确定 | `PRODUCT_FACT_PENDING`；补官方来源或避开具体产品近景 |
| 物种/原料、工艺、季节、使用方式、比例、时代或职业行为不确定 | `WORLD_LOGIC_PENDING`；补可靠来源或改用不展示细节的安全方案 |
| 人物市场语境或服装真实性错误 | 选角卡、A/B/C 服装模式与主参考，再重生成受影响锚点/单元 |
| 关键文字/日期/UI 不准或跨帧漂移 | `HOLD_FOR_TEXT_ASSET` 或 `TEXT_LAYER_CONTAMINATED`；回无字底图与确定性图层并做全时段 QA |
| 修正一项后引入换脸、产品变形或其他回归 | 拒绝候选结果；执行本次目标检查 + 全片红线回归 |
| 3D 豆包、真人、精确产品或文字等多约束同框规律性失败 | 停止同方式重试；局部出镜、拆镜、时空分离或后期合成 |
| 音乐/旁白节奏或语义不对 | 回声音路线、Cue Sheet 或最终音频生成；只有核心主张改变时才回故事 |
| 工具失败或额度不足 | 保存状态，降级提示词或暂停批次 |
| 跨天恢复 | 复述状态与执行门，不重复已完成阶段 |

## 六、规则优先级

1. 安全、隐私、版权、商用合规、品牌准确性。
2. 用户明确指令和 owner 已确认内容。
3. 宿主真实工具能力、模型绑定与参数上限。
4. 项目状态中已确认/已锁定内容及执行门。
5. 场景专用模式。
6. 长故事默认路由。
7. 表达风格、效率偏好、低风险优化建议。

## 七、启动能力检测

按 `capability-routing.md` 检测并记录：宿主与租户、推理/生图/修图/视频/续写/修复/质检/OCR/音频分析/剪辑/确定性合成候选，模型与版本、单次最大时长、比例、参考素材、分辨率、声音、并发/单批上限、下载、额度与回退。不要仅因 Skill 或历史案例写了某个型号就假设宿主存在。

```text
当前能力边界：
- 有可靠视频工具且支持目标故事单元：默认长故事生成并锁定本批模型。
- 有视频工具但时长较短：按最长原生时长重排故事单元。
- 没有视频工具：交付完整故事、锚点和可复制长提示词。
- 没有可靠剪辑工具：交付最小后期任务，不假装完成商业成片。
```

## 八、创意多样性

不能把所有客户套成“品牌符号→AI 能量流→双 Logo UI”。每个方向必须来自客户产品/品类、代表动作/流程、材质/感官、人的体验/后果和经营系统/战略等事实节点，并在叙事结构、主视觉载体、转场语法和情绪/形式生态位上不同。给 2–3 个方向时至少两个不以光为主载体，至少一个不走宏大/温情/科技光效路线；地球/全球地图只有在全球业务事实已核实时启用。多个方案仅换名字、品牌色或特效但结构相同，或连续自动出现工匠、老人、代际传承、光线/粒子，视为模式坍缩，必须按 `creative-adversarial-lab.md` 激活相反生态位、一个反方和最强反对意见后重写。

## 九、生成风险预测与停止重试

在关键帧前和视频前各评估一次：主体/身份数量、参考资产可靠度、跨时代/跨场景跨度、渲染语言冲突、精确产品/文字、复杂动作与接触、镜头连续性、宿主参考图/时长能力。记录 `LOW / MEDIUM / HIGH / CRITICAL` 与证据，不只给模糊“高风险”。每个必须一致的脸、3D/真人风格、P2 英雄产品、准确 Logo/文字、复杂手部交互、特殊工艺动作和跨主体接触都算硬约束。

- 3D 豆包与写实真人近景同框；
- 三个以上强身份主体同框；
- 精确产品、可读文字和复杂动作同时出现；
- 多个不同渲染语言主体发生手递手、拥抱或遮挡；
- 同一画面要求模型同时保持脸、服装、产品包装、文字和真实工艺。

LOW 默认 `sparse_keyframes`；MEDIUM 在同样 2/4 张预算内加强原始资产引用与硬锚点；HIGH/CRITICAL 优先 `asset_assisted_sparse`、拆镜/简化/确定性图层，或跳过不稳定生图并把已确认参考直接交给 Seedance。高风险画面在付费生成前还可选择局部出镜、时空分离、减少主体、降低可读文字、使用真实素材或后期合成。降级是导演重构，不是用闪光遮错。

同一画面连续两次出现相同规律性失败时，停止同方式重试并更换结构；第三次只允许在约束或素材方案已经实质变化、且 owner 重新授权额度后执行。不得用重复抽卡消耗预算。

## 十、素材槽

| 素材槽 | 用途 |
|---|---|
| `@A01…` | 第一故事单元的顺序、构图、角色与风格锚点 |
| `@B01…` | 第二故事单元锚点 |
| `@U1尾帧_U2首帧交接锚点` | 任意片长拆段时的静态 Handoff 降级锚点 |
| `@动态分段交接卡` | 任意拆段的共享执行合同；记录动作相位、视线/重心、镜头惯性、焦点/景深、轴线/背景、光线/材质、唯一载体、声音连续和禁止变化 |
| `@真实U1尾视频` | U1 已生成时截取的尾部动态参考；直接续写不可用时优先于静态尾帧 |
| `@真实U1尾帧` | U1 已生成时导出的真实边界；尾视频参考不可用时与动态交接卡共同作为 U2 输入 |
| `@电影化动态尾声` | 正片末段延展 4–6 秒的动作/空间/材质/光线/声音收束；准确 Logo 和宣传语为后期确定性图层 |
| `@选角卡-Cxx` | 锁定人物市场/地域语境、年龄、职业、脸型、发型、体态与角色连续性 |
| `@服装主参考-Cxx` | 锁定 A 官方工服 / B 影片客户品牌共创造型 / C 中性职业造型；A/B/C 身份不可混淆 |
| `@产品身份卡-Pxx` | 记录官方产品名、品类、代表性、当前状态、外形锁、来源、日期、置信度与禁止混淆项 |
| `@官方产品参考-Pxx` | 可识别产品的官方外观参考；要求精确外观时必须实际传入 |
| `@产品主参考基准图-Pxx` | P2 英雄产品的统一结构合同；锁定形制、比例、厚度、封口和标签区 |
| `@真实逻辑卡-WLxx` | 锁定相关物种、工艺、季节、使用方式、比例、时代或职业行为 |
| `@修复首帧` / `@修复尾帧` | 5–10s 局部修复，不用于默认全片拆镜 |
| `@已确认客户Logo` | 仅限用户/owner 上传或确认的项目资产；记录版本、用途、确认人与哈希，后期准确合成，禁止联网寻找或生成 |
| `@飞书官方Logo-深字版` | Skill 内置 `assets/feishu-logo/feishu-logo-color-dark-text.pdf` 或透明 PNG；仅用于浅色背景，真实资产确定性合成 |
| `@飞书官方Logo-白字版` | Skill 内置 `assets/feishu-logo/feishu-logo-color-white-text.pdf` 或透明 PNG；仅用于深色背景，真实资产确定性合成 |
| `@平台方Logo` | 其他平台 Logo 使用已确认真实资产后期准确合成 |
| `@豆包企业版三视图母版` | A/B 模式必需；映射 `assets/doubao-character/doubao-enterprise-turnaround.png`。三视图是同一个角色，锁定脸、发型、头身比例与 3D 建模；环境风格不得把她真人化或 2D 化 |
| `@豆包企业版头像参考` | A/B 模式共同身份锚；映射 `assets/doubao-character/doubao-enterprise-avatar.png`，锁定脸型、五官与发型 |
| `@客户共创豆包主参考` | B 模式在设计卡确认后生成并确认；锁定本项目客户化服装、色彩、材质、配饰与动作语言 |
| `@正式文字与海报素材` | 标题、日期、地点、倒计时与活动落版 |
| `@文字卡-Txx` | 关键文字逐字原文、来源、出现位置、实现方式与禁止变体 |
| `@无字干净底图` / `@准确文字层` | 场景招牌、包装、工牌、落版等精确文字的确定性实现 |
| `@产品或IP参考` | 锁定外观、服饰、材质和比例 |

Anchor 类型写进 `anchor_registry`：`Identity` 锁人物/豆包/产品身份，`World` 锁空间、时代、材质和光色，`Narrative` 锁故事转折/高潮/收束，`Handoff` 锁跨单元屏幕位置、朝向、机位、轴线、光线、景深、运动与续接时长。同一素材可有一个主类型和辅助标签；`Handoff` 必须是硬锚点并实际传入相邻任务。

历史案例中的 `@边界帧F00…` 只在短镜修复或宿主时长受限的降级路线使用。
