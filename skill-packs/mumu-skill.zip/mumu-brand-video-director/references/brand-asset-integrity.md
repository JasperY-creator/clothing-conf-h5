# 客户 Logo 与品牌资产完整性

## 最高优先级红线

未经用户或项目 owner 上传并明确确认的客户 Logo，任何智能体不得自行联网搜索、下载、截图、临摹、重绘、生成、替换或猜测。Logo 未就绪时只能使用明确标注的后期安全区；若 Logo 是当前画面的必要组成部分，则进入 `HOLD_FOR_LOGO`。所有对外成片必须使用已确认的真实 Logo 资产准确合成，并在交付前再次完成品牌资产 QA。

## 两道硬门

### Gate 1：稀疏关键帧执行前的 Preflight Asset Gate

Brief 基本信息收齐后、生成第一批稀疏关键帧前，轻量确认：

```text
本片是否需要出现客户 Logo？
如果需要，请上传由客户或项目负责人确认的官方 Logo 文件。
我不会自行从网络搜索、截图、临摹或生成客户 Logo。
```

收到文件后展示资产卡：

```text
客户 Logo 资产确认：
- 客户名称：
- 文件名：
- 使用版本：彩色版 / 白色版 / 深色版
- 使用位置：剧情场景 / 片尾落版 / 两者
- 是否为本项目确认使用的官方版本：
请回复“Logo确认”。
```

只有 owner 回复“Logo确认”或表达同等明确授权，状态才可改为 `confirmed`。

为减少交互，Logo 卡与关键文字、豆包身份/项目造型、核心人物、精确产品和必要 VI 合并为一次“品牌准确资产确认卡”；分别登记稳定资产 ID、原始文件、来源、哈希、用途、`reference_scope`、确认状态与禁止变体。它既是 Preflight Asset Gate，也是已有第一次 Logo Gate，不增加第二轮询问。精确文字遵守 `exact-text-integrity.md`。

### Gate 2：最终输出前

再次核对真实文件、客户名称、图形与文字、颜色、比例、留白、版本和使用位置。若本片需要客户 Logo 而状态不是 `confirmed`，不得把文件标记为 `final`、不得对外交付。

## 允许继续与必须暂停

- 不需要 Logo：记录 `not_required`，正常推进。
- Logo 尚未上传，但本轮只做创意、故事或不含 Logo 的分镜：可以继续；画面中使用干净的 `[客户 Logo 后期安全区]`，不得放相似图形或伪文字占位。
- Logo 是当前镜头的必要组成部分，例如招牌、服装标识、展台、产品包装、签约墙或最终落版：未确认时进入 `HOLD_FOR_LOGO`。
- 生成模型不负责准确绘制 Logo。动态 Logo 使用已确认真实资产做跟踪、遮罩或动态图形合成。
- 产品包装、制服、工牌和场景招牌中的 Logo 同样适用；不能因为它不是片尾落版就交给模型生成。

## 来源与溯源

客户 Logo 只允许来自：

1. 用户/owner 在当前项目上传的文件；
2. 项目目录中已有、且 owner 明确确认可用于本项目的文件。

在 `02_brand-assets/brand_asset_manifest.json` 记录：客户名、文件名、格式、版本、来源、用途、确认人、确认时间、文件哈希。若文件被替换，必须重新确认并生成新记录。

## 推荐格式

- 优先：SVG、AI、EPS、透明 PNG。
- 若只有 JPG 或用户上传并确认的官方页面截图，不要求用户必须补透明版：先用 `scripts/normalize_logo.py` 判断是否能安全透明化占主导的近白背景并裁边。深色或复杂背景不自动去底，保留 owner 确认卡片或暂停；低清、主体过小则暂停。智能体仍不得自行联网寻找截图，也不得重绘成“看起来一样”的版本。
- 深浅背景需要不同版本时，分别登记；不得擅自反色。

## Skill 内置飞书官方 Logo

飞书 Logo 与客户 Logo 是两套独立资产规则。飞书官方素材已由项目 owner 提供并内置于本 Skill，可直接用于项目，不需要再次联网检索或要求用户重复上传：

- 官方原始文件：`assets/feishu-logo/feishu-logo-official-source.ai`；
- 浅色背景矢量版：`assets/feishu-logo/feishu-logo-color-dark-text.pdf`；
- 浅色背景透明 PNG：`assets/feishu-logo/feishu-logo-color-dark-text-transparent.png`；
- 深色背景矢量版：`assets/feishu-logo/feishu-logo-color-white-text.pdf`；
- 深色背景透明 PNG：`assets/feishu-logo/feishu-logo-color-white-text-transparent.png`；
- 文件用途与哈希：`assets/feishu-logo/asset-manifest.json`。

始终根据最终背景选择深字或白字版，保持原始比例、颜色、组合关系、间距与安全留白。不得联网搜索替代、重绘、重新排字、反色、换色、拉伸、裁掉图形或把 Logo 交给生成模型近似绘制；动态表现使用真实资产做确定性合成。若宿主不支持 AI/PDF，使用对应透明 PNG；若支持矢量合成，优先 PDF。以上内置授权不延伸到任何客户 Logo，客户 Logo 仍必须执行两道硬门。

## 品牌资产 QA

- 文件与资产清单一致，未被生成模型改形。
- 客户名、合作关系和签约主体准确。
- Logo 比例、颜色、文字、注册标、组合关系与安全留白正确。
- 没有把低清预览、网页截图或临时占位符带入最终成片。
- 客户 Logo 与飞书等平台 Logo 的视觉层级、间距和连接符符合已确认落版。
- 飞书 Logo 使用本 Skill 内置的正确深/浅背景版本，未被改形、改色或重新生成。
- 若任何一项无法确认，退回 `HOLD_FOR_LOGO`，不以“差不多”通过。
- Logo 周围的客户名、产品名、活动文字和数字已按文字卡逐字核对，不存在“Logo 对了但文字错了”。

## Deterministic Brand Finish

正式 Logo、企业名称、活动主题、日期地点、精确 Slogan、二维码、法律文字和最终 UI 都属于品牌真值层。生成模型只负责无字背景、运动、材质和安全区；最终使用官方资产与准确排版做遮罩、跟踪、透视或动态图形合成。不得接受“模型已经画得差不多”作为完成条件。

执行顺序：先通过故事单元画面 QA → 从真实正片末段建立动态 Handoff 与 4–6 秒无字无 Logo 尾声，或锁定普通 clean plate → 读取 Preflight registry 中确认资产 → 确定性渲染/跟踪动态图层或扁平 PNG → 在字节系剪辑工具中原样叠加 → 对完整出现区间做 Logo/文字/二维码检查 → 通过 `brand_finish` Gate 后才进入 Final QC。没有安全确定性能力时交付干净底图、官方资产、准确排版、位置/时间码与操作说明，不把候选画面标记为 final。

签约、启动会与 AI 先锋活动优先按 `end-slate-system.md` 执行 `cinematic_narrative_tail`：视频能力只延展动作、空间、客户材质与光线，准确宣传语和 owner 确认 Logo 使用确定性动态图层在尾声中自然显现；不再读取签约海报垫图。默认路线异常时才由 `scripts/render_ui_end_overlay.py` 输出 V1.75 全屏 UI 降级层与时间线。其他活动可使用 `scripts/render_end_slate.py`。任一路线无法满足硬门时取消 Logo/文字结尾层，不生成近似替代。
