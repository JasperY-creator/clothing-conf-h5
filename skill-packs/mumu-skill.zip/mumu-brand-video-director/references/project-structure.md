# 幕幕 · 项目目录、命名与归档

本文件规定每个视频项目的落盘结构。项目产物不得散落在 Skill 根目录或聊天下载目录；Skill 自身只保存方法、模板和获准沉淀的脱敏案例。

## 一、项目根目录

宿主可以写文件时，在工作区的 `projects/` 下创建：

```text
projects/<YYYYMMDD>-<project-slug>/
├─ 00_state/
│  ├─ project_state.json
│  ├─ production_master_plan.json
│  ├─ generation_manifest.json
│  └─ decisions.md
├─ 01_brief-story/
│  ├─ brief.md
│  ├─ brand-story-event.md
│  ├─ product-truth.md
│  ├─ world-logic.md
│  ├─ casting-wardrobe.md
│  ├─ creative-directions.md
│  ├─ story.md
│  ├─ cinematography-bible.md
│  ├─ rhythm-plan.md
│  ├─ sound-direction.md
│  └─ director-prompts.md
├─ 02_brand-assets/
│  ├─ brand_asset_manifest.json
│  ├─ preflight_asset_registry.json
│  ├─ platform-logo/
│  │  └─ feishu-official/
│  ├─ client-logo/
│  │  └─ confirmed/
│  ├─ exact-text/
│  │  ├─ text_asset_manifest.json
│  │  ├─ clean-plates/
│  │  └─ confirmed-layers/
│  ├─ end-slate/
│  │  ├─ end_slate_config.json
│  │  ├─ end_slate_manifest.json
│  │  ├─ cinematic_tail_handoff.json
│  │  ├─ cinematic_tail_brand_layers.json
│  │  ├─ client_logo_normalized.png
│  │  ├─ end_ui_veil.png
│  │  ├─ end_ui_light.png
│  │  ├─ end_ui_logos.png
│  │  ├─ end_ui_message.png
│  │  ├─ end_ui_overlay_timeline.json
│  │  ├─ end_slate_clean_plate.png
│  │  └─ end_slate_master.png
│  ├─ product-official/
│  ├─ doubao/
│  └─ other/
├─ 03_references/
│  ├─ doubao-character/
│  └─ casting-wardrobe/
├─ 04_story-anchors/
│  ├─ sparse-keyframes/
│  └─ selected-for-model/
├─ 05_video-generation/
│  ├─ U1/
│  └─ U2/
├─ 06_repairs/
├─ 07_edit/
├─ 08_audio/
│  ├─ narration/
│  ├─ music/
│  ├─ foley-ambience-sfx/
│  ├─ voice-casting-card.md
│  ├─ music-direction.md
│  ├─ cue-sheet.md
│  └─ mix-review.md
├─ 09_delivery/
│  ├─ preview/
│  ├─ final/
│  └─ qa-report.md
└─ 99_archive/
   ├─ superseded/
   └─ rejected/
```

`project-slug` 使用简短的小写英文、拼音或数字，以连字符分隔；客户之间必须使用不同项目目录。宿主不能落盘时，在结构化状态中保留同样的逻辑路径、可访问链接和完整生成记录，并明确标注“未下载归档”。

## 二、命名规范

统一格式：

```text
<project-id>_<asset-type>_<unit-or-slot>_<duration-or-range>_vNN.<ext>
```

示例：

```text
20260802-launch_keyframe_U1-K01_v03.png
20260802-launch_video_U1_30s_v02.mp4
20260802-launch_video_U2_15s_v01.mp4
20260802-launch_repair_R01_12s-19s_from-U1-v02_v01.mp4
20260802-launch_preview_full_45s-16x9_v02.mp4
20260802-launch_final_full_45s-16x9_v03.mp4
```

规则：

- `vNN` 从 `v01` 递增，永不覆盖旧文件。
- `U1/U2` 表示故事单元；`K01–K04` 表示稀疏关键帧；`R01` 表示修复任务。
- 修复文件必须写替换时间范围和来源版本。
- `preview` 只表示内部预览，不能命名为 `final`。
- `final` 仅在商业 QA 与 owner 通过后使用；不同导出规格分别建版本。
- 文件名不使用“最新版”“最终最终”“new2”等不可追踪词。

## 三、稀疏关键帧与模型输入

独立关键帧全部保存在 `04_story-anchors/sparse-keyframes/`。根据当前视频工具的参考素材上限，复制或建立清单到 `selected-for-model/`；30 秒默认 2 张、45/60 秒默认 4 张。`preflight_asset_registry.json` 保存原始资产 ID、来源、哈希、确认状态、引用范围与禁止变体；任何拼图裁切不得覆盖或冒充原始 Identity/产品资产。

2/4 张数量是导演稳定性预算，不是硬切镜头数。模型输入清单必须记录选中理由、顺序和素材槽编号；历史多宫格只在用户明确要求或排障时保存，不作为正式视频输入。

客户 Logo 只能进入 `02_brand-assets/client-logo/confirmed/`：来源必须是用户/owner 上传，或 owner 明确确认的既有项目文件。每个版本在 `brand_asset_manifest.json` 记录客户名、文件名、格式、版本、来源、用途、确认人与文件哈希。禁止把智能体自行联网搜索、模型生成或自行重绘的 Logo 放进确认目录。用户上传并确认的官方页面截图可以进入原始输入位，但只有通过 `normalize_logo.py` 并记录 manifest 后，标准化结果才进入 confirmed 使用位。

飞书 Logo 从 Skill 的 `assets/feishu-logo/` 复制或引用到 `02_brand-assets/platform-logo/feishu-official/`，并在资产清单记录源文件路径、深字/白字用途和哈希。浅色背景使用深字版，深色背景使用白字版；不得搜索、重绘、改色、重排文字或交给生成模型仿制。该内置资产不替代客户 Logo 的上传与确认。

可识别产品的官方资料与图片放入 `02_brand-assets/product-official/`，并在 `01_brief-story/product-truth.md` 记录客户实体、产品矩阵、产品身份卡、来源链接/文件、访问日期与置信度；普通搜索图库不得冒充官方参考。选角卡、A/B/C 服装模式和主参考放入 `01_brief-story/casting-wardrobe.md` 与 `03_references/casting-wardrobe/`。官方工服复刻需保存权威参考；品牌共创造型必须标明“影片共创”。

关键文字逐字原文、来源、确认状态、出现位置和实现方式记录到 `02_brand-assets/exact-text/text_asset_manifest.json`；无字干净底图与确认后的文字/排版层分开保存。招牌、包装、工牌、标题和 UI 不得把模型伪文字放进 confirmed 目录。适用真实逻辑卡、来源与置信度保存在 `01_brief-story/world-logic.md`。

签约、启动会与 AI 先锋活动优先使用 `02_brand-assets/end-slate/`：保存 `cinematic_narrative_tail` 的真实正片参考、动态 Handoff、4–6 秒尾声生成记录、确定性 Logo/宣传语图层与时间线。默认路线异常时，`scripts/render_ui_end_overlay.py` 生成 V1.75 降级所需的全屏 veil、光线、Logo、宣传语、manifest 与时间线。当前 Skill 不保留或读取签约海报垫图，也不生成静态签约海报。一般活动可由 `normalize_logo.py` 和 `render_end_slate.py` 生成确定性 master。不得把模型生成的双 Logo 或可读文字文件放入上述目录。

豆包 A 模式的原生参考或 B 模式已确认的客户共创主参考放在 `03_references/doubao-character/`；生成清单需写明本项目形象模式及实际使用的参考文件。

摄影圣经保存在 `01_brief-story/cinematography-bible.md`；旁白选角、音乐方向、品牌声音动机、Cue Sheet、最终 voice/music ID 与授权分别保存在 `08_audio/`。视频模型自带临时声音与最终混音必须分文件、分状态记录，不能把预演音轨误标为最终。

`production_master_plan.json` 由 `project_state.json` 冻结生成，只读、带 `PMP-Rxx` 修订号和快照哈希。故事、资产、时长、双层路由、摄影、声音或执行参数变化时，先更新项目状态，再新增修订；不得在 Master Plan 中单独改值。下游生成清单记录所读取的 PMP 修订号。

拆段片的预建共享交接锚点只保存一份；但真实前段输出优先。U1、U2 的生成清单记录直接续写、尾视频参考、真实尾帧、共享锚点或文字降级的实际路线，并保存来源视频版本、尾视频范围/尾帧时间码、动态 Handoff、首尾余量、缝合载体与接缝 QA。

## 四、生成清单

每次生成在 `generation_manifest.json` 追加记录，不覆盖历史记录：

```json
{
  "asset_id": "",
  "created_at": "",
  "host": "",
  "tool": "",
  "model_id": "",
  "model_version": "",
  "host_auto_routing": "unknown",
  "capability_role": "best_video_final",
  "production_master_plan_revision": "PMP-R01",
  "storyboard_route": "sparse_keyframes",
  "quality_profile": "standard",
  "prompt_path": "",
  "reference_assets": [],
  "fact_locks": {"product_ids": [], "world_logic_ids": [], "text_ids": [], "logo_status": ""},
  "parameters": {},
  "output_path_or_url": "",
  "source_asset": "",
  "status": "candidate",
  "review": ""
}
```

如果宿主返回链接但不能下载，仍记录链接、有效期和参数；不能声称文件已归档。涉及客户敏感素材时遵守其企业存储与权限要求，不复制到公共位置。

## 五、归档纪律

- 采用可恢复归档，不直接删除过程资产。
- 被新版本替代但仍可能追溯的提示词、图片和视频移到 `99_archive/superseded/`。
- 明确废弃的候选素材移到 `99_archive/rejected/`，同时在清单记录失败原因和可复用点。
- 最终交付目录只保留可交付文件、QA 结论和必要授权证明；过程截图、聊天导出和临时下载不进入 `09_delivery/`。
- 案例沉淀只复制脱敏的方法和获准素材到 Skill 的 `references/cases/`；原始客户项目继续留在自己的项目目录。

## 六、交付前目录检查

- 项目状态、模型绑定、提示词、参考资产、参数和结果能够互相追溯。
- 产品身份卡、官方产品参考、选角卡、服装主参考与实际生成输入能够互相追溯；B 模式没有被误写成官方工服。
- 真实逻辑卡、文字卡、无字底图、准确文字层和实际生成/后期输入能够互相追溯；关键文字已做全时段检查。
- 拆段项目的真实续写/尾视频/真实尾帧/共享锚点实际路线、动态 Handoff、首尾余量和缝合点 QA 已归档。
- U1/U2、锚点、修复片和最终导出的命名唯一且版本连续。
- `09_delivery/final/` 中没有未经确认的 Logo、文字、UI、音乐或过期链接；需要客户 Logo 时状态必须为 confirmed，关键文字清单无 pending，且已完成第二次品牌资产与音画 QA。
- 签约/启动会/大赛项目若为 `cinematic_narrative_tail`，真实前段参考、4–6 秒尾声、动态 Handoff、接缝 QA、准确宣传语/Logo 哈希、确定性动态图层与水印安全记录齐全；若降级为 `seedance_end_ui_overlay`，veil/light/logos/message/overlay 分层 PNG、manifest、时间线、合并审片记录与水印挖空区检查齐全；若为 `deterministic_png`，PNG master/clean plate 与 manifest 齐全；若为 `omitted_no_compositor`，省略记录齐全且不存在模型生成的 Logo/文字尾帧。
- 当前 PMP 修订号与所有最终生成/混音/合成清单一致；资产、画册/关键帧、故事单元、声音、品牌落版和 Final QC 六级 QA 状态均通过。
- Skill 根目录没有客户项目视频、临时截图、下载文件或过程文档。
