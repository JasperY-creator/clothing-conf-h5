#!/usr/bin/env python3
"""Run deterministic V1.76 structural QA against a project-state JSON file."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


SHOT_FUNCTIONS = {"NARRATIVE_ACTION", "STATE_CHANGE", "CAUSAL_BRIDGE", "ATMOSPHERE", "BRAND_CLOSURE"}
STORY_FIELDS = ("brand_truth", "subject", "initial_state", "goal_or_obstacle", "client_action", "visible_result", "carrier")
TRANSITION_TYPES = {"direct_extension", "micro_blend", "cross_dissolve", "match_cut", "occlusion_cut", "carrier_transition"}
HANDOFF_REFERENCE_ROUTES = {"direct_extension", "tail_video_reference", "actual_tail_frame", "shared_handoff_keyframe", "text_only"}
HANDOFF_FIELDS = (
    "action_phase",
    "gaze_or_center_of_gravity",
    "camera_direction_speed_inertia",
    "focus_depth",
    "axis_background",
    "lighting_exposure_material",
    "seam_carrier",
    "audio_continuity",
    "forbidden_changes",
)


def add(items: list[dict[str, str]], gate: str, level: str, code: str, message: str) -> None:
    items.append({"gate": gate, "level": level, "code": code, "message": message})


def load(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ValueError("project state must be a JSON object")
    return value


def validate(state: dict[str, Any]) -> dict[str, Any]:
    findings: list[dict[str, str]] = []
    story_container = state.get("story") or {}
    story = story_container.get("story_contract") or state.get("story_contract") or {}
    for field in STORY_FIELDS:
        if not story.get(field):
            add(findings, "story_gate", "BLOCK", f"STORY_{field.upper()}_MISSING", f"story_contract.{field} is required")

    shots = state.get("storyboard") or []
    if not isinstance(shots, list) or not shots:
        add(findings, "storyboard_gate", "BLOCK", "STORYBOARD_MISSING", "storyboard must contain functional shots")
        shots = []
    atmosphere = 0
    narrative = 0
    total_duration = 0.0
    atmosphere_duration = 0.0
    narrative_duration = 0.0
    consecutive_atmosphere = 0
    max_consecutive_atmosphere = 0
    for index, shot in enumerate(shots, start=1):
        if not isinstance(shot, dict):
            add(findings, "storyboard_gate", "BLOCK", "SHOT_INVALID", f"shot {index} must be an object")
            continue
        function = shot.get("shot_function")
        if function not in SHOT_FUNCTIONS:
            add(findings, "storyboard_gate", "BLOCK", "SHOT_FUNCTION_INVALID", f"shot {index} has invalid shot_function")
        if function == "ATMOSPHERE":
            atmosphere += 1
            consecutive_atmosphere += 1
            max_consecutive_atmosphere = max(max_consecutive_atmosphere, consecutive_atmosphere)
        else:
            consecutive_atmosphere = 0
        if function in {"NARRATIVE_ACTION", "STATE_CHANGE"}:
            narrative += 1
        duration = shot.get("duration_seconds")
        if isinstance(duration, (int, float)) and duration > 0:
            total_duration += float(duration)
            if function == "ATMOSPHERE":
                atmosphere_duration += float(duration)
            if function in {"NARRATIVE_ACTION", "STATE_CHANGE"}:
                narrative_duration += float(duration)
        for field in ("subject", "state_before", "state_after", "story_loss_if_removed"):
            if not shot.get(field):
                add(findings, "storyboard_gate", "REVISE", "SHOT_PAYLOAD_MISSING", f"shot {index} lacks {field}")

    if shots:
        atmosphere_ratio = atmosphere / len(shots)
        narrative_ratio = narrative / len(shots)
        if atmosphere_ratio > 0.20:
            add(findings, "storyboard_gate", "BLOCK", "ATMOSPHERE_BUDGET_EXCEEDED", f"atmosphere ratio is {atmosphere_ratio:.1%}")
        if narrative_ratio < 0.60:
            add(findings, "storyboard_gate", "BLOCK", "NARRATIVE_BUDGET_TOO_LOW", f"narrative/state-change ratio is {narrative_ratio:.1%}")
        if max_consecutive_atmosphere > 1:
            add(findings, "storyboard_gate", "BLOCK", "ATMOSPHERE_CONSECUTIVE", "two or more pure atmosphere shots are consecutive")
        for start in range(max(0, len(shots) - 2)):
            window = shots[start:start + 3]
            active = sum(
                isinstance(shot, dict) and shot.get("shot_function") in {"NARRATIVE_ACTION", "STATE_CHANGE", "CAUSAL_BRIDGE"}
                for shot in window
            )
            if active < 2:
                add(findings, "storyboard_gate", "BLOCK", "THREE_SHOT_WINDOW_INACTIVE", f"shots {start + 1}-{start + 3} contain fewer than two active/causal shots")
        if total_duration > 0:
            atmosphere_duration_ratio = atmosphere_duration / total_duration
            narrative_duration_ratio = narrative_duration / total_duration
            if atmosphere_duration_ratio > 0.20:
                add(findings, "storyboard_gate", "BLOCK", "ATMOSPHERE_DURATION_EXCEEDED", f"atmosphere duration ratio is {atmosphere_duration_ratio:.1%}")
            if narrative_duration_ratio < 0.60:
                add(findings, "storyboard_gate", "BLOCK", "NARRATIVE_DURATION_TOO_LOW", f"narrative/state-change duration ratio is {narrative_duration_ratio:.1%}")

    copy = state.get("event_copy") or {}
    end_slate = state.get("end_slate") or {}
    if end_slate.get("required") is True:
        delivery_mode = end_slate.get("delivery_mode")
        if end_slate.get("model_generated_readable_text") is not False:
            add(findings, "brand_finish_gate", "BLOCK", "MODEL_TEXT_FORBIDDEN", "every required end-slate route must forbid model-generated readable text")
        if delivery_mode == "omitted_no_compositor":
            if end_slate.get("safe_omission_confirmed") is not True:
                add(findings, "brand_finish_gate", "BLOCK", "UNCONFIRMED_END_SLATE_OMISSION", "safe omission must be explicitly recorded")
            if end_slate.get("master_path"):
                add(findings, "brand_finish_gate", "BLOCK", "OMITTED_END_SLATE_HAS_MASTER", "omitted end slate must not expose a candidate master")
        elif delivery_mode not in {"cinematic_narrative_tail", "seedance_end_ui_overlay", "deterministic_png"}:
            add(findings, "brand_finish_gate", "BLOCK", "END_SLATE_ROUTE_UNSAFE", "required end slate must use cinematic tail, deterministic UI/PNG, or omitted_no_compositor")

    outputs = state.get("long_video_outputs") or []
    segment_review = state.get("segment_review") or {}
    if isinstance(outputs, list) and len(outputs) >= 2:
        if segment_review.get("owner_decision") != "approved":
            add(findings, "generation_gate", "BLOCK", "SEGMENT_REVIEW_NOT_CONFIRMED", "all generated segments must be presented together and owner-approved before editing")
        if segment_review.get("execution_order_verified") is not True:
            add(findings, "generation_gate", "BLOCK", "SEGMENT_EXECUTION_ORDER_UNVERIFIED", "later segments must be generated sequentially after inspecting the actual previous output")
        reference_route = segment_review.get("handoff_reference_route")
        if reference_route not in HANDOFF_REFERENCE_ROUTES:
            add(findings, "generation_gate", "BLOCK", "HANDOFF_REFERENCE_ROUTE_INVALID", "handoff_reference_route must record the actual continuation input route")
        handoff = segment_review.get("handoff_contract") or {}
        for field in HANDOFF_FIELDS:
            if not handoff.get(field):
                add(findings, "generation_gate", "BLOCK", "HANDOFF_CONTRACT_INCOMPLETE", f"handoff_contract.{field} is required")
        review_window = segment_review.get("seam_review_window_seconds")
        if not isinstance(review_window, (int, float)) or review_window < 2:
            add(findings, "generation_gate", "BLOCK", "SEAM_REVIEW_WINDOW_TOO_SHORT", "each seam must be reviewed for at least two seconds on both sides")
        if segment_review.get("seam_qc_pass") is not True:
            add(findings, "generation_gate", "BLOCK", "SEAM_QC_NOT_PASSED", "a failed or unreviewed seam cannot pass")
        transition_type = segment_review.get("transition_type")
        if transition_type not in TRANSITION_TYPES:
            add(findings, "generation_gate", "BLOCK", "SEGMENT_TRANSITION_INVALID", "transition_type must match the actual motion and seam carrier")
        if transition_type == "cross_dissolve":
            transition_frames = segment_review.get("transition_frames")
            if not isinstance(transition_frames, int) or not 8 <= transition_frames <= 12:
                add(findings, "generation_gate", "BLOCK", "SEGMENT_DISSOLVE_DURATION_INVALID", "low-motion cross dissolve must use 8-12 frames")
        for field in ("ending_copy_presented", "client_logo_status_presented", "feishu_logo_status_presented"):
            if segment_review.get(field) is not True:
                add(findings, "generation_gate", "BLOCK", "SEGMENT_REVIEW_CARD_INCOMPLETE", f"segment_review.{field} must be true")

    if end_slate.get("required") is True and end_slate.get("delivery_mode") == "cinematic_narrative_tail":
        closing_statement = str(copy.get("closing_statement", "")).strip()
        if copy.get("confirmed") is not True or not copy.get("copy_id") or not closing_statement:
            add(findings, "brand_finish_gate", "BLOCK", "COPY_NOT_LOCKED", "confirmed copy_id and closing_statement are required")
        if end_slate.get("copy_id") != copy.get("copy_id"):
            add(findings, "brand_finish_gate", "BLOCK", "COPY_ID_MISMATCH", "cinematic tail and event copy must reference the same copy_id")
        duration = end_slate.get("tail_duration_seconds")
        if not isinstance(duration, (int, float)) or not 4 <= duration <= 6:
            add(findings, "brand_finish_gate", "BLOCK", "CINEMATIC_TAIL_DURATION_INVALID", "cinematic narrative tail must be 4-6 seconds")
        if end_slate.get("source_reference_route") not in HANDOFF_REFERENCE_ROUTES:
            add(findings, "brand_finish_gate", "BLOCK", "CINEMATIC_TAIL_SOURCE_MISSING", "cinematic tail must record its real previous-video reference route")
        tail_handoff = end_slate.get("handoff_contract") or {}
        for field in HANDOFF_FIELDS:
            if not tail_handoff.get(field):
                add(findings, "brand_finish_gate", "BLOCK", "CINEMATIC_TAIL_HANDOFF_INCOMPLETE", f"end_slate.handoff_contract.{field} is required")
        if end_slate.get("render_method") != "deterministic_motion_overlay":
            add(findings, "brand_finish_gate", "BLOCK", "CINEMATIC_BRAND_LAYER_UNSAFE", "logos and copy must use deterministic_motion_overlay")
        if end_slate.get("video_insertion_mode") != "animated_overlay":
            add(findings, "brand_finish_gate", "BLOCK", "CINEMATIC_INSERTION_ROUTE_UNSAFE", "cinematic brand layers must use non-generative animated_overlay")
        if end_slate.get("deterministic_compositor_verified") is not True:
            add(findings, "brand_finish_gate", "BLOCK", "COMPOSITOR_NOT_VERIFIED", "deterministic motion compositor must be verified")
        if end_slate.get("seam_review_confirmed") is not True:
            add(findings, "brand_finish_gate", "BLOCK", "CINEMATIC_TAIL_SEAM_UNREVIEWED", "main film to cinematic tail seam must pass review")
        if end_slate.get("preserve_doubao_attribution_watermark") is not True:
            add(findings, "brand_finish_gate", "BLOCK", "DOUBAO_WATERMARK_POLICY_MISSING", "official Doubao attribution watermark must be preserved")
        relation = end_slate.get("relation")
        if relation == "partnership":
            logo = (state.get("asset_readiness") or {}).get("client_logo") or {}
            if logo.get("owner_confirmed") is not True:
                add(findings, "brand_finish_gate", "BLOCK", "CLIENT_LOGO_NOT_CONFIRMED", "client logo must be owner-confirmed when partnership logos are shown")
            if end_slate.get("platform_asset_manifest_verified") is not True:
                add(findings, "brand_finish_gate", "BLOCK", "PLATFORM_LOGO_NOT_VERIFIED", "built-in platform logo hash must match its manifest")

    if end_slate.get("required") is True and end_slate.get("delivery_mode") == "seedance_end_ui_overlay":
        closing_statement = str(copy.get("closing_statement", "")).strip()
        if copy.get("confirmed") is not True or not copy.get("copy_id") or not closing_statement:
            add(findings, "brand_finish_gate", "BLOCK", "COPY_NOT_LOCKED", "confirmed copy_id and closing_statement are required")
        if end_slate.get("copy_id") != copy.get("copy_id"):
            add(findings, "brand_finish_gate", "BLOCK", "COPY_ID_MISMATCH", "end UI and event copy must reference the same copy_id")
        if end_slate.get("render_method") != "deterministic_ui_overlay":
            add(findings, "brand_finish_gate", "BLOCK", "UI_OVERLAY_NOT_DETERMINISTIC", "end UI must use deterministic_ui_overlay")
        if end_slate.get("video_insertion_mode") != "animated_overlay":
            add(findings, "brand_finish_gate", "BLOCK", "UI_INSERTION_ROUTE_UNSAFE", "end UI must be inserted as a non-generative animated overlay")
        if end_slate.get("deterministic_compositor_verified") is not True:
            add(findings, "brand_finish_gate", "BLOCK", "COMPOSITOR_NOT_VERIFIED", "deterministic UI compositor must be verified")
        if not str(end_slate.get("overlay_path", "")).lower().endswith(".png"):
            add(findings, "brand_finish_gate", "BLOCK", "UI_OVERLAY_NOT_PNG", "end UI overlay must be a transparent PNG")
        if not str(end_slate.get("overlay_timeline_path", "")).lower().endswith(".json"):
            add(findings, "brand_finish_gate", "BLOCK", "UI_TIMELINE_MISSING", "end UI animation timeline JSON is required")
        opacity = end_slate.get("veil_opacity")
        if not isinstance(opacity, int) or not 210 <= opacity <= 246:
            add(findings, "brand_finish_gate", "BLOCK", "UI_VEIL_OPACITY_UNSAFE", "full-screen veil opacity must be between 210 and 246")
        for field in ("veil_path", "light_path", "logos_path", "message_path"):
            if not str(end_slate.get(field, "")).lower().endswith(".png"):
                add(findings, "brand_finish_gate", "BLOCK", "UI_LAYER_MISSING", f"end_slate.{field} must be a PNG")
        safe_area = end_slate.get("watermark_safe_area")
        if not isinstance(safe_area, list) or len(safe_area) != 4 or not all(isinstance(value, int) for value in safe_area):
            add(findings, "brand_finish_gate", "BLOCK", "WATERMARK_SAFE_AREA_MISSING", "actual four-coordinate watermark_safe_area is required for full-screen layers")
        if isinstance(outputs, list) and len(outputs) >= 2 and end_slate.get("segment_review_confirmed") is not True:
            add(findings, "brand_finish_gate", "BLOCK", "SEGMENT_REVIEW_NOT_LINKED", "end UI must reference the approved U1/U2 review")
        if end_slate.get("preserve_doubao_attribution_watermark") is not True:
            add(findings, "brand_finish_gate", "BLOCK", "DOUBAO_WATERMARK_POLICY_MISSING", "official Doubao attribution watermark must be preserved")
        relation = end_slate.get("relation")
        if relation == "partnership":
            logo = (state.get("asset_readiness") or {}).get("client_logo") or {}
            if logo.get("owner_confirmed") is not True:
                add(findings, "brand_finish_gate", "BLOCK", "CLIENT_LOGO_NOT_CONFIRMED", "client logo must be owner-confirmed when partnership logos are shown")
            if end_slate.get("platform_asset_manifest_verified") is not True:
                add(findings, "brand_finish_gate", "BLOCK", "PLATFORM_LOGO_NOT_VERIFIED", "built-in platform logo hash must match its manifest")

    if end_slate.get("required") is True and end_slate.get("delivery_mode") == "deterministic_png":
        if copy.get("confirmed") is not True or not copy.get("copy_id") or not copy.get("closing_statement"):
            add(findings, "brand_finish_gate", "BLOCK", "COPY_NOT_LOCKED", "confirmed copy_id and closing_statement are required")
        logo = (state.get("asset_readiness") or {}).get("client_logo") or {}
        if logo.get("owner_confirmed") is not True:
            add(findings, "brand_finish_gate", "BLOCK", "CLIENT_LOGO_NOT_CONFIRMED", "client logo must be owner-confirmed")
        if logo.get("normalization_status") not in {"transparent_ready", "uniform_cards_confirmed"}:
            add(findings, "brand_finish_gate", "BLOCK", "CLIENT_LOGO_NOT_NORMALIZED", "client logo must be transparent-ready or use the confirmed uniform-card route")
        if end_slate.get("render_method") != "deterministic_flattened_png":
            add(findings, "brand_finish_gate", "BLOCK", "END_SLATE_NOT_DETERMINISTIC", "end slate must use deterministic flattened PNG rendering")
        if end_slate.get("deterministic_compositor_verified") is not True:
            add(findings, "brand_finish_gate", "BLOCK", "COMPOSITOR_NOT_VERIFIED", "deterministic compositor must be verified")
        if end_slate.get("video_insertion_mode") not in {"static_append", "deterministic_overlay"}:
            add(findings, "brand_finish_gate", "BLOCK", "INSERTION_ROUTE_UNSAFE", "master PNG must be appended or overlaid without generative redraw")
        if end_slate.get("platform_asset_manifest_verified") is not True:
            add(findings, "brand_finish_gate", "BLOCK", "PLATFORM_LOGO_NOT_VERIFIED", "built-in platform logo hash must match its manifest")
        if not str(end_slate.get("master_path", "")).lower().endswith(".png"):
            add(findings, "brand_finish_gate", "BLOCK", "MASTER_NOT_FLATTENED_PNG", "end-slate master must be a flattened PNG")
        if not end_slate.get("relation"):
            add(findings, "brand_finish_gate", "BLOCK", "RELATION_SYMBOL_MISSING", "end-slate relation must be locked")
        if end_slate.get("copy_id") != copy.get("copy_id"):
            add(findings, "brand_finish_gate", "BLOCK", "COPY_ID_MISMATCH", "end slate and event copy must reference the same copy_id")
        relationship = (state.get("brief") or {}).get("relationship")
        if relationship in {None, "", "undecided"}:
            add(findings, "fact_gate", "BLOCK", "RELATIONSHIP_NOT_LOCKED", "brief.relationship must be confirmed before formal end slate")
        elif relationship == "partnership" and end_slate.get("relation") != "partnership":
            add(findings, "brand_finish_gate", "BLOCK", "PARTNERSHIP_SYMBOL_MISMATCH", "confirmed partnership requires partnership relation rendering")

    audio = state.get("audio") or {}
    if audio.get("narration_required") is True and audio.get("narration_waived_by_owner") is not True:
        if audio.get("final_generation_status") != "completed":
            add(findings, "audio_gate", "BLOCK", "NARRATION_NOT_COMPLETED", "required narration must be generated before final delivery")
        if audio.get("mix_status") != "PASS":
            add(findings, "audio_gate", "BLOCK", "AUDIO_MIX_NOT_PASSED", "required narration and mix must pass audio QA")

    blocks = sum(item["level"] == "BLOCK" for item in findings)
    revisions = sum(item["level"] == "REVISE" for item in findings)
    return {
        "schema_version": "1.76",
        "status": "FAIL" if blocks else "REVISE" if revisions else "PASS",
        "summary": {"blocks": blocks, "revisions": revisions, "findings": len(findings)},
        "findings": findings,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_state", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        report = validate(load(args.project_state.resolve()))
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"BLOCK: {exc}", file=sys.stderr)
        return 2
    serialized = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(serialized, encoding="utf-8")
    print(serialized, end="")
    return 0 if report["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
