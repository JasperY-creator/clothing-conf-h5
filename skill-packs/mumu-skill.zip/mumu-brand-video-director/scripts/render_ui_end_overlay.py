#!/usr/bin/env python3
"""Render the deterministic V1.76 fallback full-screen end-UI layers."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

try:
    from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageOps
except ImportError as exc:  # pragma: no cover - runtime capability gate
    raise SystemExit("BLOCK: deterministic UI overlay rendering requires Pillow") from exc

from normalize_logo import normalize_logo, sha256_file


RELATIONS = {"partnership": "×", "neutral": "|", "none": ""}


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object in {path}")
    return value


def require_file(value: Any, label: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} is required")
    path = Path(value).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f"{label} does not exist: {path}")
    return path


def resolve_font(config: dict[str, Any]) -> Path:
    candidates = [
        config.get("font_path"),
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Medium.ttc",
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
    ]
    for candidate in candidates:
        if candidate and Path(str(candidate)).expanduser().is_file():
            return Path(str(candidate)).expanduser().resolve()
    raise ValueError("no deterministic Chinese font is available")


def verify_platform_asset(path: Path) -> dict[str, Any]:
    manifest_path = path.parent / "asset-manifest.json"
    if not manifest_path.is_file():
        raise ValueError("platform logo manifest is missing")
    manifest = load_json(manifest_path)
    expected = next(
        (
            item.get("sha256")
            for item in manifest.get("files", [])
            if isinstance(item, dict) and item.get("path") == path.name
        ),
        None,
    )
    actual = sha256_file(path)
    if not expected or expected != actual:
        raise ValueError("platform logo does not match the built-in official asset manifest")
    return {"path": str(path), "sha256": actual, "official_manifest_verified": True}


def fitted_font(
    draw: ImageDraw.ImageDraw,
    text: str,
    font_path: Path,
    start_size: int,
    max_width: int,
    min_size: int,
) -> ImageFont.FreeTypeFont:
    for size in range(start_size, min_size - 1, -2):
        font = ImageFont.truetype(str(font_path), size=size)
        box = draw.multiline_textbbox((0, 0), text, font=font, spacing=round(size * 0.30), align="center")
        if box[2] - box[0] <= max_width:
            return font
    raise ValueError("closing_statement is too long for the confirmed UI safe area")


def fit_logo(image: Image.Image, max_width: int, max_height: int) -> Image.Image:
    result = image.copy()
    result.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
    return result


def paste_center(canvas: Image.Image, image: Image.Image, x: int, y: int) -> None:
    canvas.alpha_composite(image, (round(x - image.width / 2), round(y - image.height / 2)))


def parse_safe_area(config: dict[str, Any], width: int, height: int) -> tuple[int, int, int, int]:
    value = config.get("watermark_safe_area")
    if not isinstance(value, list) or len(value) != 4 or not all(isinstance(item, int) for item in value):
        raise ValueError("watermark_safe_area must be [left, top, right, bottom] from the actual generated video")
    left, top, right, bottom = value
    if not (0 <= left < right <= width and 0 <= top < bottom <= height):
        raise ValueError("watermark_safe_area is outside the output frame")
    return left, top, right, bottom


def clear_safe_area(layer: Image.Image, safe_area: tuple[int, int, int, int], padding: int) -> None:
    left, top, right, bottom = safe_area
    left = max(0, left - padding)
    top = max(0, top - padding)
    right = min(layer.width, right + padding)
    bottom = min(layer.height, bottom + padding)
    cutout = Image.new("L", layer.size, 0)
    ImageDraw.Draw(cutout).rectangle((left, top, right, bottom), fill=255)
    cutout = cutout.filter(ImageFilter.GaussianBlur(max(2, padding // 2)))
    layer.putalpha(ImageChops.subtract(layer.getchannel("A"), cutout))


def make_light_layer(width: int, height: int, opacity: int) -> Image.Image:
    """Create soft deterministic cyan/blue/violet light ribbons without readable pseudo-UI."""
    scale = 2
    glow = Image.new("RGBA", (width // scale, height // scale), (0, 0, 0, 0))
    draw = ImageDraw.Draw(glow)
    shapes = [
        ((-0.18, 0.02, 0.70, 0.48), (80, 190, 255, opacity)),
        ((0.28, 0.28, 1.18, 0.76), (92, 132, 255, round(opacity * 0.78))),
        ((-0.08, 0.62, 0.82, 1.06), (90, 225, 220, round(opacity * 0.62))),
        ((0.62, -0.14, 1.20, 0.40), (180, 135, 255, round(opacity * 0.48))),
    ]
    for bounds, color in shapes:
        box = tuple(round(value * (width // scale if index % 2 == 0 else height // scale)) for index, value in enumerate(bounds))
        draw.ellipse(box, fill=color)
    glow = glow.filter(ImageFilter.GaussianBlur(round(min(width, height) * 0.085 / scale)))
    return glow.resize((width, height), Image.Resampling.BICUBIC)


def save_layer(layer: Image.Image, path: Path) -> dict[str, str]:
    layer.save(path, "PNG", optimize=True)
    return {"path": str(path), "sha256": sha256_file(path)}


def render(config_path: Path, output_dir: Path) -> dict[str, Any]:
    config = load_json(config_path)
    for field in (
        "deterministic_compositor_verified",
        "copy_confirmed",
        "segment_review_confirmed",
        "preserve_doubao_attribution_watermark",
    ):
        if config.get(field) is not True:
            raise ValueError(f"{field} must be true")
    if config.get("model_generated_readable_text") is not False:
        raise ValueError("model_generated_readable_text must be false")

    event_name = str(config.get("event_name", config.get("title", ""))).strip()
    closing_statement = str(config.get("closing_statement", config.get("subtitle", ""))).strip()
    if not 1 <= len(event_name) <= 28:
        raise ValueError("event_name must contain 1-28 characters")
    if not 1 <= len(closing_statement) <= 60:
        raise ValueError("closing_statement must contain 1-60 characters")
    display_event_name = bool(config.get("display_event_name", False))

    width, height = int(config.get("width", 1920)), int(config.get("height", 1080))
    if width < 640 or height < 360:
        raise ValueError("width/height are too small for a formal overlay")
    veil_opacity = int(config.get("veil_opacity", 228))
    if not 210 <= veil_opacity <= 246:
        raise ValueError("veil_opacity must be between 210 and 246")
    light_opacity = int(config.get("light_opacity", 62))
    if not 20 <= light_opacity <= 96:
        raise ValueError("light_opacity must be between 20 and 96")
    safe_area = parse_safe_area(config, width, height)
    padding = round(min(width, height) * 0.018)

    relation = str(config.get("relation", "partnership"))
    if relation not in RELATIONS:
        raise ValueError(f"relation must be one of {sorted(RELATIONS)}")
    client_value, platform_value = config.get("client_logo"), config.get("platform_logo")
    if relation == "partnership" and (not client_value or not platform_value):
        raise ValueError("partnership end UI requires owner-confirmed client Logo and built-in Feishu Logo")
    if bool(client_value) != bool(platform_value):
        raise ValueError("client_logo and platform_logo must be supplied together")
    has_logos = bool(client_value)
    if has_logos and config.get("client_logo_confirmed") is not True:
        raise ValueError("client_logo_confirmed must be true when logos are shown")
    if has_logos and config.get("relationship_confirmed") is not True:
        raise ValueError("relationship_confirmed must be true when logos are shown")
    if not has_logos and relation != "none":
        raise ValueError("relation must be none when logos are omitted")

    output_dir.mkdir(parents=True, exist_ok=True)
    font_path = resolve_font(config)

    veil = Image.new("RGBA", (width, height), (255, 255, 255, veil_opacity))
    clear_safe_area(veil, safe_area, padding)

    light = make_light_layer(width, height, light_opacity)
    clear_safe_area(light, safe_area, padding)

    logos = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    client_meta: dict[str, Any] | None = None
    platform_meta: dict[str, Any] | None = None
    normalized_path: Path | None = None
    if has_logos:
        client_path = require_file(client_value, "client_logo")
        platform_path = require_file(platform_value, "platform_logo")
        platform_meta = verify_platform_asset(platform_path)
        client_mode = str(config.get("client_logo_mode", "auto"))
        if client_mode not in {"auto", "transparent", "card"}:
            raise ValueError("client_logo_mode must be auto, transparent or card")
        client, client_meta = normalize_logo(client_path, client_mode)
        platform, platform_normalization = normalize_logo(platform_path, "transparent")
        platform_meta["normalization"] = platform_normalization
        max_logo_h = round(height * 0.105)
        max_logo_w = round(width * 0.235)
        client = fit_logo(client, max_logo_w, max_logo_h)
        platform = fit_logo(platform, max_logo_w, max_logo_h)
        logo_y = round(height * 0.18)
        client_x, platform_x = round(width * 0.36), round(width * 0.64)
        paste_center(logos, client, client_x, logo_y)
        paste_center(logos, platform, platform_x, logo_y)
        symbol = RELATIONS[relation]
        if symbol:
            relation_font = ImageFont.truetype(str(font_path), size=round(height * 0.046))
            ImageDraw.Draw(logos).text((width // 2, logo_y), symbol, font=relation_font, fill=(34, 36, 42, 255), anchor="mm")
        normalized_path = output_dir / "client_logo_normalized.png"
        client.save(normalized_path, "PNG", optimize=True)
    clear_safe_area(logos, safe_area, padding)

    message = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(message)
    statement_font = fitted_font(draw, closing_statement, font_path, round(height * 0.082), round(width * 0.76), 34)
    statement_y = round(height * 0.54)
    draw.multiline_text(
        (width // 2, statement_y),
        closing_statement,
        font=statement_font,
        fill=(18, 20, 24, 255),
        anchor="mm",
        align="center",
        spacing=round(statement_font.size * 0.30),
    )
    if display_event_name:
        event_font = fitted_font(draw, event_name, font_path, round(height * 0.036), round(width * 0.54), 22)
        draw.text((width // 2, round(height * 0.73)), event_name, font=event_font, fill=(55, 60, 70, 238), anchor="mm")
    clear_safe_area(message, safe_area, padding)

    overlay = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    for layer in (veil, light, logos, message):
        overlay.alpha_composite(layer)

    paths = {
        "veil": save_layer(veil, output_dir / "end_ui_veil.png"),
        "light": save_layer(light, output_dir / "end_ui_light.png"),
        "logos": save_layer(logos, output_dir / "end_ui_logos.png"),
        "message": save_layer(message, output_dir / "end_ui_message.png"),
        "overlay": save_layer(overlay, output_dir / "end_ui_overlay.png"),
    }

    preview_path: Path | None = None
    if config.get("background_image"):
        background_path = require_file(config.get("background_image"), "background_image")
        if config.get("background_confirmed_clean_plate") is not True:
            raise ValueError("background_confirmed_clean_plate must be true for a preview")
        background = ImageOps.fit(Image.open(background_path).convert("RGB"), (width, height), Image.Resampling.LANCZOS).convert("RGBA")
        preview_path = output_dir / "end_ui_overlay_preview.png"
        Image.alpha_composite(background, overlay).convert("RGB").save(preview_path, "PNG", optimize=True)

    duration = float(config.get("overlay_duration_seconds", 4.0))
    if duration < 3.0:
        raise ValueError("overlay_duration_seconds must be at least 3.0 for readable signing copy")
    timeline = {
        "schema_version": "1.76",
        "time_origin": "start_of_overlay",
        "suggested_duration_seconds": duration,
        "overlay_entry": {"type": "layer_fade", "duration_frames": int(config.get("overlay_entry_frames", 10)), "allowed_range_frames": [8, 12]},
        "keyframes": [
            {"time": 0.00, "layer": "veil", "opacity": 0, "easing": "ease_in_out"},
            {"time": 0.50, "layer": "veil", "opacity": 1, "easing": "ease_in_out"},
            {"time": 0.10, "layer": "light", "opacity": 0, "x_offset_ratio": -0.055, "scale": 1.04, "easing": "ease_in_out"},
            {"time": 0.90, "layer": "light", "opacity": 1, "x_offset_ratio": 0.018, "scale": 1.00, "easing": "ease_in_out"},
            {"time": 1.70, "layer": "light", "opacity": 0.78, "x_offset_ratio": 0.050, "scale": 1.03, "easing": "ease_in_out"},
            {"time": 0.65, "layer": "logos", "opacity": 0, "y_offset_ratio": -0.020, "easing": "ease_out"},
            {"time": 1.25, "layer": "logos", "opacity": 1, "y_offset_ratio": 0.0, "easing": "ease_out"},
            {"time": 1.05, "layer": "message", "opacity": 0, "y_offset_ratio": 0.015, "easing": "ease_out"},
            {"time": 1.70, "layer": "message", "opacity": 1, "y_offset_ratio": 0.0, "easing": "ease_out"},
        ],
        "instruction": "Animate the supplied deterministic layers in the byte-family editor; do not regenerate Logos or Chinese with an image/video model.",
    }
    entry_frames = timeline["overlay_entry"]["duration_frames"]
    if not 8 <= entry_frames <= 12:
        raise ValueError("overlay_entry_frames must be between 8 and 12")
    timeline_path = output_dir / "end_ui_overlay_timeline.json"
    timeline_path.write_text(json.dumps(timeline, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    manifest = {
        "schema_version": "1.76",
        "delivery_mode": "seedance_end_ui_overlay",
        "render_method": "deterministic_ui_overlay",
        "video_insertion_mode": "animated_overlay",
        "copy_id": config.get("copy_id", ""),
        "event_name": event_name,
        "closing_statement": closing_statement,
        "display_event_name": display_event_name,
        "relation": relation,
        "full_screen_ui": {"veil_opacity": veil_opacity, "light_opacity": light_opacity, "watermark_safe_area": list(safe_area)},
        "font": {"path": str(font_path), "sha256": sha256_file(font_path), "rasterized": True},
        "assets": {
            "client_logo": ({**client_meta, "normalized_path": str(normalized_path), "owner_confirmed": True} if client_meta else None),
            "platform_logo": platform_meta,
        },
        "outputs": {
            **paths,
            "preview": str(preview_path) if preview_path else "",
            "preview_sha256": sha256_file(preview_path) if preview_path else "",
            "timeline": str(timeline_path),
        },
        "qa": {
            "copy_confirmed": True,
            "closing_statement_present": True,
            "segment_review_confirmed": True,
            "model_generated_readable_text": False,
            "deterministic_compositor_verified": True,
            "platform_asset_manifest_verified": bool(platform_meta),
            "full_screen_veil": True,
            "deterministic_flowing_light": True,
            "logos_at_top": has_logos,
            "message_centered": True,
            "preserve_doubao_attribution_watermark": True,
            "watermark_layers_cleared": True,
            "status": "PASS",
        },
    }
    manifest_path = output_dir / "end_ui_overlay_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    try:
        result = render(args.config.resolve(), args.output_dir.resolve())
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"BLOCK: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
