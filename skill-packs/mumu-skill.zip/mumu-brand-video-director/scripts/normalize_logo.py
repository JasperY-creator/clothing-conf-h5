#!/usr/bin/env python3
"""Normalize an owner-confirmed logo without asking a generative model to redraw it."""

from __future__ import annotations

import argparse
import hashlib
import json
import statistics
import sys
from pathlib import Path
from typing import Any

try:
    from PIL import Image
except ImportError as exc:  # pragma: no cover - runtime capability gate
    raise SystemExit("BLOCK: deterministic logo normalization requires Pillow") from exc


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _has_useful_alpha(image: Image.Image) -> bool:
    if "A" not in image.getbands():
        return False
    extrema = image.getchannel("A").getextrema()
    return extrema[0] < 250


def _border_profile(image: Image.Image) -> tuple[tuple[int, int, int], float, float]:
    rgb = image.convert("RGB")
    width, height = rgb.size
    stride = max(1, min(width, height) // 200)
    pixels: list[tuple[int, int, int]] = []
    for x in range(0, width, stride):
        pixels.append(rgb.getpixel((x, 0)))
        pixels.append(rgb.getpixel((x, height - 1)))
    for y in range(0, height, stride):
        pixels.append(rgb.getpixel((0, y)))
        pixels.append(rgb.getpixel((width - 1, y)))
    background = tuple(round(statistics.median(channel)) for channel in zip(*pixels))
    distances = sorted(max(abs(pixel[i] - background[i]) for i in range(3)) for pixel in pixels)
    p90 = float(distances[min(len(distances) - 1, round((len(distances) - 1) * 0.90))])
    background_coverage = sum(distance <= 20 for distance in distances) / len(distances)
    return background, p90, background_coverage


def _remove_uniform_background(image: Image.Image) -> tuple[Image.Image, dict[str, Any]]:
    background, border_p90, background_coverage = _border_profile(image)
    if min(background) < 230:
        raise ValueError(
            "automatic removal is limited to light near-white logo backgrounds; preserve this owner-confirmed "
            "card or request a transparent official logo"
        )
    if background_coverage < 0.70:
        raise ValueError(
            "background is not uniform enough for safe automatic removal; request a tighter official crop "
            "or use the explicitly confirmed uniform-card route"
        )
    rgba = image.convert("RGBA")
    source = list(rgba.getdata())
    converted: list[tuple[int, int, int, int]] = []
    low, high = 8, 52
    for red, green, blue, original_alpha in source:
        distance = max(abs(red - background[0]), abs(green - background[1]), abs(blue - background[2]))
        alpha = 0 if distance <= low else 255 if distance >= high else round((distance - low) * 255 / (high - low))
        converted.append((red, green, blue, min(original_alpha, alpha)))
    rgba.putdata(converted)
    bbox = rgba.getchannel("A").point(lambda value: 255 if value >= 8 else 0).getbbox()
    if not bbox:
        raise ValueError("background removal left no visible logo")
    visible_bbox_ratio = ((bbox[2] - bbox[0]) * (bbox[3] - bbox[1])) / (rgba.width * rgba.height)
    return rgba, {
        "background_rgb": background,
        "border_p90": border_p90,
        "border_background_coverage": round(background_coverage, 4),
        "visible_bbox_ratio": round(visible_bbox_ratio, 4),
    }


def _trim_visible(image: Image.Image, min_visible_px: int) -> Image.Image:
    alpha = image.getchannel("A")
    bbox = alpha.point(lambda value: 255 if value >= 8 else 0).getbbox()
    if not bbox:
        raise ValueError("logo has no visible pixels after normalization")
    visible_width = bbox[2] - bbox[0]
    visible_height = bbox[3] - bbox[1]
    if visible_width < min_visible_px or visible_height < min_visible_px:
        raise ValueError(
            f"logo is too small after normalization ({visible_width}x{visible_height}); request a clearer source"
        )
    padding = max(2, round(max(visible_width, visible_height) * 0.035))
    left = max(0, bbox[0] - padding)
    top = max(0, bbox[1] - padding)
    right = min(image.width, bbox[2] + padding)
    bottom = min(image.height, bbox[3] + padding)
    return image.crop((left, top, right, bottom))


def normalize_logo(path: Path, mode: str = "auto", min_visible_px: int = 64) -> tuple[Image.Image, dict[str, Any]]:
    if not path.is_file():
        raise ValueError(f"logo does not exist: {path}")
    if path.suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp"}:
        raise ValueError("logo input must be PNG, JPG, JPEG or WEBP")
    image = Image.open(path)
    if image.width < min_visible_px or image.height < min_visible_px:
        raise ValueError(f"logo source is too small ({image.width}x{image.height})")

    route = "transparent_trim"
    detail: dict[str, Any] = {}
    if mode == "card":
        route = "uniform_cards"
        if _has_useful_alpha(image):
            normalized = _trim_visible(image.convert("RGBA"), min_visible_px)
            detail["card_source_cleanup"] = "transparent_trim"
        else:
            try:
                normalized, removal_detail = _remove_uniform_background(image)
                normalized = _trim_visible(normalized, min_visible_px)
                detail.update(removal_detail)
                detail["card_source_cleanup"] = "solid_background_removed"
            except ValueError:
                normalized = image.convert("RGBA")
                detail["card_source_cleanup"] = "preserved_owner_confirmed_card"
    elif _has_useful_alpha(image):
        normalized = image.convert("RGBA")
    elif mode == "transparent":
        raise ValueError("transparent mode requires a real alpha channel")
    else:
        normalized, detail = _remove_uniform_background(image)
        route = "solid_background_removed"

    if route != "uniform_cards":
        normalized = _trim_visible(normalized, min_visible_px)
    meta = {
        "source": str(path),
        "source_sha256": sha256_file(path),
        "source_size": {"width": image.width, "height": image.height},
        "route": route,
        "normalized_size": {"width": normalized.width, "height": normalized.height},
        "generative_redraw": False,
        **detail,
    }
    return normalized, meta


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=("auto", "transparent", "card"), default="auto")
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--min-visible-px", type=int, default=64)
    args = parser.parse_args()
    try:
        source = args.input.expanduser().resolve()
        output = args.output.expanduser().resolve()
        normalized, manifest = normalize_logo(source, args.mode, args.min_visible_px)
        output.parent.mkdir(parents=True, exist_ok=True)
        normalized.save(output, "PNG", optimize=True)
        manifest["output"] = str(output)
        manifest["output_sha256"] = sha256_file(output)
        manifest_path = args.manifest.expanduser().resolve() if args.manifest else output.with_suffix(".manifest.json")
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(manifest, ensure_ascii=False, indent=2))
        return 0
    except (OSError, ValueError) as exc:
        print(f"BLOCK: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
