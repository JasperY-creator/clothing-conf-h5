#!/usr/bin/env python3
"""Render a deterministic, flattened PNG end slate from confirmed assets."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

try:
    from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps
except ImportError as exc:  # pragma: no cover - runtime capability gate
    raise SystemExit("BLOCK: deterministic PNG compositing requires Pillow") from exc

from normalize_logo import normalize_logo, sha256_file


RELATIONS = {"partnership": "×", "neutral": "|", "none": ""}
INSERTION_MODES = {"static_append", "deterministic_overlay"}


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object in {path}")
    return value


def require_file(value: Any, label: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{label} is required")
    path = Path(value).expanduser().resolve()
    if not path.is_file():
        raise ValueError(f"{label} does not exist: {path}")
    return path


def parse_color(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    if len(value) != 6:
        raise ValueError(f"invalid color: {value}")
    return tuple(int(value[index:index + 2], 16) for index in (0, 2, 4))


def resolve_font(config: dict[str, Any]) -> Path:
    candidates = [
        config.get("font_path"),
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Medium.ttc",
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
    ]
    for candidate in candidates:
        if candidate and Path(str(candidate)).expanduser().is_file():
            return Path(str(candidate)).expanduser().resolve()
    raise ValueError("no deterministic Chinese font is available; omit the end slate instead of generating text")


def verify_platform_asset(path: Path) -> dict[str, Any]:
    manifest_path = path.parent / "asset-manifest.json"
    if not manifest_path.is_file():
        raise ValueError("platform logo manifest is missing")
    manifest = load_json(manifest_path)
    expected = None
    for item in manifest.get("files", []):
        if isinstance(item, dict) and item.get("path") == path.name:
            expected = item.get("sha256")
            break
    actual = sha256_file(path)
    if not expected or actual != expected:
        raise ValueError("platform logo does not match the built-in official asset manifest")
    return {"path": str(path), "sha256": actual, "official_manifest_verified": True}


def make_background(width: int, height: int, colors: dict[str, str], background: Path | None) -> Image.Image:
    if background:
        return ImageOps.fit(Image.open(background).convert("RGB"), (width, height), Image.Resampling.LANCZOS).convert("RGBA")
    start = parse_color(colors["background_start"])
    end = parse_color(colors["background_end"])
    strip = Image.new("RGB", (1, height))
    for y in range(height):
        ratio = y / max(1, height - 1)
        strip.putpixel((0, y), tuple(round(start[i] * (1 - ratio) + end[i] * ratio) for i in range(3)))
    canvas = strip.resize((width, height)).convert("RGBA")
    glow = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    accent = parse_color(colors["accent"])
    ImageDraw.Draw(glow).ellipse(
        (round(width * 0.48), round(height * 0.42), round(width * 1.12), round(height * 1.15)),
        fill=(*accent, 52),
    )
    glow = glow.filter(ImageFilter.GaussianBlur(round(min(width, height) * 0.10)))
    return Image.alpha_composite(canvas, glow)


def fit_logo(image: Image.Image, max_width: int, max_height: int) -> Image.Image:
    copy = image.copy()
    copy.thumbnail((max_width, max_height), Image.Resampling.LANCZOS)
    return copy


def paste_center(canvas: Image.Image, image: Image.Image, center_x: int, center_y: int) -> None:
    canvas.alpha_composite(image, (round(center_x - image.width / 2), round(center_y - image.height / 2)))


def draw_cards(
    canvas: Image.Image,
    client: Image.Image,
    platform: Image.Image,
    layout: dict[str, Any],
    colors: dict[str, str],
) -> tuple[int, int]:
    width, height = canvas.size
    card_w = round(width * float(layout["card_width_ratio"]))
    card_h = round(height * float(layout["card_height_ratio"]))
    center_y = round(height * float(layout["logo_center_y_ratio"]))
    centers = (
        round(width * float(layout["client_logo_center_x_ratio"])),
        round(width * float(layout["platform_logo_center_x_ratio"])),
    )
    overlay = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    radius = round(height * 0.018)
    for center_x in centers:
        box = (center_x - card_w // 2, center_y - card_h // 2, center_x + card_w // 2, center_y + card_h // 2)
        shadow = (box[0] + 4, box[1] + 6, box[2] + 4, box[3] + 6)
        draw.rounded_rectangle(shadow, radius=radius, fill=(24, 45, 80, 24))
        draw.rounded_rectangle(box, radius=radius, fill=(255, 255, 255, 242), outline=(*parse_color(colors["card_border"]), 90), width=1)
    canvas.alpha_composite(overlay)
    max_w, max_h = round(card_w * 0.72), round(card_h * 0.58)
    paste_center(canvas, fit_logo(client, max_w, max_h), centers[0], center_y)
    paste_center(canvas, fit_logo(platform, max_w, max_h), centers[1], center_y)
    return round(width * float(layout["relation_center_x_ratio"])), center_y


def draw_free_logos(
    canvas: Image.Image,
    client: Image.Image,
    platform: Image.Image,
    layout: dict[str, Any],
) -> tuple[int, int]:
    width, height = canvas.size
    target_h = round(height * float(layout["logo_visible_height_ratio"]))
    max_w = round(width * 0.30)
    client = fit_logo(client, max_w, target_h)
    platform = fit_logo(platform, max_w, target_h)
    center_y = round(height * float(layout["logo_center_y_ratio"]))
    paste_center(canvas, client, round(width * float(layout["client_logo_center_x_ratio"])), center_y)
    paste_center(canvas, platform, round(width * float(layout["platform_logo_center_x_ratio"])), center_y)
    return round(width * float(layout["relation_center_x_ratio"])), center_y


def fitted_font(draw: ImageDraw.ImageDraw, text: str, font_path: Path, start_size: int, max_width: int) -> ImageFont.FreeTypeFont:
    size = start_size
    while size >= 24:
        font = ImageFont.truetype(str(font_path), size=size)
        bbox = draw.textbbox((0, 0), text, font=font)
        if bbox[2] - bbox[0] <= max_width:
            return font
        size -= 2
    raise ValueError("title is too long for the deterministic safe area")


def render(config_path: Path, output_dir: Path, layouts_path: Path) -> dict[str, Any]:
    config = load_json(config_path)
    layouts = load_json(layouts_path)
    if config.get("deterministic_compositor_verified") is not True:
        raise ValueError("deterministic_compositor_verified must be true; otherwise omit the end slate")
    insertion_mode = str(config.get("video_insertion_mode", ""))
    if insertion_mode not in INSERTION_MODES:
        raise ValueError("video_insertion_mode must be static_append or deterministic_overlay")
    for field in ("copy_confirmed", "client_logo_confirmed", "relationship_confirmed"):
        if config.get(field) is not True:
            raise ValueError(f"{field} must be true")
    if config.get("model_generated_readable_text") is not False:
        raise ValueError("model_generated_readable_text must be false")

    title = str(config.get("title", "")).strip()
    if not title or len(title) > 28:
        raise ValueError("title must contain 1-28 characters")
    relation = str(config.get("relation", "neutral"))
    if relation not in RELATIONS:
        raise ValueError(f"relation must be one of {sorted(RELATIONS)}")
    width, height = int(config.get("width", 1920)), int(config.get("height", 1080))
    if width < 640 or height < 360:
        raise ValueError("width/height are too small for a formal end slate")

    client_path = require_file(config.get("client_logo"), "client_logo")
    platform_path = require_file(config.get("platform_logo"), "platform_logo")
    platform_meta = verify_platform_asset(platform_path)
    logo_mode = str(config.get("client_logo_mode", "auto"))
    if logo_mode not in {"auto", "transparent", "card"}:
        raise ValueError("client_logo_mode must be auto, transparent or card")
    client, client_meta = normalize_logo(client_path, logo_mode)
    platform, platform_normalization = normalize_logo(platform_path, "transparent")
    presentation = "uniform_cards" if client_meta["route"] == "uniform_cards" else "transparent"
    if presentation == "uniform_cards" and "white-text" in platform_path.name:
        raise ValueError("uniform white cards require the built-in dark-text platform logo")

    theme = str(config.get("theme", "light"))
    themes = layouts.get("themes", {})
    if theme not in themes:
        raise ValueError(f"theme must be one of {sorted(themes)}")
    colors = themes[theme]
    background = require_file(config.get("background_image"), "background_image") if config.get("background_image") else None
    if background and config.get("background_confirmed_clean_plate") is not True:
        raise ValueError("background_confirmed_clean_plate must be true for a supplied background")

    font_path = resolve_font(config)
    clean = make_background(width, height, colors, background)
    master = clean.copy()
    if presentation == "uniform_cards":
        relation_x, relation_y = draw_cards(master, client, platform, layouts, colors)
    else:
        relation_x, relation_y = draw_free_logos(master, client, platform, layouts)

    draw = ImageDraw.Draw(master)
    symbol = RELATIONS[relation]
    if symbol:
        relation_font = ImageFont.truetype(str(font_path), size=max(28, round(height * float(layouts["relation_font_ratio"]))))
        draw.text((relation_x, relation_y), symbol, font=relation_font, fill=parse_color(colors["relation"]), anchor="mm")
    title_font = fitted_font(
        draw,
        title,
        font_path,
        round(height * float(layouts["title_font_ratio"])),
        round(width * float(layouts["title_max_width_ratio"])),
    )
    draw.text(
        (width // 2, round(height * float(layouts["title_center_y_ratio"]))),
        title,
        font=title_font,
        fill=parse_color(colors["title"]),
        anchor="mm",
    )
    meta_font = ImageFont.truetype(str(font_path), size=max(24, round(height * float(layouts["meta_font_ratio"]))))
    date = str(config.get("date", "")).strip()
    location = str(config.get("location", "")).strip()
    if date:
        draw.text((width // 2, round(height * float(layouts["meta_date_y_ratio"]))), date, font=meta_font, fill=parse_color(colors["meta"]), anchor="mm")
    if location:
        draw.text((width // 2, round(height * float(layouts["meta_location_y_ratio"]))), location, font=meta_font, fill=parse_color(colors["meta"]), anchor="mm")

    output_dir.mkdir(parents=True, exist_ok=True)
    clean_path = output_dir / "end_slate_clean_plate.png"
    master_path = output_dir / "end_slate_master.png"
    normalized_path = output_dir / "client_logo_normalized.png"
    clean.convert("RGB").save(clean_path, "PNG", optimize=True)
    master.convert("RGB").save(master_path, "PNG", optimize=True)
    client.save(normalized_path, "PNG", optimize=True)
    manifest = {
        "schema_version": "1.75",
        "template_version": layouts.get("template_version", "unknown"),
        "copy_id": config.get("copy_id", ""),
        "title": title,
        "relation": relation,
        "date": date,
        "location": location,
        "theme": theme,
        "logo_presentation": presentation,
        "video_insertion_mode": insertion_mode,
        "font": {"path": str(font_path), "sha256": sha256_file(font_path), "rasterized": True},
        "assets": {
            "client_logo": {**client_meta, "normalized_path": str(normalized_path), "owner_confirmed": True},
            "platform_logo": {**platform_meta, "normalization": platform_normalization},
            "background": str(background) if background else "deterministic_template",
        },
        "outputs": {
            "master": str(master_path),
            "master_sha256": sha256_file(master_path),
            "clean_plate": str(clean_path),
            "clean_plate_sha256": sha256_file(clean_path),
        },
        "qa": {
            "copy_confirmed": True,
            "client_logo_confirmed": True,
            "relationship_confirmed": True,
            "model_generated_readable_text": False,
            "deterministic_compositor_verified": True,
            "platform_asset_manifest_verified": True,
            "flattened_png": True,
            "status": "PASS",
        },
    }
    manifest_path = output_dir / "end_slate_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("config", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument(
        "--layouts",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "assets" / "end-slate" / "layouts.json",
    )
    args = parser.parse_args()
    try:
        result = render(args.config.resolve(), args.output_dir.resolve(), args.layouts.resolve())
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"BLOCK: {exc}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
