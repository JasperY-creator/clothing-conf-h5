# 使用示例

本文档提供从飞书云文档转换政府公文的完整使用示例。

技能脚本目录（下文统一用 `SKILL_SCRIPTS` 指代）：

```
/home/user/.super_doubao/super-doubao-runtime/workspace/.user_skills/lark-doc-to-official-docx/scripts
```

## 示例 1：完整自动提取

```python
import sys
sys.path.insert(
    0,
    '/home/user/.super_doubao/super-doubao-runtime/workspace/.user_skills/lark-doc-to-official-docx/scripts'
)
from lark_doc_to_official_docx import convert_lark_doc_to_official

# 步骤1：用页面与文件内容获取工具读取飞书云文档，拿到 Markdown 文本
# 步骤2：准备 Markdown 内容（此处为示例）
markdown_content = """
# XX市人民政府关于开展2026年全市安全生产专项整治行动的通知

XX政〔2026〕45号

各县（市、区）人民政府，市各有关部门：

为深入贯彻落实国家、省关于安全生产工作的最新部署要求，现就开展专项整治通知如下。

一、整治目标

坚决防范化解重大安全风险。

二、整治范围

（一）危险化学品领域

聚焦危险化学品生产、储存环节。

（二）建筑施工领域

针对房屋建筑、市政工程。

三、整治时间

1. 动员部署阶段（2026年6月1日—6月15日）

各县（市、区）人民政府制定实施方案。

（1）成立工作机构

明确责任分工。

（2）开展宣传动员

营造良好氛围。

附件：1.2026年全市安全生产专项整治行动领导小组名单
2.重点工作任务分解表

XX市人民政府
2026年5月28日

抄送：省应急管理厅，市委办公室，市人大常委会办公室。
XX市人民政府办公室 2026年5月28日印发
"""

# 步骤3：执行转换（自动提取所有要素）
output_file, params = convert_lark_doc_to_official(
    markdown_content=markdown_content,
    output_file='安全生产专项整治通知.docx',
    auto_extract=True
)

print(f"文档已生成: {output_file}")
print(f"实际使用的要素: {params}")
```

## 示例 2：先预览再转换（推荐做法）

关键要素建议先核对，确认无误后再生成文档：

```python
from lark_doc_to_official_docx import (
    extract_doc_info, print_extracted_info, convert_lark_doc_to_official)

# 1. 预览提取结果
info = extract_doc_info(markdown_content)
print_extracted_info(info)

# 2. 检查正文是否正确剥离了各要素
print("正文前 200 字：")
print(info['body_content'][:200])

# 3. 确认无误后再生成
output_file, params = convert_lark_doc_to_official(
    markdown_content=markdown_content,
    output_file='output.docx',
    auto_extract=True
)
```

`print_extracted_info` 输出示例：

```
==================================================
自动提取的公文信息：
==================================================
公文标题:   XX市人民政府关于开展2026年全市安全生产专项整治行动的通知
发文机关:   XX市人民政府
发文字号:   XX政〔2026〕45号
成文日期:   2026年5月28日
附件列表:   ['2026年全市安全生产专项整治行动领导小组名单', '重点工作任务分解表']
抄送机关:   省应急管理厅，市委办公室，市人大常委会办公室。
印发机关:   XX市人民政府办公室
印发日期:   2026年5月28日印发
==================================================
```

## 示例 3：手动指定关键参数

自动提取不准确时，用手动参数覆盖（手动值优先）：

```python
output_file, params = convert_lark_doc_to_official(
    markdown_content=markdown_content,
    output_file='output.docx',
    auto_extract=True,              # 仍启用自动提取作为后备
    org_name='XX市人民政府',          # 覆盖发文机关
    doc_number='XX政〔2026〕45号',    # 覆盖发文字号
    date_str='2026年5月28日'          # 覆盖成文日期
)
# 未指定的字段（如 publisher、cc_to）仍使用自动提取结果
```

**注意**：传入空字符串 `''` 或空列表 `[]` 视为"未指定"，会回退到自动提取值。
若要**强制清空**某要素，请使用 `auto_extract=False` 的完全手动模式。

## 示例 4：上行文（带签发人）

请示、报告等上行文需要标注签发人：

```python
upward_doc = """
# XX市财政局关于申请专项经费的请示

XX财〔2026〕12号

市人民政府：

现将有关情况报告如下。

XX市财政局
2026年6月1日
"""

output_file, params = convert_lark_doc_to_official(
    markdown_content=upward_doc,
    output_file='经费请示.docx',
    auto_extract=True,
    issuer='张三'      # 签发人：发文字号左空1字，签发人右空1字同行分列
)
```

## 示例 5：完全手动模式

不做任何自动提取，正文原样排版，所有要素显式指定：

```python
output_file, params = convert_lark_doc_to_official(
    markdown_content='各单位：\n\n正文内容。',
    output_file='output.docx',
    auto_extract=False,             # 关闭自动提取
    title='XX市人民政府关于XXX的通知',
    org_name='XX市人民政府',
    doc_number='XX政〔2026〕1号',
    date_str='2026年6月1日',
    issuer='张三',
    attachments=['附件一名称', '附件二名称'],
    cc_to='省厅，市委办公室',
    publisher='XX市人民政府办公室',
    publish_date='2026年6月2日印发',
    page_number=True
)
```

## 示例 6：命令行使用

```bash
cd /home/user/.super_doubao/super-doubao-runtime/workspace/.user_skills/lark-doc-to-official-docx/scripts

# 自动提取模式（先打印提取结果供核对，再生成）
python3 lark_doc_to_official_docx.py input.md output.docx

# 手动模式（不自动提取要素，正文原样排版）
python3 lark_doc_to_official_docx.py input.md output.docx --manual
```

## 示例 7：批量处理多个文档

```python
import sys
sys.path.insert(
    0,
    '/home/user/.super_doubao/super-doubao-runtime/workspace/.user_skills/lark-doc-to-official-docx/scripts'
)
from lark_doc_to_official_docx import convert_lark_doc_to_official, extract_doc_info

# doc_contents: List[Tuple[文件名, Markdown内容]]
# 各文档内容需先用页面与文件内容获取工具分别读取
doc_contents = [
    ('公文_1.docx', md_content_1),
    ('公文_2.docx', md_content_2),
    ('公文_3.docx', md_content_3),
]

results = []
for out_name, content in doc_contents:
    info = extract_doc_info(content)
    # 缺关键要素时先记录，便于事后人工补充
    missing = [k for k in ('title', 'org_name', 'doc_number', 'date_str')
               if not info.get(k)]
    result_file, params = convert_lark_doc_to_official(
        markdown_content=content,
        output_file=out_name,
        auto_extract=True
    )
    results.append((result_file, missing))
    print(f"已生成: {result_file}" + (f"（缺失要素: {missing}）" if missing else ""))
```

## 示例 8：只用底层排版函数

已有干净正文（不含标题/版头/版记要素）时，可直接调用底层函数：

```python
from convert_to_official_docx import convert_to_official_format

# input.txt 中只放正文，各要素通过参数传入
convert_to_official_format(
    'input.txt',
    'output.docx',
    title='XX局关于XXX的通知',
    org_name='XX局',
    doc_number='XX发〔2026〕3号',
    date_str='2026年7月1日',
    page_number=True
)
```

## 常见问题

### Q1: 自动提取失败怎么办？

```python
info = extract_doc_info(markdown_content)
print_extracted_info(info)

# 对为 None 的字段手动补充
output_file, params = convert_lark_doc_to_official(
    markdown_content=markdown_content,
    output_file='output.docx',
    auto_extract=True,
    org_name='XX市人民政府',      # 手动补充
    doc_number='XX政〔2026〕1号',
    date_str='2026年6月1日'
)
```

### Q2: 生成的文档没有红色版头？

版头需要 `org_name` 与 `doc_number` **同时存在**才会生成。
若标题不含"关于/印发/转发/批转"，或文中无发文字号，则不生成版头。
此时手动传入这两个参数即可。

### Q3: 某个层级标题字体不对？

层级判定依据序号格式，请确认：

| 期望层级 | 正确写法 | 对应字体 |
|----------|----------|----------|
| 一级 | `一、标题` | 黑体三号 |
| 二级 | `（一）标题` 或 `(一)标题` | 楷体_GB2312 三号 |
| 三级 | `1. 标题` | 仿宋三号加粗 |
| 四级 | `（1）标题` 或 `(1)标题` | 仿宋三号加粗 |

全角与半角括号均支持。若写成 `1、标题` 也会识别为三级。

### Q4: 正文里出现了落款/附件说明的重复内容？

新版已通过尾部区域剥离解决此问题。若仍出现，说明该要素格式特殊未被识别，
可先用 `extract_doc_info` 检查 `body_content`，再用手动参数纠正。

### Q5: 打开文档字体不对？

生成的 docx 只写入字体名称，需在**打开文档的机器**上安装对应字体：
方正小标宋简体、仿宋_GB2312、楷体_GB2312、黑体、宋体。
字体缺失不影响文件生成，只影响显示效果。

### Q6: 如何处理特殊格式的文档？

```python
# 转换前先做针对性预处理
processed = markdown_content.replace('特殊标记', '')

output_file, params = convert_lark_doc_to_official(
    markdown_content=processed,
    output_file='output.docx',
    auto_extract=True
)
```

## 输出文件验证清单

生成文档后建议检查：

1. **版头**：红色发文机关标志（二号小标宋居中）、发文字号、与版心等宽的红色分隔线
2. **标题**：方正小标宋简体二号、居中、只出现一次
3. **主送机关**：仿宋三号、顶格无缩进
4. **正文**：仿宋_GB2312 三号、首行缩进 2 字
5. **标题层级**：一级黑体、二级楷体、三/四级仿宋加粗
6. **附件说明**：左空 2 字、多附件用阿拉伯数字编号
7. **署名与日期**：右空 4 字、各只出现一次
8. **版记**：抄送机关、印发机关与日期、首末粗线中间细线
9. **页码**：单页居右、双页居左
10. **页边距**：上 3.7cm、下 3.5cm、左 2.8cm、右 2.6cm
11. **无重复内容**：落款、附件说明、版记要素未在正文中重复出现
