#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
飞书文档转政府公文（增强版）
基于 GB/T 9704-2012《党政机关公文格式》标准

与基础脚本的差异：
    本模块负责"理解"飞书云文档的 Markdown，把它拆成公文的各个法定要素
    （标题、发文字号、主送机关、正文、附件说明、署名、成文日期、版记），
    然后把纯正文交给 convert_to_official_docx 排版。

关键设计：采用自底向上的"区域切分"而非全文关键词扫描。
    版记 / 署名 / 附件说明都位于文末且顺序固定，
    先从尾部逐段剥离这些要素，剩下的才是正文。
    这样可以彻底避免同一内容既进正文又进要素区（重复输出）。
"""

import os
import re
import sys
import tempfile
from typing import Any, Dict, List, Optional, Tuple

# 允许以脚本或模块两种方式导入同目录下的依赖
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from convert_to_official_docx import (  # noqa: E402
    convert_to_official_format,
    PAGE_CONFIG,
    LINE_SPACING,
    FONTS,
    COLORS,
    set_run_font,
    set_paragraph_format,
    parse_heading_level,
    is_main_recipient,
    is_title_line,
    number_to_chinese,
    setup_page,
    add_red_header,
    add_title,
    add_main_body,
    add_attachment_note,
    add_signature,
    add_footer_section,
)
from markdown_cleaner import clean_markdown_for_docx  # noqa: E402


# ============ 正则常量 ============

# 发文字号：机关代字〔年份〕序号号，兼容六角括号〔〕与方头括号[]
RE_DOC_NUMBER = re.compile(r'^\S{0,30}?[〔\[［]\s*\d{4}\s*[〕\]］]\s*\d+\s*号$')

# 独立成行的完整日期
RE_DATE_LINE = re.compile(r'^\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日$')

# 版记中的印发行：印发机关 + 日期 + "印发/发布"
RE_PUBLISH_LINE = re.compile(
    r'^(?P<publisher>.+?)[\s　]+(?P<date>\d{4}年\d{1,2}月\d{1,2}日)\s*(?P<verb>印发|发布)$'
)

# 抄送行
RE_CC_LINE = re.compile(r'^抄送[：:](?P<cc>.*)$')

# 附件说明行（正文末尾的"附件："，非附件正文内的引用）
RE_ATTACH_LINE = re.compile(r'^附件\s*[:：]\s*(?P<rest>.*)$')

# Markdown 标题标记
RE_MD_HEADING = re.compile(r'^(#{1,6})\s+(?P<text>.*)$')

# Markdown 列表项标记
RE_MD_LIST = re.compile(r'^\s*[-*+]\s+')

# 附件多项时的序号前缀（1. / 一、 / （1））
RE_ATTACH_SEQ = re.compile(
    r'^(?:[（(]?\s*\d+\s*[)）.．、]|[（(]?\s*[一二三四五六七八九十]+\s*[)）.．、])\s*'
)

# 机关名特征词，用于识别署名行与印发机关
ORG_KEYWORDS = (
    '人民政府', '委员会', '办公室', '办公厅', '党委', '党组', '支部', '总支',
    '管理局', '监督局', '公司', '集团', '厅', '局', '部', '委', '院', '署',
    '处', '科', '中心', '协会', '学会', '基金会', '大学', '学校', '医院',
    '研究所', '工作组', '领导小组', '指挥部', '筹备组',
)


def _looks_like_org(text: str) -> bool:
    """判断一行是否像"机关名称"（用于识别署名与印发机关）"""
    text = text.strip()
    if not text or len(text) > 60:
        return False
    if parse_heading_level(text)[0] is not None:
        return False
    # 机关名不含句末标点
    if text.endswith(('。', '；', '，', '：', '！', '？', '.', ';', ',')):
        return False
    return any(kw in text for kw in ORG_KEYWORDS)


def _strip_md_marks(line: str) -> str:
    """去掉行首的 Markdown 标题 / 列表标记，保留公文层级标记"""
    m = RE_MD_HEADING.match(line)
    if m:
        return m.group('text').strip()
    if RE_MD_LIST.match(line):
        return RE_MD_LIST.sub('', line).strip()
    return line.strip()


def _normalize_date(text: str) -> str:
    """规范化日期：去掉多余空格，月日不编虚位"""
    m = re.match(r'^(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', text.strip())
    if not m:
        return text.strip()
    y, mo, d = m.groups()
    return f'{y}年{int(mo)}月{int(d)}日'


# ============ 核心：结构化提取 ============

def extract_doc_info(markdown_content: str) -> Dict[str, Any]:
    """
    从飞书云文档 Markdown 内容中提取公文各法定要素。

    采用"先剥离要素、后留正文"的策略：
        1. 逐行预清洗（去 Markdown 标记）
        2. 从头部剥离：H1 标题、发文字号
        3. 从尾部剥离：版记（印发行、抄送行）→ 署名与成文日期 → 附件说明
        4. 剩余部分即为正文，交给 markdown_cleaner 做行内清理

    Returns:
        dict，键包括 org_name / doc_number / title / date_str /
        attachments / cc_to / publisher / publish_date / body_content
    """
    info: Dict[str, Any] = {
        'org_name': None,
        'doc_number': None,
        'title': None,
        'date_str': None,
        'attachments': [],
        'cc_to': None,
        'publisher': None,
        'publish_date': None,
        'body_content': None,
    }

    # ---------- 阶段 0：预清洗 ----------
    # 保留空行（用于段落分隔），但去掉 Markdown 标记
    raw_lines = markdown_content.split('\n')
    lines: List[str] = []
    in_code_block = False
    for raw in raw_lines:
        stripped = raw.strip()
        # 跳过代码块
        if stripped.startswith('```'):
            in_code_block = not in_code_block
            continue
        if in_code_block:
            continue
        # 跳过纯分隔线
        if re.match(r'^\s*([-*_])\s*(\1\s*){2,}$', raw):
            continue
        lines.append(_strip_md_marks(raw))

    # ---------- 阶段 1：头部要素（标题、发文字号）----------
    head_consumed = set()

    # 1.1 公文标题：优先取第一个 H1；否则取首个非空且不含冒号的长行
    for i, raw in enumerate(raw_lines):
        m = RE_MD_HEADING.match(raw.strip())
        if m and len(m.group(1)) == 1:
            title_text = m.group('text').strip()
            if title_text:
                info['title'] = title_text
                break

    if not info['title']:
        for i, line in enumerate(lines):
            if not line:
                continue
            if RE_DOC_NUMBER.match(line) or is_main_recipient(line):
                continue
            if parse_heading_level(line)[0] is not None:
                continue
            if 5 <= len(line) <= 80:
                info['title'] = line
                head_consumed.add(i)
            break

    # 1.2 发文机关名称：从标题中截取"关于/印发/转发/批转"之前的部分
    if info['title']:
        org_match = re.match(
            r'^(.+?)(?=关于|印发|转发|批转|对.+?的)', info['title'])
        if org_match:
            candidate = org_match.group(1).strip()
            if candidate and len(candidate) <= 60:
                info['org_name'] = candidate

    # 1.3 发文字号
    for i, line in enumerate(lines):
        if line and RE_DOC_NUMBER.match(line):
            info['doc_number'] = line
            head_consumed.add(i)
            break

    # 从 lines 中移除已被识别为标题的行（标题不进正文）
    title_line_idx = None
    if info['title']:
        for i, line in enumerate(lines):
            if line == info['title']:
                title_line_idx = i
                break

    # ---------- 阶段 2：尾部要素（版记 → 署名 → 附件）----------
    # 建立可变工作副本，用下标标记"已消费"
    consumed = set(head_consumed)
    if title_line_idx is not None:
        consumed.add(title_line_idx)

    def _last_unconsumed() -> List[int]:
        """返回未被消费的行下标（升序）"""
        return [i for i, l in enumerate(lines)
                if i not in consumed and l.strip()]

    # 2.1 版记：印发行 与 抄送行（自尾部向前查找，限定在最后 12 个有效行内）
    active = _last_unconsumed()
    tail_window = active[-12:] if len(active) > 12 else active

    for i in reversed(tail_window):
        line = lines[i]
        m = RE_PUBLISH_LINE.match(line)
        if m and _looks_like_org(m.group('publisher')):
            info['publisher'] = m.group('publisher').strip()
            info['publish_date'] = (_normalize_date(m.group('date'))
                                    + m.group('verb'))
            consumed.add(i)
            break

    # 印发机关与日期分行的情况
    if not info['publisher']:
        for i in reversed(tail_window):
            line = lines[i]
            if ('印发' in line or '发布' in line) and _looks_like_org(
                    re.sub(r'\d{4}年\d{1,2}月\d{1,2}日\s*(印发|发布)', '', line)):
                date_m = re.search(r'(\d{4}年\d{1,2}月\d{1,2}日)', line)
                pub = re.sub(r'\d{4}年\d{1,2}月\d{1,2}日\s*(印发|发布)', '',
                             line).strip()
                if pub:
                    info['publisher'] = pub
                    if date_m:
                        info['publish_date'] = (
                            _normalize_date(date_m.group(1)) + '印发')
                    consumed.add(i)
                    break

    # 抄送行（可能跨行续接）
    active = _last_unconsumed()
    tail_window = active[-12:] if len(active) > 12 else active
    for i in reversed(tail_window):
        m = RE_CC_LINE.match(lines[i])
        if m:
            cc_parts = [m.group('cc').strip()]
            consumed.add(i)
            # 向后收集续行（缩进或不含新要素标记的行）
            j = i + 1
            while j < len(lines):
                nxt = lines[j].strip()
                if not nxt:
                    break
                if (RE_CC_LINE.match(nxt) or RE_PUBLISH_LINE.match(nxt)
                        or RE_DATE_LINE.match(nxt) or _looks_like_org(nxt)):
                    break
                if j in consumed:
                    break
                cc_parts.append(nxt)
                consumed.add(j)
                j += 1
            info['cc_to'] = ' '.join(p for p in cc_parts if p).strip()
            break

    # 2.2 署名与成文日期：位于剩余内容的尾部，形如"机关名 / 日期"
    active = _last_unconsumed()
    if active:
        # 最后一个有效行是日期 → 成文日期
        last_idx = active[-1]
        if RE_DATE_LINE.match(lines[last_idx]):
            info['date_str'] = _normalize_date(lines[last_idx])
            consumed.add(last_idx)
            # 日期上一行若是机关名 → 署名
            active = _last_unconsumed()
            if active:
                prev_idx = active[-1]
                if _looks_like_org(lines[prev_idx]):
                    if not info['org_name']:
                        info['org_name'] = lines[prev_idx].strip()
                    consumed.add(prev_idx)
        else:
            # 仅有机关名、无日期的情况
            if _looks_like_org(lines[last_idx]):
                if not info['org_name']:
                    info['org_name'] = lines[last_idx].strip()
                consumed.add(last_idx)

    # 2.3 附件说明：位于剩余内容尾部的"附件："行及其后续项
    active = _last_unconsumed()
    tail_window = active[-8:] if len(active) > 8 else active
    for i in reversed(tail_window):
        m = RE_ATTACH_LINE.match(lines[i])
        if not m:
            continue
        rest = m.group('rest').strip()
        consumed.add(i)
        if rest:
            # "附件：名称" 同行
            info['attachments'].append(RE_ATTACH_SEQ.sub('', rest).strip())
        # 收集后续附件项（带序号或非空的连续行）
        j = i + 1
        while j < len(lines):
            nxt = lines[j].strip()
            if j in consumed:
                j += 1
                continue
            if not nxt:
                # 空行后若紧跟带序号项，继续；否则结束
                k = j + 1
                while k < len(lines) and not lines[k].strip():
                    k += 1
                if k < len(lines) and RE_ATTACH_SEQ.match(lines[k].strip()):
                    j = k
                    continue
                break
            if (_looks_like_org(nxt) or RE_DATE_LINE.match(nxt)
                    or RE_CC_LINE.match(nxt)):
                break
            # 仅收集看起来像附件项的行
            if RE_ATTACH_SEQ.match(nxt) or not info['attachments']:
                info['attachments'].append(
                    RE_ATTACH_SEQ.sub('', nxt).strip())
                consumed.add(j)
                j += 1
                continue
            break
        break

    info['attachments'] = [a for a in info['attachments'] if a]

    # ---------- 阶段 3：正文 ----------
    body_lines = [lines[i] if i not in consumed else ''
                  for i in range(len(lines))]

    # 压缩连续空行为单个空行
    compact: List[str] = []
    for line in body_lines:
        if not line.strip():
            if compact and not compact[-1].strip():
                continue
            compact.append('')
        else:
            compact.append(line)
    # 去掉首尾空行
    while compact and not compact[0].strip():
        compact.pop(0)
    while compact and not compact[-1].strip():
        compact.pop()

    info['body_content'] = clean_markdown_for_docx('\n'.join(compact))

    return info


# ============ 转换入口 ============

def convert_lark_doc_to_official(
    markdown_content: str,
    output_file: str = 'output.docx',
    auto_extract: bool = True,
    **manual_params
) -> Tuple[str, Dict]:
    """
    将飞书云文档内容转换为政府公文格式 docx。

    Args:
        markdown_content: 云文档的 Markdown 内容
        output_file:      输出 docx 路径
        auto_extract:     是否自动提取公文要素
        **manual_params:  手动指定的要素，优先级高于自动提取
                          （title / org_name / doc_number / date_str /
                           issuer / attachments / cc_to / publisher /
                           publish_date / page_number）

    Returns:
        (输出文件路径, 实际使用的参数字典)
    """
    if auto_extract:
        info = extract_doc_info(markdown_content)

        def _pick(key):
            val = manual_params.get(key)
            return val if val not in (None, '', []) else info.get(key)

        params = {
            'title': _pick('title'),
            'org_name': _pick('org_name'),
            'doc_number': _pick('doc_number'),
            'date_str': _pick('date_str'),
            'attachments': _pick('attachments'),
            'cc_to': _pick('cc_to'),
            'publisher': _pick('publisher'),
            'publish_date': _pick('publish_date'),
            'issuer': manual_params.get('issuer'),
            'page_number': manual_params.get('page_number', True),
        }
        body_content = info['body_content'] or markdown_content
    else:
        params = dict(manual_params)
        params.setdefault('page_number', True)
        # 手动模式下也要去除 Markdown 标记并清理行内格式
        stripped = [_strip_md_marks(l) for l in markdown_content.split('\n')]
        body_content = clean_markdown_for_docx('\n'.join(stripped))

    # 写临时正文文件供基础转换函数读取
    tmp_fd, input_file = tempfile.mkstemp(suffix='.txt', text=True)
    try:
        with os.fdopen(tmp_fd, 'w', encoding='utf-8') as f:
            f.write(body_content)
        convert_to_official_format(input_file, output_file, **params)
        return output_file, params
    finally:
        if os.path.exists(input_file):
            os.unlink(input_file)


def print_extracted_info(info: Dict):
    """打印提取的信息，用于预览和人工核对"""
    print("=" * 50)
    print("自动提取的公文信息：")
    print("=" * 50)
    print(f"公文标题:   {info.get('title') or '未提取'}")
    print(f"发文机关:   {info.get('org_name') or '未提取'}")
    print(f"发文字号:   {info.get('doc_number') or '未提取'}")
    print(f"成文日期:   {info.get('date_str') or '未提取'}")
    print(f"附件列表:   {info.get('attachments') or '无'}")
    print(f"抄送机关:   {info.get('cc_to') or '未提取'}")
    print(f"印发机关:   {info.get('publisher') or '未提取'}")
    print(f"印发日期:   {info.get('publish_date') or '未提取'}")
    print("=" * 50)


def main():
    """命令行入口"""
    if len(sys.argv) < 3:
        print("用法: python lark_doc_to_official_docx.py <输入markdown> <输出docx> [--manual]")
        print("示例: python lark_doc_to_official_docx.py input.md output.docx")
        sys.exit(1)

    input_file, output_file = sys.argv[1], sys.argv[2]
    auto_extract = '--manual' not in sys.argv

    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()

    if auto_extract:
        print_extracted_info(extract_doc_info(content))

    result_file, params = convert_lark_doc_to_official(
        content, output_file, auto_extract=auto_extract)

    print(f"\n文档已保存至: {result_file}")
    print("使用的参数：")
    for key, value in params.items():
        if value:
            print(f"  {key}: {value}")


if __name__ == '__main__':
    main()
