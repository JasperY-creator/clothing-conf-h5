#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
政府公文格式转换脚本
基于 GB/T 9704-2012《党政机关公文格式》标准

主要能力：
    - A4 版面与国标页边距设置
    - 版头（发文机关标志、发文字号、签发人、红色分隔线）
    - 主体（标题、主送机关、正文分级、附件说明、署名与成文日期）
    - 版记（抄送机关、印发机关与印发日期、分隔线）
    - 奇偶页页码

说明：缩进一律采用"字符"为单位（Word 的 firstLineChars / leftChars 等），
      以保证在不同字号下都精确等于国标要求的"空 N 字"。
"""

import sys
import re
from typing import List, Optional, Sequence

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_TAB_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ============ 格式常量定义 ============

# 页面设置 (单位: 厘米)
PAGE_CONFIG = {
    'paper_width': Cm(21.0),      # A4纸宽度
    'paper_height': Cm(29.7),     # A4纸高度
    'margin_top': Cm(3.7),        # 上边距（天头 37mm）
    'margin_bottom': Cm(3.5),     # 下边距（地脚 35mm）
    'margin_left': Cm(2.8),       # 左边距（订口 28mm）
    'margin_right': Cm(2.6),      # 右边距（翻口 26mm）
}

# 版心宽度 = 21 - 2.8 - 2.6 = 15.6cm (156mm)
BODY_WIDTH = Cm(15.6)

# 行距设置：国标固定值 28-29 磅
LINE_SPACING = Pt(28.95)

# 字体设置（字号：二号=22pt，三号=16pt，四号=14pt）
FONTS = {
    'title': ('方正小标宋简体', Pt(22)),           # 公文标题 二号
    'org_mark': ('方正小标宋简体', Pt(22)),        # 发文机关标志 二号（红色）
    'body': ('仿宋_GB2312', Pt(16)),               # 正文 三号
    'heading_1': ('黑体', Pt(16)),                 # 一级标题 三号
    'heading_2': ('楷体_GB2312', Pt(16)),          # 二级标题 三号
    'heading_3': ('仿宋_GB2312', Pt(16)),          # 三级标题 三号（加粗）
    'heading_4': ('仿宋_GB2312', Pt(16)),          # 四级标题 三号（加粗）
    'header': ('仿宋_GB2312', Pt(16)),             # 发文字号 三号
    'signature': ('仿宋_GB2312', Pt(16)),          # 发文机关署名 三号
    'footer': ('仿宋_GB2312', Pt(14)),             # 版记 四号
    'page_number': ('宋体', Pt(14)),               # 页码 四号
}

# 颜色设置
COLORS = {
    'red': RGBColor(255, 0, 0),      # 红色（用于版头）
    'black': RGBColor(0, 0, 0),      # 黑色
}

# 分隔线粗细（单位：1/8 磅）
BORDER_SIZE = {
    'red': 12,      # 版头红色分隔线（约 1.5 磅）
    'thick': 8,     # 版记首末条分隔线（约 0.35mm）
    'thin': 6,      # 版记中间分隔线（约 0.25mm）
}


# ============ 底层辅助函数 ============

def set_run_font(run, font_name, font_size, bold=False, color=None):
    """设置文本运行的字体（同时设置西文与中文字体）"""
    run.font.name = font_name
    run.font.size = font_size
    run.font.bold = bold
    if color:
        run.font.color.rgb = color
    # 设置中文字体（eastAsia）与兜底字体
    rPr = run._element.get_or_add_rPr()
    rFonts = rPr.get_or_add_rFonts()
    rFonts.set(qn('w:eastAsia'), font_name)
    rFonts.set(qn('w:ascii'), font_name)
    rFonts.set(qn('w:hAnsi'), font_name)


def set_char_indent(para, first_line_chars=None, left_chars=None,
                    right_chars=None, hanging_chars=None):
    """
    以"字符"为单位设置缩进（Word 原生 chars 属性，单位为 1/100 字符）。

    国标中的"左空 2 字""右空 4 字"必须按字符计算，
    用固定厘米值在不同字号下会产生偏差。
    """
    pPr = para._p.get_or_add_pPr()
    ind = pPr.find(qn('w:ind'))
    if ind is None:
        ind = OxmlElement('w:ind')
        pPr.append(ind)

    if first_line_chars is not None:
        ind.set(qn('w:firstLineChars'), str(int(first_line_chars * 100)))
        # 同时给出磅值兜底，兼容部分不支持 chars 的阅读器
        ind.set(qn('w:firstLine'), str(int(first_line_chars * 16 * 20)))
    if left_chars is not None:
        ind.set(qn('w:leftChars'), str(int(left_chars * 100)))
        ind.set(qn('w:left'), str(int(left_chars * 16 * 20)))
    if right_chars is not None:
        ind.set(qn('w:rightChars'), str(int(right_chars * 100)))
        ind.set(qn('w:right'), str(int(right_chars * 16 * 20)))
    if hanging_chars is not None:
        ind.set(qn('w:hangingChars'), str(int(hanging_chars * 100)))


def set_paragraph_format(para, alignment=None, first_line_chars=None,
                         left_chars=None, right_chars=None,
                         space_before=0, space_after=0, line_spacing=None):
    """
    设置段落格式。

    注意：alignment 默认为 None，表示"不修改已有对齐方式"，
          避免覆盖调用方此前显式设置的居中/右对齐。
    """
    if alignment is not None:
        para.alignment = alignment

    para_format = para.paragraph_format
    para_format.space_before = Pt(space_before)
    para_format.space_after = Pt(space_after)

    if line_spacing is not None:
        para_format.line_spacing = line_spacing
        para_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY

    if any(v is not None for v in (first_line_chars, left_chars, right_chars)):
        set_char_indent(para, first_line_chars=first_line_chars,
                        left_chars=left_chars, right_chars=right_chars)


def add_horizontal_line(doc, size=BORDER_SIZE['thick'], color='000000'):
    """
    添加一条与版心等宽的真实横线（段落下边框实现）。

    相比用 '─' 字符重复填充，边框方式宽度精确等于版心，
    且不受字体差异影响。
    """
    para = doc.add_paragraph()
    para_format = para.paragraph_format
    para_format.space_before = Pt(0)
    para_format.space_after = Pt(0)
    para_format.line_spacing = Pt(1)
    para_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY

    pPr = para._p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), str(size))
    bottom.set(qn('w:space'), '0')
    bottom.set(qn('w:color'), color)
    pBdr.append(bottom)
    pPr.append(pBdr)
    return para


def _add_field(run, field_code):
    """向 run 中插入 Word 域代码（用于页码）"""
    fld_begin = OxmlElement('w:fldChar')
    fld_begin.set(qn('w:fldCharType'), 'begin')
    instr = OxmlElement('w:instrText')
    instr.set(qn('xml:space'), 'preserve')
    instr.text = field_code
    fld_end = OxmlElement('w:fldChar')
    fld_end.set(qn('w:fldCharType'), 'end')
    run._element.append(fld_begin)
    run._element.append(instr)
    run._element.append(fld_end)


# ============ 层级与文本解析 ============

# 层级标题正则：同时兼容全角（）与半角()括号
RE_LEVEL_1 = re.compile(r'^([一二三四五六七八九十百千万]+)[、．.]')
RE_LEVEL_2 = re.compile(r'^[（(]\s*([一二三四五六七八九十百千万]+)\s*[)）]')
RE_LEVEL_3 = re.compile(r'^(\d+)[.．、](?!\d)')
RE_LEVEL_4 = re.compile(r'^[（(]\s*(\d+)\s*[)）]')


def parse_heading_level(text):
    """
    解析标题层级。

    返回: (level, clean_text)；若不是层级标题则返回 (None, text)

    层级约定（GB/T 9704-2012 常见用法）：
        1 级: 一、二、三、
        2 级: （一）（二）（三）
        3 级: 1. 2. 3.
        4 级: （1）（2）（3）
    """
    text = text.strip()
    if not text:
        return (None, text)

    # 二级 / 四级都以括号开头，需先判断括号内是汉字还是数字
    m = RE_LEVEL_2.match(text)
    if m:
        return (2, RE_LEVEL_2.sub('', text).strip())

    m = RE_LEVEL_4.match(text)
    if m:
        return (4, RE_LEVEL_4.sub('', text).strip())

    m = RE_LEVEL_1.match(text)
    if m:
        return (1, RE_LEVEL_1.sub('', text).strip())

    m = RE_LEVEL_3.match(text)
    if m:
        return (3, RE_LEVEL_3.sub('', text).strip())

    return (None, text)


def is_main_recipient(text):
    """
    判断是否为主送机关行。

    特征：以全角冒号结尾，且不是层级标题，长度适中。
    """
    text = text.strip()
    if not text:
        return False
    if parse_heading_level(text)[0] is not None:
        return False
    return text.endswith('：') and len(text) <= 120


def number_to_chinese(num):
    """将阿拉伯数字转换为中文数字（用于层级序号等场景）"""
    chinese_nums = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
    if num <= 10:
        return chinese_nums[num]
    if num < 20:
        return '十' + (chinese_nums[num - 10] if num > 10 else '')
    tens, ones = num // 10, num % 10
    if ones == 0:
        return chinese_nums[tens] + '十'
    return chinese_nums[tens] + '十' + chinese_nums[ones]


# 兼容旧接口：保留 is_title_line，但不再用于正文标题猜测
def is_title_line(text):
    """
    [已废弃] 早期版本用于猜测公文标题，易将主送机关误判为标题。
    现在标题一律由调用方显式传入 title 参数，此函数仅作兼容保留。
    """
    text = text.strip()
    if not text:
        return False
    if parse_heading_level(text)[0] is not None:
        return False
    if is_main_recipient(text):
        return False
    return 5 <= len(text) <= 60


# ============ 各组成部分生成 ============

def setup_page(doc):
    """设置页面格式（A4 + 国标页边距）"""
    section = doc.sections[0]
    section.page_width = PAGE_CONFIG['paper_width']
    section.page_height = PAGE_CONFIG['paper_height']
    section.top_margin = PAGE_CONFIG['margin_top']
    section.bottom_margin = PAGE_CONFIG['margin_bottom']
    section.left_margin = PAGE_CONFIG['margin_left']
    section.right_margin = PAGE_CONFIG['margin_right']

    # 设置文档默认字体为正文字体，避免未覆盖处出现 Calibri
    style = doc.styles['Normal']
    style.font.name = FONTS['body'][0]
    style.font.size = FONTS['body'][1]
    style.element.rPr.rFonts.set(qn('w:eastAsia'), FONTS['body'][0])
    return section


def add_page_number(doc):
    """
    添加页码：单页码居右空 1 字，双页码居左空 1 字（GB/T 9704-2012）。
    通过启用奇偶页不同页脚实现。
    """
    # 启用奇偶页不同的页眉页脚
    settings = doc.settings.element
    if settings.find(qn('w:evenAndOddHeaders')) is None:
        even_odd = OxmlElement('w:evenAndOddHeaders')
        settings.append(even_odd)

    section = doc.sections[0]

    def _fill(footer, alignment, left_chars=None, right_chars=None):
        para = footer.paragraphs[0]
        para.alignment = alignment
        set_char_indent(para, left_chars=left_chars, right_chars=right_chars)
        run = para.add_run()
        set_run_font(run, FONTS['page_number'][0], FONTS['page_number'][1])
        _add_field(run, 'PAGE')

    # 奇数页（含首页）：居右，右空 1 字
    _fill(section.footer, WD_ALIGN_PARAGRAPH.RIGHT, right_chars=1)
    # 偶数页：居左，左空 1 字
    _fill(section.even_page_footer, WD_ALIGN_PARAGRAPH.LEFT, left_chars=1)


def add_red_header(doc, org_name, doc_number, issuer=None):
    """
    添加红色版头。

    org_name:   发文机关标志（红色、居中、二号小标宋）
    doc_number: 发文字号
    issuer:     签发人（上行文需要）

    布局规则：
        - 无签发人：发文字号居中
        - 有签发人：发文字号左空 1 字，签发人右空 1 字，同行左右分列
    """
    # 发文机关标志
    para = doc.add_paragraph()
    run = para.add_run(org_name)
    set_run_font(run, FONTS['org_mark'][0], FONTS['org_mark'][1],
                 color=COLORS['red'])
    set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.CENTER,
                         space_before=0, space_after=18)

    # 发文字号（与签发人）
    para = doc.add_paragraph()
    if issuer:
        # 左侧发文字号 + 右对齐制表位承载签发人，二者同行不混段
        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.LEFT,
                             left_chars=1, right_chars=1)
        para.paragraph_format.tab_stops.add_tab_stop(
            BODY_WIDTH - Cm(0.6), WD_TAB_ALIGNMENT.RIGHT)
        run = para.add_run(doc_number)
        set_run_font(run, FONTS['header'][0], FONTS['header'][1])
        run = para.add_run('\t签发人：' + issuer)
        set_run_font(run, FONTS['header'][0], FONTS['header'][1])
    else:
        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.CENTER)
        run = para.add_run(doc_number)
        set_run_font(run, FONTS['header'][0], FONTS['header'][1])

    # 红色分隔线（与版心等宽的真实横线）
    add_horizontal_line(doc, size=BORDER_SIZE['red'], color='FF0000')


def add_title(doc, title_text):
    """添加公文标题（红色分隔线下空 2 行，二号小标宋居中）"""
    if not title_text:
        return
    # 标题前空 2 行
    for _ in range(2):
        empty = doc.add_paragraph()
        empty.paragraph_format.space_before = Pt(0)
        empty.paragraph_format.space_after = Pt(0)

    for i, line in enumerate(str(title_text).split('\n')):
        line = line.strip()
        if not line:
            continue
        para = doc.add_paragraph()
        run = para.add_run(line)
        set_run_font(run, FONTS['title'][0], FONTS['title'][1])
        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.CENTER,
                             line_spacing=Pt(33))
        # 仅最后一行留段后距
        para.paragraph_format.space_after = Pt(0)

    # 标题下空 1 行
    empty = doc.add_paragraph()
    empty.paragraph_format.space_before = Pt(0)
    empty.paragraph_format.space_after = Pt(0)


def add_main_body(doc, content_lines):
    """
    添加正文内容。

    - 主送机关：顶格，无首行缩进
    - 层级标题：按级别套用对应字体
    - 普通正文：首行缩进 2 字
    """
    recipient_done = False

    for raw in content_lines:
        line = raw.strip() if isinstance(raw, str) else ''
        if not line:
            continue

        # 主送机关（只处理正文开头的第一个冒号结尾行，顶格排布）
        if not recipient_done and is_main_recipient(line):
            para = doc.add_paragraph()
            run = para.add_run(line)
            set_run_font(run, FONTS['body'][0], FONTS['body'][1])
            set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.LEFT,
                                 first_line_chars=0, line_spacing=LINE_SPACING)
            recipient_done = True
            continue

        level, _ = parse_heading_level(line)
        para = doc.add_paragraph()

        if level == 1:
            # 一级标题：黑体三号（黑体本身即粗，不再叠加 bold）
            run = para.add_run(line)
            set_run_font(run, FONTS['heading_1'][0], FONTS['heading_1'][1])
        elif level == 2:
            # 二级标题：楷体_GB2312 三号（国标不加粗）
            run = para.add_run(line)
            set_run_font(run, FONTS['heading_2'][0], FONTS['heading_2'][1])
        elif level == 3:
            # 三级标题：仿宋三号加粗
            run = para.add_run(line)
            set_run_font(run, FONTS['heading_3'][0], FONTS['heading_3'][1],
                         bold=True)
        elif level == 4:
            # 四级标题：仿宋三号加粗
            run = para.add_run(line)
            set_run_font(run, FONTS['heading_4'][0], FONTS['heading_4'][1],
                         bold=True)
        else:
            run = para.add_run(line)
            set_run_font(run, FONTS['body'][0], FONTS['body'][1])

        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.JUSTIFY,
                             first_line_chars=2, line_spacing=LINE_SPACING)


def add_attachment_note(doc, attachments):
    """
    添加附件说明。

    国标：正文下空 1 行，左空 2 字编排"附件："，
          多个附件用阿拉伯数字标注顺序，附件名后不加标点。
    """
    if not attachments:
        return
    if isinstance(attachments, str):
        attachments = [attachments]
    attachments = [str(a).strip() for a in attachments if str(a).strip()]
    if not attachments:
        return

    # 空 1 行
    empty = doc.add_paragraph()
    empty.paragraph_format.space_after = Pt(0)

    if len(attachments) == 1:
        # 单个附件：附件名与"附件："同行
        para = doc.add_paragraph()
        run = para.add_run('附件：' + attachments[0].rstrip('。.'))
        set_run_font(run, FONTS['body'][0], FONTS['body'][1])
        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.LEFT,
                             first_line_chars=2, line_spacing=LINE_SPACING)
        return

    # 多个附件：用阿拉伯数字顺序标注
    para = doc.add_paragraph()
    run = para.add_run('附件：')
    set_run_font(run, FONTS['body'][0], FONTS['body'][1])
    set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.LEFT,
                         first_line_chars=2, line_spacing=LINE_SPACING)

    for i, attachment in enumerate(attachments, 1):
        para = doc.add_paragraph()
        run = para.add_run(f'{i}.{attachment.rstrip("。.")}')
        set_run_font(run, FONTS['body'][0], FONTS['body'][1])
        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.LEFT,
                             first_line_chars=3, line_spacing=LINE_SPACING)


def add_signature(doc, org_name, date_str):
    """
    添加发文机关署名和成文日期。

    国标：正文（或附件说明）下空 2 行，右空 4 字编排。
    """
    if not org_name and not date_str:
        return

    for _ in range(2):
        empty = doc.add_paragraph()
        empty.paragraph_format.space_after = Pt(0)

    if org_name:
        para = doc.add_paragraph()
        run = para.add_run(org_name)
        set_run_font(run, FONTS['signature'][0], FONTS['signature'][1])
        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.RIGHT,
                             right_chars=4, line_spacing=LINE_SPACING)

    if date_str:
        para = doc.add_paragraph()
        run = para.add_run(date_str)
        set_run_font(run, FONTS['signature'][0], FONTS['signature'][1])
        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.RIGHT,
                             right_chars=4, line_spacing=LINE_SPACING)


def add_footer_section(doc, cc_to=None, publisher=None, publish_date=None):
    """
    添加版记（抄送机关、印发机关与印发日期）。

    国标：首末条分隔线用粗线，中间用细线，宽度同版心；
          各要素左右各空 1 字；印发机关左空 1 字、印发日期右空 1 字。
    """
    if not (cc_to or publisher or publish_date):
        return

    # 空 1 行
    empty = doc.add_paragraph()
    empty.paragraph_format.space_after = Pt(0)

    # 首条分隔线（粗）
    add_horizontal_line(doc, size=BORDER_SIZE['thick'])

    # 抄送机关
    if cc_to:
        cc_text = str(cc_to).strip()
        if not cc_text.endswith(('。', '.')):
            cc_text += '。'
        para = doc.add_paragraph()
        run = para.add_run('抄送：' + cc_text)
        set_run_font(run, FONTS['footer'][0], FONTS['footer'][1])
        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.LEFT,
                             left_chars=1, right_chars=1)
        # 回行与冒号后首字对齐
        set_char_indent(para, left_chars=1, right_chars=1, hanging_chars=3)
        para.paragraph_format.line_spacing = Pt(18)
        para.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY

        # 中间分隔线（细）
        add_horizontal_line(doc, size=BORDER_SIZE['thin'])

    # 印发机关和印发日期：左右分列同行
    if publisher or publish_date:
        para = doc.add_paragraph()
        set_paragraph_format(para, alignment=WD_ALIGN_PARAGRAPH.LEFT,
                             left_chars=1, right_chars=1)
        para.paragraph_format.line_spacing = Pt(18)
        para.paragraph_format.line_spacing_rule = WD_LINE_SPACING.EXACTLY
        para.paragraph_format.tab_stops.add_tab_stop(
            BODY_WIDTH - Cm(0.99), WD_TAB_ALIGNMENT.RIGHT)

        if publisher:
            run = para.add_run(str(publisher).strip())
            set_run_font(run, FONTS['footer'][0], FONTS['footer'][1])
        if publish_date:
            run = para.add_run('\t' + str(publish_date).strip())
            set_run_font(run, FONTS['footer'][0], FONTS['footer'][1])

        # 末条分隔线（粗）
        add_horizontal_line(doc, size=BORDER_SIZE['thick'])


# ============ 主转换函数 ============

def convert_to_official_format(input_file, output_file, **kwargs):
    """
    将文本内容转换为政府公文格式。

    参数:
        input_file:  输入文本文件路径（纯正文，不含标题/版头/版记要素）
        output_file: 输出 docx 文件路径
        **kwargs:
            - title:        公文标题（显式传入，不再从正文猜测）
            - org_name:     发文机关名称
            - doc_number:   发文字号
            - issuer:       签发人
            - date_str:     成文日期
            - attachments:  附件列表
            - cc_to:        抄送机关
            - publisher:    印发机关
            - publish_date: 印发日期
            - page_number:  是否添加页码（默认 True）
    """
    with open(input_file, 'r', encoding='utf-8') as f:
        content = f.read()

    lines = content.split('\n')

    doc = Document()
    setup_page(doc)

    # 版头：发文机关标志与发文字号齐备时才生成
    if kwargs.get('org_name') and kwargs.get('doc_number'):
        add_red_header(doc, kwargs['org_name'], kwargs['doc_number'],
                       kwargs.get('issuer'))

    # 公文标题（显式传入）
    if kwargs.get('title'):
        add_title(doc, kwargs['title'])

    # 正文
    add_main_body(doc, lines)

    # 附件说明
    if kwargs.get('attachments'):
        add_attachment_note(doc, kwargs['attachments'])

    # 署名与成文日期
    if kwargs.get('org_name') or kwargs.get('date_str'):
        add_signature(doc, kwargs.get('org_name'), kwargs.get('date_str'))

    # 版记
    add_footer_section(doc, kwargs.get('cc_to'), kwargs.get('publisher'),
                       kwargs.get('publish_date'))

    # 页码
    if kwargs.get('page_number', True):
        add_page_number(doc)

    doc.save(output_file)
    print(f"文档已保存至: {output_file}")
    return output_file


def main():
    """命令行入口"""
    if len(sys.argv) < 3:
        print("用法: python convert_to_official_docx.py <输入文件> <输出文件>")
        print("示例: python convert_to_official_docx.py input.txt output.docx")
        sys.exit(1)

    convert_to_official_format(sys.argv[1], sys.argv[2])


if __name__ == '__main__':
    main()
