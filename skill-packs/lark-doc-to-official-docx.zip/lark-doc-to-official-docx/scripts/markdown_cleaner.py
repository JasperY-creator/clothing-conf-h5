#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Markdown 格式清理模块
用于在生成 Word 文档前清理残留的 Markdown 格式代码
支持：表格、图片、超链接、粗体/斜体等
"""

import re
from typing import List, Tuple, Optional


class MarkdownCleaner:
    """Markdown 格式清理器"""
    
    def __init__(self, keep_tables: bool = True, keep_links_text: bool = True):
        """
        初始化清理器
        
        Args:
            keep_tables: 是否保留表格结构（转换为纯文本表格）
            keep_links_text: 是否保留链接文字（去除 URL）
        """
        self.keep_tables = keep_tables
        self.keep_links_text = keep_links_text
    
    def clean(self, markdown_content: str) -> str:
        """
        清理 Markdown 格式
        
        Args:
            markdown_content: 原始 Markdown 内容
            
        Returns:
            清理后的纯文本内容
        """
        lines = markdown_content.split('\n')
        cleaned_lines = []
        i = 0
        
        while i < len(lines):
            line = lines[i]
            
            # 检查是否是表格行
            if self._is_table_row(line):
                # 收集整个表格
                table_lines = []
                while i < len(lines) and self._is_table_row(lines[i]):
                    table_lines.append(lines[i])
                    i += 1
                
                # 转换表格为格式化文本
                if table_lines:
                    cleaned_table = self._convert_table_to_text(table_lines)
                    cleaned_lines.extend(cleaned_table)
                continue
            
            # 清理单行中的 Markdown 标记
            cleaned_line = self._clean_inline_markdown(line)
            cleaned_lines.append(cleaned_line)
            i += 1
        
        return '\n'.join(cleaned_lines)
    
    def _is_table_row(self, line: str) -> bool:
        """检查是否是 Markdown 表格行"""
        line = line.strip()
        if not line:
            return False
        # 表格行特征：以 | 开头或包含 |
        return line.startswith('|') and '|' in line[1:]
    
    def _is_table_separator(self, line: str) -> bool:
        """检查是否是表格分隔行（如 |---|---|）"""
        line = line.strip()
        if not line.startswith('|'):
            return False
        # 移除所有 | 和空白字符后，应该只剩下 - : 字符
        content = line.replace('|', '').replace(' ', '').replace('\t', '')
        return all(c in '-:|' for c in content) and '-' in content
    
    def _convert_table_to_text(self, table_lines: List[str]) -> List[str]:
        """
        将 Markdown 表格转换为格式化文本
        
        Args:
            table_lines: 表格的各行
            
        Returns:
            转换后的文本行列表
        """
        if not table_lines:
            return []
        
        # 解析表格内容
        rows = []
        for line in table_lines:
            line = line.strip()
            if self._is_table_separator(line):
                continue
            
            # 解析表格单元格
            cells = self._parse_table_cells(line)
            if cells:
                rows.append(cells)
        
        if not rows:
            return []
        
        # 计算每列的最大宽度
        num_cols = max(len(row) for row in rows)
        col_widths = [0] * num_cols
        
        for row in rows:
            for i, cell in enumerate(row):
                cell_text = self._clean_inline_markdown(cell.strip())
                col_widths[i] = max(col_widths[i], len(cell_text))
        
        # 生成格式化表格文本
        result = []
        result.append('')  # 空行
        
        for row_idx, row in enumerate(rows):
            # 格式化每一行
            formatted_cells = []
            for i in range(num_cols):
                if i < len(row):
                    cell_text = self._clean_inline_markdown(row[i].strip())
                else:
                    cell_text = ''
                # 左对齐，用空格填充
                formatted_cells.append(cell_text.ljust(col_widths[i]))
            
            row_text = ' │ '.join(formatted_cells)
            result.append(row_text)
            
            # 在表头后添加分隔线
            if row_idx == 0:
                separator = '─' * (sum(col_widths) + 3 * (num_cols - 1))
                result.append(separator)
        
        result.append('')  # 空行
        return result
    
    def _parse_table_cells(self, line: str) -> List[str]:
        """解析表格行的单元格"""
        line = line.strip()
        if not line.startswith('|'):
            return []
        
        # 移除首尾 |
        content = line[1:]
        if content.endswith('|'):
            content = content[:-1]
        
        # 分割单元格
        cells = content.split('|')
        return [cell.strip() for cell in cells]
    
    def _clean_inline_markdown(self, text: str) -> str:
        """
        清理行内的 Markdown 标记
        
        Args:
            text: 原始文本
            
        Returns:
            清理后的文本
        """
        if not text:
            return text
        
        original = text
        
        # 1. 清理图片 ![alt](url) -> alt（保留描述文字）
        text = re.sub(r'!\[([^\]]*)\]\([^)]+\)', r'\1', text)
        
        # 2. 清理超链接 [text](url) -> text（保留链接文字）
        if self.keep_links_text:
            text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)
        else:
            text = re.sub(r'\[([^\]]+)\]\([^)]+\)', '', text)
        
        # 3. 清理粗体 **text** 或 __text__
        text = re.sub(r'\*\*([^\*]+)\*\*', r'\1', text)
        text = re.sub(r'__([^_]+)__', r'\1', text)
        
        # 4. 清理斜体 *text* 或 _text_
        text = re.sub(r'\*([^\*]+)\*', r'\1', text)
        text = re.sub(r'_([^_]+)_', r'\1', text)
        
        # 5. 清理行内代码 `code`
        text = re.sub(r'`([^`]+)`', r'\1', text)
        
        # 6. 清理删除线 ~~text~~
        text = re.sub(r'~~([^~]+)~~', r'\1', text)
        
        # 7. 清理 HTML 标签
        text = re.sub(r'<[^>]+>', '', text)
        
        # 8. 清理转义字符 \*
        text = re.sub(r'\\([\*\[\]\(\)`~_])', r'\1', text)
        
        # 9. 清理多余的 Markdown 标题标记（##、### 等）- 保留层级标记
        # 这个需要在整体处理时进行，这里不做
        
        # 10. 清理水平线 ---
        if re.match(r'^\s*---\s*$', text):
            text = '─' * 40
        
        return text


def clean_markdown_for_docx(markdown_content: str) -> str:
    """
    清理 Markdown 内容以便转换为 Word 文档
    
    这是主入口函数，方便直接调用
    
    Args:
        markdown_content: 原始 Markdown 内容
        
    Returns:
        清理后的文本内容
    """
    cleaner = MarkdownCleaner(keep_tables=True, keep_links_text=True)
    return cleaner.clean(markdown_content)


def clean_line_by_line(lines: List[str]) -> List[str]:
    """
    逐行清理 Markdown 格式
    
    Args:
        lines: 行列表
        
    Returns:
        清理后的行列表
    """
    cleaner = MarkdownCleaner(keep_tables=True, keep_links_text=True)
    content = '\n'.join(lines)
    cleaned = cleaner.clean(content)
    return cleaned.split('\n')


# 测试函数
if __name__ == '__main__':
    # 测试示例
    test_content = """
# 标题

这是一个包含**粗体**和*斜体*的段落。

这里有一张图片：![图片描述](http://example.com/image.png)

这里有链接：[点击这里](http://example.com)查看详情。

## 表格示例

| 姓名 | 年龄 | 部门 |
|------|------|------|
| 张三 | 28 | 技术部 |
| 李四 | 32 | 市场部 |

## 列表

- 项目1
- 项目2
- 项目3

正文结束。
"""
    
    cleaner = MarkdownCleaner()
    result = cleaner.clean(test_content)
    print("清理后的内容：")
    print(result)
