---
name: lark-doc-to-official-docx
label: 飞书文档转政府公文
description: 将飞书云文档自动转换为符合 GB/T 9704-2012《党政机关公文格式》标准的 Word 文档(.docx)。支持智能识别发文机关、发文字号、成文日期、附件列表、抄送机关等关键信息，自动应用规范的标题层级格式、字体字号、页面边距，生成完整的版头和版记。当用户需要将飞书云文档转换为政府公文格式、生成符合国标的公文 docx 文件、或处理公文排版时使用此技能。
---

# 飞书文档转政府公文

本技能用于将飞书云文档自动转换为符合中国国家标准 GB/T 9704-2012《党政机关公文格式》的 Word 文档。

## 核心功能

- **结构化要素提取**：自动识别公文标题、发文机关、发文字号、主送机关、成文日期、附件列表、抄送机关、印发机关等法定要素
- **正文零重复**：采用"先剥离要素、后留正文"的区域切分策略，落款/附件说明/版记等要素不会在正文中重复出现
- **Markdown 智能清理**：自动清理表格、图片、超链接、粗体/斜体、行内代码等残留格式
- **国标格式应用**：按层级套用规范字体字号，缩进以"字符"为单位精确对应国标的"空 N 字"
- **完整公文结构**：版头（红色发文机关标志、发文字号、签发人、红色分隔线）、主体（标题、主送机关、正文、附件说明、署名与成文日期）、版记（抄送、印发信息、粗细分隔线）、奇偶页页码
- **手动参数覆盖**：所有要素均支持手动指定，优先级高于自动提取

## 快速开始

### 基本使用流程

```python
import sys
sys.path.insert(
    0,
    '/home/user/.super_doubao/super-doubao-runtime/workspace/.user_skills/lark-doc-to-official-docx/scripts'
)
from lark_doc_to_official_docx import convert_lark_doc_to_official

# 1. 用页面与文件内容获取工具读取飞书云文档，得到 Markdown 内容
#    （得到的 markdown 文本赋值给 markdown_content）

# 2. 执行转换（自动提取所有要素）
output_file, params = convert_lark_doc_to_official(
    markdown_content=markdown_content,
    output_file='政府公文.docx',
    auto_extract=True
)

print(f"文档已生成: {output_file}")
print(f"实际使用的要素: {params}")
```

### 3. 交付文件（必须执行）
生成 .docx 后，**必须**调用 `NotifyHuman` 工具将本地文件交付给用户，以生成支持在线预览和下载的链接。禁止只返回本地路径或仅用文字说明。
```
NotifyHuman(attachments=[{
    "attachment_name": "公文标题.docx",
    "attachment_source": output_file
}])
```
- `attachment_name` 使用公文标题（与 `title` 参数一致），保留 `.docx` 后缀
- 一次只交付一个 .docx 文件；若同时生成多个文件，分多次调用 NotifyHuman
- NotifyHuman 返回的在线链接支持在豆包中直接预览和下载，这是本技能的标准交付形态

### 转换前先预览提取结果（推荐）

关键要素（发文字号、成文日期等）建议先预览确认，再生成文档：

```python
from lark_doc_to_official_docx import extract_doc_info, print_extracted_info

info = extract_doc_info(markdown_content)
print_extracted_info(info)   # 打印各要素，供人工核对
```

### 手动指定参数

当自动提取不准确时，可以手动指定参数覆盖：

```python
output_file, params = convert_lark_doc_to_official(
    markdown_content=markdown_content,
    output_file='政府公文.docx',
    auto_extract=True,              # 仍启用自动提取作为后备
    title='XX市人民政府关于XXX的通知',  # 公文标题
    org_name='XX市人民政府',           # 发文机关
    doc_number='XX政〔2026〕45号',     # 发文字号
    date_str='2026年5月28日',          # 成文日期
    issuer='张三',                    # 签发人（上行文需要）
    attachments=['附件一名称', '附件二名称'],
    cc_to='省应急管理厅，市委办公室',
    publisher='XX市人民政府办公室',
    publish_date='2026年5月28日印发',
    page_number=True               # 是否生成页码，默认 True
)
```

## 要素提取规则

技能采用**自底向上的区域切分**：先从头部剥离标题与发文字号，再从尾部依次剥离版记（印发行、抄送行）→ 署名与成文日期 → 附件说明，剩余内容才作为正文。这样可确保同一段内容不会既进正文又进要素区。

| 参数 | 文档位置 | 提取规则 |
|------|----------|----------|
| `title` | 一级标题 | Markdown H1；无 H1 时取首个非冒号结尾的长行 |
| `org_name` | 标题开头 / 落款 | 标题中"关于/印发/转发/批转"之前的部分；无则回退到落款机关名 |
| `doc_number` | 标题下方 | 匹配 `XX〔2026〕45号`，兼容 `〔〕` `[]` `［］` |
| `date_str` | 落款处 | 文末（剥离版记后）的独立日期行 |
| `attachments` | "附件："后 | 支持同行单附件与多行编号附件，自动去除序号前缀 |
| `cc_to` | "抄送："后 | 支持跨行续接 |
| `publisher` | 版记 | 印发行中的机关名，按机关特征词校验 |
| `publish_date` | 版记 | 印发行中的日期 + "印发/发布" |

详细提取规则请参考：[references/extraction_rules.md](references/extraction_rules.md)

## 格式规范

生成的文档符合 GB/T 9704-2012 标准：

| 项目 | 设置值 |
|------|--------|
| 纸张 | A4 (210×297mm) |
| 上/下边距 | 3.7cm / 3.5cm |
| 左/右边距 | 2.8cm / 2.6cm |
| 版心宽度 | 15.6cm (156mm) |
| 发文机关标志 | 方正小标宋简体 二号 红色 居中 |
| 公文标题 | 方正小标宋简体 二号 居中 |
| 主送机关 | 仿宋_GB2312 三号 顶格（无缩进）|
| 正文 | 仿宋_GB2312 三号 首行缩进 2 字 |
| 一级标题（一、）| 黑体 三号（不叠加加粗）|
| 二级标题（（一））| 楷体_GB2312 三号（不加粗）|
| 三级标题（1.）| 仿宋_GB2312 三号 加粗 |
| 四级标题（（1））| 仿宋_GB2312 三号 加粗 |
| 署名与成文日期 | 仿宋_GB2312 三号 右空 4 字 |
| 版记 | 仿宋_GB2312 四号 左右各空 1 字 |
| 页码 | 宋体 四号，单页居右空 1 字、双页居左空 1 字 |
| 行距 | 固定值 28.95 磅 |
| 分隔线 | 段落边框实现，与版心等宽；版记首末条粗线、中间细线 |

层级标题的序号**同时兼容全角（一）与半角(一)括号**。

详细格式规范请参考：[references/format_spec.md](references/format_spec.md)

## API 参考

### 主转换函数

```python
convert_lark_doc_to_official(
    markdown_content: str,             # 云文档的 Markdown 内容
    output_file: str = 'output.docx',  # 输出文件路径
    auto_extract: bool = True,         # 是否自动提取要素
    **manual_params                    # 手动参数（优先级更高）
) -> Tuple[str, Dict]                  # 返回 (输出路径, 实际使用的参数)
```

手动参数支持：`title`、`org_name`、`doc_number`、`date_str`、`issuer`、
`attachments`、`cc_to`、`publisher`、`publish_date`、`page_number`。

### 信息提取函数

```python
extract_doc_info(markdown_content: str) -> Dict
# 返回各要素 + body_content（已剥离要素并清理格式的纯正文）

print_extracted_info(info: Dict)
# 打印提取的信息，用于预览和确认
```

### 底层排版函数（按需直接调用）

```python
convert_to_official_format(input_file, output_file, **kwargs)
# input_file 应为纯正文文本（不含标题/版头/版记要素）
# kwargs 与上述手动参数一致
```

详细使用示例请参考：[references/usage_examples.md](references/usage_examples.md)

## 命令行用法

```bash
cd /home/user/.super_doubao/super-doubao-runtime/workspace/.user_skills/lark-doc-to-official-docx/scripts

# 自动提取模式（会先打印提取结果供核对）
python3 lark_doc_to_official_docx.py input.md output.docx

# 手动模式（不自动提取，正文原样排版）
python3 lark_doc_to_official_docx.py input.md output.docx --manual
```

## 脚本文件说明

| 文件 | 说明 |
|------|------|
| `scripts/convert_to_official_docx.py` | 基础排版脚本：页面设置、字体应用、版头版记、页码、字符级缩进 |
| `scripts/lark_doc_to_official_docx.py` | 增强版脚本：结构化要素提取 + 正文切分 + 转换入口 |
| `scripts/markdown_cleaner.py` | Markdown 格式清理模块：表格、图片、超链接、粗体/斜体等 |

## 依赖要求

```bash
pip install python-docx
```

## 字体要求

生成的 docx 会写入以下字体名称，需在**打开文档的机器**上安装才能正确显示：

- 方正小标宋简体（发文机关标志、公文标题）
- 仿宋_GB2312（正文、署名、版记）
- 楷体_GB2312（二级标题）
- 黑体（一级标题）
- 宋体（页码）

Windows 系统通常自带仿宋_GB2312、楷体_GB2312、黑体、宋体；方正小标宋简体一般需单独安装。
macOS / Linux 通常需手动安装全部字体，否则会回退到替代字体，排版效果偏离国标。
**注意：字体缺失不影响 docx 生成成功，只影响显示效果。**

## 输入格式要求

飞书云文档应包含以下结构（各要素齐备时效果最佳）：

```markdown
# XX市人民政府关于XXX的通知

XX政〔2026〕45号

各县（市、区）人民政府：

正文内容...

一、一级标题

（一）二级标题

1. 三级标题

（1）四级标题

附件：1.附件一名称
2.附件二名称

XX市人民政府
2026年5月28日

抄送：省厅，市委办公室。
XX市人民政府办公室 2026年5月28日印发
```

## 输出文件结构

```
[版头]
├── 发文机关标志（红色 二号小标宋 居中）
├── 发文字号（无签发人时居中；有签发人时左空1字，签发人右空1字同行）
└── 红色分隔线（与版心等宽）

[主体]
├── 公文标题（方正小标宋简体 二号 居中，前空2行）
├── 主送机关（仿宋 三号 顶格）
├── 正文（按层级应用不同字体，首行缩进2字）
├── 附件说明（左空2字，多附件用阿拉伯数字编号）
└── 发文机关署名 + 成文日期（右空4字）

[版记]
├── 首条分隔线（粗）
├── 抄送机关（左右各空1字，回行与冒号后首字对齐）
├── 中间分隔线（细）
├── 印发机关（左空1字）+ 印发日期（右空1字）
└── 末条分隔线（粗）

[页脚]
└── 页码（单页居右空1字，双页居左空1字）
```

## 注意事项

1. **必须在线交付**：生成 .docx 后必须调用 `NotifyHuman` 交付文件，确保用户获得可在线预览、下载的链接；禁止仅返回本地文件路径
2. **提取后建议核对**：自动提取的关键信息（发文字号、成文日期、附件）建议先用 `print_extracted_info` 预览确认
3. **手动覆盖优先级高**：手动指定的参数会覆盖自动提取的结果；空字符串和空列表视为"未指定"，会回退到自动提取值
4. **版头条件生成**：仅当 `org_name` 与 `doc_number` 同时存在时才生成红色版头；缺一则跳过版头但仍生成标题与正文
5. **正文与要素互斥**：被识别为要素的行不会进入正文；若发现某要素被误识别，可通过手动参数纠正
6. **层级标记会被保留**：`一、`、`（一）`、`1.`、`（1）` 等序号在正文中原样保留，仅用于判定字体层级
7. **Markdown 格式清理**：
   - **表格**：转换为对齐的文本表格，保留行列结构
   - **图片**：`![描述](URL)` → 保留描述文字
   - **超链接**：`[文字](URL)` → 保留链接文字
   - **粗体/斜体/行内代码/删除线**：转为纯文本
   - **列表标记**：`- 项目` → 去除标记保留内容
   - **代码块**：整段跳过
8. **版记未做偶数页强制**：国标规定版记位于偶数页，当前实现为紧随正文之后，如需严格合规可在生成后于 Word 中手动调整分页
