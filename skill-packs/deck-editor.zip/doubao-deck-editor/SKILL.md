---
name: doubao-deck-editor
description: 为 doubao-html-deck-generator 生成的 16:9 演示 deck(HTML)增加「PPT 式增强编辑层」的独立 skill。输入是已生成的 deck.html,输出是一份带增强编辑能力的新 HTML——在浏览器里所见即所得地编辑,改完一键导出。它复用宿主 deck 已内置的文字/图片/导出/草稿契约,只叠加宿主没有的三块能力:①页面增删排序(复制页/空白页/删除页/侧栏拖拽重排)②文字字号调整(选中文字后 A-/A+/复位,写内联覆盖)③图片位置与缩放(在图框内拖拽移动 + 滚轮/按钮缩放)。Use when:要对已生成的 HTML deck 做后期编辑、增删页面、调整页面顺序、改字号、挪动或缩放图片、把 deck 变成可编辑的 HTML 版 PPT;用户说「编辑这份 deck / 加一页 / 删一页 / 调顺序 / 字太大太小 / 图片位置不对」并给出一个 deck.html。DO NOT USE:从零生成新 deck(用 doubao-html-deck-generator)、编辑飞书云文档、生成 PPTX。
---

# doubao-deck-editor — HTML deck 的 PPT 式增强编辑层

把 `doubao-html-deck-generator` 产出的 `deck.html` 变成一份**可在浏览器里所见即所得编辑**的 HTML PPT。
做法是往已生成的 deck 里**注入一层「增强编辑运行时」(CSS + JS)**,产出一份新 HTML;用户在浏览器里进编辑模式改,改完一键导出固化。

```
已生成 deck.html ──► inject_editor.py ──► deck.edit.html
   (宿主 skill 产物)      注入增强层         (浏览器里所见即所得编辑 → 导出新 deck.html)
```

## 核心设计:不重复造轮子,只补增量

宿主 deck **已内置**一套运行时编辑系统,本 skill 直接复用、不重写:

| 宿主已有(复用) | 契约 |
|---|---|
| 文字改内容 | 正文/标题标 `data-edt`,编辑模式即 `contenteditable` |
| 图片替换 | 图片位标 `data-edimg`,支持上传/替换/清空(含一位多图) |
| 每页备注编辑 | `#deckNoteBox`,与投影端同步 |
| 编辑模式开关 | `#deckEdit` → `body.deck-editing` |
| 导出新 HTML | `#deckExport`:克隆 documentElement、去 contenteditable、下载 |
| 草稿持久化 | 文字/图片/字号草稿 + 元记录走宿主 `localStorage`;**全量快照走 IndexedDB**(v3.4);存取键按**全页内容指纹** `docSig` 命名(v3.6),内容变即换键、旧快照不再遮蔽 |
| 翻页控制器 | `window.__deck = {go, frames, total, cur}`、`#deckTrack` |

本 skill **只叠加宿主没有的增量能力(以下分块)**:

1. **页面级**:复制本页 / 插入空白页(复用本页版式,**只保留页眉+标题+页脚,正文清空**) / 删除本页 / 左侧页面栏**拖拽重排**;侧栏 chip 标题**动态取本页实际标题**(改标题即同步)。
2. **文字字号 / 颜色**:点选任一文字块 → 浮动工具条 `A-` / `A+` / `↺复位` 写**内联 `font-size`**(覆盖自适应基线,不改版式类)。**不限于 `data-edt`**——白名单选择器覆盖新增卡片文字、宿主模块的大数字/大字号文本等;`removeAttribute('data-fit')` 冻结宿主 `fit()` 避免 resize 回改。**段内特定文字放大**:在段落里选中一段文字再点 `A+`,只把选区包进 `.dep-fs-run` span 写内联字号,不影响整段。工具条还带**文字颜色**色板:主题纯色 + **渐变模板色**(PPT 模板渐变字,`--fs-grad-title` + `background-clip:text`)+ 复位;有选区只作用选区,无选区作用整段。
3. **图片位置/缩放**:图片位(`data-edimg`)在图框内**拖拽移动** + **滚轮/按钮缩放**,写**内联 `transform: translate() scale()`**。
4. **新增浮层元素**:`＋文字` / `＋卡片` / `＋图片` 往当前页插入**可拖拽浮层**(`.dep-float`),在页面 1280×720 坐标系内自由摆放 + 按钮缩放 + `✕`删除,双击就地编辑文字 / 上传图片(FileReader→data URL);卡片用主题变量 `--fs-*` 跟随深浅主题,自带「淡入上浮」入场动效并在翻页时重放。
5. **卡片文字 / 大数字内容改写**:宿主只把 `[data-edt]` 设为 `contenteditable`,卡片正文(`.stat .t/.d`)与大数字(`.num .v/.u`)原本**无法改内容**。进编辑模式时对这批文字补 `contenteditable`(标 `data-depce`),**颜色与入场动效原样保留**;改大数字时把新值**同步进 `data-to`**——count-up 动效仍在,终点变成用户改后的值;改成非数字则去掉 `data-to`(不再参与 count-up,静态保留)。退出编辑或宿主导出时统一去掉 `contenteditable`,产物干净。
6. **卡片装饰(动效 + 描边色)**:点选卡片容器(`.stat/.card/.fpoint/.rcard/.impact .card` 及浮层卡片)弹出装饰面板 `#depDeco`。**动效恒作用于「卡片整体」**——无论点在卡片留白、大数字还是某段文字上,`pickDeco()` 都 `closest(DECOSEL)` 归一到最近的卡片容器(不再有针对数字/文字子块的分层命中);面板顶部 `.dep-cap` 恒回显「正在设置:<b>卡片整体</b> · 当前动效 X」,并高亮当前动效按钮(`dep-on`)。**为什么只作用整卡**:早期版本允许把动效落到卡片内的数字/某段文字子块,但对原始卡片脆弱的文字节点做 transform/opacity 动画会导致「点上浮文字直接消失、点淡入整卡下移」,故移除子块分层,动效统一落在卡片容器,稳定且符合「卡片就是卡片本身」的语义。**入场动效可调/删/加**——上浮 / 淡入 / 放大 / 无,用**类驱动 + `!important`**(`dep-anim-*`),点选即「摘类→回流→重挂类」**即时预览**并 `tip()` 提示。**每次演示到该页都重放**:增强层同时监听 `deck:nav` 与 `deck:ready`,`replayDeco()` 重放本页所有动效;卡片内含 count-up 数字时顺带调宿主 `__mcCountReset+__mcCount` 让 count-up **从头再数一遍**,非编辑(投影)态同样生效。**卡片描边色**(左侧 keyline `::before` 彩条)——主题渐变边 / 纯色(蓝/青紫/紫/亮蓝)/ 复位;描边恒作用于卡片容器(`edgeTarget()` 取 `decoCard`,因只有卡片有 keyline);因 `::before` 不能写内联样式,改写元素上的 `--dep-edge` 变量 + `data-dep-edge` 属性,由注入的 CSS 规则以 `!important` 读入 `::before`。三者随导出克隆(类名/内联变量/属性)一并固化。
7. **图片点击放大(lightbox)**:**非编辑态**点击任一内容图片(图片位 `data-edimg` / 新增图片浮层 `.dep-float.dep-img` / 页面正文里独立的内容 `<img>`)→ 全屏遮罩 `#depLightbox` 放大居中显示,点右上角 `✕` / 点背景 / 按 `Esc` 均可关闭复原。可放大图片由 `markZoomable()` 标 `data-depzoom="1"` 并给 `cursor:zoom-in` 提示;**logo/装饰图不可放大**——`isDecorImg()` 排除 `.bird/.bloom/.lockup/.cobrand/.brand/.deck-dots` 及增强控件内的图,以及尺寸已知且很小(`<80×60`)的图标。**编辑态一律不开 lightbox**(点=拖拽/选中图片),委托点击处理器在 `body.deck-editing` 时直接 return。`markZoomable` 在启动、`deck:nav`(翻页,标记新页)、`addPage`(复制/空白页克隆)后都会跑一遍;`#depLightbox` 结构 + 图片 `data-depzoom` 标记随导出克隆固化,导出的 HTML 放大能力照常。
8. **PPT 式编辑增量(v2.8,对齐 PowerPoint 常用能力)**:全部落真实 DOM,随宿主导出克隆固化;快捷键仅在 `body.deck-editing` 下生效,正在改文字(`contenteditable`/`INPUT`/`TEXTAREA`)时不拦截 C/V/Delete。
   - **撤销/重做**:对**当前页根**(`frameRoot`)做 `innerHTML` 快照栈(结构态,**不进 localStorage**,避免与宿主页数 hash 冲突)。`pushHist()` 在每次结构性改动(新增/删除/粘贴/拖拽首次移动/对齐分布/成组解组/改填充/z-order)前入栈,上限 60;`Ctrl+Z` 撤销、`Ctrl+Y`/`Ctrl+Shift+Z` 重做。恢复快照后 `hydrateFloats+armImgSlots+markZoomable` 重挂事件(克隆的是死 DOM)。
   - **元素复制/粘贴/删除**:`Ctrl+C` 存选中浮层 `outerHTML` 到内部剪贴板,`Ctrl+V` 以 `+24px` 偏移粘贴并重挂事件、选中新元素,`Delete`/`Backspace` 删除选中浮层。
   - **文字加粗/斜体/下划线/对齐 + 项目符号/编号列表**:字号条 `A-/A+/↺` **之后**追加格式按钮(`B/I/U` + `⬅/⬌/➡` 对齐 + `•≡/1≡` 列表),`applyTextFormat(k)` 临时开 `contenteditable` 后 `execCommand`(bold/italic/underline、insertUnorderedList/insertOrderedList),对齐写 `style.textAlign`;有选区作用选区,无选区作用整段;`queryCommandState` 回显激活态。**A-/A+/↺ 三个字号按钮索引不变**,不破坏既有测试契约。
   - **层级 z-order**:选中浮层写**内联 `z-index`**(置顶=页面 max+1 / 置底=min-1 / 上移/下移=±1),随克隆固化。
   - **对齐 / 分布 / 智能吸附辅助线**:多选(≥2)左/右/水平居中、顶/底/垂直居中对齐;多选(≥3)水平/垂直均匀分布。**单选拖拽**时 `applySnap()` 对页面中心线(x=640/y=360)与其它浮层的边/中心做 6px 阈值吸附,命中即显示 `.dep-guide`(`dep-gv`/`dep-gh`)红线,`mouseup` 清除。
   - **多选 + 成组/解组**:`Shift+点击` 追加/切换多选(橙色 `.dep-msel` 外框);`Ctrl+G` 成组(把选中浮层包进 `.dep-float.dep-group`,子元素坐标转成相对组左上角),`Ctrl+Shift+G` 解组(还原为页面绝对坐标)。组本身即一个可拖拽浮层。
   - **形状元素**:顶部 `▭矩形/◯圆/／线/➔箭头` 插入 `.dep-float.dep-shape`(内层 `.dep-shbody` 画形,矩形/圆用 `--dep-fill/--dep-strk/--dep-strkc` 变量,线/箭头用 `::before/::after` 伪元素);选中形状时浮出 `#depShape` 操作条,含层级/对齐/成组按钮 + **填充色板**(点色块写内联 `--dep-fill`)。
   - **选中浮层浮动操作条 `#depShape`**:选中任一浮层即在其上方浮出,聚合层级/对齐分布/成组解组(+形状填充);点空白处或翻页/退出编辑即收起并清选择。
9. **PPT 式细节增量(v3.0)**:延续「全部落真实 DOM、随导出克隆固化」原则,补齐三处 PowerPoint 常见交互。
   - **文字框手动调宽高**:文字浮层(`.dep-float.dep-text`)右下角带一枚 `.dep-rz` 尺寸手柄(仅编辑态可见),拖拽写**内联 `width/height`** 并打 `data-depsized`(解除 `min/max-width` 约束,`overflow-wrap:break-word` 让长文本按框宽换行)。位移按 `pageScale` 与浮层 `scale()` 双重换算回页面坐标;手柄已在 `bindFloatDrag` 与 `FUISEL` 中排除,故调尺寸时**不触发整框拖移**。手柄经 `newFloat` 创建、`hydrateFloats` 重挂(先摘旧 `.dep-rz` 再重建),随导出克隆固化。
   - **新增图片浮层无底色**:`.dep-float.dep-img` 空态 `background:transparent`(此前的 `rgba(20,40,80,.05)` 淡蓝底去掉),只留虚线边 + 「双击上传图片」占位;上传成功(有 `<img>` 子节点)后打 `.dep-has-img`,连虚线边也转 `transparent`——纯图片观感。`enableImgPick` 上传回调与 `hydrateFloats`(复现已带图的克隆)都会补 `.dep-has-img`。
   - **文字工具栏防重叠 + 不遮挡被点内容**:一次点击可能同时浮出 `#depFont`(元素上方)、`#depShape`(元素上方)、`#depDeco`(元素下方),三者独立 `position:fixed` 定位,既可能彼此重叠、也可能压在刚点的内容上。`resolveBarOverlap()` 改为**锚点感知**:先由 `curAnchorEl()` 求出本轮被点/选中的锚点元素(优先 `fontTarget`,次 `decoCard`,再选中浮层 `sels[0]`),然后把 `#depFont`/`#depShape` 依次向锚点**上方**堆叠、`#depDeco` 向锚点**下方**堆叠——始终让开锚点矩形,保证点了文字后内容仍可见;上方空间不足的条自动溢出到下方,下方也不足再夹取回视口内。无锚点时回退到 `resolveBarStackOnly()`(旧版按优先级仅解决条与条的相互重叠)。入口 `dodgeBars()` 用 `setTimeout(0)` 去抖,保证同一轮多次放置都已落定;主点击处理与 `maybeShapeBar` 末尾均触发。测试钩子 `window.__deckEditorPlus.dodgeBars` 暴露同步收敛以便断言。
10. **手动全量保存(v3.2)**:进入编辑模式后右上角浮出保存框 `#depSaveBox`(`💾 保存` 按钮 + 状态文字),让用户像 PPT 一样**显式落盘**。任何改动内容的操作都会把状态置为「● 未保存」(`markDirty()` 挂在 `persist()`/`pushHist()`/`addPage`/`deletePage`/`reorder` 上);点「保存」执行**真实全量保存**——`saveFull()` 把整条 `#deckTrack` 的**净化后 HTML**(内联字号/图片/形状编辑已烘进节点,先 `setEnhance(false)` 收起增强层再克隆、剔除 `contenteditable`)连同字号/图片桶一起写进独立键 `deckeditplusfull:<hash>`(与 storeKey 同样【不含页数】),状态转「已保存 HH:MM」。启动时 `restoreFull()` 命中快照即**整段还原 `#deckTrack`**(含新增/删除/重排的页与浮层),再 `refreshNav()`+常规回存/复活(`applyStoredFonts/Imgs`+`hydrateFloats`+`markZoomable`)——**刷新即所见即所得**。`#depSaveBox` 挂在 `body`、不在 `track` 内,不进导出/投影快照,产物干净。这正面回应了用户「想要一个保存按钮、点了就是真实全量保存」的诉求。见 `verify_editor_save.py`。
11. **保存链路健壮化(v3.3,7 项)**:一次整体复查后对保存/还原链路做的收口。
    - **①内容指纹入键(`docSig`)**:storeKey / fullKey 从 `hash(title|deck)` 升级为 `deckeditplus[full]:<docSig>`。`docSig=hash(标题|首屏原始页数|首页标题文本|首个 data-edt 文本)`,在 `restoreFull()` **之前**基于宿主原始内容计算(故跨载入稳定、不被还原本身扰动),且**刻意不含用户新增页数**以维持「结构增删不旋转键」契约。修掉了「不同 deck 恰好同标题时草稿/快照串档」。
    - **②快照签名校验**:`saveFull()` 把 `sig:docSig` 写进快照;`restoreFull()` 命中后若 `snap.sig!==docSig` 则**忽略并放行原始 deck**,杜绝跨 deck 快照误还原(伪造/陈旧 sig 会被识别)。
    - **③还原后重跑数字**:`restoreFull()` 成功后补 `replayDeco(当前页)` + `window.__mcCount(track)`,让 count-up 大数字在整段 DOM 替换后重新滚动到位,而非停在静态终值。
    - **④体积/配额守卫**:`saveFull()` 估算 `approxMB=(payload*2)/1MB`,超 4.7MB 拒绝写入并提示,避免撞 localStorage 配额导致静默失败。
    - **⑤逃生口(v3.7 起改为 `?depfresh`)**:早期版本在保存框放过一个 `清除` 按钮;因用户反馈其含义易混淆,v3.7 已**移除该按钮**。清缓存改由「打开即清」URL 参数承担——带 `?depfresh`(或 `#depfresh`)打开即 `clearFull(true)` 静默删本文档 full/meta/draft 键 + IDB 快照并跳过还原,回落原始 deck。`clearFull()` 函数本身保留,仅不再有 UI 入口。
    - **⑥speaker 模式跳过还原**:`location.search` 含 `present=speaker` 时 `restoreFull()` 直接返回 false——演讲者视图永远呈现主窗广播的实时内容,不被本地快照抢染。
    - **⑦保存时间跨天显示日期**:`fmtTs()` 在时间戳非「今天」时前缀 `MM/DD `,隔天再看能分清是哪天存的。
    见 `verify_editor_save.py`(持久化 profile + 硬重载 + 崩溃自愈,断言确定性通过)。
12. **全量快照迁移到 IndexedDB(v3.4)**:修「点保存报错:内容体积 14.3MB 超出浏览器 5MB 上限」的真 bug。根因是含大量内联 base64 图片的真实 deck,其净化 HTML 动辄十几~几十 MB,**天生塞不进 `localStorage`(~5MB 硬顶)**;v3.3 的④体积守卫只是如实拒写、并没让大 deck 真的存下来。
    - **后端换 IDB**:`saveFull()` 现把大 HTML 写进 IndexedDB(`db='deckeditplus'`、`store='snaps'`、key=`deckeditplusfull:<docSig>`),容量到几百 MB~GB 级、且在 `file://` 源下可用。`localStorage` 只留一条【几十字节】元记录 `deckeditplusmeta:<docSig>`={ts,cur,sig,len},供**同步**判定「有无快照 / 存于何时」(启动判定与状态回显都要同步读到)。硬顶从 4.7MB 抬到 200MB(纯防内联图片彻底失控存崩浏览器)。
    - **两段式异步还原**:IDB 取回是异步的,故还原拆成 ① 同步 `fullMeta()` 读元记录判定有无快照、先把状态回显成「已保存」并暂缓常规复活;② 异步 `restoreFullAsync()` 取回大 HTML 替换 `track` 后,统一跑复活 `revive()`(`applyStoredFonts/Imgs`+`hydrateFloats`+`markZoomable`,还原时补 `refreshNav`+`replayDeco`+重跑 count-up)。签名校验(`snap.sig===docSig`)、speaker 跳过、逃生口(`clearFull()` 删 IDB 行+meta+draft,v3.7 起经 `?depfresh` 触发)一并保留。
    - **向后兼容**:≤3.3 写在 `localStorage` 的旧版 `deckeditplusfull:` 快照仍**只读**兼容——IDB 未命中时回退去读它;IDB 写失败(私密模式/配额禁用)则退回 `localStorage`(仍受 ~5MB 顶,超了如实提示)。无 `IndexedDB`/`Promise` 的老环境自动走 localStorage 路径。
    见 `verify_editor_save.py`(v3.4,含 **>5MB 大快照 save/restore** 用例正面复现并验证 14.3MB bug 已修;持久化 profile + 硬重载 + 崩溃自愈,断言确定性通过)。
13. **复制页重铸宿主内容 id,斩断跨页串档(bug#7,v3.5)**:修「改『方案细节1』第一张卡片下面的正文,『方案细节2』同位正文也被删/改——明明是两个页面」的真 bug。根因是**宿主生成器自己的**内容持久化 id(`data-edt` 文字 / `data-edimg` 图位)是宿主 `collect()`/`load()` 在 `localStorage`(键 `deckedit:`+hash)里的存取键,而它**无页命名空间**;`复制本页`用 `cloneNode` 复制页面时把这些 id 原样拷走,于是两页共用同一批 id → 宿主把一页的文字按 id 回写到**所有同 id 节点**,覆盖/清空了另一页同位文字。
    - **修法**:在 `addPage` 复制页时,除了原有的重铸我方 `data-deppg` 页身份外,新增 `reidHostEdit(clone)`——对复制页内所有带 `data-edt`/`data-edimg` 的节点现铸全新全局唯一 id(`dup<stamp>-<i>` / `dupi<stamp>-<i>`,stamp 由 `hash(seq|时间戳|random)` 生成),让复制页与源页在宿主存储层彻底解耦。
    - 见 `verify_editor_dupedit.py`:复制含卡片文字的内容页后断言(A)复制页与源页 `data-edt`/`data-edimg` **零共享 id**、全文档 `data-edt` 全局唯一;(B)在页内模拟宿主 `collect()→load()` 的 id-keyed 回写,改源页正文后复制页同位文字**保持不变**。用真实 detail-page fixture `real_deck.edit.html`(current host,含 `.fpoint` 卡片)验证。
14. **深化内容指纹 + 打开即清缓存(bug#8,v3.6)**:修用户反馈的两处——「①同一 HTML 无痕模式与正常模式展示不一致 ②最后一页的信息保存+退出编辑再导出 HTML 没有变化」。**同一根因**:`docSig` 只采样【首页】标题 + 首个 `data-edt`,于是**非首页(尤其最后一页)**的文字改动**不改变指纹**;导出产物里新内容明明烘进了文件,但重开时旧缓存快照(与新文件**共用同一把 key**)按 `sig===docSig` 命中、**整段还原覆盖掉文件自带的新内容**——正常模式吃到旧缓存、无痕模式无缓存,故两者不一致;用户在正常模式看到的「导出没变化」实为旧快照遮蔽了新文件。
    - **修法 A(深化指纹)**:`deckSig()` 改为采样**每一页**的稳定文本(`frameText()` 用 `TreeWalker` 遍历文本节点拼接;**跳过** count-up 数字节点的 live 文本、改用其 `data-to` 终值,保证跨重载稳定;不克隆 DOM 故不复制内联大图 src)。这样**任意一页**(含最后一页)文字一变,指纹即变 → 内容不同的导出产物获得**不同 key** → 旧快照自然不再命中、新文件如实透出。仍不含用户增删的页数(`n` 取 raw 首屏),保持 RC1「增删页不旋转存取键」契约。
    - **修法 B(打开即清缓存)**:带 `?depfresh=1`(或 `#depfresh`)打开 HTML 时,启动早期 `clearFull(true)` **静默清掉本文档**的 `deckeditplus*` 键 + IDB 快照并**跳过还原**,直接透出文件自带内容,使正常模式与无痕一致——给用户一个「无痕式打开」的确定性逃生口(只清本文档、按 docSig 定位,不动其它 deck 的存档)。
    - 见 `verify_editor_freshsig.py`:(A)同会话内保存+重载仍能还原最后一页编辑(正常存/取不回归);(B)最后一页 live 编辑后导出,产物含新内容、不含旧快照;(C)在**仍持有旧缓存**的浏览器里重开该导出文件,显示其**自带新内容**而非旧快照;(D)`?depfresh=1` 清缓存后显示底稿、meta 记录被清空。持久化 profile + 崩溃自愈,断言确定性通过。
15. **渐变裁字编辑态获焦消失 + 移除清除按钮(v3.7)**:修用户反馈的三点——「①团队模块标题、②痛点大数字 01/02/03/04,在编辑模式点一下文字就没了、点别处又出现;③清除按钮含义困惑,去掉」。
    - **①②同一根因**:这些元素用 `-webkit-background-clip:text` + `-webkit-text-fill-color:transparent` 靠裁剪渐变绘制字形(`.tname`/`.bignum` 等)。在编辑态被 `contenteditable` + 光标/焦点激活时,Chromium 会漏掉对**透明填充**字形的重绘 → 整块文字消失,点别处触发下一次重绘才恢复(已知 Chromium 渲染 bug)。宿主 v0.2.7 只单点修了 `.cover h2`,其余渐变标题/数字未覆盖。
    - **修法(模板无关)**:JS 在 `focusin`(捕获阶段)判断事件目标或其祖先是否为「裁字=text + 填充=透明」的渐变元素,是则打 `.dep-gradedit` 类;CSS 规则(仅 `body.deck-editing` 作用域)强制其改用实心 `currentColor` 填充并 `background-clip:initial`,逼一次完整重绘;`focusout` 时若焦点未落在同元素内则摘类,未编辑的标题**仍保留渐变观感**。不依赖任何具体类名,任意渐变裁字获焦即受保护;仅编辑态生效,导出/投影产物不含该类。
    - **③移除清除按钮**:删掉保存框里的 `清除` 按钮(创建/`appendChild`/click 绑定 + `.dep-clearbtn` CSS)。清缓存能力不丢——由 v3.6 已有的 `?depfresh` URL 参数(`clearFull(true)`)承担;`clearFull()` 函数保留。
    - 见 `verify_gradfix.py`(渐变元素获焦时 `.dep-gradedit` 上身、`-webkit-text-fill-color` 由 transparent 翻成实心、失焦复原)与 `verify_editor_save.py`(逃生口用例改跑 `?depfresh`)。
16. **渐变裁字获焦仍消失(v3.7 未真修)彻底修复 + 大数字备注泄漏脚本源码(v3.8)**:v3.7 的 focusin 方案在真实 deck 上**并未生效**——用户反馈的两处仍复现:「①编辑态点渐变标题/大数字文字就消失;②有时页面『备注』里冒出 count-up 脚本源码」。逐帧探针定位到两个各自独立的真因:
    - **①真因(v3.7 判定时机错)**:元素一旦被 `focus`+`contenteditable` 激活,其计算 `-webkit-background-clip` 会**持续**回退成 `border-box`(实测下一帧 rAF 仍是 `border-box`,不是只坏一帧)。故 v3.7「focusin 当刻/下一帧用 `getComputedStyle` 判 clip==text」**永远判不出**,`.dep-gradedit` 打不上。**修法**:改为**进编辑模式时(样式仍稳定、无元素获焦)预扫**整卷渐变裁字元素记入 JS 闭包集合 `gradEls`(不写 DOM,不污染导出),`focusin` 时**按身份匹配**而非实时 `getComputedStyle` 来命中并打类;`refreshNav` 后(增删/复制/重排页)重扫,新页同样受保护。
    - **①补丁(透明 `color` 元素)**:部分渐变元素(`.pct` 百分比、`.cmain` 结语)自身 `color` 也是透明,单靠 `currentColor` 翻不出可见色。故预扫时用 `gradSolid()` 从其 `color`/`background-image` 渐变里抠出**首个实心色**,获焦时写进内联 `--dep-solid`,CSS 用 `var(--dep-solid,currentColor)` 兜底,确保任何渐变字获焦都翻成**可见实心色**;失焦/退出编辑清掉内联变量与类。
    - **②真因(脚本被误标 `data-edt`)**:宿主生成器把 `data-edt` 铺到了页内 `<script>`/`<style>` 上,宿主备注/标题采集按 `data-edt` 收文本时把 count-up **脚本源码**也吃了进去。**修法**:初始化时 `stripScriptEdtAttrs()` 摘掉 `script/style` 上的 `data-edt`/`data-edimg`;`frameText()` 的 `TreeWalker` 跳过 `SCRIPT`/`STYLE` 祖先;`titleOf()` 兜底改用 `frameText` 而非 `textContent`,脚本源码不再泄漏进备注/侧栏 chip 标题。
    - **段内变色防嵌套**:`runForSel()` 复用已有 `.dep-fs-run`、选区落在 count-up 数字里返回 null,避免 `.dep-grad-text` 层层嵌套(嵌套本身也会诱发①的消失);整块上色仍照常(仅改自身内联样式/类,不产生嵌套,不动 `data-to`)。
    - 见 `verify_editor_gradfix.py`(渐变元素获焦 `.dep-gradedit` 上身且填充翻实心)与 `verify_fix.py`(脚本 `data-edt` 运行时被摘、备注/chip 不含脚本源码、count-up 段内不产生嵌套)。全套 `verify_editor_*.py` 回归通过。

17. **最后一页数字/文字改了刷新又变回 + 原图位置被重置(v3.9)**:用户反馈两处新问题——「①最后一页卡片上的**数字/文字**调整一直保存不下来;②对**原有图片的位置**调整,希望编辑态放在哪就留在哪(现在会默认弹回原始状态)」。定位到三条各自独立的真因并分别根治:
    - **①-a 数字同步命中面太窄**:`input` 监听此前只认 `.num` 内的 `.v`,只覆盖 `m-c/m-d2/m-f` 卡片;而**最后一页(价值页)的大数字是 `.m-g .impact .card .pct .v[data-to]`**,改它不触发 `syncNumber()`,`data-to` 终值不更新。**修法**:`input` 处理放宽为「命中任何带 `data-to` 的元素(自身或 `closest('[data-to]')`)即 `syncNumber`」,所有页型的 count-up 数字改动都写回终值。
    - **①-b docSig 跨重载漂移(真正根因)**:旧版每次载入都用**当下 live DOM** 重算内容指纹 `docSig`,但宿主自带的 `data-edt` 回存层会在重载时改写 DOM(与 count-up 交互后甚至令某页文本重复),导致**同一文件**每次重载算出的指纹漂移(`zxhgw→vele6f…`)——我方保存的全量快照按旧 key 存、重载按新 key 找,永远对不上,表现为「(尤其最后一页的)数字/文字改了、保存了,一刷新又变回原样」。**修法**:指纹在**注入那一刻**按宿主原始内容算好、写死进文件当运行期常量(`BAKED_SIG` / Python 侧 `compute_baked_sig`),运行期直接读常量,不再受运行时 DOM 变动影响;仅当常量缺失(极老产物/手改文件)才回退 live 计算。
    - **①-c 导出件需重新烘指纹(调和 bug#8)**:①-b 把指纹冻成常量后,若**导出的新文件**原样继承同一枚常量,则「内容变了、指纹却没变」,会被按同一把 key 缓存的**旧快照**遮蔽(即审查早已修掉的 bug#8:最后一页保存/导出后打开无变化、无痕≠正常)。**修法**:在 `#deckExport` 的 **capture 阶段**(先于按钮自身监听、克隆发生前)`rebakeExportSig()` 用 `deckSig()` 按当前 live 内容重算指纹、改写我方 `<script>` 里的 `var BAKED_SIG='…'` 字面量。于是「同一份磁盘文件重复载入」指纹稳定(治①-b),而「导出的内容已变的新文件」获得不同指纹、旧快照自然不再命中(保 bug#8 不回归)。
    - **②原图位置被重置**:`applyT()` 在 `store.imgt` 无该图记录时会**无条件清空**图片的内联 `transform`——于是导出件里烘进的位置/缩放在重开(store 为空)时被抹掉,弹回原始态。**修法**:`applyT()` 在 store 无记录时**不再抹**图片自带的内联 `transform`;并新增 `parseT()`+`adoptImgT()`,进编辑/应用时先把图片现有内联 `transform` **收编进 store**,后续拖拽/缩放照常增量更新并随导出固化。
    - 见 `verify_editor_freshsig.py`(导出→重开不被旧快照遮蔽、`?depfresh` 逃生口)与 `repro_bugs.py`/`repro_bug2c.py`(最后一页数字刷新后仍为新值、空 store 下原图 transform 不被抹)。全套 `verify_editor_*.py` 回归通过(3 项预存的 fixture 假设类失败与本次改动无关,已对 v3.8 基线复核确认同样失败)。

18. **最后一页数字「改了保存不下来」的真正根因:count-up 动画逐帧冲写用户输入(v3.10)**:v3.9 的 ①-a/①-b 修好了「data-to 写回」与「指纹漂移」,但用户复现仍失败。忠实用**真实键盘**在动画窗口复现(`repro_real_kbd.py`)后定位真因——**宿主 count-up 的 `tick()` 每一帧都 `el.textContent=round(ease(p)*to)`,持续约 1.3s,且 `requestAnimationFrame` 一旦启动就无法取消**。用户翻到某页(尤其最后的总览页)会经 `deck:nav` 触发 count-up 重跑,此时点进数字改成如 `99`:动画每帧把「99」冲掉,`syncNumber` 读到的永远是动画中间值,`data-to` 也就变不成 99 → 表现为「数字改了、翻页/保存后又变回去」。此前只放宽 `syncNumber` 命中面治标不治本——只要动画还在逐帧写 `textContent`,输入必被冲掉。
    - **修法(覆盖宿主 count-up 全局)**:宿主把 `__mcCount/__mcCountReset` 挂在 `window` 上,且其 `deck:nav` 处理器**运行时动态读取**这两个函数——故增强层在自己脚本里**包装覆盖**它们:**编辑态**不做逐帧动画,直接把数字**静置到 `data-to` 终值**(一次性 `textContent=to`+`data-counted=1`),并**完全跳过**用户正在编辑(当前有焦点)或已编辑过(带 `data-depedited`)的数字,一个字都不碰;**演示态**原样委托宿主实现,count-up 动画照旧。因宿主每次翻页都重新读 `window.__mcCount`,覆盖能在真正的冲写点(`deck:nav`)命中。
    - **配套**:`syncNumber()` 写回时给该数字打 `data-depedited='1'`,标记为「用户已改」→ count-up 此后**永不**再覆写它(即便失焦、跨页往返)。
    - 见 `repro_real_kbd.py`(真实键盘在动画窗口输入 `99` → `data-to` 变 99、静置显示 99、保存并刷新后仍为 99)、`verify_editor_animux.py`(编辑态翻页数字稳定不重置;演示态动效重放仍生效)。全套回归通过(仅 `dupedit`/`save` 2 项预存 fixture 假设类失败,已复核与本次改动无关)。

19. **同一 HTML「无痕正常、正常模式串了别卷内容」的真根因:内容指纹对图片失明(v3.11)**:用户反馈「无痕模式下都正常,但正常浏览器里同一个 HTML 正常浏览与无痕浏览展示内容不一致」。逐字复现并定位真因——内容指纹(运行期 `deckSig()`/`frameText()` 与注入期 `compute_baked_sig()`)此前**只哈希可见文本**:`frameText` 的 `TreeWalker` 用 `SHOW_TEXT` 只走文本节点,Python 侧则先剥 `<script>/<style>` 再去标签取纯文本——**图片(`<img src>`、svg `<image>`、内联 `background url`)完全不进指纹**。于是两份**文字相同、配图不同**的 deck 会算出**同一枚 `BAKED_SIG`**,命中同一把存取 key;A 卷保存过的全量快照会在 B 卷**正常模式**下经 `restoreFullAsync()` 的 `track.innerHTML=snap.html` 把 B 的真身**整段遮蔽**,而**无痕模式**无缓存、如实透出文件自带内容 → 两种模式所见不一致。实测:仅改一张 `<img src>` 一个字节,旧指纹岿然不动(`1u7lqox` 撞 `1u7lqox`),证明碰撞真实存在。
    - **修法(指纹补采图片/媒体,JS+Python 双侧对称)**:`frameText()` 新增 `mediaText(f)`——把该页每张 `img[src]`、svg `<image>` 的 `(xlink:)href`、带 `background` 的内联 `style` 里的 `url(...)` 各取 `hash()` 摘要后并入指纹(用 `@M@` 前缀分段);Python 侧 `compute_baked_sig()` 同步用正则采同样三类媒体、经 `_djb2` 摘要并入。用**摘要**而非原样并入,避免把 4MB+ 的 base64 data-uri 塞进指纹串(只多算一遍 djb2,一次载入内完成)。于是**换图即指纹变、key 变、旧快照不再命中**,跨卷缓存永不遮蔽文件自带内容;文字与配图皆不变时指纹稳定(既有编辑照样读得回,RC1/bug#8 契约不破)。注:JS/Python 两侧哈希值本就不必逐位相等(`BAKED_SIG` 是每文件烘死的常量,只需**能区分**不同内容),导出件仍由 `rebakeExportSig()` 按 live 内容重烘。
    - 见 `verify_editor_mediasig.py`(烘出「文字全同、hero 图不同」的 A/B 两卷:①两者 `BAKED_SIG` 不再相同;②同一 profile 先存 A 快照再开 B,B **正常模式**显示 B 自己的图而非 A 缓存;③B 在**全新 profile(等价无痕)**同样显示 B 的图;④正常==无痕,分歧消失)。全套 `verify_editor_*.py` 回归通过(仅 `dupedit` 因**宿主原始 deck 自带 3 个重复 `data-edt`** 这一素材缺陷失败,与本次改动无关)。

> 为什么这样拆:结构变更、内联字号、图片 transform 都直接落在真实 DOM 上,所以宿主的
> `#deckExport`「克隆 documentElement 下载」会天然把这些改动一并固化到导出 HTML——
> 无需另写一套序列化/回写逻辑,导出即所见即所得。

## 使用流程

### Step 1 — 拿到输入 deck.html
输入必须是 `doubao-html-deck-generator` 生成的成卷 `deck.html`(含 `#deckTrack` / `#deckEdit` / `#deckExport` 外壳)。
若用户只给了单页或非成卷 HTML,先提示用宿主 skill 的 `compose` 成卷。

### Step 2 — 注入增强层
```bash
python3 scripts/inject_editor.py <deck.html>                 # 产出 <deck>.edit.html
python3 scripts/inject_editor.py <deck.html> -o out.html     # 指定输出
python3 scripts/inject_editor.py <deck.html> --in-place      # 原地写回(先自动备份 .bak)
python3 scripts/inject_editor.py <deck.html> --check         # 只检测是否已注入
```
注入是**幂等**的:对已注入文件再次运行会替换(升级)增强层块,不会叠加。

### Step 3 — 交付编辑版给用户
把 `deck.edit.html` 上传/交付。用户在浏览器打开后:
- 点右下角宿主的 **✎ 编辑模式**(`#deckEdit`)进入编辑;顶部出现「编辑+」增强工具条,左侧出现页面栏。
- **加/删/排序页**:顶部 `＋复制本页` / `＋空白页` / `🗑删除本页`;左侧页面栏每个 chip 显示「页码 + 本页标题 + 版式代号」,**悬停即跳到该页预览**、**拖拽 chip** 重排。
- **改字号 / 段内放大 / 文字颜色**:点一段文字 → 浮动 `A-/A+/↺`;**先选中段落里的一段文字再点 `A+`**,只放大选中那段;工具条右侧色板改文字颜色(主题纯色 / **渐变模板色** / 复位),有选区只改选区。
- **挪图/缩放**:直接拖图片;滚轮或图框右下角 `－/＋/↺` 缩放。
- **卡片/数字动效与描边色**:点选卡片 → 弹出装饰面板,`动效` 行切换 上浮/淡入/放大/无,`描边` 行改卡片左侧彩条颜色(主题渐变边 / 纯色 / 复位)。
- **加内容**:顶部 `＋文字` / `＋卡片` / `＋图片` → 当前页出现浮层元素;拖拽移动、右下角 `－/＋/↺` 缩放、右上角 `✕` 删除;**双击**就地编辑文字(卡片可编标题+正文)或上传图片。
- **加形状**:顶部 `▭矩形` / `◯圆` / `／线` / `➔箭头` → 当前页插入形状浮层;选中形状后上方浮出操作条,含填充色板。
- **文字格式 / 列表**:点一段文字后,字号条右侧的 `B`/`I`/`U` 加粗斜体下划线、`⬅/⬌/➡` 对齐、`•≡/1≡` 项目符号/编号列表(有选区作用选区)。
- **多选 / 层级 / 对齐 / 成组**:`Shift+点击` 多选浮层;选中后上方操作条可**置顶/置底/上移/下移**、**对齐/分布**、**成组/解组**(也支持 `Ctrl+G`/`Ctrl+Shift+G`);拖单个元素时出现红色**吸附辅助线**。
- **撤销 / 复制**:`Ctrl+Z` 撤销、`Ctrl+Y`(或 `Ctrl+Shift+Z`)重做;选中浮层 `Ctrl+C`/`Ctrl+V` 复制粘贴、`Delete` 删除。
- **改文案/换图/备注**:沿用宿主原生能力(双击文字、图片位上传)。
- 改完点宿主右下角原生的 **⬇ 导出 HTML**(`#deckExport`),下载固化后的新 `deck.html`。增强层不再另放导出按钮,避免与宿主重复。

### Step 4 — (可选)回收编辑成果
导出的新 `deck.html` 就是最终产物,可再次投影/演示,或再次注入继续编辑(幂等)。

## 持久化模型
- **字号 + 图片 transform**:另存一份 `localStorage`(键 `deckeditplus:<docSig>`),刷新页面不丢,作为编辑草稿双保险。**storeKey 只认文档标识、【不含用户新增页数】**——早期实现把 `track.children.length` 拌进 key,于是「新增/删除任意一页」都会让整份草稿的存取键旋转、既有编辑全部读不回来(用户反馈「退出编辑后保存不生效」的根因之一);v3.3 起固定为**内容指纹** `docSig=hash(标题|首屏原始页数|首页标题文本|首个 data-edt 文本)`(在还原前基于宿主原始内容算,跨载入稳定),结构增删不再殃及草稿,且不同 deck 恰好同标题也不会串档。
- **每页编辑相互独立(页命名空间)**:字号/图片的存储键一律以**页身份 `data-deppg`** 作命名空间前缀(`<deppg>::<页内本地键>`)。首屏既有页在启动时按 DOM 次序铸**确定性** id(`p0/p1/…`,可跨普通重载复现);运行时新建/复制页由 `pageId()` 铸**随机唯一** id。**复制/空白页在 `addPage` 里剥离克隆来的 `data-deppg`**(cloneNode 会原样拷走源页 id),故复制页获得全新页身份,其后编辑独立入桶。回存 `fsFind()` 先按 `data-deppg` 锁定目标页、再在页内定位节点——**改哪页只落哪页**。这修掉了用户反馈的「改第 3 页却影响第 2、4 页」以及由「回存命中别页首个同指纹节点」引发的「原有格式乱了」。见 `verify_editor_pageindep.py`。
- **结构性变更(增/删/重排页、浮层增删移、形状、成组…)**:直接改真实 DOM。默认以**导出即固化**为准;此外提供**手动全量保存**(见下)可把结构一并写进 localStorage。
- **全量保存按钮(右上角 `#depSaveBox`,仅编辑模式显示)**:进入编辑模式后右上角出现 `💾 保存` 按钮 + 状态文字(v3.7 起去掉了并排的 `清除` 按钮)。任何会改动内容的操作(字号/颜色/动效、增删重排页、浮层/形状增删移等)都会把状态置为「● 未保存」。点击「保存」执行**真实全量保存**:把整条 `#deckTrack` 的**净化后 HTML**(内联字号/图片/形状编辑已烘进节点、剔除 `contenteditable` 与增强 UI 残留)连同 `sig:docSig` 打包,**写进 IndexedDB**(`db='deckeditplus'`/`store='snaps'`/key=`deckeditplusfull:<docSig>`);字号/图片桶即时落进 `localStorage`,另在 `localStorage` 留一条几十字节元记录 `deckeditplusmeta:<docSig>`={ts,cur,sig,len} 供启动同步判定。状态转为「已保存 [MM/DD] HH:MM」(跨天带日期);写入前估算体积、超 200MB 才拒写(远大于旧的 4.7MB——**这正是修「14.3MB 超 localStorage 5MB 上限」bug 的关键**:含大量内联图片的真实 deck 天生塞不进 localStorage,故改存 IDB)。下次载入若存在**且 sig 匹配**的快照(且非 `present=speaker` 演讲者视图),启动时先同步读元记录回显「已保存」、再**异步**从 IDB 取回大 HTML 整段还原 `#deckTrack`(含新增/删除/重排的页与浮层),重跑 count-up 数字,再走常规回存/复活流程——**刷新即所见即所得**;需要回落原始底稿时带 `?depfresh` 打开即静默清 IDB 快照行+元记录+草稿桶(v3.7 起取代原 `清除` 按钮)。旧版(≤3.3)写在 localStorage 的快照仍**只读**兼容(IDB 未命中回退去读);IDB 写失败(私密模式/配额禁用)退回 localStorage(仍受 ~5MB 顶)。`#depSaveBox` 挂在 `body`(不在 `track` 内),故不进导出/投影快照,不污染产物。见 `verify_editor_save.py`(含 >5MB 大快照 save/restore 用例)。
- 宿主自身的文字/图片/备注草稿仍由宿主的 localStorage 负责,两者并存不打架。

## 关键实现约束(改代码时务必遵守)
- **纯注入、零依赖**:增强层是自包含的 `<style>`+`<script>`,注入在 `</body>` 前;不引外部资源,离线可用。
- **ES5 风格**:与宿主既有脚本、无头 Chromium 保持兼容,不用可选链/箭头函数等(宿主脚本即 ES5)。
- **接管导航**:增删/重排会让宿主 IIFE 的闭包 `frames` 数组失效。增强层用 live DOM 重新实现 `go()`,并**覆盖 `window.__deck.go/cur/frames/total`**、重绑 `#deckPrev/#deckNext/dots`、在 capture 阶段接管方向键——保证结构变更后翻页与投影同步仍正确。**接管后必须自行维护箭头 `disabled`**:宿主原 `render` 只在自己的翻页里写 `prev.disabled=(cur===0)`/`next.disabled=(cur===N-1)`,一旦被增强层的 `go()` 取代就不再更新;若不在 `go()` 里同步 `disabled`,宿主初始把 `prev` 置 `disabled`(cur===0)后会**永久卡死**,表现为「页面下方向左箭头不生效」。故 `go(i)` 每次都 `prev.disabled=(i===0)`、`next.disabled=(i===N-1)`(见 `verify_editor_navarrow.py`)。
- **编辑模式联动**:用 `MutationObserver` 监听 `body.deck-editing`,进入才显示增强控件、武装图片位;退出即收起,**不污染非编辑态与导出产物**。
- **导出唯一入口 + 编辑态导出必须等于非编辑态导出**:导出统一走宿主右下角的 `#deckExport`,增强层**不再放自己的导出按钮**。宿主 `#deckExport` 处理是**同步**的(`setEditing(false)`→`cloneNode`→下载),而我方增强控件的收起靠 `MutationObserver` **异步**响应 `body.deck-editing` 变化;于是「编辑模式下点导出」时,clone 发生在我方 `setEnhance(false)` 之前,会把 `#depBar/#depRail/.dep-imgtool` 与 `data-depce` 的 `contenteditable` 一并固化进产物,和「退出编辑后再导出」不一致(这是曾出现「编辑模式下下载 HTML 有问题」的根因)。**修法**:在 `document` 上加 **capture 阶段** click 监听(命中 `#deckExport` 且处于编辑态即同步 `setEnhance(false)`);**必须挂 `document` 而非按钮本身**——同一元素上多个监听按注册顺序在 target 阶段触发、capture 标志被忽略,宿主 export 监听注册在前,挂按钮上会晚于宿主 clone;挂祖先 `document` 的 capture 阶段才真正先于目标执行。宿主处理末尾 `setEditing(was)` 会翻回 `body` 类 → 我方 observer 自动重新武装。见 `verify_editor_dualsync_export.py`。
- **页面栏可辨识**:每个 chip 显示「页码 + 本页标题(`titleOf` 优先 `.ptitle`,回退首个标题/`data-edt` 文本)+ 版式代号」,悬停跳该页预览;翻页时只 `paintRailCur()` 挪高亮、不整栏重建(否则悬停中的 chip 会被销毁)。**就地改标题时**由 capture 阶段的 `input` 监听 `syncRailTitles()` 局部刷新 chip 文本,同样不整栏重建。
- **字号写目标元素的内联 `font-size`**:命中面为白名单 `FTXT`(排除 `FUISEL` 增强控件),含 `.dep-cardt/.dep-cardb`、`.num .v/.num`、`.stat .t/.d`、标题与通用 `h1-4/p/li/span` 等;`data-edt` 元素 key 用其 id,其余元素落一枚 `data-depfs` 属性作 key(随导出克隆固化,重开可精确回填)。写字号时 `removeAttribute('data-fit')` 冻结宿主自适应;**不碰颜色与动效**,故原有配色/入场动画不变。
- **空白页只留骨架**:`addPage('blank')` 克隆后把 `.content` 清空(`innerHTML=''`);标题空则填占位「新页面标题」,便于识别与就地改写。**无 `.content` 骨架的版式(如封面)不能按「删除不在白名单里的直接子节点」处理**:封面结构是 `.deck-scale > .cover-wrap(承载页面背景 `--fs-grad-mesh`)> .cover > …`,其**唯一直接子节点恰是承载背景的 `.cover-wrap`**——它既不等于任何白名单节点也不会被逐一匹配到,于是被整块删掉 → 页面失去背景 → 在投影黑底(`body.deck-projecting{background:#000}`)上呈现为**纯黑页**(这是曾出现「首页新增空白页出现纯黑页面」的根因,bug#4)。**修法(三步,缺一不可)**:①**包含式保留**——只删除「既不是保留节点(`.eyebrow/.kicker/.ptitle/.title-zone/h1/h2/.ptick/.pfoot/.foot`)、也不 `contains` 任何保留节点」的直接子节点,从而始终保住承载背景的包裹层及其中的页眉/标题/页脚;②**黑屏兜底**——若所有直接子节点都被判为可删(纯装饰封面、无任何保留节点),则一个都不删,宁可多留内容也绝不产出无背景的纯黑页;③保住背景后再顺手清掉**可安全识别的纯装饰叶子**(`.bloom/.bird/.cobrand/.lockup/.mh-meta/.rule`),它们都不承载页面背景(背景在外层包裹上),删掉只让空白页更干净、绝不会重新产生黑页,也让「空白页」不至于等同「复制本页」。见 `verify_editor_blankcover.py`(断言封面 +空白页后 `.cover-wrap` 存活、`background-image≠none`、纯装饰被清、标题保留、侧栏同步,且**渲染像素为浅色非黑**)。
- **图片 transform 写第一张 `<img>` 的内联 `transform`**,`transform-origin:center`;缩放范围 0.2–5。
- **新增浮层写真实 DOM**:`.dep-float` 用内联 `left/top`(页面 1280×720 坐标)定位、`transform:scale()` 缩放,连同 `data-depfloat` 标记一起被宿主导出克隆固化;拖拽位移需除以 `.deck-scale` 的实际缩放系数换算回页面坐标。缩放与入场动效分层(外层 `.dep-float` 缩放、内层 `.dep-fanim` 动画),避免 transform 互相覆盖。属结构变更,同样不进 localStorage,导出即固化;再次注入时 `hydrateFloats()` 从 `.dep-float`/`data-depfloat` 复活拖拽与按钮。
- **段内放大 / 文字颜色写行内 `.dep-fs-run`**:有非折叠选区且落在 `fontTarget` 内时,`A+/A-` 与色板不动整段,而是 `wrapRun()` 把选区包进 `<span class="dep-fs-run">` 写内联 `font-size`/`color`;渐变模板色用 `.dep-grad-text` 类(`--fs-grad-title` + `background-clip:text` + `text-fill-color:transparent`),复位则去类去内联。整段模式(无选区)直接写 `fontTarget` 内联。**纯色必须用 `!important` 并同时写 `-webkit-text-fill-color`**:宿主大数字/渐变标题用 `-webkit-text-fill-color:transparent` 让字透明,只写 `color` 会被它盖住看不到颜色(这是曾出现「放大后的卡片文字改不了色」的根因);故 `applyTextColor` 对纯色分支 `setProperty('color',v,'important')` + `setProperty('-webkit-text-fill-color',v,'important')`。这些都随导出克隆(span/类/内联)固化。字号色板追加在 `A-/A+/↺` 三个按钮**之后**,不打乱既有按钮索引。
- **卡片动效类驱动 + `!important`**:动效用 `dep-anim-rise/fade/zoom/none` 类而非内联,因宿主 `replayCards()` 只清 inline `style.animation`,类 + `!important` 才能扛住其重放。**重播必须靠切类**——因动效类带 `!important`,inline `animation:none` 压不住它,`setAnim()`/`replayDeco()` 都用「摘类→`offsetWidth` 回流→重挂类」才能让 computed animation 真正 off→on 重触发(直接写 inline animation 无效,这是曾出现「调了动效不生效」的根因)。浮层卡片的动画类要落在**内层 `.dep-fanim`**(`animNode()` 取):外层 `.dep-float` 有 `transform:scale()`,与动画 transform 打架,落外层会失效。命中面 `DECOSEL=.stat/.card/.fpoint/.rcard/.impact .card/.dep-float.dep-card`;`deck:nav` 时 `replayDeco()` 与宿主 `SEL` 卡片同步重放。
- **动效恒作用整卡,不落文字/数字子块**:`pickDeco()` 一律 `closest(DECOSEL)` 归一到卡片容器并返回 `{card,anim:card,kind:'card'}`,`.dep-cap` 恒回显「卡片整体」。**为什么不再分层命中子块**:对原始卡片内部的数字/某段文字节点直接做入场 transform/opacity 动画,会出现「点上浮文字整块消失、点淡入整卡被动画位移拽下移」——脆弱文字节点扛不住动画重排。归一到卡片容器后,宿主 `mcCardIn` 与我方 `dep-anim-*`(带 `!important`)落在**同一** `.stat` 元素,类 + `!important` 天然盖住宿主入场,无需再靠 `.dep-hostoff` 静音子块场景(该机制已退役,`setAnim()` 只在挂类前顺手 `decoCard.classList.remove('dep-hostoff')` 清理历史残留)。见 `verify_editor_animux.py` / `verify_editor_v20fix.py`。
- **动效终态必须自带「就位可见」(不能只写 from→to 的语义)**:宿主卡片基础样式是 `opacity:0 + transform:translateY(14~16px)`,**卡片本来就靠入场动画 `mcCardIn{to{opacity:1;translateY(0)}}` 才显现/归位**。因此我方每个动效类都必须把终态钉死为 `opacity:1`,否则会复刻宿主基础态的"隐身/下移"。具体:`depFadeIn` 的 `from/to` 都写 `transform:none`(只写 `opacity` 会让卡片停在基础态的 `translateY(16px)` → 曾出现「点淡入整卡下移」);`.dep-anim-none` 不能只 `animation:none`,必须同时 `opacity:1!important;transform:none!important`(只关动画会让卡片永远停在基础态 `opacity:0` → 曾出现「点无整张卡片消失」)。`depRiseIn`/`depZoomIn` 因 `to` 已含 `opacity:1+transform` 归位,天然正确。四种动效终态均经探针实测:上浮/放大/淡入/无 全部 `opacity:1` 且 transform 为 identity/none。
- **新增图片浮层不裁剪控件**:`✕/±/↺` 控件定位在浮层框外(负偏移 `top/right/bottom`),故 `.dep-float.dep-img` **绝不能写 `overflow:hidden`**——否则整排按钮被裁掉看不见(曾出现「新增图片框右下/右上的放大/缩小/重置/删除按钮看不到」的根因)。裁剪只落在内层 `.dep-imgbox{overflow:hidden;border-radius}`:图片被裁而控件溢出可见,外层 `.dep-float.dep-img` 保持 `overflow:visible`。
- **卡片描边色写 `--dep-edge` 变量**:`::before` 伪元素不能写内联样式,故在元素上写 `data-dep-edge` 属性 + 内联 `--dep-edge` 变量,由注入 CSS 规则 `[data-dep-edge]...::before{background:var(--dep-edge)!important}` 读入;渐变边取 `--fs-grad-keyline`。属性与内联变量随导出克隆固化。
- **复制页/重开页必须重挂事件**:`cloneNode(true)` 与宿主导出克隆只拷 DOM,不拷 JS 事件与 `__dep*` 标记。复制本页(`addPage('dup')`)后,克隆页里的浮层会拖不动、`✕/±` 失效,图片位工具条也失灵;同理重开上一轮导出的 HTML 时,浮层/图片位带的是「死控件」。故 `addPage` 克隆后对新页作用域调 `hydrateFloats(clone)` + `armImgSlots(true)`;`hydrateFloats`/`armImgSlots` 用 **JS 标记幂等守卫**(`__depHydrated`/`__depTool`/`__depDrag`,均不随 cloneNode 复制)而非 DOM 存在性判断,并**先摘掉复制来的死 `✕/±/.dep-imgtool` 再重建带事件的**(用 DOM 存在性判断会命中死节点跳过重建,这是曾出现「复制页的浮层/图片按钮点了没反应」的根因);新建浮层即置 `__depHydrated=1`,避免二次扫描重绑。
- **结构变更后双屏(投影+演讲者)仍同步**:宿主 `launchProjector()` 用 `window.open(file://...?present=speaker)` 开演讲者窗口——那是**从磁盘重载原始文件**,不含运行时新增/删除/重排的页,所以必须把「当前 live DOM(含新增页)」交给它。**同步靠同源**:宿主用 `BroadcastChannel('deck-sync')` + `localStorage` 按页 idx 同步,二者**只在同源之间生效**。曾用 `Blob` URL 直接喂演讲者:页数对了,但 Blob 文档是 opaque `null` 源,与 `file://` 投影窗口**跨源** → `BroadcastChannel`/`localStorage` 全断 →「双屏彻底不同步」(这是曾出现的回归根因;真实双窗探针 `repro_twowin.py` 实测:演讲者 `origin=null`/`scheme=blob:`、投影 `origin=file://`)。**正确修法(二合一,缺一不可)**:① 仍用 `Blob` 承载新增页——演讲者内容才正确,且 Blob 是全新文档,CSS `both` 入场动效随节点插入**自动播**,故「演讲者模式动效正常」;② 另建一条 **`postMessage` 跨源桥**补上被 Blob 源隔断的按页同步——`postMessage` 允许跨源(探针 `probe_postmsg.py` 实证 `file://` ↔ `blob:null` 双向可达、`opener` 可用),而 `BroadcastChannel`/`localStorage` 不行。桥两端跑同一份注入脚本(Blob 即含增强层的 live DOM 克隆),对称:任一端 `deck:nav` → 向对端 `postMessage({__depSync:idx})` → 对端 `__deck.go(idx)`(`__depSyncMute` 防回环);演讲者 `deck:ready` 后向 `opener` 报到(`{__depReady}`),投影据此推当前页完成首帧对齐。**为什么不直接改回同源 file:// 打开**:那样同步是好的,但演讲者磁盘重载拿不到运行时新增页,回到「新增页后演讲者少一页」的老问题——故必须 Blob(带页)+ postMessage(带同步)并用。属结构态,不进 localStorage。**教训**:双屏必须用**真实两窗**跑真 `Shift+P` 回归,只验 blob 帧数会漏掉跨源同步被切断。见 `verify_editor_dualsync_live.py`(真双窗、双向同步)与 `verify_editor_dualsync_export.py`。
- **投影(全屏)动效:进投影先把当前页动效「摁回起始态」,等全屏真正就位再播(hold-then-play,真机专属时序坑的终极修法)**:增强层的动效重放 `replayDeco()`/`replayFloats()` 常态只挂在 `deck:nav`(翻页)与 `deck:ready`(首屏就位)上。**演讲者(speaker)窗口是 blob/磁盘重载的新文档**——CSS `both` 入场动效随节点插入自动播,故演讲者态天然正常,无需干预。真正出问题的只有**投影(projector)主窗**:它就地加 `body.deck-projecting`、**复用同一 live DOM**;若「刚在编辑态新建的那一页」正是当前页,动效早在编辑时就播完并停在终态,进投影既不翻页也无 `deck:ready` → 不重放 → 用户看到的是「直接是结果、没有动效」。
  **失败过两版(教训)**:v2.3 用 observer 进投影后 `setTimeout(60)` 重放、v2.5 再挂 `fullscreenchange` 后 `setTimeout(90)` 重放——**都用固定延时**。但真机**全屏切换过渡耗时是可变的几百毫秒**,任何固定延时都可能落在过渡**期间**(黑屏/缩放中)把动效播掉,等画面就位用户只看到终态。**无头环境没有真全屏过渡,故两版探针都通过、却在真机连续失败**——凡涉及 `requestFullscreen` 的时序,`animationstart` 计数与固定延时采样都不足为证。
  **v2.6 正确修法(不再赌延时,改为 hold-then-play)**:① 一进投影(`deck-projecting` 由无到有)立刻给「当前页动效节点」加 `.dep-projhold`(`animation:none!important;opacity:0!important`),把它们**摁回起始态**——过渡多长都**绝不露出终态、也不偷播**;② 真正播放由**事件**驱动:监听 `fullscreenchange`/`webkitfullscreenchange`,全屏**真正就位**后 `requestAnimationFrame`+一拍(120ms 让宿主 `fitProjector` 的 transform 落定)才摘掉 hold、回流、干净重放——此刻画面已可见,是用户真正看到的入场动效;③ **安全兜底**:900ms 内若 `fullscreenchange` 一直不来(弹窗被拦/就地投影/浏览器不触发)就强制播一次,单次守卫 `played` 防重复,**保证卡片绝不会永远停在 `opacity:0`**;退出投影时清掉遗留的 `.dep-projhold`。speaker 就地态(非全屏)仍走简单的 `replayCurrentSimple()`。`.dep-projhold` 规则定义在所有 `.dep-anim-*` **之后**,单类选择器 `!important` 平手时靠「后定义」胜出,故能压住已选的 `dep-anim-rise` 等。见 `verify_editor_projhold_replay.py`(模拟**可变长过渡**:断言过渡期恒 `opacity:0` 不露终态 → 伪造 `fullscreenElement`+派发 `fullscreenchange` → 断言动效重新触发出现 `0<opacity<1` 中间帧并收敛到 1 → 另一条路径断言 `fullscreenchange` 永不来时安全兜底仍到 `opacity:1`)。
- **默认视图退出编辑也要重放新建浮层动效(bug#5)**:编辑态点 `＋卡片/＋文字/＋图片` 新建的浮层,其内层 `.dep-fanim.dep-anim` 是 CSS `both` 入场动效——**插入的一瞬就播了一次并停在终态**(opacity=1)。此后用户**退出编辑回到默认视图、仍停在同一页**时,既没有翻页(无 `deck:nav`)、也没进投影/演讲者 → 动效不再重放 → 用户看到「卡片直接就位、没有入场动效」。**为什么只有演讲者正常**:演讲者(speaker)窗口是 blob/磁盘重载的**全新文档**,CSS `both` 随节点插入自动播;投影(projector)由 `armProjectionArrival` 的 hold-then-play 兜底;**唯独「默认视图退出编辑」这条路径缺重放钩子**(这是曾出现「除演讲者模式外,新建卡片动效都不出现,含默认与全屏」的根因)。**修法**:在监听 `body` 类的 `MutationObserver` 里,当 `deck-editing` 由 `true→false`**且当前非 `deck-projecting`/`deck-speaker`** 时,对当前页 `setTimeout(30)` 补一次 `replayFloats(f)+replayDeco(f)`;仅默认态触发,避免与投影 hold-then-play 竞争。导出流程宿主会同步 `setEditing(false)→setEditing(was)`,这两次类翻转被本 observer 异步合并,退出编辑的重放发生在宿主 clone **之后**,不污染导出产物。见 `verify_editor_newcardanim.py`(断言退出编辑后当前页新建卡片采样到 `0<opacity<0.99` 中间帧并收敛到 1)。
- **翻页入场动效必须等「整页滑入过渡到位」后才播,不能固定 30ms 在侧滑期偷播(bug#6)**:宿主 `#deckTrack` 有 `transition:transform .55s cubic-bezier(.6,.02,.1,1)` 的整页滑入过渡(约 550ms)。旧 `deck:nav` 处理**固定 `setTimeout(30)`** 就重放卡片的 0.5s 入场动效——于是动效整段都发生在**页面还在侧滑、尚未进入视口中央**的过程里,等滑动结束(~550ms)动效恰好也刚播完并停在终态,用户看到的永远是「页面到位即终态、没有入场」。**全屏投影下滑动更显眼**,故用户在**「运行时新建页面上的新建卡片」**最容易察觉(该页是运行时插入的,`armProjectionArrival` 只武装了进投影时的当前页,翻到新页只走 `deck:nav` 这条固定延时路径 → **必现**)。本质是 v2.6 projhold 早已警告过的「固定延时会落在过渡期把动效播掉」,只是发生在**翻页**而非**进投影**路径上。**修法(与 hold-then-play 同一套哲学,统一到所有模式)**:`armNavArrival(f)` 翻到目标页先 `holdAnims(f)` 摁回起始态(滑入期绝不露终态),再由 `track` 的 `transitionend`(`propertyName==='transform'` 且 `target===track`,即滑动真正到位)驱动 `releaseAnims+回流+replayFloats+replayDeco`——此刻页面已居中静止,是用户真正看到入场动效的那一次;附 **620ms(>0.55s)安全兜底**:`prefers-reduced-motion`(宿主过渡被禁、无 `transitionend`)走直接重放快路径、目标即当前位、浏览器不触发 `transitionend` 时也必定重放,绝不卡在 `opacity:0`;`_navTok` 自增令牌保证连续快速翻页只有最后一次生效,过期回调直接 `return`,避免误摘/误播。**教训**:凡涉及宿主滑入过渡的时序,必须用**真机/忠实时序探针**(测 `transitionend` 与 `animationstart`/`animationend` 的相对时刻),无头环境无真过渡、固定延时探针会假通过。见 `verify_editor_navslide.py`(全屏投影下翻到运行时新建+带新建卡片的页,断言卡片 `animationstart` 晚于 `track` 滑入 `transitionend` 且收敛到 `opacity:1`)。


## 验证(改动后必跑)
用无头 Chromium 加载注入后的 HTML,断言:
1. `window.__deckEditorPlus` 存在;进编辑模式后 `#depBar` 显示、`#depRail` chip 数 == frames 数。
2. 复制页 frames+1、空白页再+1、删除页 -1,侧栏 chip 数始终同步。
3. 点文字后 `A+` 三次,`getComputedStyle(...).fontSize` 增大;`↺` 归零。
4. 图片位有 `.dep-imgtool` 与 `.dep-imgpos`;`＋`缩放使 `transform` 出现 `scale`,拖拽再改 `translate`。
5. `＋文字/＋卡片/＋图片` 各插入一个 `.dep-float`(`data-depfloat` 对应);`.dep-scaler` 的 `＋` 写 `transform:scale`,拖拽改 `left/top`;`.dep-elx` 删除 -1;导出克隆里 `.dep-float` 仍在。
6. 导出会触发带 `download` 的 `<a>.click()` 且移除 `contenteditable`。
7. 幂等:对已注入文件再次 `inject_editor.py` 得到 `status=reinjected`,字节数基本不变。
8. **卡片装饰**:点卡片弹 `#depDeco`;动效切 `dep-anim-zoom→none→rise` 类互斥;**动效恒作用整卡**——无论点数字/文字/卡片留白,`pickDeco` 都归一到卡片容器(点数字/文字不再分层落子块,`num`/`txt` 命中均解析为「卡片整体」且卡片子块不带动效类);`.dep-cap` 恒回显「正在设置:卡片整体」且当前动效按钮 `dep-on` 高亮;**重放**——`deck:nav`+`deck:ready` 都 `replayDeco()`,含 count-up 数字的卡片重跑 count-up(投影态亦然);描边色写 `--dep-edge`/`data-dep-edge`(纯色 + 渐变边 + 复位)且恒作用卡片容器;选中段落内文字 `A+` 生成 `.dep-fs-run` 且其字号 > 整段;文字色板纯色写内联 `color`、渐变写 `.dep-grad-text`(`background-clip:text`)、复位清空;导出克隆里动效类/描边属性/`.dep-fs-run` 均在。参考 `verify_editor_animux.py`。
9. **图片点击放大(lightbox,req#1)**:非编辑态点内容图(`data-edimg`/`.dep-float.dep-img`/正文 `img[data-depzoom]`)→ `#depLightbox` 显示且其 `<img>.src` 被填;点 `✕`(`#depLbClose`)/ 点背景 / 按 `Esc` 均关闭;**编辑态点图片不开** lightbox(点=拖拽/选中);logo/装饰图(`.bird/.lockup` 等)不被标 `data-depzoom`;导出克隆里仍带 `#depLightbox` 结构 + 图片 `data-depzoom`。参考 `verify_editor_lightbox.py`(该 fixture 无内容图,脚本先注入一张合成内容图再验证)。
10. **PPT 增量能力(req#2,8 项)**:①`▭/◯/／/➔` 各插入对应 `.dep-shape.dep-{rect,ellipse,line,arrow}`,选中形状浮出 `#depShape` 且点填充色块写内联 `--dep-fill`;②置顶/置底后内联 `z-index` 前>后;③`Shift+点击`多选(`.dep-msel`≥2),`Ctrl+G` 成组包进 `.dep-group`(≥2 子)、`Ctrl+Shift+G` 解组(组消失);④多选左对齐后 `left` 相等,单选拖到 x≈640 出现 `.dep-guide.dep-gv` 且中心吸附到 640、`mouseup` 后隐藏;⑤`＋文字`后 `Ctrl+Z` 撤销 -1、`Ctrl+Y` 重做 +1;⑥选中浮层 `Ctrl+C`/`Ctrl+V` 粘贴 +1、`Delete` 删除回落;⑦点文字挂 `#depFont`,`data-depfmt=bold` 写进 DOM、`center` 设 `textAlign`、`ul` 生成 `<li>`,且 `A-/A+/↺` 前三索引不变;⑧导出克隆保留 `.dep-shape`。参考 `verify_editor_ppt.py`。
11. **翻页入场动效等滑入到位后才播(bug#6)**:全屏投影下翻到一张**运行时新建、且带新建卡片**的页,卡片入场动效的 `animationstart` 必须发生在 `#deckTrack` 滑入过渡 `transitionend`(transform)**之后**(页面居中静止才播,不在侧滑期偷播),且最终收敛到 `opacity:1`。参考 `verify_editor_navslide.py`(埋点记录 `slide-end`/`anim-start`/`anim-end` 相对时刻,断言 `anim-start >= slide-end`)。

参考验证脚本见 `references/verify.md`。

## 边界
- 不从零生成 deck(那是 `doubao-html-deck-generator`)。
- **既有** `data-edt` 文字块**不做**脱离栅格的自由拖拽(会破坏版式栅格,留待 v2);新增内容通过 `＋文字/＋卡片/＋图片` 浮层自由摆放。
- 不编辑飞书云文档、不产出 PPTX。
