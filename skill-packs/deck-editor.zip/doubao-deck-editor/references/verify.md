# 验证参考(doubao-deck-editor)

改动增强层后,用无头 Chromium 跑以下验证。沙箱内需先设置:
```bash
export LD_LIBRARY_PATH=/home/mira/.session/221547879187/libs/usr/lib/x86_64-linux-gnu:/home/mira/.session/221547879187/libs/lib/x86_64-linux-gnu
```
(路径以实际环境的 Playwright/Chromium 依赖为准。)

## 1. 图片点击放大 lightbox(scripts/verify_editor_lightbox.py · req#1)
非编辑态点内容图放大、`✕`/背景/`Esc` 关闭。该 fixture 只有装饰 logo、无内容图,脚本会**先注入一张合成内容图**(canvas 画 300×200,躲过 `isDecorImg` 尺寸阈值)再 `markZoom()`,然后断言:
- **A** 非编辑态点内容图(`data-edimg`/`.dep-float.dep-img`/`img[data-depzoom]`)→ `#depLightbox` 显示且 `img.src` 被填;
- **B** 点 `✕`(`#depLbClose`)→ 关闭;再开点背景 → 关闭;再开按 `Esc` → 关闭;
- **C** 编辑态点图片**不**开 lightbox(点=拖拽/选中);
- **D** logo/装饰图(`.bird/.lockup` 等)不被标 `data-depzoom`;
- **E** 导出克隆里仍带 `#depLightbox` 结构 + 图片 `data-depzoom`。

## 1b. 注入 + 幂等
```bash
python3 scripts/inject_editor.py deck.html -o deck.edit.html   # status=injected
python3 scripts/inject_editor.py deck.edit.html --check        # INJECTED
python3 scripts/inject_editor.py deck.edit.html -o x.html      # status=reinjected(字节数基本不变)
```

## 2. 功能断言(scripts/verify_editor.py)
加载 `deck.edit.html`,依次断言:
- `window.__deckEditorPlus` 存在;`#deckEdit` 点击后 `#depBar` 显示、`#depRail .dep-chip` 数 == `#deckTrack` 子元素数。
- 顶部按钮 `[0]复制 / [1]空白 / [2]删除`:frames 依次 +1 / +1 / -1,chip 数同步。
- 点某 `data-edt` → `#depFont` 三个按钮 `[A-,A+,↺]`;点 A+ 后 `fontSize` 增大。
- 导出:覆写 `HTMLAnchorElement.prototype.click`,断言触发带 `download` 的下载且导出前 `contenteditable` 被移除。

## 3. 图片位置/缩放(scripts/verify_editor_img.py)
若输入 deck 无 `data-edimg`(如纯 cover+e2),动态注入一个合成图片位再验证:
- 进编辑模式后该位有 `.dep-imgpos` 与 `.dep-imgtool`。
- 点 `＋` 使 `<img>` 的 `transform` 出现 `scale`;mousedown→mousemove→mouseup 拖拽再改 `translate`。

两个脚本可直接从本 skill 的 `scripts/` 取用(它们接受一个 `deck.edit.html` 路径)。

## 7. 卡片/数字动效 · 描边色 · 段内放大 · 文字颜色(scripts/verify_editor_batchd.py)
进编辑模式并 `go(1)` 到内容页后:
- **动效可调/删/加**:点 `.stat` 弹 `#depDeco`;`.dep-anb` 依次切 放大(`dep-anim-zoom`)→ 无(`dep-anim-none`,清掉 zoom)→ 上浮(`dep-anim-rise`),类互斥。
- **卡片描边色**:`#depDeco` 第二行 `.dep-sw`:纯色写 `--dep-edge:#2B6CF0` 且置 `data-dep-edge=1`;渐变边写 `var(--fs-grad-keyline,...)`;复位清 `data-dep-edge`。
- **段内特定文字放大**:点段落使其成 `fontTarget`,在其文本节点选 3 字,点 `#depFont` 的 `A+`,断言生成 `.dep-fs-run` 且其 `fontSize` > 整段基线。
- **文字颜色**:`#depFont` 色板 `[data-depcol]`:`#2B6CF0` 写内联 `color`;`__grad__` 加 `.dep-grad-text`(`background-clip:text`=text);`__reset__` 去类去内联。
- **导出固化**:`document.documentElement.cloneNode(true)` 里 `.dep-anim-rise`、`[data-dep-edge]`、`.dep-fs-run` 均残留(导出即固化)。

## 5. 空白页 / 卡片与大数字字号 / 动态标题(scripts/verify_editor_batchb.py)
进编辑模式后:
- **空白页**:先 `go(1)` 到内容页再点 `＋空白页`,断言新页保留 `.eyebrow/.kicker`、`.ptitle`、`.pfoot`,且 `.content` 子节点数为 0。
- **卡片字号**:`＋卡片` 后点其 `.dep-cardt/.dep-cardb`,`#depFont` 显示,连点 `A+` 使 `fontSize` 增大。
- **宿主大数字/文本字号**:点任一 `.num .v/.num/.stat .t/.ptitle/h2/p`,`A+` 后 `fontSize` 增大、`color` 不变、`data-fit` 被移除。
- **动态标题**:改某页 `.ptitle` 文本并派发 `input`,对应侧栏 chip 的 `.dep-ttl` title 跟随更新。

## 5b. 封面新增空白页不出黑页(scripts/verify_editor_blankcover.py · bug#4)
首页(封面,`.deck-scale > .cover-wrap > .cover`,无 `.content`)点 `＋空白页`,断言:
- 新页仍保有承载背景的 `.cover-wrap`,其 `background-image ≠ none`(背景未被误删)。
- 纯装饰(`.bloom/.bird/.cobrand`)被清掉 —— 是真·空白页而非封面副本。
- 标题占位保留可改写;侧栏 chip 数与 frames 同步。
- **像素级**:进到该页截图,多点采样均为浅色,任一点都不得为纯黑。

## 6. 卡片文字 / 大数字内容改写(scripts/verify_editor_content.py)
先等 count-up 跑完再进编辑模式,断言:
- **武装**:编辑前 `.stat .t` / `.num .v` 无 `contenteditable`;进编辑模式后 `.t/.d/.v/.u` 均为 `contenteditable=true`。
- **改文字**:改写 `.stat .t` 内容生效,`getComputedStyle().color` 前后一致(颜色保留)。
- **改数字**:改 `.num .v` 为 `88`,`data-to` 同步为 `88`(count-up 终点跟随)。
- **非数字**:改为 `N/A`,`data-to` 被移除(不再被 count-up 回改)。
- **退出/导出**:退出编辑模式后 `contenteditable` 被移除;导出克隆经宿主统一 strip 后无残留。

## 4. 新增浮层元素(scripts/verify_editor_float.py)进编辑模式后,点顶部 `＋文字/＋卡片/＋图片` 各插入一个浮层,断言:
- 三个 `.dep-float` 生成,`data-depfloat` 覆盖 `text/card/img`。
- `.dep-scaler` 的 `＋` 使外层 `transform` 出现 `scale`;mousedown→move→up 拖拽改 `left/top`(位移已按 `.deck-scale` 缩放系数换算)。
- `.dep-elx` 点击删除该浮层(计数 -1)。
- 克隆 documentElement 后 `.dep-float` 仍在(导出即固化)。

## 8. PPT 增量能力 · 8 项(scripts/verify_editor_ppt.py · req#2)
进编辑模式并 `go(1)` 到内容页后,依次断言(全部落真实 DOM、随导出克隆固化;快捷键仅编辑态生效,改文字时不拦截 C/V/Delete):
- **形状(#49)**:顶部 `▭/◯/／/➔` 各插入 `.dep-shape.dep-{rect,ellipse,line,arrow}`;选中形状浮出 `#depShape`,点 `.dep-cw` 填充色块写内联 `--dep-fill`(前后不同)。
- **层级(#46)**:选中后「置顶/置底」写内联 `z-index`,front > back。
- **多选+成组/解组(#48)**:`Shift+点击` 多选(`.dep-msel` ≥2);「成组」把选中包进 `.dep-float.dep-group`(≥2 子);「解组」后 `.dep-group` 计数为 0。
- **对齐/分布+吸附(#47)**:两元素打散后多选「左对齐」→ `left` 相等;单选拖拽使中心接近 x=640 → `.dep-guide.dep-gv` 显示且中心吸附到 640,`mouseup` 后辅助线隐藏。
- **撤销/重做(#43)**:`＋文字` +1;`Ctrl+Z` 回到 before;`Ctrl+Y` 再 +1。
- **复制/粘贴/删除(#44)**:选中浮层 `Ctrl+C`→`Ctrl+V` +1(偏移 24px);`Delete` 删除粘贴出的元素回落。
- **文字格式+列表(#45/#50)**:点宿主文字挂 `#depFont`;`data-depfmt=bold` 生成 `<b>/<strong>` 或 font-weight、`center` 设 `textAlign:center`、`ul` 生成 `<li>`;**`A-/A+/↺` 前三索引不变**(保护既有测试契约)。
- **导出固化**:`document.documentElement.cloneNode(true)` 里 `.dep-shape` ≥1 残留。


## 9. 新建浮层动效在默认视图退出编辑后重放(scripts/verify_editor_newcardanim.py · bug#5)
编辑态点 `＋卡片` 新建浮层,其 `.dep-fanim.dep-anim` 入场动效在**插入时即播完并停在终态**(opacity=1)。退出编辑回到**默认视图同页**(既不翻页、也不进投影/演讲者)时脚本断言:
- 退出编辑后当前页新建卡片动效被**重放**:采样到中途帧 `0<opacity<0.99`;
- 最终收敛到 `opacity=1`(不卡在半透明/隐身)。

> 演讲者(speaker)是 blob 重载新文档,CSS `both` 随插入自动播故天然正常;投影(projector)由 `armProjectionArrival` hold-then-play 兜底;唯独默认视图退出编辑缺重放钩子,故在 `MutationObserver` 的 `deck-editing` 由 true→false 且非投影/演示态时补一次 `replayFloats+replayDeco`。

## 10. 翻页入场动效等整页滑入到位后才播(scripts/verify_editor_navslide.py · bug#6)
宿主 `#deckTrack` 有 `transition:transform .55s` 的整页滑入过渡。旧实现固定 30ms 就重放,动效整段落在页面还在侧滑(未进视口中央)时播完 → 用户「到位即终态、没入场」;全屏投影下最明显,「运行时新建页面上的新建卡片」是必现(新页只走 `deck:nav` 固定延时路径)。脚本流程:编辑态定位首页 → `＋复制本页`得到运行时新建页(idx=1)→ 在其上 `＋卡片` → 退出编辑回首页 → 伪造 `fullscreenElement`+派发 `fullscreenchange` 进全屏投影 → 埋点监听 `track` 的 transform `transitionend`(`slide-end`)与卡片 `animationstart`/`animationend` → `go(newPage)` 翻到新页。断言:
- 卡片入场动效**必定触发**(`anim-start` 存在)、`track` 滑入过渡**必定发生**(`slide-end` 存在);
- **关键**:`anim-start >= slide-end-30`(入场在页面滑到位后才(重)播,不在离屏侧滑期偷播);
- 卡片最终收敛到 `opacity:1`。
> 修法:`armNavArrival(f)` 翻页先 `holdAnims` 摁回起始态,由 `transitionend(transform)` 驱动 release+重放,附 620ms 安全兜底;`prefers-reduced-motion` 走直接重放快路径;`_navTok` 令牌防连续快翻的过期回调误播。凡涉及宿主滑入过渡的时序须用忠实时序探针(测 transitionend vs animationstart 相对时刻),无头无真过渡、固定延时探针会假通过。

## 11. PPT 式细节增量·3 项(scripts/verify_editor_ppt2.py · v3.0)
进编辑模式并 `go(1)` 到内容页后,先断言 `window.__deckEditorPlus.v=="3.0"`,再依次验证用户反馈的三处:
- **图片浮层无底色(issue#2)**:`＋图片` 后 `.dep-float.dep-img` 的 `getComputedStyle().backgroundColor` 为 `rgba(0, 0, 0, 0)`(透明,不再有淡蓝底),但**保留虚线边**(`border-style` 含 `dashed`)与占位文字 `.dep-imgph`;注入 `<img>` + 打 `.dep-has-img` 后 `borderTopColor` 转 `rgba(0, 0, 0, 0)`(纯图观感)。
- **文字框手动调宽高(issue#1)**:`＋文字` 后 `.dep-float.dep-text` 带可见的 `.dep-rz` 手柄;对手柄 `mousedown→mousemove(+140,+80)→mouseup` 后框的 `width/height` 明显增大、写内联 `width/height`、打 `data-depsized`;在手柄上拖拽**不移动**整框(`left/top` 不变);导出克隆保留 `data-depsized` 文字框及内联宽高。
- **工具栏防重叠 + 不遮挡被点内容(issue#3)**:`resolveBarOverlap()` 为**锚点感知**去重叠。验证分两部分:
  - **3A 几何兜底**:人为把 `#depFont/#depShape/#depDeco` 三条都设为可见并同坐标(制造重叠),调用同步钩子 `window.__deckEditorPlus.dodgeBars()` 后,断言可见工具条两两矩形**互不相交**。
  - **3B 真实场景**:`＋卡片` 造一张浮层卡片并摆到页面上方(`left=300px;top=120px`,让上方空间紧张),`mousedown` 选中卡片(浮出 `#depShape`)→点标题文字(浮出 `#depFont`+`#depDeco`)→`dodgeBars()`。断言**三条可见工具条都不遮挡被点的标题锚点**(`covers(bar,anchor)` 全为 false)——即用户点了文字后内容仍看得见。字号条/形状条向锚点上方堆叠、装饰面板向下方堆叠,让开锚点矩形;上方不足自动溢出到下方,无锚点时回退 `resolveBarStackOnly()`(仅解决条与条相互重叠)。

## 12. 每页编辑独立 + 结构变更后草稿回存(scripts/verify_editor_pageindep.py · v3.1+)
针对用户反馈「①退出编辑后保存不生效、且原有格式乱了 ②改第 3 页影响第 2、4 页」的双根因回归。进编辑模式验证:
- **A 改一页不动别页**:放大第 0 页标题(A+ ×8)后,断言第 0 页字号确实变大、而**其余各页标题字号逐一不变**。这验证 `data-deppg` 页命名空间隔离了跨页存储桶。
- **B 复制页与源页互相独立**:`复制本页` 后放大复制页(index 1)标题,断言**复制页生效、源页第 0 页字号不变**;并断言全体 `data-deppg` **两两唯一**(证明 `addPage` 已剥离克隆来的页身份、`pageId()` 现铸新 id)。这是「改一页动别页」根因(cloneNode 原样拷走 `data-depfs`/`data-edimg` + `sig()` 跨页指纹相撞)的正面验证。
- **C 结构变更后草稿仍回存(RC1)**:编辑一个 `data-edt` 节点(其 key 已固化在文件里、可跨普通重载复现)→ `空白页` 造一次结构变更 → 等去抖 `persist()` 落盘 → **重载页面**,断言该节点字号被恢复。这验证 storeKey 已不含页数,增删页不再让整份草稿的存取键旋转、把既有编辑读不回来。

## 13. 全量保存按钮 · 结构+编辑整卷回存(scripts/verify_editor_save.py · v3.4)
先清掉本文档所有 `deckeditplus*` localStorage 键 + IndexedDB `deckeditplus/snaps` 存储从干净态起,断言 `window.__deckEditorPlus.v=="3.7"`,再验证右上角保存框 `#depSaveBox` 的全量保存闭环(**v3.4 大快照存 IndexedDB**,localStorage 只留元记录):
- **可见性**:非编辑态 `#depSaveBox` 带 `dep-hidden`;进编辑模式后可见(`offsetWidth>0`),状态初始为「未改动」。
- **脏标记**:放大第 0 页标题(A+ ×8)后状态转 `.dep-dirty`「● 未保存」;`＋空白页` 使页数 +1、`＋文字` 使 `.dep-float` +1(结构改动)。
- **保存**:点 `.dep-savebtn` 后(IDB 写是异步,轮询等状态翻转)状态转 `.dep-saved`「已保存 [MM/DD] HH:MM」;断言 **IndexedDB `snaps` 里出现快照行**、`localStorage` 出现 `deckeditplusmeta:` 元记录、且大快照**不再**落在 `localStorage[deckeditplusfull:]`(规避 ~5MB 上限)。
- **刷新回存**:重载页面后(还原是异步,轮询等页数到位)——页数恢复到保存时的值、`.dep-float` 浮层仍在、第 0 页标题字号与保存前一致(结构 + 内联编辑整卷还原)。重载后再进编辑模式,状态不再是 `.dep-dirty`(干净快照)。
- **不污染产物**:`#deckTrack.cloneNode(true)` 里无 `#depSaveBox`(保存框挂在 body,不进导出/投影快照)。
- **元记录带 docSig**:`deckeditplusmeta:` 记录含 `sig` 字段。
- **逃生口(v3.7:清除按钮已移除,改用 `?depfresh`)**:带 `?depfresh=1` 重开后 `deckeditplusmeta:` 键消失、IDB 快照行清零、页数回到原始 3 页(`clearFull(true)` 启动早期静默清 + 跳过还原)。
- **大快照 save/restore(正面复现 14.3MB bug)**:干净态下往第 0 页注入一张 **~6MB** data-URI `<img data-bigprobe>`(远超 localStorage ~5MB),点保存——断言**保存成功**(状态翻 `.dep-saved`,不再报「超出 5MB 上限」)、大快照落 IDB 而非 localStorage;重载后断言 `#deckTrack img[data-bigprobe]` **被还原**且其 `src` 仍是多 MB data URI(证明 >5MB 的 HTML 完整走 IDB round-trip)。
- **陈旧 sig 免疫**:保存后把 `deckeditplusmeta:` 的 `sig` 与 IDB 快照行的 `sig`/`html` 都篡改为 `__bogus_sig__`/伪造 2 页,重载后仍显示原始 3 页(sig 不匹配→忽略伪造快照,不误还原)。
> 实现:`saveFull()` 先把字号/图片桶即时落盘,取 `sanitizedTrackHTML()`(收起增强层→克隆 track→剔除 contenteditable)+ 时间戳 + `sig:docSig` 打包 `payload`,**写进 IndexedDB**(`idbPut(fullKey,payload)`,`fullKey='deckeditplusfull:'+docSig`);同步写一条几十字节的 `metaKey='deckeditplusmeta:'+docSig`={ts,cur,sig,len} 到 localStorage 供启动判定;硬顶抬到 200MB(纯防内联图片失控)。启动 `fullMeta()`(同步)判定有无快照并回显「已保存」,`restoreFullAsync()`(异步 `idbGet`)取回大 HTML,命中且 `sig===docSig`(且非 `present=speaker`)才整段替换 `track.innerHTML` 后 `refreshNav()`,随后 `applyStoredFonts/Imgs+hydrateFloats+markZoomable` 复活并 `replayDeco`+重跑 count-up(统一在 `revive()` 里)。`clearFull()` 删 IDB 行(`idbDel`)+meta+draft。向后兼容:≤3.3 的 localStorage 快照仍只读回退;IDB/Promise 不可用时退回 localStorage(受 ~5MB 顶)。`markDirty()` 挂在 `persist()`/`pushHist()`/`addPage`/`deletePage`/`reorder` 上,保存时清零。
> **测试基座(健壮化)**:本脚本对存储做多轮保存/还原,受限沙箱里 headless Chromium 反复整页重载易整进程崩溃(`TargetClosedError`)。脚本用**持久化磁盘 profile**(`launch_persistent_context`)承载 localStorage+IDB + `--disable-dev-shm-usage` 等旗标,`reload()` 用**硬重载**(先 `ctx.close()` 把 leveldb/IDB 落盘再重启导航),`poll()` 等异步 IDB 保存/还原到位,并在 goto 层做崩溃自愈重试——使所有断言在崩溃噪声下仍确定性通过。


## 14. 复制页跨页文字串档回归(scripts/verify_editor_dupedit.py · v3.5)
针对用户反馈「改『方案细节1』第一张卡片下面的正文,『方案细节2』同位正文也被删——明明是两个页面」的 bug#7 回归。根因:宿主生成器**自己的**内容持久化 id(`data-edt` 文字 / `data-edimg` 图位)是宿主 `collect()`/`load()` 在 localStorage 里的存取键、且**无页命名空间**;`复制本页`用 `cloneNode` 把这些 id 原样拷走 → 两页共用同一批 id → 宿主按 id 回写文字时覆盖/清空了另一页同位文字。用**真实 detail-page fixture** `real_deck.edit.html`(current host,含 `.fpoint` 卡片)运行,断言 `v=="3.7"`、清 localStorage、进编辑模式,定位首个含可编辑文字(`.fpoint .d,.card .d,.rcard .d,[data-edt]`)的内容页并 `复制本页`:
- **A 存储键零共享**:复制页与源页之间 `data-edt`、`data-edimg` **共享 id 数均为 0**;复制页自身仍保有 ≥1 个可编辑节点;全文档所有 `data-edt` **全局两两唯一**(无跨页碰撞)。这验证 `addPage→reidHostEdit(clone)` 已给复制页的宿主 id 现铸全新唯一值。
- **B 功能面回写不串档**:在页内模拟宿主 `collect()`(按 `data-edt` 收全量 `texts[id]=innerHTML`)→`load()`(回灌到所有同 id 节点)。先把源页第一处正文改成 `SRC-PAGE-EDITED`,跑完 round-trip 后断言:源页改动生效、**复制页同位文字保持不变**、源/复制页同位节点 `data-edt` 不同。旧实现下复制页会被覆盖成源页文字,故此用例正面复现并锁死 bug#7。
> 实现:`addPage` 复制页时,除重铸我方 `data-deppg` 页身份外,新增 `reidHostEdit(clone)`——遍历复制页内所有带 `data-edt`/`data-edimg` 的节点,分别改写为 `dup<stamp>-<i>` / `dupi<stamp>-<i>`,`stamp=hash(seq|时间戳|Math.random())` 保证全局唯一,使复制页与源页在宿主存储层彻底解耦。


## 15. 深化内容指纹 + 打开即清缓存(scripts/verify_editor_freshsig.py · bug#8 · v3.6)
针对用户反馈「①同一 HTML 无痕模式与正常模式展示不一致 ②最后一页信息保存+退出编辑再导出 HTML 没有变化」的**同根因**回归。根因:`docSig` 旧实现只采样首页标题 + 首个 `data-edt`,**非首页(尤其最后一页)**文字改动不改指纹;导出产物虽已烘进新内容,但重开时旧缓存快照(共用同一把 key、`sig===docSig`)整段还原**覆盖了文件自带新内容**——正常模式吃旧缓存、无痕模式无缓存,故两者不一致。用真实 detail-page fixture `real_deck.edit.html`(含最后一页 `.fpoint` 卡片底部 `data-depce` 文字),先断言 `v=="3.7"`、清干净态,进编辑模式到最后一页编辑 `data-depce` 节点:
- **A 正常存/取不回归**:编辑最后一页 depce 文字为 `V1` → 点全量保存 → 硬重载,轮询断言最后一页恢复出 `V1`(同会话保存/还原闭环仍正常)。
- **B 导出反映新编辑**:再把最后一页 live 改成 `V2`(**不点我方保存**)→ 退出编辑 → 点宿主 `#deckExport`,`URL.createObjectURL` 钩子抓下导出文本;断言导出含 `V2`、**不含**旧快照 `V1`。
- **C 旧缓存不再遮蔽新文件(核心)**:把导出文本写盘为新文件,在**同一 profile(IDB 里仍留着 V1 快照)**里重开它;断言最后一页显示其**自带 `V2`**、而非旧快照 `V1`。这正面复现并锁死 bug#8——旧实现此处会显示 `V1`。
- **D `?depfresh=1` 打开即清缓存**:先确认不带参重开原 fixture 仍被旧缓存还原成 `V1`;再带 `?depfresh=1` 重开,断言最后一页显示底稿(**无** `V1`)、`deckeditplusmeta:` 元记录被清空。
> 实现:①`deckSig()` 改采样每一页稳定文本——`frameText()` 用 `TreeWalker` 只遍历文本节点拼接、跳过 count-up(`data-to`)节点的 live 文本改用其终值(跨重载稳定)、不克隆 DOM 故不复制内联大图;`hash(title|n||page0文本||page1文本…)`,`n` 仍取 raw 首屏页数(保 RC1)。任意页文字一变即换 key,旧快照自然失配。②`wantFresh()` 匹配 `?depfresh` / `#depfresh`,启动早期 `clearFull(true)`(静默删本文档 full/meta/store 键 + IDB 行)并跳过还原 `revive(false)`;`clearFull(silent)` 加静默参(v3.7 起清缓存只经此 `?depfresh` 路径触发,已无手动按钮)。测试用持久化 profile + 崩溃自愈,断言确定性通过。

## 16. 渐变裁字编辑态获焦不消失(scripts/verify_editor_gradfix.py · v3.7)
针对用户反馈「①团队模块标题、②痛点大数字 01/02/03/04,编辑模式点一下文字就消失、点别处又出现」。根因:这些元素用 `-webkit-background-clip:text`+`-webkit-text-fill-color:transparent` 靠裁剪渐变绘制字形;编辑态被 `contenteditable`+光标激活时 Chromium 漏重绘透明填充字形 → 整块消失。用 current-host fixture `real_deck.edit.html`(编辑器完整初始化、含渐变裁字),进编辑模式后自动定位首个「裁字=text 且填充透明」的元素(打 `data-gctest`),断言:
- **获焦前**:`-webkit-text-fill-color` 为透明(`rgba(...,0)`/`transparent`)——渐变观感在。
- **获焦时**:`contenteditable`+`focus`+光标后,元素被打上 `.dep-gradedit`,且 `-webkit-text-fill-color` 翻成**实心 currentColor**(非透明)——逼一次完整重绘,文字不再消失。
- **失焦后**:焦点移出后 `.dep-gradedit` 被摘、填充回到透明——未编辑的标题保留渐变观感。
> 实现:JS 在捕获阶段 `focusin` 用 `gradAncestor()` 沿目标向上找「裁字+透明填充」的渐变祖先(限页面根内、排除增强 UI),命中即加 `.dep-gradedit`;`focusout` 若焦点未落在同元素内则摘类。CSS 规则仅 `body.deck-editing` 作用域,强制 `-webkit-text-fill-color:currentColor`+`background-clip:initial`+`background:none`。模板无关(不认具体类名),任意渐变裁字获焦即受保护;仅编辑态生效,不进导出产物。**注**:该测试须跑在 current-host fixture(有 `window.__deck`,编辑器主体才会注册 `focusin` 监听);old-host deck(无 `window.__deck`)编辑器只设 `{v}` 不初始化,不适用。



