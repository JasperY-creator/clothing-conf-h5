from playwright.sync_api import sync_playwright
import pathlib, json, sys
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.goto(url); pg.wait_for_timeout(1300)
    pg.evaluate("() => { var e=document.getElementById('deckEdit'); if(e) e.click(); }")
    pg.wait_for_timeout(300)
    pg.evaluate("() => { window.__deck && window.__deck.go && window.__deck.go(1); }")
    # bug#6:翻页入场动效改为「滑入到位(transitionend ~.55s)后才重放」。故 go(1) 触发的
    # 到位重放会在约 550–660ms 后发生、再播 0.5s 入场,约 1.2s 才完全落定。本测试后续会
    # 「施加动效→固定 750ms→断言已完全就位」;若不先等到位重放播完,它会正好落在测量窗口里
    # 把 .stat 的动效重启,导致误判为「未完全就位」。故此处等足到位重放,先让页面静止再操作
    # (与真实使用一致:页面滑到位后用户才会去改动效)。
    pg.wait_for_timeout(1300)

    # --- Issue 1: newly-added IMAGE float's ✕/± buttons are NOT clipped away ---
    img = pg.evaluate(r"""() => {
      var bar=document.getElementById('depBar');
      bar.querySelectorAll('button')[5].click(); // +image
      var fl=document.querySelector('.dep-float.dep-img');
      var box=fl.querySelector('.dep-imgbox');
      var elx=fl.querySelector('.dep-elx'), sc=fl.querySelector('.dep-scaler');
      function R(n){var r=n.getBoundingClientRect();return {l:r.left,t:r.top,r:r.right,bo:r.bottom,w:r.width,h:r.height};}
      var fr=R(fl), er=R(elx), sr=R(sc);
      return {
        floatOverflow:getComputedStyle(fl).overflow,     // must NOT be hidden
        boxOverflow:getComputedStyle(box).overflow,       // inner box clips image
        elxDisplay:getComputedStyle(elx).display,
        scDisplay:getComputedStyle(sc).display,
        elxSized: er.w>0 && er.h>0,
        scSized: sr.w>0 && sr.h>0,
        // buttons deliberately sit outside the float box (negative offsets)
        elxOutside: er.t < fr.t && er.r > fr.r,
        scOutside: sr.bo > fr.bo
      };
    }""")
    print("issue1 img buttons:", json.dumps(img, ensure_ascii=False))
    assert img["floatOverflow"] != "hidden", "img float must NOT clip (overflow!=hidden) so ✕/± render"
    assert img["boxOverflow"] == "hidden", "inner .dep-imgbox still clips the image"
    assert img["elxDisplay"] != "none" and img["scDisplay"] != "none", "delete/scaler controls displayed"
    assert img["elxSized"] and img["scSized"], "control buttons have real size"
    assert img["elxOutside"] and img["scOutside"], "buttons sit outside box (would be clipped by overflow:hidden)"

    # --- Issue 2a: clicking a card NUMBER animates the WHOLE card, our class beats host mcCardIn ---
    num = pg.evaluate(r"""() => {
      var numv=document.querySelector('.num .v') || document.querySelector('.num');
      numv.click();
      var deco=document.getElementById('depDeco');
      deco.querySelectorAll('.dep-anb')[0].click(); // rise
      var num=document.querySelector('.num');
      var stat=num.closest('.stat');
      return {
        statHasRise:stat.classList.contains('dep-anim-rise'),
        statAnim:getComputedStyle(stat).animationName,     // our depRiseIn, overriding host mcCardIn
        numHasAnim:num.classList.contains('dep-anim-rise'), // child must NOT be animated
        capIsCard:/卡片整体/.test(deco.querySelector('.dep-cap').textContent)
      };
    }""")
    print("issue2a card-from-number:", json.dumps(num, ensure_ascii=False))
    assert num["capIsCard"], "clicking a number targets 卡片整体 (no per-number animation)"
    assert num["statHasRise"] and num["statAnim"] == "depRiseIn", "whole card gets our effective rise anim (beats host mcCardIn)"
    assert not num["numHasAnim"], "the .num child must NOT carry an animation class"

    # --- Issue 2b: animating a card is idempotent & stable (no text-disappear / no residual shift) ---
    card = pg.evaluate(r"""() => {
      var stat=document.querySelector('.stat');
      stat.click();
      var deco=document.getElementById('depDeco');
      deco.querySelectorAll('.dep-anb')[2].click(); // zoom on whole card
      return {
        hasZoom:stat.classList.contains('dep-anim-zoom'),
        animName:getComputedStyle(stat).animationName,
        noHostOff:!stat.classList.contains('dep-hostoff')   // hostoff mechanism retired
      };
    }""")
    print("issue2b card anim:", json.dumps(card, ensure_ascii=False))
    assert card["hasZoom"], "whole-card zoom applied"
    assert card["animName"] == "depZoomIn", "card computed animation is our keyframe, not host/none"
    assert card["noHostOff"], "dep-hostoff no longer applied under card-only model"

    # --- Issue 2d: every anim (incl. 淡入/无) settles VISIBLE (opacity:1) & not shifted ---
    # host card base is opacity:0 + translateY(16px); anim must reveal+seat it, never leave it hidden/shifted
    def settle_anim(i):
        pg.evaluate(r"""(i)=>{document.querySelector('.stat').click();
          document.getElementById('depDeco').querySelectorAll('.dep-anb')[i].click();}""", i)
        pg.wait_for_timeout(750)
        return pg.evaluate(r"""()=>{var c=getComputedStyle(document.querySelector('.stat'));
          return {op:c.opacity, tf:c.transform};}""")
    ends = {"rise": settle_anim(0), "fade": settle_anim(1), "zoom": settle_anim(2), "none": settle_anim(3)}
    print("issue2d anim end-states:", json.dumps(ends, ensure_ascii=False))
    for k, v in ends.items():
        assert abs(float(v["op"]) - 1.0) < 0.01, k + " must settle fully visible (opacity 1), not host base opacity:0"
        # transform must be identity (matrix(1,0,0,1,0,0)) or none — never a residual translateY
        assert v["tf"] in ("none", "matrix(1, 0, 0, 1, 0, 0)"), k + " must settle un-shifted (no residual translateY)"

    # --- Issue 2c: newly-added card animation lands on inner .dep-fanim and is effective ---
    added = pg.evaluate(r"""() => {
      var bar=document.getElementById('depBar');
      bar.querySelectorAll('button')[4].click(); // +card
      var fc=document.querySelector('.dep-float.dep-card');
      fc.click();
      document.getElementById('depDeco').querySelectorAll('.dep-anb')[0].click(); // rise
      var inner=fc.querySelector('.dep-fanim');
      return {innerHasRise:inner.classList.contains('dep-anim-rise'),
              innerAnim:getComputedStyle(inner).animationName,
              outerHasRise:fc.classList.contains('dep-anim-rise')};
    }""")
    print("issue2c added card:", json.dumps(added, ensure_ascii=False))
    assert added["innerHasRise"] and added["innerAnim"] == "depRiseIn", "added-card anim effective on inner .dep-fanim"
    assert not added["outerHasRise"], "anim must NOT go on scaled outer .dep-float"

    # --- export固化: card anim class + img float survive documentElement clone ---
    exp = pg.evaluate(r"""() => {
      var stat=document.querySelector('.stat');
      stat.click();
      document.getElementById('depDeco').querySelectorAll('.dep-anb')[0].click(); // rise on card
      var clone=document.documentElement.cloneNode(true);
      return {animInClone:clone.querySelectorAll('.dep-anim-rise,.dep-anim-zoom,.dep-anim-fade').length,
              imgFloatInClone:clone.querySelectorAll('.dep-float.dep-img').length};
    }""")
    print("export clone:", json.dumps(exp, ensure_ascii=False))
    assert exp["animInClone"] >= 1, "card anim class固化 in export clone"

    print("V2.0-FIX ASSERTIONS PASSED")
    b.close()
