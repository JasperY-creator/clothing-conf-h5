from playwright.sync_api import sync_playwright
import pathlib, json, sys
# 真实双窗回归(bug#1 同步 + bug#3 投屏动效),跑真 Shift+P → launchProjector → window.open。
# 这是把「双屏同步」从『只验 blob 内容』升级为『验真实跨窗 postMessage 同步』的权威回归——
# 之前只验 blob 帧数,漏掉了 blob:null 跨源导致 BroadcastChannel/localStorage 同步被切断的回归。
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    ctx = b.new_context(viewport={"width": 1280, "height": 720})
    proj = ctx.new_page()
    proj.goto(url); proj.wait_for_timeout(1200)

    # edit → blank page → card → rise anim → exit edit
    proj.evaluate("()=>{document.getElementById('deckEdit').click();}"); proj.wait_for_timeout(250)
    proj.evaluate("()=>{document.getElementById('depBar').querySelectorAll('button')[1].click();}"); proj.wait_for_timeout(250)
    total = proj.evaluate("()=>window.__deck.total")
    proj.evaluate("(n)=>{window.__deck.go(n-1);}", total); proj.wait_for_timeout(200)
    cardPage = proj.evaluate("()=>window.__deck.cur()")
    proj.evaluate("()=>{document.getElementById('depBar').querySelectorAll('button')[4].click();}"); proj.wait_for_timeout(200)
    proj.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      f.querySelector('.dep-float.dep-card').click();
      document.getElementById('depDeco').querySelectorAll('.dep-anb')[0].click();}"""); proj.wait_for_timeout(300)
    proj.evaluate(r"""()=>{var f=window.__deck.frames[%d];
      var inner=f.querySelector('.dep-float.dep-card .dep-fanim');
      window.__animStarts=0; if(inner)inner.addEventListener('animationstart',function(){window.__animStarts++;});}""" % cardPage)
    proj.evaluate("()=>{document.getElementById('deckEdit').click();}"); proj.wait_for_timeout(300)
    totalAfter = proj.evaluate("()=>window.__deck.total")
    assert totalAfter == total, "blank page persisted after exiting edit"

    startsBefore = proj.evaluate("()=>window.__animStarts")
    # REAL Shift+P
    with proj.expect_popup(timeout=6000) as pop:
        proj.click("#deckPresent", modifiers=["Shift"])
    speaker = pop.value
    speaker.wait_for_timeout(1300)
    proj.wait_for_timeout(500)

    # BUG#3: projector (main window, in-place deck-projecting) replayed current card page's animation
    startsAfter = proj.evaluate("()=>window.__animStarts")
    print("bug3 animStarts before/after present:", startsBefore, startsAfter)
    assert startsAfter > startsBefore, "projector replayed current-page float-card animation on entering projection"

    # speaker carries the added page (blob = live DOM)
    sp_total = speaker.evaluate("()=>window.__deck?window.__deck.total:-1")
    print("bug1 speaker total:", sp_total, "main total:", totalAfter)
    assert sp_total == totalAfter, "speaker window has same (added) frame count as projector"

    # BUG#1: real cross-window sync, BOTH directions (postMessage bridge across file:// <-> blob:null)
    proj.evaluate("()=>window.__deck.go(0)"); proj.wait_for_timeout(600)
    assert speaker.evaluate("()=>window.__deck.cur()") == 0, "speaker followed projector.go(0)"
    speaker.evaluate("(t)=>window.__deck.go(t)", cardPage); speaker.wait_for_timeout(600)
    assert proj.evaluate("()=>window.__deck.cur()") == cardPage, "projector followed speaker.go(cardPage)"
    print("bug1 bidirectional sync: OK")

    print("DUALSYNC-LIVE (bug1 sync + bug3 projector anim) PASSED")
    b.close()
