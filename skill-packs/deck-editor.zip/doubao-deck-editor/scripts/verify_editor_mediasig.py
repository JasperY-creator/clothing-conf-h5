from playwright.sync_api import sync_playwright
import pathlib, sys, re, tempfile, shutil

# Regression for bug#8-B (v3.11): "same HTML shows different content in normal vs incognito".
# Root cause: the content fingerprint (compute_baked_sig / deckSig+frameText) hashed only VISIBLE
# TEXT and was blind to images. Two decks with identical text but DIFFERENT images collided on the
# same BAKED_SIG, so a cached snapshot saved for deck A got restored (track.innerHTML=snap.html) for
# deck B in NORMAL mode, masking B's real content — while incognito (no cache) showed B's true file.
# Fix: fold a per-image digest (img src / svg <image> href / style background url) into the
# fingerprint on BOTH the Python (baked) and JS (runtime) sides, so image-only differences yield a
# distinct key and a cross-deck cached snapshot can never mask the file's own content.
#
# This test bakes two variant files A and B: IDENTICAL text, DIFFERENT hero image. It seeds a saved
# snapshot for A (persistent profile == "normal browser"), then opens B in the SAME profile and
# asserts B shows B's own image (no masking). It also opens B in a FRESH profile ("incognito") and
# asserts the two renderings are IDENTICAL.

INJ = pathlib.Path(__file__).resolve().parent / "inject_editor.py"
SRC = sys.argv[1] if len(sys.argv) > 1 else "/home/mira/.session/427569162003/problem_deck.v39c.html"
LAUNCH = ["--disable-dev-shm-usage", "--no-sandbox", "--disable-gpu"]

fails = []
def ck(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  <<< " + str(extra)))
    if not cond: fails.append(name)

import subprocess
def inject(inp, out):
    r = subprocess.run([sys.executable, str(INJ), inp, "-o", out], capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    return out

def baked(path):
    t = pathlib.Path(path).read_text(encoding="utf-8")
    m = re.search(r"var BAKED_SIG='([^']*)';", t)
    return m.group(1) if m else None

def first_img_src(path):
    t = pathlib.Path(path).read_text(encoding="utf-8")
    m = re.search(r'<img\b[^>]*?\ssrc="([^"]{20,})"', t)
    return m.group(1) if m else None

with sync_playwright() as p:
    work = tempfile.mkdtemp(prefix="mediasig_")
    prof = tempfile.mkdtemp(prefix="mediasig_prof_")
    try:
        host = pathlib.Path(SRC).read_text(encoding="utf-8")
        # strip any prior injection to get a clean host, then create two image-different variants
        b, e = "<!-- doubao-deck-editor:begin -->", "<!-- doubao-deck-editor:end -->"
        if b in host and e in host:
            host = host.split(b, 1)[0] + host.split(e, 1)[1]

        # unique markers baked into the FIRST img src so we can tell A's image from B's on screen
        m = re.search(r'(<img\b[^>]*?\ssrc=")([^"]{20,})(")', host)
        assert m, "fixture must contain an inline <img src>"
        base_src = m.group(2)
        hostA = host[:m.start(2)] + base_src + "#IMG_A" + host[m.end(2):]
        hostB = host[:m.start(2)] + base_src + "#IMG_B" + host[m.end(2):]
        rawA = str(pathlib.Path(work) / "deckA.html"); pathlib.Path(rawA).write_text(hostA, encoding="utf-8")
        rawB = str(pathlib.Path(work) / "deckB.html"); pathlib.Path(rawB).write_text(hostB, encoding="utf-8")
        A = inject(rawA, str(pathlib.Path(work) / "deckA.edit.html"))
        B = inject(rawB, str(pathlib.Path(work) / "deckB.edit.html"))

        sigA, sigB = baked(A), baked(B)
        print("baked A:", sigA, " baked B:", sigB)
        ck("image-only-diff decks get DISTINCT baked sig (no collision)", sigA and sigB and sigA != sigB, (sigA, sigB))

        urlA = "file://" + str(pathlib.Path(A).resolve())
        urlB = "file://" + str(pathlib.Path(B).resolve())

        def open_ctx(url, wait=1400):
            ctx = p.chromium.launch_persistent_context(prof, headless=True, args=LAUNCH, viewport={"width":1280,"height":720})
            pg = ctx.pages[0] if ctx.pages else ctx.new_page()
            pg.on("dialog", lambda d: d.accept())
            pg.goto(url, wait_until="load"); pg.wait_for_timeout(wait)
            return ctx, pg

        def shown_first_img(pg):
            return pg.evaluate("()=>{var i=document.querySelector('#deckTrack img[src]');return i?i.getAttribute('src'):null;}")

        # --- SESSION 1 (normal browser): open A, save a full snapshot into the persistent profile ---
        ctx, pg = open_ctx(urlA)
        ck("version is 3.11", pg.evaluate("()=>window.__deckEditorPlus&&window.__deckEditorPlus.v") == "3.11")
        pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(250)
        pg.evaluate("()=>{var b=document.querySelector('#depSaveBox .dep-savebtn');if(b)b.click();}")
        pg.wait_for_timeout(1200)
        imgA = shown_first_img(pg)
        ck("A shows A's own image", imgA and imgA.endswith("#IMG_A"), imgA)
        ctx.close()

        # --- SESSION 2 (SAME profile == normal browser, cache present): open B ---
        ctx, pg = open_ctx(urlB)
        pg.wait_for_timeout(1200)
        imgB_normal = shown_first_img(pg)
        ck("B in normal mode shows B's OWN image, not A's cached snapshot",
           imgB_normal and imgB_normal.endswith("#IMG_B"), imgB_normal)
        ctx.close()

        # --- FRESH profile (== incognito): open B ---
        prof2 = tempfile.mkdtemp(prefix="mediasig_incog_")
        try:
            ctx2 = p.chromium.launch_persistent_context(prof2, headless=True, args=LAUNCH, viewport={"width":1280,"height":720})
            pg2 = ctx2.pages[0] if ctx2.pages else ctx2.new_page()
            pg2.goto(urlB, wait_until="load"); pg2.wait_for_timeout(1400)
            imgB_incog = pg2.evaluate("()=>{var i=document.querySelector('#deckTrack img[src]');return i?i.getAttribute('src'):null;}")
            ctx2.close()
            ck("B in incognito shows B's own image", imgB_incog and imgB_incog.endswith("#IMG_B"), imgB_incog)
            ck("normal == incognito for the SAME file (divergence gone)", imgB_normal == imgB_incog, (imgB_normal, imgB_incog))
        finally:
            shutil.rmtree(prof2, ignore_errors=True)
    finally:
        shutil.rmtree(work, ignore_errors=True)
        shutil.rmtree(prof, ignore_errors=True)

print("\n==== " + ("ALL PASS" if not fails else ("FAILED: " + ", ".join(fails))) + " ====")
sys.exit(1 if fails else 0)
