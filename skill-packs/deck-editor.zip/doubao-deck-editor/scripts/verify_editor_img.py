from playwright.sync_api import sync_playwright
import pathlib, json, sys
_target = sys.argv[1] if len(sys.argv) > 1 else "deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(700)
    # inject a synthetic image slot into current frame, then enter edit mode
    res = pg.evaluate(r"""() => {
      var f=document.getElementById('deckTrack').children[0];
      var root=f.querySelector('.page,.cover-wrap,.cover')||f;
      var slot=document.createElement('div');
      slot.setAttribute('data-edimg','synthetic-0');
      slot.style.cssText='width:200px;height:120px;';
      var img=document.createElement('img');
      img.src='data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
      img.style.cssText='width:100%;height:100%;';
      slot.appendChild(img); root.appendChild(slot);
      // enter edit mode
      document.getElementById('deckEdit').click();
      return {armed:true};
    }""")
    pg.wait_for_timeout(300)
    info = pg.evaluate(r"""() => {
      var slot=document.querySelector('[data-edimg="synthetic-0"]');
      var img=slot.querySelector('img');
      var hasTool=!!slot.querySelector('.dep-imgtool');
      var posed=slot.classList.contains('dep-imgpos');
      var before=getComputedStyle(img).transform;
      // zoom in via + button (buttons: [-,+,reset])
      slot.querySelector('.dep-imgtool').querySelectorAll('button')[1].click();
      slot.querySelector('.dep-imgtool').querySelectorAll('button')[1].click();
      var afterZoom=getComputedStyle(img).transform;
      // simulate drag via internal store: dispatch mousedown/move/up
      var r=slot.getBoundingClientRect();
      slot.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,clientX:r.left+10,clientY:r.top+10}));
      document.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:r.left+40,clientY:r.top+30}));
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      var afterDrag=getComputedStyle(img).transform;
      return {hasTool:hasTool,posed:posed,before:before,afterZoom:afterZoom,afterDrag:afterDrag};
    }""")
    print(json.dumps(info,ensure_ascii=False))
    assert info["hasTool"] and info["posed"], "slot should be armed with tool + pos class"
    assert info["afterZoom"]!="none" and info["afterZoom"]!=info["before"], "zoom should apply transform"
    assert info["afterDrag"]!=info["afterZoom"], "drag should further change transform"
    print("IMG ASSERTIONS PASSED")
    b.close()
