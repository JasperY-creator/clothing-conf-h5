from playwright.sync_api import sync_playwright
import pathlib, json, sys
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.goto(url); pg.wait_for_timeout(1400)
    pg.evaluate("() => { var e=document.getElementById('deckEdit'); if(e) e.click(); }")
    pg.wait_for_timeout(300)
    pg.evaluate("() => { window.__deck && window.__deck.go && window.__deck.go(1); }")
    pg.wait_for_timeout(250)

    # --- (user request) animation ALWAYS targets the whole card, never text/number sub-blocks ---
    kinds = pg.evaluate(r"""() => {
      var out={};
      var deco=document.getElementById('depDeco');
      var cap=deco.querySelector('.dep-cap');
      // clicking the card container -> 卡片整体
      var stat=document.querySelector('.stat');
      stat.click();
      out.cardCap=cap.textContent;
      out.cardKindCard=/卡片整体/.test(cap.textContent);
      // clicking a number MUST still resolve to the whole card (no 数字 target anymore)
      var num=document.querySelector('.num');
      if(num){ num.click(); out.numCap=cap.textContent; out.numIsCard=/卡片整体/.test(cap.textContent); }
      // clicking a text sub-block MUST also resolve to the whole card (no 文字 target anymore)
      var txt=document.querySelector('.stat .d, .stat .t');
      if(txt){ txt.click(); out.txtCap=cap.textContent; out.txtIsCard=/卡片整体/.test(cap.textContent); }
      return out;
    }""")
    print("kinds:", json.dumps(kinds, ensure_ascii=False))
    assert kinds.get("cardKindCard"), "clicking card body => 卡片整体"
    assert kinds.get("numIsCard"), "clicking number must resolve to 卡片整体 (no per-number target)"
    assert kinds.get("txtIsCard"), "clicking card text must resolve to 卡片整体 (no per-text target)"

    # --- animation ALWAYS lands on the card container (.stat), never on .num/text child ---
    targets = pg.evaluate(r"""() => {
      var deco=document.getElementById('depDeco');
      var num=document.querySelector('.num');
      var stat=num.closest('.stat');
      num.click();                              // click the number
      deco.querySelectorAll('.dep-anb')[2].click(); // zoom
      var numHasZoom=num.classList.contains('dep-anim-zoom');
      var statHasZoom=stat.classList.contains('dep-anim-zoom');
      var childAnim=stat.querySelector('.num.dep-anim-zoom,.d.dep-anim-zoom,.t.dep-anim-zoom');
      return {numHasZoom:numHasZoom, statHasZoom:statHasZoom, hasChildAnim:!!childAnim};
    }""")
    print("targets:", json.dumps(targets, ensure_ascii=False))
    assert targets["statHasZoom"] and not targets["numHasZoom"], "anim must land on whole card (.stat), not the .num child"
    assert not targets["hasChildAnim"], "no text/number sub-block should carry an animation class"

    # --- caption回显 current anim ---
    echo = pg.evaluate(r"""() => {
      var deco=document.getElementById('depDeco');
      var cap=deco.querySelector('.dep-cap');
      var stat=document.querySelector('.stat');
      stat.click();
      deco.querySelectorAll('.dep-anb')[0].click(); // rise
      var capText=cap.textContent;
      // active button highlight
      var on=deco.querySelector('.dep-anb.dep-on');
      return {cap:capText, riseInCap:/上浮/.test(capText), onBtn: on?on.getAttribute('data-depanb'):null};
    }""")
    print("echo:", json.dumps(echo, ensure_ascii=False))
    assert echo["riseInCap"], "caption reflects current anim 上浮"
    assert echo["onBtn"]=="rise", "current anim button highlighted"

    # --- EDIT MODE: count-up must NOT restart/clobber on nav (protects in-place number edits) ---
    # (In presentation mode the every-visit replay still fires — verified further below.)
    replay = pg.evaluate(r"""() => {
      var deco=document.getElementById('depDeco');
      var num=document.querySelector('.num');
      var v=num.querySelector('.v[data-to]');
      // give the number a rise anim
      num.click();
      deco.querySelectorAll('.dep-anb')[0].click(); // rise on number
      // navigate away then back, sample the .v text right after nav
      window.__deck.go(0);
      window.__deck.go(1);
      var immediate = v ? v.textContent : null;
      return {hasV: !!v, dataTo: v?v.getAttribute('data-to'):null, immediate:immediate};
    }""")
    pg.wait_for_timeout(1200)
    settled = pg.evaluate(r"""() => {
      var v=document.querySelector('.num .v[data-to]');
      return v?v.textContent:null;
    }""")
    print("replay(edit):", json.dumps(replay, ensure_ascii=False), "settled:", settled)
    assert replay["hasV"], "number with data-to exists"
    # In edit mode the number must be STATIC at its data-to value right after nav (no count-up
    # restart that would overwrite a user's in-place edit). immediate == settled == data-to.
    assert replay["immediate"] == settled, "edit-mode number must be stable across nav (no clobber)"
    assert replay["immediate"] == replay["dataTo"], "edit-mode number settles to its data-to value"


    # --- replay also fires in NON-edit (presentation) mode ---
    pres = pg.evaluate(r"""() => {
      // ensure page index 1's own card carries a rise anim (self-contained, page-scoped)
      var scope=document.querySelectorAll('#deckTrack > *')[1];
      var card=scope.querySelector('.stat,.card,.fpoint,.rcard,.impact .card');
      if(card){
        card.click();
        var deco=document.getElementById('depDeco');
        deco.querySelectorAll('.dep-anb')[0].click(); // rise
      }
      // exit edit mode
      var e=document.getElementById('deckEdit'); if(e && document.body.classList.contains('deck-editing')) e.click();
      var anim=scope.querySelector('.dep-anim-rise');
      window.__deck.go(0);
      window.__deck.go(1);
      // right after nav the anim class should still be present and (re)applied
      return {editing:document.body.classList.contains('deck-editing'),
              hadAnim: !!anim,
              animStillThere: !!scope.querySelector('.dep-anim-rise'),
              name: anim?getComputedStyle(anim).animationName:null};
    }""")
    print("presentation:", json.dumps(pres, ensure_ascii=False))
    assert not pres["editing"], "should be in presentation mode"
    assert pres["hadAnim"], "page-1 card got a rise anim class in edit mode"
    assert pres["animStillThere"], "anim class persists across edit->present"

    print("ANIM-UX ASSERTIONS PASSED")
    b.close()
