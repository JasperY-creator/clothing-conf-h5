from playwright.sync_api import sync_playwright
import pathlib, sys
# v2.8 —— PPT 增量能力回归(需求2:第一/第二梯队 8 项)
#  1 撤销/重做  2 复制/粘贴/删除  3 文字加粗/斜体/下划线/对齐  4 层级 z-order
#  5 对齐/分布/吸附  6 多选+成组/解组  7 形状(矩形/圆/线/箭头)  8 项目符号/编号列表
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())

def enter_edit(pg):
    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(200)
    # 到内容页(非封面),浮层才能落在带 .content/.deck-scale 的根上
    pg.evaluate("()=>window.__deck.go(1)"); pg.wait_for_timeout(150)

def count_floats(pg):
    return pg.evaluate("()=>window.__deck.frames[window.__deck.cur()].querySelectorAll('.dep-float').length")

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(900)
    assert pg.evaluate("()=>!!window.__deckEditorPlus"), "enhancement layer must exist"
    assert pg.evaluate("()=>window.__deckEditorPlus.v")=="3.11", "version must be 3.11"

    enter_edit(pg)

    # ---------- 7) 形状:矩形/圆/线/箭头 ----------
    def top_btn(label):
        return pg.evaluate("""(lab)=>{var bs=document.querySelectorAll('#depBar button');
          for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf(lab)>=0){bs[i].click();return true;}}return false;}""", label)
    n0 = count_floats(pg)
    assert top_btn("矩形"), "▭矩形 button must exist"
    pg.wait_for_timeout(80)
    assert top_btn("圆"), "◯圆 button"; pg.wait_for_timeout(80)
    assert top_btn("线"), "／线 button"; pg.wait_for_timeout(80)
    assert top_btn("箭头"), "➔箭头 button"; pg.wait_for_timeout(120)
    shapes = pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      return {rect:f.querySelectorAll('.dep-shape.dep-rect').length,
              ell:f.querySelectorAll('.dep-shape.dep-ellipse').length,
              line:f.querySelectorAll('.dep-shape.dep-line').length,
              arr:f.querySelectorAll('.dep-shape.dep-arrow').length};}""")
    print("7) shapes:", shapes)
    assert shapes["rect"]>=1 and shapes["ell"]>=1 and shapes["line"]>=1 and shapes["arr"]>=1, "all 4 shapes created"

    # 形状填充色板(选中一个形状即出现 #depShape,含 .dep-cw 色块;点色块改 --dep-fill)
    fillres = pg.evaluate(r"""()=>{
      var f=window.__deck.frames[window.__deck.cur()];
      var s=f.querySelector('.dep-shape.dep-rect');
      window.__deckEditorPlus; // noop
      s.dispatchEvent(new MouseEvent('mousedown',{bubbles:true}));
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      var bar=document.getElementById('depShape');
      var shown=bar&&!bar.classList.contains('dep-hidden');
      var sw=bar.querySelector('.dep-cw');
      var before=s.style.getPropertyValue('--dep-fill');
      if(sw)sw.click();
      var after=s.style.getPropertyValue('--dep-fill');
      return {shown:!!shown,before:before,after:after};}""")
    print("   fill swatch:", fillres)
    assert fillres["shown"], "#depShape bar must show when a shape is selected"
    assert fillres["after"] and fillres["after"]!=fillres["before"], "clicking swatch must set --dep-fill"

    # ---------- 4) 层级 z-order(置顶/置底) ----------
    z = pg.evaluate(r"""()=>{
      var f=window.__deck.frames[window.__deck.cur()];
      var s=f.querySelector('.dep-shape.dep-rect');
      var P=window.__deckEditorPlus;
      s.dispatchEvent(new MouseEvent('mousedown',{bubbles:true}));document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      function clk(t){var bs=document.querySelectorAll('#depShape button');for(var i=0;i<bs.length;i++){if(bs[i].title===t){bs[i].click();return;}}}
      clk('置顶'); var zf=parseInt(s.style.zIndex,10);
      clk('置底'); var zb=parseInt(s.style.zIndex,10);
      return {front:zf,back:zb};}""")
    print("4) z-order:", z)
    assert z["front"]>z["back"], "front z-index must exceed back z-index"

    # ---------- 6) 多选 + 成组/解组 ----------
    grp = pg.evaluate(r"""()=>{
      var f=window.__deck.frames[window.__deck.cur()];
      var els=f.querySelectorAll('.dep-shape'); // 选前两个形状
      var a=els[0],c=els[1];
      a.dispatchEvent(new MouseEvent('mousedown',{bubbles:true}));document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      c.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,shiftKey:true}));document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      var mselCount=f.querySelectorAll('.dep-float.dep-msel').length;
      // 成组
      function clk(t){var bs=document.querySelectorAll('#depShape button');for(var i=0;i<bs.length;i++){if(bs[i].title===t){bs[i].click();return true;}}return false;}
      var gok=clk('成组');
      var groups=f.querySelectorAll('.dep-group').length;
      var kidsInGroup=f.querySelectorAll('.dep-group > .dep-float').length;
      // 解组(此时选中的是该 group)
      var uok=clk('解组');
      var groupsAfter=f.querySelectorAll('.dep-group').length;
      return {msel:mselCount,gok:gok,groups:groups,kids:kidsInGroup,uok:uok,groupsAfter:groupsAfter};}""")
    print("6) group/ungroup:", grp)
    assert grp["msel"]>=2, "shift-click must multi-select (dep-msel)"
    assert grp["groups"]==1 and grp["kids"]>=2, "group must wrap selected floats"
    assert grp["groupsAfter"]==0, "ungroup must remove the group wrapper"

    # ---------- 5) 对齐 / 分布 ----------
    aln = pg.evaluate(r"""()=>{
      var f=window.__deck.frames[window.__deck.cur()];
      var sh=f.querySelectorAll('.dep-shape');
      // 打散位置
      sh[0].style.left='100px';sh[0].style.top='100px';
      sh[1].style.left='300px';sh[1].style.top='250px';
      // 多选两个
      sh[0].dispatchEvent(new MouseEvent('mousedown',{bubbles:true}));document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      sh[1].dispatchEvent(new MouseEvent('mousedown',{bubbles:true,shiftKey:true}));document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      function clk(t){var bs=document.querySelectorAll('#depShape button');for(var i=0;i<bs.length;i++){if(bs[i].title===t){bs[i].click();return true;}}return false;}
      clk('左对齐');
      return {l0:parseFloat(sh[0].style.left),l1:parseFloat(sh[1].style.left)};}""")
    print("5) align-left:", aln)
    assert abs(aln["l0"]-aln["l1"])<0.5, "left-align must equalize left"

    # 吸附辅助线:单选拖到接近页面中心线时出现 .dep-guide 显示
    snap = pg.evaluate(r"""()=>{
      var f=window.__deck.frames[window.__deck.cur()];
      var s=f.querySelector('.dep-shape.dep-rect');
      var w=s.offsetWidth;
      // 计算把中心拖到页面竖直中心线(x=640)所需的屏幕位移
      var scaleEl=f.querySelector('.deck-scale');
      var k=scaleEl?(scaleEl.getBoundingClientRect().width/scaleEl.offsetWidth):1;
      var L0=parseFloat(s.style.left)||0;
      var targetLeft=640-w/2+2;             // 中心落在 ~640,阈值内
      var dxPage=targetLeft-L0;
      var sx=200,sy=200;
      s.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,clientX:sx,clientY:sy}));
      var mx=sx+dxPage*k, my=sy;
      document.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:mx,clientY:my}));
      var gv=document.querySelector('.dep-guide.dep-gv');
      var shown=gv&&gv.style.display!=='none';
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      var gvAfter=document.querySelector('.dep-guide.dep-gv');
      var hidden=!gvAfter||gvAfter.style.display==='none';
      return {guideShown:!!shown,left:parseFloat(s.style.left),center:(parseFloat(s.style.left)+w/2),hiddenAfterUp:!!hidden};}""")
    print("   snap guide:", snap)
    assert snap["guideShown"], "vertical snap guide must appear near page center on drag"
    assert abs(snap["center"]-640)<1.0, "shape center must snap onto x=640"
    assert snap["hiddenAfterUp"], "guides must hide on mouseup"

    # ---------- 1) 撤销/重做 ----------
    undo = pg.evaluate(r"""()=>{
      var f=window.__deck.frames[window.__deck.cur()];
      var before=f.querySelectorAll('.dep-float').length;
      // 新增一个文字浮层
      var bs=document.querySelectorAll('#depBar button');for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf('＋文字')>=0){bs[i].click();break;}}
      var afterAdd=f.querySelectorAll('.dep-float').length;
      // Ctrl+Z 撤销
      document.dispatchEvent(new KeyboardEvent('keydown',{key:'z',ctrlKey:true,bubbles:true}));
      var afterUndo=f.querySelectorAll('.dep-float').length;
      // Ctrl+Y 重做
      document.dispatchEvent(new KeyboardEvent('keydown',{key:'y',ctrlKey:true,bubbles:true}));
      var afterRedo=f.querySelectorAll('.dep-float').length;
      return {before:before,afterAdd:afterAdd,afterUndo:afterUndo,afterRedo:afterRedo};}""")
    print("1) undo/redo:", undo)
    assert undo["afterAdd"]==undo["before"]+1, "add float +1"
    assert undo["afterUndo"]==undo["before"], "Ctrl+Z must undo the add"
    assert undo["afterRedo"]==undo["before"]+1, "Ctrl+Y must redo the add"

    # ---------- 2) 复制 / 粘贴 / 删除 ----------
    cpd = pg.evaluate(r"""()=>{
      var f=window.__deck.frames[window.__deck.cur()];
      var fl=f.querySelector('.dep-shape.dep-rect');
      fl.dispatchEvent(new MouseEvent('mousedown',{bubbles:true}));document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      var before=f.querySelectorAll('.dep-float').length;
      document.dispatchEvent(new KeyboardEvent('keydown',{key:'c',ctrlKey:true,bubbles:true}));
      document.dispatchEvent(new KeyboardEvent('keydown',{key:'v',ctrlKey:true,bubbles:true}));
      var afterPaste=f.querySelectorAll('.dep-float').length;
      // 删除当前选中(粘贴后选中的是新元素)
      document.dispatchEvent(new KeyboardEvent('keydown',{key:'Delete',bubbles:true}));
      var afterDel=f.querySelectorAll('.dep-float').length;
      return {before:before,afterPaste:afterPaste,afterDel:afterDel};}""")
    print("2) copy/paste/delete:", cpd)
    assert cpd["afterPaste"]==cpd["before"]+1, "Ctrl+V must paste one copy"
    assert cpd["afterDel"]==cpd["before"], "Delete must remove the pasted float"

    # ---------- 3) 文字加粗/斜体/下划线/对齐 + 8) 列表 ----------
    # 点一段宿主文字挂 fontBar,再点格式按钮
    fmt = pg.evaluate(r"""()=>{
      var f=window.__deck.frames[window.__deck.cur()];
      var p=f.querySelector('p,.ptitle,h2,li,.stat .t');
      if(!p)return {noTarget:true};
      p.click();
      var bar=document.getElementById('depFont');
      var shown=bar&&!bar.classList.contains('dep-hidden');
      function clkFmt(k){var bs=document.querySelectorAll('#depFont .dep-fmt');for(var i=0;i<bs.length;i++){if(bs[i].getAttribute('data-depfmt')===k){bs[i].click();return true;}}return false;}
      var okB=clkFmt('bold');
      // 对齐
      clkFmt('center');
      var align=p.style.textAlign;
      // 列表
      var okUL=clkFmt('ul');
      var hasLI=f.querySelectorAll('ul li,ol li').length;
      // 粗体是否写进 DOM(execCommand 生成 <b>/<strong> 或 font-weight)
      var boldMark=(p.innerHTML||'').match(/<(b|strong)\b/i)||(p.querySelector&&p.querySelector('[style*="font-weight"]'));
      return {shown:!!shown,okB:okB,align:align,okUL:okUL,hasLI:hasLI,boldMark:!!boldMark};}""")
    print("3+8) text-format:", fmt)
    assert fmt.get("shown"), "#depFont must show on text click"
    assert fmt["okB"] and fmt["okUL"], "format buttons B / ul must exist"
    assert fmt["align"]=="center", "center align must set textAlign"

    # A-/A+/↺ 索引不变(前 3 个仍是字号按钮)—— 保护既有测试契约
    idx = pg.evaluate(r"""()=>{var bs=document.querySelectorAll('#depFont button');
      return {b0:(bs[0].textContent||'').trim(),b1:(bs[1].textContent||'').trim(),b2:(bs[2].textContent||'').trim()};}""")
    print("   font-btn index invariant:", idx)
    assert idx["b0"] and idx["b1"] and idx["b2"], "first 3 font buttons (A-/A+/reset) preserved"

    # ---------- 导出固化:形状/组类随克隆保留 ----------
    ex = pg.evaluate(r"""()=>{var c=document.documentElement.cloneNode(true);
      return {shapes:c.querySelectorAll('.dep-shape').length,
              shapeBarInClone:!!c.querySelector('#depShape')};}""")
    print("export clone:", ex)
    assert ex["shapes"]>=1, "exported clone must keep shape floats"

    print("PPT (req#2, 8 features) PASSED — undo/redo, copy/paste/del, text-format+lists, z-order, align/distribute+snap, multi-select group/ungroup, shapes")
    b.close()
