from playwright.sync_api import sync_playwright
import pathlib, json, sys

_target = sys.argv[1] if len(sys.argv) > 1 else "deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(700)

    def state():
        return pg.evaluate(r"""() => {
          const track=document.getElementById('deckTrack');
          return {
            plus: !!window.__deckEditorPlus,
            frames: track?track.children.length:-1,
            cur: (window.__deck&&window.__deck.cur)?window.__deck.cur():-1,
            barHidden: document.getElementById('depBar').classList.contains('dep-hidden'),
            railChips: document.querySelectorAll('#depRail .dep-chip').length,
            editing: document.body.classList.contains('deck-editing')
          };
        }""")

    print("00 initial:", json.dumps(state(), ensure_ascii=False))

    # enter edit mode via host #deckEdit
    pg.evaluate("() => { var e=document.getElementById('deckEdit'); if(e) e.click(); }")
    pg.wait_for_timeout(300)
    print("01 after edit-on:", json.dumps(state(), ensure_ascii=False))

    n0 = state()["frames"]
    # duplicate current page
    pg.evaluate("() => document.getElementById('depBar').querySelectorAll('button')[0].click()")
    pg.wait_for_timeout(300)
    s = state(); print("02 after duplicate:", json.dumps(s, ensure_ascii=False))
    assert s["frames"] == n0+1, "duplicate should +1 frame"
    assert s["railChips"] == n0+1, "rail chip count should track frames"

    # blank page
    pg.evaluate("() => document.getElementById('depBar').querySelectorAll('button')[1].click()")
    pg.wait_for_timeout(300)
    s = state(); print("03 after blank:", json.dumps(s, ensure_ascii=False))
    assert s["frames"] == n0+2, "blank should +1 more frame"

    # delete current page
    pg.evaluate("() => document.getElementById('depBar').querySelectorAll('button')[2].click()")
    pg.wait_for_timeout(300)
    s = state(); print("04 after delete:", json.dumps(s, ensure_ascii=False))
    assert s["frames"] == n0+1, "delete should -1 frame"

    # font bump on first data-edt of current page
    fs = pg.evaluate(r"""() => {
      var f=document.getElementById('deckTrack').children[ window.__deck.cur() ];
      var t=f.querySelector('[data-edt]'); if(!t) return null;
      t.scrollIntoView(); t.click();
      var before=getComputedStyle(t).fontSize;
      // buttons = [A-, A+, reset]; A+ is index 1
      var fb=document.getElementById('depFont');
      for(var i=0;i<3;i++) fb.querySelectorAll('button')[1].click();
      return {before:before, after:getComputedStyle(t).fontSize, id:t.getAttribute('data-edt')};
    }""")
    print("05 font bump:", json.dumps(fs, ensure_ascii=False))
    if fs:
        assert float(fs["after"][:-2]) > float(fs["before"][:-2]), "font should grow"

    # image transform on first data-edimg (if any)
    it = pg.evaluate(r"""() => {
      var slot=document.querySelector('[data-edimg]');
      if(!slot) return {none:true};
      var img=slot.querySelector('img');
      var before=img?getComputedStyle(img).transform:'none';
      var tool=slot.querySelector('.dep-imgtool');
      if(tool) tool.querySelectorAll('button')[1].click(); // zoom in +
      return {before:before, after:img?getComputedStyle(img).transform:'none', hasTool:!!tool};
    }""")
    print("06 img transform:", json.dumps(it, ensure_ascii=False))

    # reorder: drag chip 0 -> last (call internal go/reorder via API not exposed; use rail DnD sim)
    # simpler: verify go() navigates
    pg.evaluate("() => window.__deck.go(0)")
    pg.wait_for_timeout(200)
    print("07 nav go(0) cur:", state()["cur"])

    # export via fallback (headless: capture blob by overriding)
    exp = pg.evaluate(r"""() => {
      var got={clicked:false};
      var a_click = HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click = function(){ if(this.download){got.clicked=true; got.name=this.download;} };
      // exit edit first (host export does this)
      document.getElementById('deckExport') ? document.getElementById('deckExport').click()
        : document.getElementById('depBar').querySelectorAll('button')[4].click();
      HTMLAnchorElement.prototype.click = a_click;
      return got;
    }""")
    print("08 export:", json.dumps(exp, ensure_ascii=False))

    pg.evaluate("() => { document.body.classList.add('deck-editing'); }")
    pg.wait_for_timeout(200)
    pg.screenshot(path="/tmp/e2r/editor_edit_mode.png")
    print("ALL ASSERTIONS PASSED")
    b.close()
