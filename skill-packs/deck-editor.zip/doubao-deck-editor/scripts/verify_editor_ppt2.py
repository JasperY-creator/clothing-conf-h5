from playwright.sync_api import sync_playwright
import pathlib, sys
# v3.0 —— PPT 增量·第二批(用户三小问题)
#  1 文字框手动调宽高(右下角 .dep-rz 手柄,写内联 width/height,解除 min/max)
#  2 新增图片浮层:空态无底色(background:transparent),仅虚线边;上传后连边也隐
#  3 文字工具栏防重叠:#depFont / #depShape / #depDeco 同现时竖直错开不相交
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())

def enter_edit(pg):
    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(200)
    pg.evaluate("()=>window.__deck.go(1)"); pg.wait_for_timeout(150)

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(900)
    assert pg.evaluate("()=>!!window.__deckEditorPlus"), "enhancement layer must exist"
    assert pg.evaluate("()=>window.__deckEditorPlus.v")=="3.11", "version must be 3.11"

    enter_edit(pg)

    def add_float(label):
        return pg.evaluate("""(lab)=>{var bs=document.querySelectorAll('#depBar button');
          for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf(lab)>=0){bs[i].click();return true;}}return false;}""", label)

    # ---------- 2) 图片浮层空态无底色 ----------
    assert add_float("＋图片"), "＋图片 button must exist"
    pg.wait_for_timeout(120)
    imgbg = pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var im=f.querySelector('.dep-float.dep-img');
      var cs=getComputedStyle(im);
      // 归一化 background-color:transparent 会被算成 rgba(0,0,0,0)
      var bc=cs.backgroundColor;
      var transparent=(bc==='rgba(0, 0, 0, 0)'||bc==='transparent');
      var hasDash=(cs.borderStyle||'').indexOf('dashed')>=0;
      var ph=!!im.querySelector('.dep-imgph');
      return {bc:bc,transparent:transparent,hasDash:hasDash,placeholder:ph};}""")
    print("2) img empty bg:", imgbg)
    assert imgbg["transparent"], "empty image float must have transparent background (no tint)"
    assert imgbg["hasDash"], "empty image float must keep dashed border"
    assert imgbg["placeholder"], "empty image float must keep the upload placeholder text"

    # 模拟已上传:注入 <img> 并打 dep-has-img,断言边框转透明(纯图观感)
    uploaded = pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var im=f.querySelector('.dep-float.dep-img');
      var box=im.querySelector('.dep-imgbox')||im.querySelector('.dep-fanim');
      var g=document.createElement('img');g.src='data:image/gif;base64,R0lGODlhAQABAAAAACwAAAAAAQABAAA=';
      box.insertBefore(g,box.firstChild);
      im.classList.add('dep-has-img');
      var cs=getComputedStyle(im);
      return {edge:cs.borderTopColor};}""")
    print("   img uploaded edge:", uploaded)
    assert uploaded["edge"]=='rgba(0, 0, 0, 0)', "uploaded image float border must go transparent"

    # ---------- 1) 文字框手动调宽高 ----------
    assert add_float("＋文字"), "＋文字 button must exist"
    pg.wait_for_timeout(120)
    grip = pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var t=f.querySelector('.dep-float.dep-text');
      var rz=t.querySelector('.dep-rz');
      var vis=rz&&getComputedStyle(rz).display!=='none';
      return {hasGrip:!!rz,visible:!!vis};}""")
    print("1) text resize grip:", grip)
    assert grip["hasGrip"], "text float must carry a .dep-rz resize handle"
    assert grip["visible"], ".dep-rz must be visible in edit mode"

    # 拖拽手柄改宽高:mousedown 在手柄 → mousemove +120/+60 → 断言 width/height 增大、打 data-depsized
    resized = pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var t=f.querySelector('.dep-float.dep-text');
      var rz=t.querySelector('.dep-rz');
      var r0=t.getBoundingClientRect();
      var w0=r0.width,h0=r0.height;
      var rr=rz.getBoundingClientRect();
      var sx=rr.left+rr.width/2, sy=rr.top+rr.height/2;
      rz.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,clientX:sx,clientY:sy}));
      document.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:sx+140,clientY:sy+80}));
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      var r1=t.getBoundingClientRect();
      return {w0:w0,h0:h0,w1:r1.width,h1:r1.height,
              sized:t.getAttribute('data-depsized'),
              wStyle:t.style.width,hStyle:t.style.height};}""")
    print("   text resized:", resized)
    assert resized["wStyle"] and resized["hStyle"], "resize must write inline width/height"
    assert resized["w1"]>resized["w0"]+20 and resized["h1"]>resized["h0"]+10, "drag grip must enlarge the box"
    assert resized["sized"]=="1", "resized text float must carry data-depsized"

    # 拖拽手柄本身不移动整框(手柄被 bindFloatDrag 排除)
    nomove = pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var t=f.querySelector('.dep-float.dep-text');
      var l0=parseFloat(t.style.left)||0, tp0=parseFloat(t.style.top)||0;
      var rz=t.querySelector('.dep-rz');var rr=rz.getBoundingClientRect();
      var sx=rr.left+2,sy=rr.top+2;
      rz.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,clientX:sx,clientY:sy}));
      document.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:sx+40,clientY:sy+40}));
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      return {l0:l0,tp0:tp0,l1:parseFloat(t.style.left)||0,t1:parseFloat(t.style.top)||0};}""")
    print("   grip drag doesn't move box:", nomove)
    assert abs(nomove["l1"]-nomove["l0"])<0.5 and abs(nomove["t1"]-nomove["tp0"])<0.5, "resizing must not translate the box"

    # 导出克隆保留尺寸手柄 + 内联宽高
    ex = pg.evaluate(r"""()=>{var c=document.documentElement.cloneNode(true);
      var t=c.querySelector('.dep-float.dep-text[data-depsized]');
      return {sizedFloat:!!t, hasWidth:!!(t&&t.style.width)};}""")
    print("   export keeps sized text:", ex)
    assert ex["sizedFloat"] and ex["hasWidth"], "exported clone must keep manually-sized text float"

    # ---------- 3) 工具栏防重叠 + 不遮挡被点内容 ----------
    # A) 兜底几何:三条都强制可见并叠在一起 → 同步去重叠后互不相交。
    overlap = pg.evaluate(r"""()=>{
      function box(id){var e=document.getElementById(id);if(!e)return null;
        e.classList.remove('dep-hidden');e.style.left='400px';e.style.top='300px';
        return e;}
      var f=box('depFont'),s=box('depShape'),d=box('depDeco');
      if(!f||!s||!d)return {skipped:true};
      window.__deckEditorPlus.dodgeBars();   /* 同步收敛 */
      function r(id){var e=document.getElementById(id);var b=e.getBoundingClientRect();
        return {id:id,left:b.left,right:b.right,top:b.top,bottom:b.bottom,
                hidden:e.classList.contains('dep-hidden'),h:b.height};}
      return {f:r('depFont'),s:r('depShape'),d:r('depDeco')};}""")
    print("3A) toolbar geom raw:", overlap)
    if not overlap.get("skipped"):
        def rects_overlap(a,bb):
            if a["hidden"] or bb["hidden"]:
                return False
            return not (a["right"]<=bb["left"] or a["left"]>=bb["right"] or a["bottom"]<=bb["top"] or a["top"]>=bb["bottom"])
        vis = [x for x in [overlap["f"],overlap["s"],overlap["d"]] if not x["hidden"]]
        assert len(vis)>=2, "need at least 2 visible bars to test de-collision"
        for i in range(len(vis)):
            for j in range(i+1,len(vis)):
                assert not rects_overlap(vis[i],vis[j]), \
                    "visible toolbars must not overlap after de-collision: %s vs %s" % (vis[i]["id"],vis[j]["id"])
        print("   visible bars pairwise non-overlapping:", [v["id"] for v in vis])

    # B) 真实场景:点选一张浮层卡片的标题文字 → 同时浮出字号条(#depFont,文字上方)、
    #    装饰面板(#depDeco,卡片下方),并选中该浮层(#depShape)。断言:去重叠后,
    #    「三条可见工具条都不遮挡被点的锚点元素」——即用户点了文字后内容仍看得见。
    anchor = pg.evaluate(r"""()=>{
      // 先隐掉上一步强制显示的条,恢复干净起点
      ['depFont','depShape','depDeco'].forEach(function(id){
        var e=document.getElementById(id);if(e)e.classList.add('dep-hidden');});
      var f=window.__deck.frames[window.__deck.cur()];
      // 造一张浮层卡片:含标题文字,便于点击既触发 fontBar 又触发 deco
      var bs=document.querySelectorAll('#depBar button');
      for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf('＋卡片')>=0){bs[i].click();break;}}
      var card=f.querySelector('.dep-float.dep-card');
      // 把卡片摆到页面上方,让「元素上方」空间有限,考验避让是否真让开锚点
      card.style.left='300px';card.style.top='120px';
      var title=card.querySelector('.dep-cardt');
      // 选中浮层(mousedown)→ shapeBar;再点标题文字 → fontBar + deco
      card.dispatchEvent(new MouseEvent('mousedown',{bubbles:true}));
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      title.dispatchEvent(new MouseEvent('click',{bubbles:true}));
      window.__deckEditorPlus.dodgeBars();   /* 同步收敛(生产里是 setTimeout(0)) */
      var ar=title.getBoundingClientRect();
      function r(id){var e=document.getElementById(id);var b=e.getBoundingClientRect();
        return {id:id,left:b.left,right:b.right,top:b.top,bottom:b.bottom,
                hidden:e.classList.contains('dep-hidden')};}
      return {anchor:{left:ar.left,right:ar.right,top:ar.top,bottom:ar.bottom},
              f:r('depFont'),s:r('depShape'),d:r('depDeco')};}""")
    print("3B) anchor scenario raw:", anchor)
    an=anchor["anchor"]
    def covers(bar,a):
        if bar["hidden"]:
            return False
        return not (bar["right"]<=a["left"] or bar["left"]>=a["right"] or bar["bottom"]<=a["top"] or bar["top"]>=a["bottom"])
    for bar in [anchor["f"],anchor["s"],anchor["d"]]:
        assert not covers(bar,an), \
            "toolbar %s must NOT cover the clicked anchor element" % bar["id"]
    print("   no visible toolbar covers the clicked text anchor")

    print("PPT2 (3 fixes) PASSED — text box manual resize, image float no tint, toolbar de-collision")
    b.close()
