from playwright.sync_api import sync_playwright
import pathlib, json, sys
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.goto(url); pg.wait_for_timeout(1200)
    def cur(): return pg.evaluate("()=>window.__deck.cur()")
    def dis(i): return pg.evaluate("(id)=>document.getElementById(id).disabled", i)

    # page 0: prev disabled, next enabled
    assert cur() == 0, "starts on page 0"
    assert dis("deckPrev") is True, "prev disabled on first page"
    assert dis("deckNext") is False, "next enabled on first page"

    # click next -> prev must re-enable, and a real click on prev must go back
    pg.click("#deckNext"); pg.wait_for_timeout(80)
    assert cur() == 1, "next advances"
    assert dis("deckPrev") is False, "prev re-enabled after leaving page 0"
    pg.click("#deckPrev"); pg.wait_for_timeout(80)
    assert cur() == 0, "LEFT ARROW works: navigates back to page 0"
    assert dis("deckPrev") is True, "prev disabled again at page 0"

    # go to last page: next disabled, prev works
    N = pg.evaluate("()=>window.__deck.total")
    pg.evaluate("(n)=>window.__deck.go(n-1)", N); pg.wait_for_timeout(80)
    assert cur() == N-1, "at last page"
    assert dis("deckNext") is True, "next disabled on last page"
    assert dis("deckPrev") is False, "prev enabled on last page"
    pg.click("#deckPrev"); pg.wait_for_timeout(80)
    assert cur() == N-2, "prev works from last page"

    print("NAV-ARROW ASSERTIONS PASSED")
    b.close()
