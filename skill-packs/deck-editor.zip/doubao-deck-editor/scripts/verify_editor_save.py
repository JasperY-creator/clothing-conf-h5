from playwright.sync_api import sync_playwright
import pathlib, sys, tempfile, shutil

_t = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_t).resolve())

# Constrained-sandbox launch flags: headless Chromium defaults to /dev/shm for shared
# memory, which is tiny in containers and makes the whole browser crash
# (TargetClosedError) under repeated full reloads. Routing shm off + disabling gpu
# removes that race. We ALSO run on a persistent on-disk profile so that, if the browser
# process does die, we can relaunch it and localStorage (the thing under test) survives.
LAUNCH_ARGS = ["--disable-dev-shm-usage", "--no-sandbox", "--disable-gpu"]

# ---- v3.4 storage moved from localStorage to IndexedDB (localStorage can't hold the
# 14.3MB inline-image decks the user hit). These async helpers probe the real backend. ----
IDB_DB, IDB_STORE = "deckeditplus", "snaps"
# wipe both localStorage draft/meta keys AND the IDB snapshot store → clean slate
JS_CLEAR_ALL = """()=>new Promise(function(res){
  try{for(var i=localStorage.length-1;i>=0;i--){var k=localStorage.key(i);if(k&&k.indexOf('deckeditplus')===0)localStorage.removeItem(k);}}catch(e){}
  try{var rq=indexedDB.open('deckeditplus',1);
    rq.onupgradeneeded=function(e){try{e.target.result.createObjectStore('snaps');}catch(_){}};
    rq.onsuccess=function(){var db=rq.result;try{var tx=db.transaction('snaps','readwrite');tx.objectStore('snaps').clear();tx.oncomplete=function(){db.close();res(true);};tx.onerror=function(){try{db.close();}catch(_){}res(true);};}catch(e){try{db.close();}catch(_){}res(true);}};
    rq.onerror=function(){res(true);};
  }catch(e){res(true);}
})"""
# how many snapshot rows live in IDB (async; -N on error paths)
JS_IDB_COUNT = """()=>new Promise(function(res){
  try{var rq=indexedDB.open('deckeditplus',1);
    rq.onupgradeneeded=function(e){try{e.target.result.createObjectStore('snaps');}catch(_){}};
    rq.onsuccess=function(){var db=rq.result;try{var tx=db.transaction('snaps','readonly');var g=tx.objectStore('snaps').getAllKeys();
      g.onsuccess=function(){db.close();res(g.result?g.result.length:0);};g.onerror=function(){db.close();res(-1);};}catch(e){try{db.close();}catch(_){}res(-2);}};
    rq.onerror=function(){res(-3);};
  }catch(e){res(-4);}
})"""
# corrupt the sig+html of every IDB snapshot row (simulates cross-deck cross-talk / stale row)
JS_CORRUPT_IDB = """()=>new Promise(function(res){
  try{var rq=indexedDB.open('deckeditplus',1);
    rq.onsuccess=function(){var db=rq.result;try{var tx=db.transaction('snaps','readwrite');var st=tx.objectStore('snaps');var ck=st.getAllKeys();
      ck.onsuccess=function(){var keys=ck.result||[];if(!keys.length){db.close();res(0);return;}var done=0;
        for(var i=0;i<keys.length;i++){(function(key){var gg=st.get(key);gg.onsuccess=function(){try{var s=JSON.parse(gg.result);s.sig='__bogus_sig__';s.html='<section>forged</section><section>forged</section>';st.put(JSON.stringify(s),key);}catch(e){}done++;if(done===keys.length){}};})(keys[i]);}
        tx.oncomplete=function(){db.close();res(keys.length);};tx.onerror=function(){try{db.close();}catch(_){}res(-1);};};
      ck.onerror=function(){db.close();res(-2);};}catch(e){try{db.close();}catch(_){}res(-3);}};
    rq.onerror=function(){res(-4);};
  }catch(e){res(-5);}
})"""
def _js_meta_exists():
    return "()=>{for(var i=0;i<localStorage.length;i++){if((localStorage.key(i)||'').indexOf('deckeditplusmeta:')===0)return true;}return false;}"
def _js_full_ls_exists():
    return "()=>{for(var i=0;i<localStorage.length;i++){if((localStorage.key(i)||'').indexOf('deckeditplusfull:')===0)return true;}return false;}"

fails=[]
def ck(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ")+name+("" if cond else "  <<< "+str(extra)))
    if not cond: fails.append(name)

class Session(object):
    """A crash-tolerant single-tab session backed by a persistent on-disk profile.
       localStorage lives in the profile dir, so relaunching after a browser crash
       preserves the exact state the save/restore logic is being tested against."""
    def __init__(self, pw, profile):
        self.pw=pw; self.profile=profile; self.ctx=None; self.pg=None
        self._launch()
    def _launch(self):
        self.ctx=self.pw.chromium.launch_persistent_context(
            self.profile, headless=True, args=LAUNCH_ARGS,
            viewport={"width":1280,"height":720})
        self.pg=self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
        self.pg.on("dialog", lambda d: d.accept())   # auto-accept the 清除 confirm()
    def _relaunch(self):
        try: self.ctx.close()
        except Exception: pass
        self._launch()
    def goto(self, wait=800, tries=5):
        last=None
        for _ in range(tries):
            try:
                self.pg.goto(url, wait_until="load"); self.pg.wait_for_timeout(wait); return
            except Exception as e:
                last=e
                # page-level drop → new page; browser-level crash → full relaunch
                try:
                    if self.pg.is_closed(): self.pg=self.ctx.new_page(); self.pg.on("dialog", lambda d:d.accept())
                except Exception:
                    try: self._relaunch()
                    except Exception: pass
                try: self.pg.wait_for_timeout(200)
                except Exception:
                    try: self._relaunch()
                    except Exception: pass
        raise last
    def reload(self, wait=700):
        # HARD reload: close the context first (this FLUSHES the persistent leveldb to
        # disk), then relaunch and navigate. This makes the localStorage-restore assertions
        # deterministic — they no longer depend on same-process in-memory survival, so an
        # intervening renderer crash cannot swallow a not-yet-flushed save.
        self._relaunch()
        self.goto(wait)
    def ev(self, js): return self.pg.evaluate(js)
    def wait(self, ms):
        try: self.pg.wait_for_timeout(ms)
        except Exception: pass
    def poll(self, js, want=True, timeout=4000, step=100):
        """Poll a JS predicate until it equals `want` or timeout. Used for the v3.4
           ASYNC IndexedDB restore, which finishes some ticks after page load."""
        waited=0
        while waited<timeout:
            try:
                if self.ev(js)==want: return True
            except Exception: pass
            self.wait(step); waited+=step
        return False
    def close(self):
        try: self.ctx.close()
        except Exception: pass

with sync_playwright() as p:
    prof = tempfile.mkdtemp(prefix="deckedit_prof_")
    try:
        S = Session(p, prof)
        S.goto(800)
        # clear any prior draft/snapshot (localStorage keys + IDB store) so we start clean
        S.ev(JS_CLEAR_ALL)
        S.reload(700)

        ck("version is 3.11", S.ev("()=>window.__deckEditorPlus&&window.__deckEditorPlus.v")=="3.11")

        # the file's OWN baseline page count (fixture-agnostic; older tests hardcoded 3)
        ORIG_PAGES = S.ev("()=>document.getElementById('deckTrack').children.length")

        # save box hidden before edit mode
        ck("saveBox hidden before edit", S.ev("()=>{var b=document.getElementById('depSaveBox');return !!b&&b.classList.contains('dep-hidden');}"))

        S.ev("()=>document.getElementById('deckEdit').click()"); S.wait(200)
        ck("saveBox visible in edit mode", S.ev("()=>{var b=document.getElementById('depSaveBox');return !!b&&!b.classList.contains('dep-hidden')&&b.offsetWidth>0;}"))
        ck("status starts as 未改动", S.ev("()=>{var s=document.querySelector('#depSaveBox .dep-savest');return s&&s.textContent.indexOf('未改动')>=0;}"))

        # count frames before
        n_before = S.ev("()=>document.getElementById('deckTrack').children.length")

        # ---- make a font edit on page0 title (records a fontSize change into store) ----
        S.ev("""()=>{var P=window.__deckEditorPlus;var t=document.getElementById('deckTrack');
            P.go(0);var e=t.children[0].querySelector('.ptitle,h1,h2,.stat .t,p,[data-edt]');e.click();
            var fb=document.querySelectorAll('#depFont button');for(var k=0;k<8;k++)fb[1].click();}""")
        S.wait(120)
        ck("dirty after font edit", S.ev("()=>{var s=document.querySelector('#depSaveBox .dep-savest');return s&&s.classList.contains('dep-dirty')&&s.textContent.indexOf('未保存')>=0;}"))

        # ---- add a blank page (structural change) ----
        S.ev("""()=>{var bs=document.querySelectorAll('#depBar button');
            for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf('空白页')>=0){bs[i].click();break;}}}""")
        S.wait(150)
        n_after_add = S.ev("()=>document.getElementById('deckTrack').children.length")
        ck("page count grew after add-blank", n_after_add==n_before+1, (n_before,n_after_add))

        # ---- add a float text element (structural) ----
        S.ev("""()=>{var bs=document.querySelectorAll('#depBar button');
            for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf('＋文字')>=0){bs[i].click();break;}}}""")
        S.wait(120)
        floats_added = S.ev("()=>document.querySelectorAll('.dep-float').length")
        ck("a float was added", floats_added>=1, floats_added)

        # capture edited page0 title fontSize + the new page count for post-reload comparison
        fs_p0 = S.ev("""()=>{var t=document.getElementById('deckTrack');
            var e=t.children[0].querySelector('.ptitle,h1,h2,.stat .t,p,[data-edt]');
            return e?getComputedStyle(e).fontSize:null;}""")

        # ---- CLICK SAVE (real full save; v3.4 writes the big HTML to IndexedDB, a tiny meta record to localStorage) ----
        S.ev("()=>document.querySelector('#depSaveBox .dep-savebtn').click()")
        # IDB write is async → poll status to flip to 已保存
        ck("status cleared to 已保存 after save",
           S.poll("()=>{var s=document.querySelector('#depSaveBox .dep-savest');return !!(s&&s.classList.contains('dep-saved')&&s.textContent.indexOf('已保存')>=0);}"),
           S.ev("()=>{var s=document.querySelector('#depSaveBox .dep-savest');return s?s.textContent:null;}"))
        ck("v3.4 full snapshot written to IndexedDB", S.ev(JS_IDB_COUNT)>=1)
        ck("v3.4 tiny meta record written to localStorage", S.ev(_js_meta_exists()))
        ck("v3.4 big snapshot NOT left in localStorage (avoids ~5MB cap)", not S.ev(_js_full_ls_exists()))

        # ---- RELOAD: full state must be restored (v3.4 restore is ASYNC — poll for it) ----
        S.reload(900)
        S.poll("()=>document.getElementById('deckTrack').children.length===%d" % n_after_add, timeout=6000)
        n_reload = S.ev("()=>document.getElementById('deckTrack').children.length")
        ck("page count RESTORED after reload", n_reload==n_after_add, (n_after_add,n_reload))
        floats_reload = S.ev("()=>document.querySelectorAll('.dep-float').length")
        ck("float RESTORED after reload", floats_reload>=1, floats_reload)
        fs_p0_reload = S.ev("""()=>{var t=document.getElementById('deckTrack');
            var e=t.children[0].querySelector('.ptitle,h1,h2,.stat .t,p,[data-edt]');
            return e?getComputedStyle(e).fontSize:null;}""")
        ck("page0 title fontSize RESTORED after reload", fs_p0_reload==fs_p0, (fs_p0,fs_p0_reload))

        # status after reload should reflect a saved timestamp (not dirty)
        ck("not dirty after reload (clean snapshot)", S.ev("()=>{var b=document.getElementById('depSaveBox');document.getElementById('deckEdit').click();var s=document.querySelector('#depSaveBox .dep-savest');return s&&!s.classList.contains('dep-dirty');}"))

        # ---- export must NOT contain the save box (no UI pollution) ----
        has_savebox_in_clone = S.ev("""()=>{var c=document.getElementById('deckTrack').cloneNode(true);
            return c.querySelector('#depSaveBox')!=null;}""")
        ck("saveBox NOT inside deckTrack (won't pollute export snapshot)", not has_savebox_in_clone)

        # ---- v3.4: meta record carries a docSig (guards against cross-deck cross-talk) ----
        meta_has_sig = S.ev("""()=>{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);
            if((k||'').indexOf('deckeditplusmeta:')===0){try{var s=JSON.parse(localStorage.getItem(k));return !!(s&&s.sig);}catch(e){return false;}}}return false;}""")
        ck("v3.4 meta record carries docSig", meta_has_sig)

        # ---- escape hatch (v3.7: 清除按钮已移除,逃生口改用 ?depfresh):
        #      重开时带 ?depfresh 应静默清掉本文档 IDB 快照 + meta 记录并跳过还原,回到原始 deck ----
        n_saved = S.ev("()=>document.getElementById('deckTrack').children.length")
        # reload WITH ?depfresh — clearFull(true) runs at startup, then revive(false)
        S._relaunch()
        S.pg.goto(url + "?depfresh=1", wait_until="load"); S.wait(800)
        meta_gone = not S.ev(_js_meta_exists())
        idb_gone = S.ev(JS_IDB_COUNT)==0
        ck("?depfresh removed the meta record", meta_gone)
        ck("?depfresh removed the IDB snapshot row", idb_gone, S.ev(JS_IDB_COUNT))
        S.poll("()=>document.getElementById('deckTrack').children.length===%d" % ORIG_PAGES, timeout=4000)
        n_after_clear = S.ev("()=>document.getElementById('deckTrack').children.length")
        ck("after ?depfresh page count back to ORIGINAL", n_after_clear==ORIG_PAGES, (n_saved, n_after_clear, ORIG_PAGES))

        # ================= LARGE-SNAPSHOT save/restore (the real 14.3MB bug) =================
        # Reproduce the user's scenario: a deck whose content dwarfs the ~5MB localStorage cap.
        # We inject a ~6MB data-URI <img> into page0, save (must succeed via IDB, NOT error),
        # then reload and confirm the big image survived — i.e. Save actually works for big decks.
        S.ev(JS_CLEAR_ALL); S.reload(700)
        S.ev("()=>document.getElementById('deckEdit').click()"); S.wait(150)
        big_len = S.ev("""()=>{var t=document.getElementById('deckTrack');var pg=t.children[0];
            // ~6MB payload: base64 string ~6M chars. Build cheaply.
            var chunk='ABCD'.repeat(1024);          // 4KB
            var big='';for(var i=0;i<1536;i++)big+=chunk;   // ~6MB
            var img=document.createElement('img');
            img.src='data:image/png;base64,'+big;
            img.setAttribute('data-bigprobe','1');
            (pg.querySelector('.content,.page,.cover-wrap,.cover')||pg).appendChild(img);
            return big.length;}""")
        ck("large payload injected (~6MB)", big_len>5*1024*1024, big_len)
        # mark dirty so save has something to persist, then SAVE
        S.ev("""()=>{var t=document.getElementById('deckTrack');
            var e=t.children[0].querySelector('.ptitle,h1,h2,.stat .t,p,[data-edt]');
            if(e){e.click();var fb=document.querySelectorAll('#depFont button');if(fb[1])fb[1].click();}}""")
        S.wait(120)
        S.ev("()=>document.querySelector('#depSaveBox .dep-savebtn').click()")
        big_saved = S.poll("()=>{var s=document.querySelector('#depSaveBox .dep-savest');return !!(s&&s.classList.contains('dep-saved'));}", timeout=8000)
        ck("LARGE deck SAVED without error (IDB, not blocked at 5MB)", big_saved,
           S.ev("()=>{var s=document.querySelector('#depSaveBox .dep-savest');return s?s.textContent:null;}"))
        ck("large snapshot landed in IDB (not localStorage)", S.ev(JS_IDB_COUNT)>=1 and not S.ev(_js_full_ls_exists()))
        # reload → the big image must come back (proves the >5MB HTML round-tripped)
        S.reload(1200)
        big_back = S.poll("()=>!!document.querySelector('#deckTrack img[data-bigprobe]')", timeout=8000)
        ck("LARGE image RESTORED after reload (14.3MB bug fixed)", big_back)
        big_src_len = S.ev("()=>{var im=document.querySelector('#deckTrack img[data-bigprobe]');return im?im.src.length:0;}")
        ck("restored big image retains its multi-MB data URI", big_src_len>5*1024*1024, big_src_len)

        # ================= stale-sig resilience (v3.4: corrupt the IDB row) =================
        # clean slate, save once to materialize the real IDB row + meta, then corrupt sig+html in IDB
        S.ev(JS_CLEAR_ALL); S.reload(600)
        S.ev("""()=>{document.getElementById('deckEdit').click();
            document.querySelector('#depSaveBox .dep-savebtn').click();}""")
        S.poll("()=>{var s=document.querySelector('#depSaveBox .dep-savest');return !!(s&&s.classList.contains('dep-saved'));}", timeout=6000)
        # also corrupt the meta sig so fullMeta() still fires but the async row fails validation
        S.ev("""()=>{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);
            if((k||'').indexOf('deckeditplusmeta:')===0){try{var m=JSON.parse(localStorage.getItem(k));m.sig='__bogus_sig__';localStorage.setItem(k,JSON.stringify(m));}catch(e){}}}}""")
        S.ev(JS_CORRUPT_IDB)
        S.wait(150)
        S.reload(900)
        S.poll("()=>document.getElementById('deckTrack').children.length===%d" % ORIG_PAGES, timeout=4000)
        n_stale = S.ev("()=>document.getElementById('deckTrack').children.length")
        ck("stale-sig snapshot IGNORED (original pages show through, not forged 2)", n_stale==ORIG_PAGES, (n_stale, ORIG_PAGES))
        # cleanup
        S.ev(JS_CLEAR_ALL)
        S.close()
    finally:
        shutil.rmtree(prof, ignore_errors=True)

print("\n==== %d FAIL ====" % len(fails) if fails else "\n==== ALL PASS ====")
sys.exit(1 if fails else 0)
