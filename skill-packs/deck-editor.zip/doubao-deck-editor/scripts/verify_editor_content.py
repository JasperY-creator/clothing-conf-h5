from playwright.sync_api import sync_playwright
import pathlib, json, sys
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.goto(url); pg.wait_for_timeout(1400)  # let count-up finish

    # go to a content page that has .stat cards + big numbers
    pg.evaluate("() => { window.__deck && window.__deck.go && window.__deck.go(1); }")
    pg.wait_for_timeout(300)

    # BEFORE edit mode: card text / numbers must NOT be editable
    before = pg.evaluate(r"""() => {
      var t=document.querySelector('.stat .t');
      var v=document.querySelector('.num .v');
      return {tEditable: t?t.getAttribute('contenteditable'):null,
              vEditable: v?v.getAttribute('contenteditable'):null};
    }""")
    print("00 before-edit:", json.dumps(before, ensure_ascii=False))
    assert before["tEditable"] in (None, "false"), "card text not editable outside edit mode"

    # enter edit mode
    pg.evaluate("() => { var e=document.getElementById('deckEdit'); if(e) e.click(); }")
    pg.wait_for_timeout(300)

    armed = pg.evaluate(r"""() => {
      var t=document.querySelector('.stat .t');
      var d=document.querySelector('.stat .d');
      var v=document.querySelector('.num .v');
      var u=document.querySelector('.num .u');
      return {t: t?t.getAttribute('contenteditable'):null,
              d: d?d.getAttribute('contenteditable'):null,
              v: v?v.getAttribute('contenteditable'):null,
              u: u?u.getAttribute('contenteditable'):null};
    }""")
    print("01 armed in edit:", json.dumps(armed, ensure_ascii=False))
    assert armed["t"]=="true" and armed["v"]=="true", "card text & big number must be contenteditable in edit mode"

    # edit card text content; color must be preserved (compare computed color before/after text change)
    ce = pg.evaluate(r"""() => {
      var t=document.querySelector('.stat .t');
      var colorBefore=getComputedStyle(t).color;
      t.textContent='已改写的卡片标题';
      t.dispatchEvent(new Event('input',{bubbles:true}));
      return {text:t.textContent, color:getComputedStyle(t).color, colorBefore:colorBefore};
    }""")
    print("02 edit card text:", json.dumps(ce, ensure_ascii=False))
    assert ce["text"]=="已改写的卡片标题", "card text edit should take"
    assert ce["color"]==ce["colorBefore"], "text color preserved"

    # edit a big number -> data-to must sync to the new value (animation endpoint follows)
    num = pg.evaluate(r"""() => {
      var v=document.querySelector('.num .v[data-to], .num .v');
      var toBefore=v.getAttribute('data-to');
      v.textContent='88';
      v.dispatchEvent(new Event('input',{bubbles:true}));
      return {toBefore:toBefore, toAfter:v.getAttribute('data-to'), text:v.textContent};
    }""")
    print("03 edit number:", json.dumps(num, ensure_ascii=False))
    assert num["toAfter"]=="88", "editing number must sync data-to to new value"

    # non-numeric input -> data-to removed (won't be reset by count-up)
    nonnum = pg.evaluate(r"""() => {
      var v=document.querySelector('.num .v');
      v.textContent='N/A';
      v.dispatchEvent(new Event('input',{bubbles:true}));
      return {hasTo:v.hasAttribute('data-to'), text:v.textContent};
    }""")
    print("04 non-numeric:", json.dumps(nonnum, ensure_ascii=False))
    assert nonnum["hasTo"]==False, "non-numeric number drops data-to"

    # exiting edit mode strips our contenteditable
    off = pg.evaluate(r"""() => {
      var e=document.getElementById('deckEdit'); if(e) e.click();
      var t=document.querySelector('.stat .t');
      return {t: t?t.getAttribute('contenteditable'):null};
    }""")
    print("05 after edit-off:", json.dumps(off, ensure_ascii=False))
    assert off["t"] in (None,"false"), "contenteditable removed when leaving edit mode"

    # export clone: no contenteditable leaks
    exp = pg.evaluate(r"""() => {
      var e=document.getElementById('deckEdit'); if(e) e.click(); // back to edit
      var clone=document.documentElement.cloneNode(true);
      // host export strips all contenteditable; simulate:
      var eds=clone.querySelectorAll('[contenteditable]');
      return {editableInClone: eds.length};
    }""")
    print("06 export snapshot (raw clone, pre-strip):", json.dumps(exp, ensure_ascii=False))

    print("CONTENT-EDIT ASSERTIONS PASSED")
    b.close()
