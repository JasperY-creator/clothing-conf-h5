from playwright.sync_api import sync_playwright
import pathlib, sys
# bug#7 —— 复制含卡片的页后,改一页卡片正文不得删/改另一页同位文字。
# 根因:cloneNode 把宿主内容持久化 id(data-edt / data-edimg)原样拷走,两页共用同 id;
#   宿主 compose_deck 的 collect()/load() 只按 data-edt 存取文本且无页命名空间 → 存一页
#   的文字经 localStorage 回写到【所有同 id 节点】,把另一页同位文字覆盖/清空。
# 修法:addPage 复制页时 reidHostEdit() 给 data-edt / data-edimg 现铸全新唯一 id。
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/real_deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())

fails=[]
def ck(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ")+name+("" if cond else "  <<< "+str(extra)))
    if not cond: fails.append(name)

with sync_playwright() as p:
    b = p.chromium.launch(headless=True, args=["--disable-dev-shm-usage","--no-sandbox","--disable-gpu"])
    pg = b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(900)
    ck("version is 3.11", pg.evaluate("()=>window.__deckEditorPlus&&window.__deckEditorPlus.v")=="3.11")
    pg.evaluate("()=>{try{localStorage.clear()}catch(e){}}")

    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(250)

    # 找到一个含 data-edt 的内容页(卡片文字页),定位其索引
    srcIdx = pg.evaluate(r"""()=>{var t=document.getElementById('deckTrack');
      for(var i=0;i<t.children.length;i++){
        if(t.children[i].querySelector('.fpoint .d,.card .d,.rcard .d,[data-edt]'))return i;}
      return -1;}""")
    ck("found a content page with editable text", srcIdx>=0, srcIdx)

    # go to it, 复制本页 -> 生成同版式页(旧实现:同 data-edt;新实现:重铸唯一 id)
    pg.evaluate("(i)=>window.__deck.go(i)", srcIdx); pg.wait_for_timeout(120)
    pg.evaluate("""()=>{var bs=document.querySelectorAll('#depBar button');
      for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf('复制本页')>=0){bs[i].click();break;}}}""")
    pg.wait_for_timeout(300)

    # A) 复制页与源页之间 data-edt / data-edimg 均无共享 id
    share = pg.evaluate(r"""(si)=>{var t=document.getElementById('deckTrack');
      var f1=t.children[si],f2=t.children[si+1];
      function ids(f,attr){var a=f.querySelectorAll('['+attr+']');var o=[];
        for(var i=0;i<a.length;i++)o.push(a[i].getAttribute(attr));return o;}
      var e1=ids(f1,'data-edt'),e2=ids(f2,'data-edt');
      var g1=ids(f1,'data-edimg'),g2=ids(f2,'data-edimg');
      var sEdt=e1.filter(function(x){return e2.indexOf(x)>=0;});
      var sImg=g1.filter(function(x){return g2.indexOf(x)>=0;});
      return {e1:e1.length,e2:e2.length,sharedEdt:sEdt.length,
              g1:g1.length,g2:g2.length,sharedImg:sImg.length};}""", srcIdx)
    print("share:",share)
    ck("A: duplicated page shares NO data-edt id with source", share["sharedEdt"]==0, share)
    ck("A: duplicated page shares NO data-edimg id with source", share["sharedImg"]==0, share)
    ck("A: duplicated page still has its own editable nodes", share["e2"]>=1, share)

    # 全体 data-edt 文档内两两唯一(无任何跨页碰撞)
    globalUniq = pg.evaluate(r"""()=>{var a=document.querySelectorAll('[data-edt]');
      var m={},d=0;for(var i=0;i<a.length;i++){var k=a[i].getAttribute('data-edt');m[k]=(m[k]||0)+1;}
      for(var k in m)if(m[k]>1)d++;return {total:a.length,dupKeys:d};}""")
    print("global data-edt:",globalUniq)
    ck("A: all data-edt ids globally unique", globalUniq["dupKeys"]==0, globalUniq)

    # B) 功能面:模拟宿主 collect()->load() 的 id-keyed 回写(不整页重载,复制页仍在)。
    #    改源页第一处正文 -> 收集全量 texts(键=data-edt) -> 回灌到所有同 id 节点 ->
    #    断言复制页同位文字【未被改动】(旧实现会被覆盖成源页文字)。
    res = pg.evaluate(r"""(si)=>{var t=document.getElementById('deckTrack');
      var f1=t.children[si],f2=t.children[si+1];
      var d1=f1.querySelector('.fpoint .d,.card .d,.rcard .d,[data-edt]');
      var d2=f2.querySelector('.fpoint .d,.card .d,.rcard .d,[data-edt]');
      var b2=d2?d2.innerHTML:null;
      if(d1){d1.innerHTML='SRC-PAGE-EDITED';}
      // 模拟宿主 collect(): texts[data-edt]=innerHTML(整卷,含复制页)
      var texts={};var all=document.querySelectorAll('[data-edt]');
      for(var i=0;i<all.length;i++)texts[all[i].getAttribute('data-edt')]=all[i].innerHTML;
      // 模拟宿主 load(): 回灌到所有同 id 节点
      for(var j=0;j<all.length;j++){var id=all[j].getAttribute('data-edt');
        if(texts.hasOwnProperty(id))all[j].innerHTML=texts[id];}
      return {srcEdt:d1?d1.getAttribute('data-edt'):null,
              dupEdt:d2?d2.getAttribute('data-edt'):null,
              dupBefore:b2, dupAfter:d2?d2.innerHTML:null,
              srcAfter:d1?d1.innerHTML:null};}""", srcIdx)
    print("roundtrip:",res)
    ck("B: source edit applied", res["srcAfter"]=="SRC-PAGE-EDITED", res)
    ck("B: duplicated page text UNCHANGED after host id-keyed roundtrip",
       res["dupAfter"]==res["dupBefore"], res)
    ck("B: source/dup have DIFFERENT data-edt at same position",
       res["srcEdt"]!=res["dupEdt"], res)

    b.close()

print("\n==== %d FAIL ====" % len(fails) if fails else "\n==== ALL PASS ====")
sys.exit(1 if fails else 0)
