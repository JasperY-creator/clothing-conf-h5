import os, sys
from playwright.sync_api import sync_playwright

# Regression for v3.10 (bug#18): last-page count-up numbers "can't be saved".
# Root cause: the host count-up tick() overwrites el.textContent every rAF frame for ~1.3s
# and cannot be cancelled once started; navigating to a page (esp. the value-overview last
# page) re-triggers count-up via deck:nav, so a number the user types (e.g. 99) is clobbered
# frame-by-frame -> data-to never becomes 99 -> the edit is lost on nav/save/reload.
# Fix: in edit mode the injected layer overrides window.__mcCount/__mcCountReset to STATICALLY
# settle numbers to their data-to value and to skip any number the user is editing / has edited
# (data-depedited). This test types "99" into the FIRST last-page count-up number during the
# animation window, then saves + reopens and asserts the value persists as 99.

TARGET = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
DECK = "file://" + os.path.abspath(TARGET)
PROF = "/tmp/rp_realkbd"

fails = []
def ck(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else "  <<< " + str(extra)))
    if not cond: fails.append(name)

with sync_playwright() as p:
    ctx = p.chromium.launch_persistent_context(PROF, headless=True,
            args=["--disable-dev-shm-usage", "--no-sandbox"])
    pg = ctx.new_page()
    pg.goto(DECK, wait_until="load"); pg.wait_for_timeout(600)
    pg.evaluate("()=>{try{Object.keys(localStorage).forEach(function(k){if(k.indexOf('deckeditplus')>=0)localStorage.removeItem(k);});}catch(e){} if(window.indexedDB){try{indexedDB.deleteDatabase('deckeditplus');}catch(e){}}}")
    pg.reload(wait_until="load"); pg.wait_for_timeout(800)
    pg.evaluate("()=>{var b=document.getElementById('deckEdit');if(b&&!document.body.classList.contains('deck-editing'))b.click();}")
    pg.wait_for_timeout(300)
    total = pg.evaluate("()=>window.__deck.total")

    # navigate to last page -> triggers count-up replay in the ORIGINAL bug
    pg.evaluate("(n)=>window.__deck.go(n-1)", total)
    pg.wait_for_timeout(150)
    ed = pg.evaluate("""()=>{var fs=document.getElementById('deckTrack').children;var last=fs[fs.length-1];
        var v=last.querySelector('.pct .v[data-to],.num .v[data-to],.v[data-to]');return v?v.getAttribute('data-edt'):null;}""")
    ck("found a last-page count-up number", ed is not None, ed)

    if ed:
        # focus the number and select its contents IMMEDIATELY (during would-be animation),
        # then type via the REAL keyboard so the count-up race is actually exercised.
        pg.evaluate("""(ed)=>{var el=document.querySelector('[data-edt="'+ed+'"]');
            el.focus();var r=document.createRange();r.selectNodeContents(el);
            var s=window.getSelection();s.removeAllRanges();s.addRange(r);}""", ed)
        pg.keyboard.type("99", delay=40)
        pg.wait_for_timeout(700)
        live = pg.evaluate("""(ed)=>{var el=document.querySelector('[data-edt="'+ed+'"]');
            return {text:el.textContent,to:el.getAttribute('data-to'),dep:el.getAttribute('data-depedited')};}""", ed)
        print("after typing 99 (edit, +700ms):", live)
        ck("typed value not clobbered by count-up (text stays 99)", live.get("text") == "99", live)
        ck("data-to updated to 99", live.get("to") == "99", live)

        # blur + manual save
        pg.evaluate("()=>document.activeElement&&document.activeElement.blur()"); pg.wait_for_timeout(120)
        pg.evaluate("()=>{var b=document.querySelector('#depSaveBox .dep-savebtn');if(b)b.click();}")
        pg.wait_for_timeout(1200)

        # reopen (same profile -> snapshot present) and verify persistence
        pg2 = ctx.new_page()
        pg2.goto(DECK, wait_until="load"); pg2.wait_for_timeout(1500)
        pg2.evaluate("(n)=>window.__deck&&window.__deck.go(n-1)", total)
        pg2.wait_for_timeout(3000)  # let presentation-mode count-up settle to terminal
        after = pg2.evaluate("""(ed)=>{var el=document.querySelector('[data-edt="'+ed+'"]');
            return el?{text:el.textContent,to:el.getAttribute('data-to')}:null;}""", ed)
        print("after reload:", after)
        ck("reload: data-to persists as 99", after and after.get("to") == "99", after)
        ck("reload: number settles to 99", after and after.get("text") == "99", after)

    ctx.close()

print("\n==== " + ("ALL PASS" if not fails else ("FAILED: " + ", ".join(fails))) + " ====")
sys.exit(1 if fails else 0)
