from playwright.sync_api import sync_playwright
import pathlib, sys
_t = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_t).resolve())

fails=[]
def ck(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ")+name+("" if cond else "  <<< "+str(extra)))
    if not cond: fails.append(name)

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    ctx = b.new_context(viewport={"width":1280,"height":720})
    pg = ctx.new_page()
    pg.goto(url); pg.wait_for_timeout(800)
    ck("version is 3.11", pg.evaluate("()=>window.__deckEditorPlus&&window.__deckEditorPlus.v")=="3.11")
    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(200)

    # helper in-page: title of a frame
    TITLE = """(fi)=>{var t=document.getElementById('deckTrack');var f=t.children[fi];
        return f.querySelector('.ptitle,h1,h2,.stat .t,p');}"""

    # ===== TEST A: edit page0 title, other pages' fontSize UNCHANGED =====
    fs_before = pg.evaluate("""()=>{var t=document.getElementById('deckTrack');var o=[];
        for(var i=0;i<t.children.length;i++){var e=t.children[i].querySelector('.ptitle,h1,h2,.stat .t,p');
        o.push(e?getComputedStyle(e).fontSize:null);}return o;}""")
    pg.evaluate("""()=>{var P=window.__deckEditorPlus;var t=document.getElementById('deckTrack');
        P.go(0);var e=t.children[0].querySelector('.ptitle,h1,h2,.stat .t,p');e.click();
        var fb=document.querySelectorAll('#depFont button');for(var k=0;k<8;k++)fb[1].click();}""")
    pg.wait_for_timeout(150)
    fs_after = pg.evaluate("""()=>{var t=document.getElementById('deckTrack');var o=[];
        for(var i=0;i<t.children.length;i++){var e=t.children[i].querySelector('.ptitle,h1,h2,.stat .t,p');
        o.push(e?getComputedStyle(e).fontSize:null);}return o;}""")
    ck("A: edited page0 title grew", fs_after[0]!=fs_before[0], (fs_before[0],fs_after[0]))
    others_same = all(fs_after[i]==fs_before[i] for i in range(1,len(fs_before)))
    ck("A: other pages' titles UNCHANGED", others_same, list(zip(fs_before,fs_after)))

    # ===== TEST B: duplicate page0 -> edit the DUP -> source page0 UNCHANGED =====
    src0 = pg.evaluate("(f)=>getComputedStyle(f).fontSize", pg.evaluate_handle(TITLE,0))
    pg.evaluate("""()=>{var P=window.__deckEditorPlus;P.go(0);
        var bs=document.querySelectorAll('#depBar button');
        for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf('复制本页')>=0){bs[i].click();break;}}}""")
    pg.wait_for_timeout(200)
    # duplicated page is now index 1; edit its title BIG
    dupFS_before = pg.evaluate("(f)=>getComputedStyle(f).fontSize", pg.evaluate_handle(TITLE,1))
    src0_before  = pg.evaluate("(f)=>getComputedStyle(f).fontSize", pg.evaluate_handle(TITLE,0))
    pg.evaluate("""()=>{var P=window.__deckEditorPlus;var t=document.getElementById('deckTrack');
        P.go(1);var e=t.children[1].querySelector('.ptitle,h1,h2,.stat .t,p');e.click();
        var fb=document.querySelectorAll('#depFont button');for(var k=0;k<10;k++)fb[1].click();}""")
    pg.wait_for_timeout(150)
    dupFS_after = pg.evaluate("(f)=>getComputedStyle(f).fontSize", pg.evaluate_handle(TITLE,1))
    src0_after  = pg.evaluate("(f)=>getComputedStyle(f).fontSize", pg.evaluate_handle(TITLE,0))
    ck("B: duplicated page edit took effect", dupFS_after!=dupFS_before, (dupFS_before,dupFS_after))
    ck("B: SOURCE page0 UNCHANGED when editing its duplicate", src0_after==src0_before, (src0_before,src0_after))

    # unique data-deppg per frame?
    deppgs = pg.evaluate("""()=>{var t=document.getElementById('deckTrack');var o=[];
        for(var i=0;i<t.children.length;i++)o.push(t.children[i].getAttribute('data-deppg'));return o;}""")
    present = [d for d in deppgs if d]
    ck("B: all deppg ids unique", len(present)==len(set(present)), deppgs)

    # ===== TEST C: save round-trip survives add-page then reload =====
    # Use a data-edt node (its key is baked into the file), so a PLAIN reload can restore it.
    # This isolates the RC1 storeKey fix: structural change (add page) must NOT orphan the draft.
    editC = pg.evaluate("""()=>{var t=document.getElementById('deckTrack');
        var e=t.children[0].querySelector('[data-edt]');if(!e)return null;
        window.__deckEditorPlus.go(0);e.click();
        var fb=document.querySelectorAll('#depFont button');for(var k=0;k<8;k++)fb[1].click();
        return {edt:e.getAttribute('data-edt'),fs:getComputedStyle(e).fontSize};}""")
    ck("C: found a data-edt node to edit", editC is not None, editC)
    if editC:
        # add a blank page (structural change) -> would trigger old RC1 storeKey rotation
        pg.evaluate("""()=>{var bs=document.querySelectorAll('#depBar button');
            for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf('空白页')>=0){bs[i].click();break;}}}""")
        pg.wait_for_timeout(450)  # let debounced persist flush
        pg.goto(url); pg.wait_for_timeout(900)
        restoredC = pg.evaluate("""(edt)=>{var e=document.querySelector('[data-edt="'+edt+'"]');
            return e?getComputedStyle(e).fontSize:null;}""", editC["edt"])
        ck("C: data-edt edit RESTORED after add-page+reload (RC1)", restoredC==editC["fs"], (editC["fs"],restoredC))

    ctx.close(); b.close()

print("\n==== %d FAIL ====" % len(fails) if fails else "\n==== ALL PASS ====")
sys.exit(1 if fails else 0)
