from playwright.sync_api import sync_playwright
import pathlib, json
url="file://"+str(pathlib.Path("/tmp/e2r/deck.edit.html").resolve())
with sync_playwright() as p:
    b=p.chromium.launch(headless=True)
    pg=b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(1200)
    pg.evaluate("()=>{var e=document.getElementById('deckEdit');if(e)e.click();}")
    pg.wait_for_timeout(200)
    pg.evaluate("()=>{window.__deck&&window.__deck.go&&window.__deck.go(1);}")
    pg.wait_for_timeout(150)
    r=pg.evaluate(r"""()=>{
      var bar=document.getElementById('depBar');
      bar.querySelectorAll('button')[4].click(); // +card float on page1
      // duplicate current page -> moves to page2 (the clone)
      bar.querySelectorAll('button')[0].click();
      // find the float on the now-current page (the clone)
      var fs=document.getElementById('deckTrack').children;
      var cur=window.__deck.cur();
      var fl=fs[cur].querySelector('.dep-float');
      if(!fl) return {err:'no float on cloned page'};
      var L0=parseFloat(fl.style.left)||0;
      // simulate drag: dispatch mousedown/move/up
      var rect=fl.getBoundingClientRect();
      function ev(type,x,y){var e=new MouseEvent(type,{bubbles:true,clientX:x,clientY:y});fl.dispatchEvent(type==='mousedown'?e:document.dispatchEvent(e)&&e);return e;}
      fl.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,clientX:rect.left+5,clientY:rect.top+5}));
      document.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:rect.left+85,clientY:rect.top+65}));
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      var L1=parseFloat(fl.style.left)||0;
      // test delete button works
      var before=document.querySelectorAll('.dep-float').length;
      fl.querySelector('.dep-elx').click();
      var after=document.querySelectorAll('.dep-float').length;
      return {leftBefore:L0, leftAfter:L1, moved:(L1!==L0), delWorks:(after===before-1)};
    }""")
    print("DRAG/DEL PROBE:", json.dumps(r,ensure_ascii=False))
    assert r.get("moved"), "cloned float must be draggable"
    assert r.get("delWorks"), "cloned float delete button must work"
    print("PROBE PASSED")
    b.close()
