from playwright.sync_api import sync_playwright
import pathlib, sys
# bug#5 —— 新建卡片(＋卡片/＋文字/＋图片)入场动效在【默认视图退出编辑】后应重放一次。
# 早前只有翻页(deck:nav)/投影(projector)/演讲者(speaker,blob 重载自动播)能看到动效;
# 编辑态新建的浮层其 CSS both 入场动效在插入时即播完停终态,退出编辑回默认视图同页无重放 → 无动效。
target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url="file://"+str(pathlib.Path(target).resolve())
with sync_playwright() as p:
    b=p.chromium.launch(headless=True)
    pg=b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(900)
    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(200)
    pg.evaluate("()=>window.__deck.go(1)"); pg.wait_for_timeout(150)
    pg.evaluate("""()=>{var bs=document.querySelectorAll('#depBar button');
      for(var i=0;i<bs.length;i++){if((bs[i].textContent||'').indexOf('＋卡片')>=0){bs[i].click();break;}}}""")
    pg.wait_for_timeout(700)
    pg.evaluate("()=>document.getElementById('deckEdit').click()")
    # sample mid-animation
    pg.wait_for_timeout(120)
    mid=pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var c=f.querySelectorAll('.dep-float.dep-card .dep-fanim.dep-anim');var a=c[c.length-1];
      return parseFloat(getComputedStyle(a).opacity);}""")
    pg.wait_for_timeout(700)
    end=pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var c=f.querySelectorAll('.dep-float.dep-card .dep-fanim.dep-anim');var a=c[c.length-1];
      return parseFloat(getComputedStyle(a).opacity);}""")
    print("mid opacity:",mid,"| end opacity:",end)
    assert mid<0.99, "must be mid-animation (not instantly full)"
    assert end>0.99, "must converge to fully visible"
    print("EXIT-EDIT DEFAULT REPLAY PASSED")
    b.close()
