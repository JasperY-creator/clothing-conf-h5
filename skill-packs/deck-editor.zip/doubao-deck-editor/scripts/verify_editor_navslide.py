from playwright.sync_api import sync_playwright
import pathlib, json, sys
# bug#6 权威回归:翻页入场动效必须在【宿主 .55s 整页滑入过渡到位后】才播,而不是固定 30ms
# 就在侧滑期把动效偷播掉。旧实现固定 30ms → 动效整段落在页面还没进视口中央时,滑动结束(~550ms)
# 动效恰好也播完停在终态 → 用户看到「到位即终态、没有入场」。全屏投影下更明显,「新建页面上的
# 新建卡片」是必现(新页是运行时插入,armProjectionArrival 只武装进投影时的当前页,翻到新页只走
# deck:nav 这条固定延时路径)。
# 修法:翻到目标页先 holdAnims 摁回起始态(滑入期绝不露终态),由 track 的 transitionend(transform)
# 驱动 release+重放(页面居中静止后才播),附 620ms 安全兜底。
# 本测试断言:在全屏投影下【翻到一张运行时新建、且带新建卡片的页】,卡片入场动效的 animationstart
# 必须发生在【track 滑入 transitionend 之后】(即页面到位后才播),且最终收敛到 opacity:1。
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    ctx = b.new_context(viewport={"width":1280,"height":720})
    ctx.on("page", lambda pop: None)  # swallow speaker popup if any
    pg = ctx.new_page()
    pg.goto(url); pg.wait_for_timeout(1200)

    # 编辑态:定位到首页 → ＋复制本页 得到一张运行时新建页 → 在其上 ＋卡片
    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(220)
    pg.evaluate("()=>window.__deck.go(0)"); pg.wait_for_timeout(120)
    pg.evaluate("()=>document.getElementById('depBar').querySelectorAll('button')[0].click()"); pg.wait_for_timeout(240)  # 复制本页
    newPage = pg.evaluate("()=>window.__deck.cur()")
    assert newPage == 1, "new page inserted right after page0"
    pg.evaluate("()=>document.getElementById('depBar').querySelectorAll('button')[4].click()"); pg.wait_for_timeout(260)  # ＋卡片
    pg.evaluate(r"""(np)=>{var f=window.__deck.frames[np];
      var cs=f.querySelectorAll('.dep-float.dep-card .dep-fanim');
      window.__cardInner=cs[cs.length-1];}""", newPage)
    assert pg.evaluate("()=>!!window.__cardInner"), "new card exists on new page"

    # 退出编辑,回到首页,进全屏投影(伪造 fullscreenElement + fullscreenchange)
    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(260)
    pg.evaluate("()=>window.__deck.go(0)"); pg.wait_for_timeout(200)
    pg.evaluate(r"""()=>{try{Object.defineProperty(document,'fullscreenElement',{configurable:true,get:function(){return document.documentElement;}});}catch(e){}
      document.body.classList.add('deck-projecting');}"""); pg.wait_for_timeout(60)
    pg.evaluate("()=>document.dispatchEvent(new Event('fullscreenchange'))"); pg.wait_for_timeout(1000)

    # 埋点:记录 track 的 transform transitionend(滑入到位)与卡片 animationstart 的相对时刻
    pg.evaluate(r"""()=>{
      window.__ev=[]; window.__T0=Date.now();
      var tr=document.getElementById('deckTrack');
      tr.addEventListener('transitionend',function(e){
        if(e.target===tr&&(!e.propertyName||e.propertyName==='transform'))
          window.__ev.push({k:'slide-end',t:Date.now()-window.__T0});});
      var el=window.__cardInner;
      el.addEventListener('animationstart',function(){window.__ev.push({k:'anim-start',t:Date.now()-window.__T0});});
      el.addEventListener('animationend',function(){window.__ev.push({k:'anim-end',t:Date.now()-window.__T0,op:getComputedStyle(el).opacity});});
    }""")

    # 全屏投影下翻到那张【运行时新建 + 带新建卡片】的页
    pg.evaluate("(np)=>window.__deck.go(np)", newPage)
    pg.wait_for_timeout(1600)
    ev = pg.evaluate("()=>window.__ev")
    print("timeline:", json.dumps(ev, ensure_ascii=False))
    slide = [e["t"] for e in ev if e["k"]=="slide-end"]
    astart = [e["t"] for e in ev if e["k"]=="anim-start"]
    aend = [e["t"] for e in ev if e["k"]=="anim-end"]
    settled = float(pg.evaluate("()=>getComputedStyle(window.__cardInner).opacity")) == 1.0

    assert astart, "card entrance animation MUST fire on the new page in projection (bug#6)"
    assert slide, "track slide transition must occur when navigating to the new page"
    # 关键断言:动效开始 必须晚于 滑入到位(页面居中静止后才播,不在侧滑期偷播)
    print("anim-start:", astart, "slide-end:", slide, "anim-end:", aend, "settled:", settled)
    assert astart[0] >= slide[0]-30, (
        "entrance must (re)start AFTER the page has slid into place (>=slide-end), "
        "not during the off-screen slide — else user never sees it. "
        "anim-start=%s slide-end=%s" % (astart[0], slide[0]))
    assert settled, "card must settle to opacity:1"
    print("BUG#6 SLIDE-AWARE REPLAY PASSED — new-page new-card entrance plays AFTER slide, in fullscreen")
    b.close()
