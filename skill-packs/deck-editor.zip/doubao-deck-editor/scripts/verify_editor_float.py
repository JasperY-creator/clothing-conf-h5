from playwright.sync_api import sync_playwright
import pathlib, json, sys
_target = sys.argv[1] if len(sys.argv) > 1 else "deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(700)

    # enter edit mode
    pg.evaluate("() => { var e=document.getElementById('deckEdit'); if(e) e.click(); }")
    pg.wait_for_timeout(300)

    # add one of each kind via top bar buttons
    added = pg.evaluate(r"""() => {
      var bar=document.getElementById('depBar');
      var btns=bar.querySelectorAll('button');
      // buttons: [0]dup [1]blank [2]del [3]+text [4]+card [5]+img [6]export
      var labels=[]; for(var i=0;i<btns.length;i++)labels.push(btns[i].textContent);
      btns[3].click(); btns[4].click(); btns[5].click();
      var fls=document.querySelectorAll('.dep-float');
      var kinds=[]; for(var j=0;j<fls.length;j++)kinds.push(fls[j].getAttribute('data-depfloat'));
      return {labels:labels, count:fls.length, kinds:kinds};
    }""")
    print("01 add floats:", json.dumps(added, ensure_ascii=False))
    assert added["count"] == 3, "should have 3 floats"
    assert set(added["kinds"]) == {"text","card","img"}, "one of each kind"

    # scale a float via .dep-scaler + button, then drag it
    moved = pg.evaluate(r"""() => {
      var fl=document.querySelector('.dep-float.dep-text');
      var beforeT=fl.style.transform;
      var sc=fl.querySelector('.dep-scaler').querySelectorAll('button'); // [-,+,reset]
      sc[1].click(); sc[1].click();
      var afterScale=fl.style.transform;
      var l0=parseFloat(fl.style.left)||0, t0=parseFloat(fl.style.top)||0;
      var r=fl.getBoundingClientRect();
      fl.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,clientX:r.left+5,clientY:r.top+5}));
      document.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,clientX:r.left+55,clientY:r.top+35}));
      document.dispatchEvent(new MouseEvent('mouseup',{bubbles:true}));
      return {beforeT:beforeT, afterScale:afterScale, l0:l0, t0:t0,
              l1:parseFloat(fl.style.left)||0, t1:parseFloat(fl.style.top)||0};
    }""")
    print("02 scale+drag:", json.dumps(moved, ensure_ascii=False))
    assert "scale" in moved["afterScale"], "scaler should write transform:scale"
    assert moved["l1"]!=moved["l0"] or moved["t1"]!=moved["t0"], "drag should move left/top"

    # delete one float via .dep-elx
    deleted = pg.evaluate(r"""() => {
      var before=document.querySelectorAll('.dep-float').length;
      var fl=document.querySelector('.dep-float.dep-card');
      fl.querySelector('.dep-elx').click();
      return {before:before, after:document.querySelectorAll('.dep-float').length};
    }""")
    print("03 delete float:", json.dumps(deleted, ensure_ascii=False))
    assert deleted["after"] == deleted["before"]-1, "delete should remove one"

    # export: floats must survive into cloned HTML; contenteditable stripped
    exp = pg.evaluate(r"""() => {
      var clone=document.documentElement.cloneNode(true);
      var eds=clone.querySelectorAll('[contenteditable]');
      var floats=clone.querySelectorAll('.dep-float').length;
      return {floats:floats, editable:eds.length};
    }""")
    print("04 export snapshot:", json.dumps(exp, ensure_ascii=False))
    assert exp["floats"] >= 2, "floats should persist into export clone"

    print("FLOAT ASSERTIONS PASSED")
    b.close()
