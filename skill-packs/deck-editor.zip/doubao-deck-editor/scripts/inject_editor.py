#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
doubao-deck-editor / inject_editor.py

把「增强编辑层」(CSS + JS)注入到 doubao-html-deck-generator 生成的 deck.html,
产出一份带增强编辑能力的新 HTML。

增强层不重复造轮子——它复用宿主 deck 已有的编辑契约:
  - data-edt   : 可编辑文字节点(宿主已支持 contenteditable 改文案)
  - data-edimg : 可编辑图片位(宿主已支持上传/替换/清空)
  - #deckEdit  : 编辑模式开关(toggle body.deck-editing)
  - #deckExport: 导出新 HTML(克隆 documentElement 下载)
  - window.__deck : {go, frames, total, cur} 翻页控制器
  - #deckTrack : 横向 track,子元素为各 .deck-frame

增强层只叠加宿主没有的三块能力:
  1. 页面级:增加页(复制当前页) / 删除页 / 拖拽重排顺序
  2. 字号:选中文字后浮动工具条 A- / A+ / 复位(写内联覆盖)
  3. 图片位置/缩放:图片位拖拽移动 + 滚轮/按钮缩放(写内联 transform)

所有改动都直接落在真实 DOM 上,因此宿主的 #deckExport「克隆 documentElement 下载」
会天然把结构变更、内联字号、图片 transform 一并固化到导出的 HTML。
字号与图片 transform 另存一份 localStorage 草稿(deckeditplus:<hash>),刷新不丢;
结构性变更(增/删/重排页)以「导出即固化」为准。

用法:
  python3 inject_editor.py deck.html                  # 产出 deck.edit.html
  python3 inject_editor.py deck.html -o out.html      # 指定输出
  python3 inject_editor.py deck.html --in-place        # 原地写回(先备份 .bak)
  python3 inject_editor.py deck.html --check           # 只检测是否已注入,不写文件
"""

import argparse
import os
import re
import sys
import shutil

MARKER = "__deckEditorPlus"  # 幂等哨兵:出现即视为已注入
BEGIN = "<!-- doubao-deck-editor:begin -->"
END = "<!-- doubao-deck-editor:end -->"
SIG_TOKEN = "__DECK_BAKED_SIG__"  # 运行期常量占位符,注入时按宿主原始内容算好写死

EDITOR_CSS = r"""
<style id="deckEditorPlusCSS">
/* ===== doubao-deck-editor 增强层样式 ===== */
/* 仅在宿主编辑模式(body.deck-editing)开启时显示增强控件 */
.dep-hidden{display:none !important;}

/* 顶部增强工具条 */
#depBar{position:fixed;top:10px;left:50%;transform:translateX(-50%);
  z-index:2147483000;display:flex;gap:8px;align-items:center;
  padding:6px 10px;border-radius:12px;font:13px/1.2 system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;
  background:rgba(20,22,28,.92);color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.35);
  backdrop-filter:blur(6px);}
#depBar button{cursor:pointer;border:0;border-radius:8px;padding:5px 10px;
  font-size:12px;background:#3a3f4b;color:#fff;transition:background .15s;}
#depBar button:hover{background:#4a5160;}
#depBar .dep-sep{width:1px;height:18px;background:rgba(255,255,255,.18);margin:0 2px;}
#depBar .dep-title{font-weight:600;opacity:.85;margin-right:2px;}

/* 右上角:全量保存 + 上次保存时间(仅编辑态显示)。position:fixed 独立于顶部工具条,
   避免居中工具条溢出;导出/投影时随 dep-hidden 一并隐藏,不进产物。 */
#depSaveBox{position:fixed;top:10px;right:12px;z-index:2147483001;display:flex;gap:8px;align-items:center;
  padding:6px 10px;border-radius:12px;font:13px/1.2 system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;
  background:rgba(20,22,28,.92);color:#fff;box-shadow:0 6px 24px rgba(0,0,0,.35);backdrop-filter:blur(6px);}
#depSaveBox .dep-savebtn{cursor:pointer;border:0;border-radius:8px;padding:5px 12px;font-size:12px;font-weight:600;
  background:#2B6CF0;color:#fff;transition:background .15s;}
#depSaveBox .dep-savebtn:hover{background:#3B7BF5;}
#depSaveBox .dep-savest{font-size:11px;color:#9fb0c9;white-space:nowrap;min-width:76px;text-align:right;}
#depSaveBox .dep-savest.dep-dirty{color:#ffb454;}
#depSaveBox .dep-savest.dep-saved{color:#7fd39b;}

/* 页面管理侧栏 */
#depRail{position:fixed;top:56px;left:10px;bottom:10px;width:184px;z-index:2147482900;
  display:flex;flex-direction:column;gap:6px;padding:8px;overflow-y:auto;
  background:rgba(20,22,28,.9);border-radius:12px;box-shadow:0 6px 24px rgba(0,0,0,.3);}
#depRail .dep-railhd{font:600 11px system-ui;color:#cbd3e1;letter-spacing:.4px;
  padding:2px 2px 4px;position:sticky;top:0;}
.dep-chip{position:relative;display:flex;align-items:center;gap:6px;cursor:grab;
  padding:8px 8px;border-radius:8px;background:#2b303b;color:#e7ecf5;
  font:12px system-ui;user-select:none;border:1px solid transparent;}
.dep-chip:hover{background:#333a48;}
.dep-chip.dep-cur{border-color:#6ea0ff;background:#31405e;}
.dep-chip.dep-drag{opacity:.5;}
.dep-chip.dep-over{border-color:#9ec1ff;box-shadow:inset 0 0 0 1px #9ec1ff;}
.dep-chip .dep-idx{min-width:18px;text-align:center;font-weight:700;color:#8fa9d6;}
.dep-chip .dep-meta{display:flex;flex-direction:column;gap:1px;min-width:0;flex:1;}
.dep-chip .dep-ttl{font-size:12px;color:#e7ecf5;line-height:1.3;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.dep-chip .dep-mod{opacity:.55;font-size:10px;letter-spacing:.3px;text-transform:uppercase;}
.dep-chip .dep-del{margin-left:auto;border:0;background:transparent;color:#ff8a8a;
  cursor:pointer;font-size:13px;line-height:1;padding:2px 4px;border-radius:6px;}
.dep-chip .dep-del:hover{background:rgba(255,138,138,.16);}

/* 文字字号浮动工具条 */
#depFont{position:fixed;z-index:2147483200;display:flex;gap:4px;align-items:center;
  padding:4px 6px;border-radius:10px;background:rgba(20,22,28,.95);color:#fff;
  box-shadow:0 4px 16px rgba(0,0,0,.35);font:12px system-ui;}
#depFont button{cursor:pointer;border:0;border-radius:6px;width:26px;height:24px;
  background:#3a3f4b;color:#fff;font-size:13px;}
#depFont button:hover{background:#4a5160;}
#depFont .dep-fs{min-width:40px;text-align:center;opacity:.9;}
#depFont .dep-sepv{width:1px;height:18px;background:rgba(255,255,255,.18);margin:0 3px;}
/* 色板通用样式(字号条里的文字色 + deco 面板里的描边色共用) */
.dep-sw{cursor:pointer;width:18px;height:18px;border-radius:5px;border:1px solid rgba(255,255,255,.35);
  padding:0;flex:0 0 auto;box-shadow:0 1px 3px rgba(0,0,0,.3);}
.dep-sw.dep-grad{background:linear-gradient(100deg,#212938 0%,#2B6CF0 62%,#8273E0 100%);}
.dep-sw.dep-reset{background:#5a6172;color:#fff;font-size:11px;line-height:16px;text-align:center;border-style:dashed;}

/* 卡片/数字装饰面板:动效 + 描边色 */
#depDeco{position:fixed;z-index:2147483200;display:flex;flex-direction:column;gap:6px;
  padding:8px 10px;border-radius:10px;background:rgba(20,22,28,.96);color:#fff;
  box-shadow:0 4px 16px rgba(0,0,0,.4);font:12px system-ui;min-width:180px;}
#depDeco .dep-row{display:flex;gap:5px;align-items:center;}
#depDeco .dep-lbl{opacity:.7;min-width:52px;font-size:11px;}
#depDeco .dep-cap{font-size:11px;opacity:.92;padding:1px 2px 3px;border-bottom:1px solid rgba(255,255,255,.12);margin-bottom:2px;line-height:1.5;}
#depDeco .dep-cap b{color:#8fb6ff;font-weight:600;}
#depDeco .dep-anb{cursor:pointer;border:0;border-radius:6px;padding:4px 8px;font-size:11px;
  background:#3a3f4b;color:#fff;}
#depDeco .dep-anb:hover{background:#4a5160;}
#depDeco .dep-anb.dep-on{background:#31405e;box-shadow:inset 0 0 0 1px #6ea0ff;}

/* ===== Batch D: 可调/删/加 的入场动效(类驱动 + !important,能扛住宿主 replayCards
   只清 inline animation 的重放;宿主 SEL 命中的卡片会随 deck:nav 自动重放)===== */
@keyframes depFadeIn{from{opacity:0;transform:none;}to{opacity:1;transform:none;}}
@keyframes depRiseIn{from{opacity:0;transform:translateY(24px);}to{opacity:1;transform:translateY(0);}}
@keyframes depZoomIn{from{opacity:0;transform:scale(.92);}to{opacity:1;transform:scale(1);}}
.dep-anim-fade{animation:depFadeIn .6s ease both !important;}
.dep-anim-rise{animation:depRiseIn .6s cubic-bezier(.22,.9,.32,1) both !important;}
.dep-anim-zoom{animation:depZoomIn .6s cubic-bezier(.22,.9,.32,1) both !important;}
/* 「无」= 去掉入场动效,但必须把卡片强制显现到最终静止态。
   宿主卡片基础样式是 opacity:0(靠 mcCardIn 的 to{opacity:1} 才显现),若只写 animation:none
   会让卡片永远停在 opacity:0 → 整张卡片消失。故这里同时钉死 opacity:1 + transform:none,
   等价于「无动画、直接就位可见」。 */
.dep-anim-none{animation:none !important;opacity:1 !important;transform:none !important;}
/* dep-hostoff:v2.0 曾用它把宿主 mcCardIn 静音,好让「数字/文字子块」动效可见。v2.1 起动效
   恒作用整卡(我方类带 !important 已直接盖过 mcCardIn),不再需要静音,故此机制已退役。
   仅保留规则本身,以便重新注入 v2.0 老导出时能消掉其残留的 dep-hostoff 类观感一致;
   setAnim() 也会在挂类前顺手 remove('dep-hostoff') 做清理。新代码不再添加此类。 */
.dep-hostoff{animation:none !important;}
/* dep-projhold(bug#3 v2.6):进入全屏投影的【切换过渡期】把动效节点摁回起始态并暂停,
   使过渡期(黑屏/缩放中)绝不露出终态;全屏就位后由 JS 摘掉此类并干净重放入场。
   放在所有 dep-anim-* 之后,同为单类选择器时靠「后定义」在 !important 平手中胜出。 */
.dep-projhold{animation:none !important;opacity:0 !important;}

/* ===== Batch D: 卡片描边色(::before keyline)覆盖。写元素上的 --dep-edge 变量,
   规则以 !important 读取,导出克隆时随属性/内联变量一并固化。===== */
[data-dep-edge].stat::before,[data-dep-edge].card::before,[data-dep-edge].fpoint::before,
[data-dep-edge].rcard::before,[data-dep-edge].impact .card::before,
[data-dep-edge]::before{background:var(--dep-edge) !important;}
/* dep-card 浮层本无 keyline,补一条,便于统一改描边色 */
.dep-float.dep-card[data-dep-edge]::before{content:"";position:absolute;left:0;top:0;bottom:0;
  width:4px;border-radius:16px 0 0 16px;background:var(--dep-edge);}

/* ===== Batch D: 文字渐变模板色(PPT 模板渐变字)。整段或选区 span 共用。===== */
.dep-grad-text{background:var(--fs-grad-title,linear-gradient(100deg,#212938 0%,#2B6CF0 62%,#8273E0 100%)) !important;
  -webkit-background-clip:text !important;background-clip:text !important;
  -webkit-text-fill-color:transparent !important;color:transparent !important;}
/* 段内特定文字放大 / 变色的行内包裹 */
.dep-fs-run{display:inline;}

/* ===== 修:渐变裁字(-webkit-background-clip:text + text-fill-color:transparent)在
   编辑态获得光标/焦点时,Chromium 会漏掉对透明填充字形的重绘 → 整块文字消失,点别处
   才恢复(团队标题 .tname / 痛点大数字 .bignum 等)。宿主 v0.2.7 只修了 .cover h2;
   这里做成模板无关:JS 在 focusin 时给命中渐变裁字的可编辑元素打 .dep-gradedit,
   本规则强制其改用实心 currentColor 填充并关掉裁剪,逼一次完整重绘;focusout 时摘类,
   未编辑的标题仍保留渐变观感。仅编辑态生效,不进导出产物。 */
body.deck-editing .dep-gradedit,
body.deck-editing .dep-gradedit *,
body.deck-editing .dep-gradedit .dep-grad-text,
body.deck-editing .dep-gradedit.dep-grad-text{
  -webkit-text-fill-color:var(--dep-solid,currentColor) !important;
  color:var(--dep-solid,currentColor) !important;
  -webkit-background-clip:initial !important;background-clip:initial !important;
  background:none !important;}


/* 图片位:编辑模式下的可拖拽态 + 手柄 */
body.deck-editing [data-edimg].dep-imgpos{outline:1px dashed rgba(110,160,255,.7);
  outline-offset:-1px;cursor:move;}
body.deck-editing [data-edimg].dep-imgpos img{will-change:transform;}
.dep-imgtool{position:absolute;right:6px;bottom:6px;z-index:60;display:flex;gap:4px;
  background:rgba(20,22,28,.92);border-radius:8px;padding:3px 4px;
  box-shadow:0 3px 12px rgba(0,0,0,.3);}
.dep-imgtool button{cursor:pointer;border:0;border-radius:6px;width:24px;height:22px;
  background:#3a3f4b;color:#fff;font-size:13px;line-height:1;}
.dep-imgtool button:hover{background:#4a5160;}

/* ===== 图片点击放大(lightbox)=====
   非编辑态点内容图片 → 全屏居中放大;右上角 ✕ / 点背景 / Esc 恢复。
   编辑态点=拖拽/选中,故此能力仅在 :not(.deck-editing) 生效(下方 JS 亦守卫)。
   可放大的图片(内容图 / 图片位 / 新增图片浮层)标 data-depzoom,给 zoom-in 光标提示。 */
body:not(.deck-editing) [data-edimg][data-depzoom],
body:not(.deck-editing) .dep-float.dep-img[data-depzoom],
body:not(.deck-editing) img[data-depzoom]{cursor:zoom-in;}
#depLightbox{position:fixed;top:0;right:0;bottom:0;left:0;z-index:2147483400;
  display:none;align-items:center;justify-content:center;
  background:rgba(6,8,12,.86);cursor:zoom-out;}
#depLightbox.dep-show{display:flex;}
#depLightbox img{max-width:92vw;max-height:92vh;width:auto;height:auto;object-fit:contain;
  border-radius:8px;box-shadow:0 24px 70px rgba(0,0,0,.6);background:#fff;cursor:default;
  transform:scale(.96);opacity:0;transition:transform .18s ease,opacity .18s ease;pointer-events:auto;}
#depLightbox.dep-show img{transform:scale(1);opacity:1;}
#depLbClose{position:absolute;top:16px;right:20px;z-index:2147483401;width:40px;height:40px;
  border:0;border-radius:50%;background:rgba(255,255,255,.16);color:#fff;font-size:19px;
  line-height:40px;text-align:center;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.35);}
#depLbClose:hover{background:rgba(255,255,255,.3);}

/* ===== 新增浮层元素(文字 / 图片 / 卡片)===== */
/* 新增内容脱离原栅格,以「可拖拽浮层」形式插入 page root,不破坏原版式。
   left/top 定位在页面 1280×720 坐标系内;transform-origin 取 top-left 便于精确缩放。 */
.dep-float{position:absolute;z-index:40;transform-origin:top left;}
body.deck-editing .dep-float{cursor:move;outline:1px dashed rgba(110,160,255,.55);outline-offset:2px;}
body.deck-editing .dep-float.dep-sel{outline:2px solid #6ea0ff;}
/* ✕ 删除 / ± 缩放:只在编辑模式显示,导出的 HTML 平时不显示、无残留观感 */
.dep-float .dep-elx,.dep-float .dep-scaler{display:none;}
body.deck-editing .dep-float .dep-elx{display:block;position:absolute;top:-11px;right:-11px;z-index:60;
  width:22px;height:22px;border:0;border-radius:50%;background:#ff6b6b;color:#fff;font-size:12px;
  line-height:22px;text-align:center;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.3);}
body.deck-editing .dep-float .dep-scaler{display:flex;position:absolute;bottom:-13px;right:-6px;z-index:60;gap:3px;}
.dep-float .dep-scaler button{width:22px;height:20px;border:0;border-radius:6px;background:#3a3f4b;
  color:#fff;font-size:12px;line-height:1;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,.25);}
.dep-float.dep-text{min-width:120px;max-width:640px;padding:6px 10px;font-size:24px;line-height:1.6;
  color:var(--fs-ink,#1a2233);font-weight:600;}
/* 文字框手动调宽高(issue#1):写过内联尺寸的框解除 min/max 约束,由用户自由拖拽。
   over-wrap 让长文本按框宽换行,不撑破手动宽度。 */
.dep-float.dep-text[data-depsized]{overflow-wrap:break-word;word-break:break-word;white-space:normal;}
/* 尺寸手柄:仅编辑模式可见,定位在框右下角内侧,与框外下方的 ±缩放条互不遮挡 */
.dep-float .dep-rz{display:none;}
body.deck-editing .dep-float.dep-text .dep-rz{display:block;position:absolute;right:2px;bottom:2px;
  z-index:62;width:12px;height:12px;border-radius:3px;background:#6ea0ff;border:2px solid #fff;
  box-shadow:0 1px 4px rgba(0,0,0,.35);cursor:nwse-resize;}
/* 中性卡片:用主题变量 --fs-* 跟随深浅主题,取不到则安全兜底 */
.dep-float.dep-card{min-width:200px;max-width:380px;padding:22px 24px;border-radius:16px;
  background:var(--fs-card,rgba(255,255,255,.92));border:1px solid var(--fs-line,rgba(20,40,80,.12));
  box-shadow:0 12px 34px rgba(20,40,80,.14);color:var(--fs-ink,#1a2233);}
.dep-float.dep-card .dep-cardt{font-weight:700;font-size:21px;margin-bottom:8px;color:var(--fs-accent,#2b6cff);}
.dep-float.dep-card .dep-cardb{font-size:15px;line-height:1.66;opacity:.86;}
/* 注意:不要在 .dep-float 上写 overflow:hidden——✕/± 按钮定位在框外(负偏移),
   一旦裁剪就整排看不见(曾出现「新增图片框的放大/缩小/重置/删除按钮看不到」的根因)。
   裁剪只落在内层 .dep-imgbox 上,图片被裁而按钮溢出可见。 */
.dep-float.dep-img{width:280px;height:170px;background:transparent;
  border:1px dashed var(--fs-line,rgba(20,40,80,.28));border-radius:12px;overflow:visible;
  display:flex;align-items:center;justify-content:center;}
/* 已上传图片(有 img 子节点)后,连虚线边也去掉——纯图片观感 */
.dep-float.dep-img.dep-has-img{border-color:transparent;}
.dep-float.dep-img img{width:100%;height:100%;object-fit:contain;pointer-events:none;}
.dep-float.dep-img .dep-imgph{font-size:13px;color:#5a6a85;pointer-events:none;}
.dep-float.dep-img .dep-imgbox{width:100%;height:100%;display:flex;align-items:center;
  justify-content:center;overflow:hidden;border-radius:11px;}
/* 内层动画包裹:外层 .dep-float 用 transform:scale() 缩放,入场动效放在内层,
   两个 transform 分层互不覆盖(否则 animation 的 translateY 会顶掉缩放)。 */
.dep-fanim{display:block;}
@keyframes depIn{from{opacity:0;transform:translateY(16px);}to{opacity:1;transform:translateY(0);}}
/* 入场动效:与原生卡片同款「淡入上浮」语言,由增强层在翻页时重放 */
.dep-fanim.dep-anim{animation:depIn .5s cubic-bezier(.2,.7,.2,1) both;}

/* 提示条 */
#depToast{position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:2147483300;
  background:rgba(20,22,28,.95);color:#fff;padding:8px 14px;border-radius:10px;
  font:13px system-ui;box-shadow:0 6px 20px rgba(0,0,0,.35);opacity:0;
  transition:opacity .2s;pointer-events:none;}
#depToast.dep-show{opacity:1;}

/* ===== v2.8 PPT 对齐能力:文字格式条 / 层级 / 形状 / 多选 / 对齐分布 / 吸附辅助线 ===== */
/* 文字格式条(B/I/U + 对齐 + 列表),挂在 #depFont 里,追加在色板之后,不打乱既有索引 */
#depFont .dep-fmt{cursor:pointer;border:0;border-radius:6px;min-width:24px;height:24px;padding:0 5px;
  background:#3a3f4b;color:#eef1f6;font-size:13px;line-height:1;}
#depFont .dep-fmt:hover{background:#4a5160;}
#depFont .dep-fmt.dep-on{background:#2b6cff;color:#fff;}
#depFont .dep-fmt b{font-weight:800;}#depFont .dep-fmt i{font-style:italic;}
#depFont .dep-fmt u{text-decoration:underline;}
/* 顶部工具条里新增按钮沿用 #depBar button 既有样式,无需额外规则 */
/* 形状浮层:矩形 / 圆 / 线 / 箭头。外层 .dep-float 定位缩放,内层 .dep-shbody 画形状 */
.dep-float.dep-shape{width:180px;height:120px;}
.dep-float.dep-shape .dep-shbody{width:100%;height:100%;display:block;pointer-events:none;}
.dep-float.dep-shape.dep-rect .dep-shbody{background:var(--dep-fill,#2b6cff);border:var(--dep-strk,0) solid var(--dep-strkc,#1a2233);border-radius:6px;}
.dep-float.dep-shape.dep-ellipse .dep-shbody{background:var(--dep-fill,#2b6cff);border:var(--dep-strk,0) solid var(--dep-strkc,#1a2233);border-radius:50%;}
.dep-float.dep-shape.dep-line .dep-shbody,
.dep-float.dep-shape.dep-arrow .dep-shbody{background:transparent;position:relative;}
.dep-float.dep-shape.dep-line .dep-shbody::before,
.dep-float.dep-shape.dep-arrow .dep-shbody::before{content:'';position:absolute;left:0;right:0;top:50%;
  height:0;border-top:calc(var(--dep-strk,3px)) solid var(--dep-fill,#2b6cff);transform:translateY(-50%);}
.dep-float.dep-shape.dep-arrow .dep-shbody::after{content:'';position:absolute;right:0;top:50%;
  width:0;height:0;border-left:12px solid var(--dep-fill,#2b6cff);
  border-top:8px solid transparent;border-bottom:8px solid transparent;transform:translateY(-50%);}
.dep-float.dep-shape.dep-line,.dep-float.dep-shape.dep-arrow{height:40px;}
/* 多选选框(与单选 .dep-sel 区分:多选用不同色便于识别) */
body.deck-editing .dep-float.dep-msel{outline:2px solid #ffb020 !important;outline-offset:2px;}
/* 成组:被组包裹的浮层组合 */
.dep-group{position:absolute;z-index:41;transform-origin:top left;}
body.deck-editing .dep-group{cursor:move;outline:1px dashed rgba(255,176,32,.7);outline-offset:3px;}
/* 对齐吸附辅助线(拖拽时临时显示) */
.dep-guide{position:absolute;z-index:2147483100;background:#ff3b7f;pointer-events:none;opacity:.9;}
.dep-guide.dep-gv{width:1px;top:0;bottom:0;}
.dep-guide.dep-gh{height:1px;left:0;right:0;}
/* 选中浮层/形状时的浮动操作条:层级 / 对齐分布 / 成组 / 形状填充描边 */
#depShape{position:fixed;z-index:2147483200;display:flex;flex-wrap:wrap;gap:4px;align-items:center;
  padding:6px 8px;border-radius:10px;background:#232833;box-shadow:0 8px 24px rgba(0,0,0,.4);
  font:12px/1.4 -apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:560px;}
#depShape.dep-hidden{display:none;}
#depShape .dep-cap{color:#aeb6c4;margin-right:2px;}
#depShape .dep-sepv{width:1px;height:18px;background:rgba(255,255,255,.18);margin:0 3px;}
#depShape button{cursor:pointer;border:0;border-radius:6px;min-width:26px;height:26px;padding:0 6px;
  background:#333a47;color:#e7ecf5;font-size:12px;}
#depShape button:hover{background:#4a5160;}
#depShape .dep-cw{width:20px;height:20px;border-radius:5px;border:1px solid rgba(255,255,255,.25);cursor:pointer;padding:0;}
@media print{#depBar,#depRail,#depFont,#depDeco,#depToast,#depSaveBox,.dep-imgtool,#depLightbox,.dep-guide,#depShape{display:none !important;}}
</style>
"""

# 增强运行时。ES5 风格,匹配宿主既有脚本与无头 Chromium。
EDITOR_JS = r"""
<script id="deckEditorPlusJS">
(function(){
  if(window.__deckEditorPlus)return;            /* 幂等:已注入则跳过 */
  window.__deckEditorPlus={v:'3.11'};

  function ready(fn){
    if(window.__deck){fn();return;}
    document.addEventListener('deck:ready',function h(){document.removeEventListener('deck:ready',h);fn();});
    /* 兜底:即便没接到 deck:ready 也在下一帧尝试 */
    setTimeout(function(){if(window.__deck)fn();},60);
  }

  ready(function(){
    var body=document.body;
    var track=document.getElementById('deckTrack');
    if(!track){warn('未找到 #deckTrack,增强层退化为仅字号/图片编辑');}
    var dotsWrap=document.querySelector('.deck-dots');
    var countEl=document.getElementById('deckCount');

    /* ---------- 修:宿主给 <script>/<style> 误铺 data-edt ----------
       宿主生成器把 count-up 等内联脚本节点也打上了 data-edt(本应只标可编辑文本)。
       data-edt 是宿主 collect()/演讲稿备注收集的存取键,于是脚本【源码】被当成一条
       「可编辑文本」抓进备注/演讲稿(用户可见的那段 (function(){...pickVs...})())。
       这里在初始化早期把非文本节点(SCRIPT/STYLE)上的 data-edt/data-edimg 摘掉,
       宿主再按 data-edt 收集时就不会碰到脚本源码;不进导出产物、不影响脚本执行。 */
    function stripScriptEdtAttrs(){
      try{
        var bad=document.querySelectorAll('script[data-edt],style[data-edt],script[data-edimg],style[data-edimg]');
        for(var i=0;i<bad.length;i++){
          bad[i].removeAttribute('data-edt');
          bad[i].removeAttribute('data-edimg');
        }
      }catch(e){}
    }
    stripScriptEdtAttrs();

    /* ---------- 持久化:字号 + 图片 transform ---------- */
    function hash(s){var h=5381,i=s.length;while(i){h=(h*33)^s.charCodeAt(--i);}return (h>>>0).toString(36);}
    /* docSig:文档【内容指纹】——把 document.title + 首屏页数 + 【全部页面的稳定文本】
       一起 hash。它在【每次载入的 raw 宿主内容】上计算(早于 restoreFull,故不受还原影响),
       只要底稿不变就稳定复现。设计取舍:
        · 不再只认 document.title —— 标题为空 / 两份 deck 同名时会命中【同一把 key】互相覆盖串档;
        · v3.6:采样【每一页】的稳定文本(见 frameText),而非只取首页标题+首个 data-edt——
          否则【非首页(尤其最后一页)】的文字改动不改指纹,导出的新内容会被旧缓存快照按同一把
          key 遮蔽,表现为「最后一页保存+导出后打开无变化」「同一 HTML 无痕≠正常模式」;
        · 仍【不含用户增删的页数】—— 指纹里的页数取自 raw 宿主首屏,是模板固定值,不随编辑漂移,
          故「新增/删除任意一页」不会让存取键旋转、既有编辑照样读得回(RC1 契约保持);
        · 宿主重新生成、内容变了 → 指纹变 → key 变 → 旧快照【自然不再命中】,新内容如实透出,
          不会被过期快照永久遮蔽(审查发现的「旧快照遮蔽」隐患由此根治)。 */
    /* 取一页的【稳定文本指纹】:遍历该页所有文本节点拼接;但【跳过】计数动画数字节点
       (含 data-to)内部的 live 文本——它从 0 数到终值,若并入会让指纹随「载入时恰好数到几」
       跨重载抖动——改用其 data-to 终值(稳定)代替。用 TreeWalker 只访问文本节点,不克隆
       DOM,故【不复制内联大图 src】,含几十 MB base64 图的真实 deck 也不吃内存。 */
    /* bug#8-B(v3.11):指纹此前只采【可见文本】,对【图片/媒体】完全失明——两份【文字相同、
       配图不同】的 deck 会命中【同一把 key】,于是 A 卷保存的旧快照会在 B 卷【正常模式】下经
       restoreFullAsync 的 `track.innerHTML=snap.html` 整段遮蔽 B 的真身;而【无痕模式】无缓存,
       如实透出文件自带内容 → 用户所见「同一 HTML 无痕正常、正常模式串了别卷内容」。修法:把每张
       图片 src(含 svg <image> href、内联 style 的 background url)的【全量哈希】并入 frameText,
       图变则指纹变、key 变、旧快照不再命中。用 hash() 摘要而非原样并入,避免把 4MB+ 的 base64
       data-uri 塞进指纹串(只多算一遍 djb2,一次载入内完成,可接受)。 */
    function mediaText(f){
      var toks=[],i,el,list,st,m;
      try{
        list=f.querySelectorAll?f.querySelectorAll('img[src]'):[];
        for(i=0;i<list.length;i++)toks.push('i'+hash(''+(list[i].getAttribute('src')||'')));
        list=f.querySelectorAll?f.querySelectorAll('image'):[];   /* svg <image> */
        for(i=0;i<list.length;i++){el=list[i];
          var h=el.getAttribute('href')||el.getAttribute('xlink:href')||
                (el.getAttributeNS&&el.getAttributeNS('http://www.w3.org/1999/xlink','href'))||'';
          toks.push('s'+hash(''+h));}
        list=f.querySelectorAll?f.querySelectorAll('[style*="background"]'):[];
        for(i=0;i<list.length;i++){st=(list[i].getAttribute('style')||'');
          m=st.match(/url\(([^)]*)\)/i);if(m)toks.push('b'+hash(m[1]));}
      }catch(e){}
      return toks.join(' ');
    }
    function frameText(f){
      if(!f)return '';
      var out=[];
      try{
        var w=document.createTreeWalker(f,NodeFilter.SHOW_TEXT,null,false),node;
        while((node=w.nextNode())){
          var p=node.parentNode,skip=false;
          while(p&&p!==f){
            var tn=(p.nodeName||'').toUpperCase();
            if(tn==='SCRIPT'||tn==='STYLE'){skip=true;break;}   /* 宿主给 <script> 铺了 data-edt,其源码不能并入文本指纹/备注 */
            if(p.getAttribute&&p.getAttribute('data-to')!=null){skip=true;break;}
            p=p.parentNode;
          }
          if(skip)continue;
          var s=(node.nodeValue||'').replace(/\s+/g,' ').trim();
          if(s)out.push(s);
        }
      }catch(e){
        /* 极老环境无 TreeWalker:退回整页 textContent(仍是确定性,只是含 live 数字) */
        out.push((f.textContent||'').replace(/\s+/g,' ').trim());
      }
      var nums=f.querySelectorAll?f.querySelectorAll('[data-to]'):[];
      for(var i=0;i<nums.length;i++)out.push('#'+(nums[i].getAttribute('data-to')||''));
      var md=mediaText(f);
      if(md)out.push('@M@'+md);   /* 折入图片/媒体摘要,令「文字同、配图异」的卷获得不同指纹 */
      return out.join(' ');
    }
    /* docSig 采样【全部页面】的稳定文本(不再只看首页标题+首个 data-edt)。这样【任意一页】
       (包括最后一页)的文字改动都会改变指纹 → 内容变了的【导出产物】获得不同 sig,重开时
       【不再被旧快照按同一把 key 遮蔽】(修「最后一页保存+导出后无变化」「无痕≠正常」的真 bug)。
       仍不含用户增删的页数(n 取 raw 首屏),保持 RC1「增删页不旋转存取键」契约。 */
    function deckSig(){
      var t=(document.title||'');
      var fs=track?track.children:[];var n=fs.length;
      var acc=t+'|'+n;
      for(var i=0;i<n;i++)acc+='||'+frameText(fs[i]);
      return hash(acc);
    }
    /* v3.9:docSig 优先取【注入时烘进文件的固定指纹】(__DECK_BAKED_SIG__)。
       根因:旧版每次载入都用【当下 live DOM】重算指纹,但宿主自带的 data-edt 回存层会在
       重载时改写 DOM(与 count-up 交互后甚至令某页文本重复),导致【同一文件】每次重载算出的
       指纹漂移(zxhgw→vele6f…)——于是我方保存的全量快照按旧 key 存、重载按新 key 找,永远
       对不上,表现为「(尤其最后一页的)数字/文字改了、保存了,一刷新又变回原样」。
       解法:指纹在【注入那一刻】按宿主原始内容算好、写死进文件,运行期直接读常量,不再受
       运行时 DOM 变动影响。契约不变:①宿主内容变→重新注入→烘进的指纹自然不同→旧快照不再命中;
       ②运行时增删页不改这枚常量→存取键不旋转,既有编辑照样读得回。仅当常量缺失(极老产物/
       手改文件)才回退到 live 计算。 */
    var BAKED_SIG='__DECK_BAKED_SIG__';
    var docSig=(BAKED_SIG&&BAKED_SIG.indexOf('DECK_BAKED')<0)?BAKED_SIG:deckSig();
    var storeKey='deckeditplus:'+docSig;
    var store={fonts:{},imgt:{}};
    try{var raw=localStorage.getItem(storeKey);if(raw){var o=JSON.parse(raw);store.fonts=o.fonts||{};store.imgt=o.imgt||{};}}catch(e){}
    var saveT=null;
    function persist(){clearTimeout(saveT);saveT=setTimeout(function(){
      try{localStorage.setItem(storeKey,JSON.stringify(store));}catch(e){}
    },300);markDirty();}

    /* ---------- 全量保存:整卷结构 + 所有编辑 快照 ----------
       字号/图片桶(store)一直随编辑去抖落盘,但【结构改动】(增/删/重排页、浮层增删移、
       形状、成组…)此前只「导出即固化」、不进本地存储 —— 用户反馈「想要一个保存按钮,
       点了就是真实的全量保存」。故点保存时把整条 #deckTrack 的净化后 innerHTML(内联编辑已
       烘进节点、剔除 contenteditable 与增强 UI 残留)连同 store 一起写盘;下次载入若存在该快照,
       先整段还原 track 再走常规回存/复活流程,刷新即所见即所得。

       v3.4 存储后端从 localStorage 换成 IndexedDB —— 含内联 base64 图片的真实 deck 动辄
       10MB+,而 localStorage 单域硬顶约 5MB(v3.3 到此只能报错拒存)。IndexedDB 容量到
       几百 MB~GB 级、且在 file:// 源下可用,足以承载整卷。localStorage 里仅留一条【几十字节】
       的元记录(sig/ts/cur/len),供【同步】判定「有无快照 / 存于何时」——启动与状态回显都要
       同步读到它;真正的大 HTML 走 IDB 异步取。旧版(≤3.3)写在 localStorage 的 fullKey 快照
       仍保留【读】兼容,启动时若 IDB 未命中会回退去读它。 */
    var fullKey='deckeditplusfull:'+docSig;         /* 旧版 localStorage 快照键(仅向后兼容读) */
    var metaKey='deckeditplusmeta:'+docSig;          /* v3.4 轻量元记录键(localStorage,几十字节) */
    var IDB_DB='deckeditplus', IDB_STORE='snaps';    /* v3.4 全量快照后端 */
    /* --- IndexedDB 极简封装(ES5 + Promise;无 Promise 的老环境自动回退到 localStorage) --- */
    function idbOK(){return (typeof indexedDB!=='undefined')&&(typeof window.Promise!=='undefined');}
    function idbOpen(){
      return new window.Promise(function(res,rej){
        var rq;try{rq=indexedDB.open(IDB_DB,1);}catch(e){rej(e);return;}
        rq.onupgradeneeded=function(e){try{e.target.result.createObjectStore(IDB_STORE);}catch(e2){}};
        rq.onsuccess=function(){res(rq.result);};
        rq.onerror=function(){rej(rq.error);};
        rq.onblocked=function(){rej(new Error('idb-blocked'));};
      });
    }
    function idbPut(key,val){
      return idbOpen().then(function(db){return new window.Promise(function(res,rej){
        var tx=db.transaction(IDB_STORE,'readwrite');
        tx.objectStore(IDB_STORE).put(val,key);
        tx.oncomplete=function(){try{db.close();}catch(e){}res(true);};
        tx.onabort=function(){try{db.close();}catch(e){}rej(tx.error||new Error('idb-abort'));};
        tx.onerror=function(){try{db.close();}catch(e){}rej(tx.error||new Error('idb-error'));};
      });});
    }
    function idbGet(key){
      return idbOpen().then(function(db){return new window.Promise(function(res,rej){
        var tx=db.transaction(IDB_STORE,'readonly');var g=tx.objectStore(IDB_STORE).get(key);
        g.onsuccess=function(){try{db.close();}catch(e){}res(g.result);};
        g.onerror=function(){try{db.close();}catch(e){}rej(g.error);};
      });});
    }
    function idbDel(key){
      return idbOpen().then(function(db){return new window.Promise(function(res){
        var tx=db.transaction(IDB_STORE,'readwrite');tx.objectStore(IDB_STORE)['delete'](key);
        tx.oncomplete=function(){try{db.close();}catch(e){}res(true);};
        tx.onerror=function(){try{db.close();}catch(e){}res(false);};
        tx.onabort=function(){try{db.close();}catch(e){}res(false);};
      });});
    }
    var _dirty=false,_savedTs=0,saveSt=null;
    function fmtTs(t){var d=new Date(t);function z(n){return (n<10?'0':'')+n;}
      var hm=z(d.getHours())+':'+z(d.getMinutes());
      var now=new Date();
      /* 同一天只显示 HH:MM;跨天补上 MM/DD,避免长会话里把昨天的保存误当作刚存 */
      if(d.getFullYear()===now.getFullYear()&&d.getMonth()===now.getMonth()&&d.getDate()===now.getDate())return hm;
      return z(d.getMonth()+1)+'/'+z(d.getDate())+' '+hm;}
    function paintSaveStatus(){
      if(!saveSt)return;
      saveSt.classList.remove('dep-dirty','dep-saved');
      if(_dirty){saveSt.textContent='● 未保存';saveSt.classList.add('dep-dirty');}
      else if(_savedTs){saveSt.textContent='已保存 '+fmtTs(_savedTs);saveSt.classList.add('dep-saved');}
      else{saveSt.textContent='未改动';}
    }
    function markDirty(){if(!_dirty){_dirty=true;paintSaveStatus();}}
    /* 取一份净化后的 track.innerHTML:与 buildSpeakerDocURL 同philosophy——先收起增强层
       (armImgSlots/armContentEdit(false) 摘掉 .dep-imgtool / 图片位类 / contenteditable),
       再克隆 track、剔除任何残留 contenteditable,序列化后把编辑态原样恢复。saveBox 挂在 body
       上、不在 track 内,天然不会进快照。 */
    function sanitizedTrackHTML(){
      var wasEd=body.classList.contains('deck-editing');
      if(wasEd)setEnhance(false);
      var clone=track.cloneNode(true);
      var eds=clone.querySelectorAll('[contenteditable]'),i;
      for(i=0;i<eds.length;i++)eds[i].removeAttribute('contenteditable');
      var html=clone.innerHTML;
      if(wasEd)setEnhance(true);
      return html;
    }
    function saveFull(){
      if(!track)return;
      try{localStorage.setItem(storeKey,JSON.stringify(store));}catch(e){}  /* 字号/图片桶即时落盘,不等去抖 */
      var snap={html:sanitizedTrackHTML(),ts:(+new Date()),cur:cur,sig:docSig};
      var payload=JSON.stringify(snap);
      var approxMB=(payload.length*2)/1048576;
      /* 上限抬到 IndexedDB 量级(远大于 localStorage 的 ~5MB)。留一个宽松硬顶纯粹防「内联图片
         彻底失控」把浏览器存崩;正常含图 deck(十几~几十 MB)都能存进 IDB。 */
      if(approxMB>200){tip('保存失败:内容体积约 '+approxMB.toFixed(1)+'MB,过大;请精简内联图片后重试');return;}
      function metaWrite(){
        /* localStorage 只放【几十字节】元记录:同步可读,用于启动判定与状态回显。 */
        try{localStorage.setItem(metaKey,JSON.stringify({ts:snap.ts,cur:snap.cur,sig:docSig,len:payload.length}));}catch(e){}
      }
      function onSaved(){
        try{localStorage.removeItem(fullKey);}catch(e){}   /* 清掉可能存在的旧版 localStorage 快照,避免双份 */
        metaWrite();_dirty=false;_savedTs=snap.ts;paintSaveStatus();tip('已全量保存');
      }
      if(idbOK()){
        idbPut(fullKey,payload).then(onSaved)['catch'](function(err){
          /* IDB 写失败(极端配额/私密模式禁用):退回 localStorage,但那有 ~5MB 硬顶,超了就如实告知。 */
          if(approxMB>4.7){tip('保存失败:内容约 '+approxMB.toFixed(1)+'MB,超出本浏览器可用存储;请精简内联图片后重试');return;}
          try{localStorage.setItem(fullKey,payload);onSaved();}
          catch(e2){tip('保存失败(存储空间不足?约 '+approxMB.toFixed(1)+'MB);请精简内联图片或清理其他站点数据');}
        });
      }else{
        /* 无 IndexedDB / 无 Promise 的老环境:只能用 localStorage(~5MB 顶)。 */
        if(approxMB>4.7){tip('保存失败:内容约 '+approxMB.toFixed(1)+'MB,超出浏览器约 5MB 存储上限;请精简内联图片后重试');return;}
        try{localStorage.setItem(fullKey,payload);onSaved();}
        catch(e){tip('保存失败(存储空间不足?约 '+approxMB.toFixed(1)+'MB);请精简内联图片');}
      }
    }
    /* 同步判定:本文档有无【已保存的全量快照】(不读大 HTML,只看元记录 / 旧版 localStorage 存在性)。
       返回快照的 {ts,cur} 供状态回显;真正的整段还原由异步 restoreFullAsync 完成。 */
    function fullMeta(){
      if((''+(location.search||'')).indexOf('present=speaker')>=0)return null;  /* speaker 视图不吃主站快照 */
      try{var m=localStorage.getItem(metaKey);if(m){var o=JSON.parse(m);if(o&&(!o.sig||o.sig===docSig))return o;}}catch(e){}
      /* 无 v3.4 元记录 → 看有没有旧版 localStorage 全量快照(≤3.3 存的) */
      try{var raw=localStorage.getItem(fullKey);if(raw){var s=JSON.parse(raw);
        if(s&&typeof s.html==='string'&&s.html&&(!s.sig||s.sig===docSig))return {ts:s.ts||0,cur:s.cur,sig:s.sig,legacy:true};}}catch(e2){}
      return null;
    }
    /* 异步取回大 HTML 并整段还原 track;done(true) 表示已还原,由调用方接后续复活流程。 */
    function restoreFullAsync(done){
      if(!track){done(false);return;}
      var meta=fullMeta();
      if(!meta){done(false);return;}
      function apply(raw){
        var snap;try{snap=JSON.parse(raw);}catch(e){done(false);return;}
        if(!snap||typeof snap.html!=='string'||!snap.html){done(false);return;}
        if(snap.sig&&snap.sig!==docSig){done(false);return;}   /* 防御性二重校验 */
        track.innerHTML=snap.html;_savedTs=snap.ts||0;
        if(typeof snap.cur==='number')cur=snap.cur;
        done(true);
      }
      if(meta.legacy){                      /* 旧版快照就在 localStorage */
        var r=null;try{r=localStorage.getItem(fullKey);}catch(e){}
        if(r)apply(r);else done(false);return;
      }
      if(idbOK()){
        idbGet(fullKey).then(function(raw){
          if(typeof raw==='string'&&raw){apply(raw);return;}
          /* IDB 未命中 → 再兜底看 localStorage 旧版 */
          var r=null;try{r=localStorage.getItem(fullKey);}catch(e){}
          if(r)apply(r);else done(false);
        })['catch'](function(){
          var r=null;try{r=localStorage.getItem(fullKey);}catch(e){}
          if(r)apply(r);else done(false);
        });
      }else{
        var r2=null;try{r2=localStorage.getItem(fullKey);}catch(e){}
        if(r2)apply(r2);else done(false);
      }
    }
    /* 清除本文档的全量快照(IDB + 旧版 localStorage + 元记录 + 字号/图片桶)——逃生口。 */
    function clearFull(silent){
      try{localStorage.removeItem(fullKey);}catch(e){}
      try{localStorage.removeItem(metaKey);}catch(e2){}
      try{localStorage.removeItem(storeKey);}catch(e3){}
      if(idbOK()){try{idbDel(fullKey);}catch(e4){}}
      _dirty=false;_savedTs=0;paintSaveStatus();
      if(!silent)tip('已清除保存,刷新后回到原始底稿');
    }

    /* ---------- 工具:live frames / 当前页 ---------- */
    function frames(){return track?Array.prototype.slice.call(track.children):[];}
    function curIdx(){return (window.__deck&&window.__deck.cur)?window.__deck.cur():0;}
    function frameRoot(f){return f?f.querySelector('.page,.cover-wrap,.cover'):null;}
    function modOf(f){
      var s=f?f.querySelector('.deck-scale'):null;
      var cn=s?(''+(s.className||'')):'';
      var m=cn.match(/\bm-([a-z0-9]+)\b/i);
      if(m&&m[1]!=='light'&&m[1]!=='dark')return m[1];
      var r=frameRoot(f); if(r){var rc=''+(r.className||'');
        if(rc.indexOf('cover')>=0)return 'cover';
        var mm=rc.match(/\bm-([a-z0-9]+)\b/); if(mm)return mm[1];}
      return '·';
    }
    /* 取本页的标识文字:优先标题类节点,回退到首个非空 data-edt / 任意可见文本,
       让侧栏 chip 一眼能认出「这是哪一页」,而不是只有页码+版式代号。 */
    function titleOf(f){
      var r=frameRoot(f)||f; if(!r)return '';
      var sels=['.ptitle','h1','h2','.title','.deck-title','.cover-title','.page-title',
                '.m-title','.headline','.subtitle','[data-edt]'];
      for(var i=0;i<sels.length;i++){
        var nodes=r.querySelectorAll(sels[i]);
        for(var j=0;j<nodes.length;j++){
          var t=(nodes[j].textContent||'').replace(/\s+/g,' ').trim();
          if(t)return t;
        }
      }
      var all=(frameText(r)||'').replace(/\s+/g,' ').trim();
      return all;
    }

    /* ---------- 导航重同步(结构变更后调用)---------- */
    /* 增强层接管导航:读取 live frames,并把 dots / prev / next / 方向键都指向自己,
       避免宿主 IIFE 的闭包 frames 数组在增删/重排后失效导致翻页错乱。 */
    var cur=curIdx();
    function clamp(i,n){return i<0?0:(i>=n?n-1:i);}
    function go(i){
      var fs=frames(),N=fs.length; if(!N)return;
      i=clamp(i,N); cur=i;
      if(typeof clearSel==='function')clearSel();   /* 翻页清掉浮层选择 */
      if(track)track.style.transform='translateX(-'+fs[i].offsetLeft+'px)';
      paintDots(N,i);
      if(countEl)countEl.textContent=pad(i+1)+' / '+pad(N);
      /* 接管导航后必须自己维护 prev/next 的 disabled——宿主 render 已被替换,不会再更新;
         否则宿主初始把 prev 置 disabled(cur===0)后永久卡死,导致「向左箭头不生效」。 */
      var pb=document.getElementById('deckPrev'); if(pb)pb.disabled=(i===0);
      var nb=document.getElementById('deckNext'); if(nb)nb.disabled=(i===N-1);
      try{document.dispatchEvent(new CustomEvent('deck:nav',{detail:{idx:i,total:N}}));}catch(e){}
    }
    function pad(n){return (n<10?'0':'')+n;}
    function paintDots(N,i){
      if(!dotsWrap)return;
      var have=dotsWrap.querySelectorAll('.deck-dot');
      /* 数量对齐 */
      while(have.length>N){dotsWrap.removeChild(have[have.length-1]);have=dotsWrap.querySelectorAll('.deck-dot');}
      while(have.length<N){var d=document.createElement('button');d.type='button';d.className='deck-dot';dotsWrap.appendChild(d);have=dotsWrap.querySelectorAll('.deck-dot');}
      for(var k=0;k<have.length;k++){have[k].classList.toggle('is-active',k===i);
        if(!have[k].__depBound){have[k].__depBound=1;(function(idx){have[k].addEventListener('click',function(){go(idx);});})(k);}}
    }
    /* 接管 prev/next:clone 掉旧监听后重绑 */
    function rebind(id,delta){
      var b=document.getElementById(id); if(!b)return;
      var nb=b.cloneNode(true); b.parentNode.replaceChild(nb,b);
      nb.addEventListener('click',function(){go(cur+delta);});
      return nb;
    }
    var prevBtn=rebind('deckPrev',-1), nextBtn=rebind('deckNext',1);
    /* 方向键:capture 阶段接管,阻止宿主 stale 闭包处理 */
    document.addEventListener('keydown',function(e){
      if(body.classList.contains('deck-editing'))return;   /* 编辑中不翻页 */
      var k=e.key;
      if(k==='ArrowRight'||k==='PageDown'){e.stopImmediatePropagation();go(cur+1);}
      else if(k==='ArrowLeft'||k==='PageUp'){e.stopImmediatePropagation();go(cur-1);}
    },true);
    /* 用增强控制器覆盖 window.__deck,让外部(投影同步等)也拿到 live 版本 */
    if(window.__deck){
      window.__deck.go=go;
      window.__deck.cur=function(){return cur;};
      Object.defineProperty(window.__deck,'frames',{get:function(){return frames();},configurable:true});
      Object.defineProperty(window.__deck,'total',{get:function(){return frames().length;},configurable:true});
    }
    function refreshNav(){var fs=frames();cur=clamp(cur,fs.length);go(cur);
      /* 结构变更(增/删/复制/重排页)后,若在编辑态,重扫渐变裁字集合,让新页也受保护 */
      if(typeof markGradEls==='function'&&body.classList.contains('deck-editing'))markGradEls();}

    /* ================= 增强 UI(仅编辑模式显示)================= */
    function el(tag,cls,txt){var e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e;}

    /* 顶部工具条 */
    var bar=el('div');bar.id='depBar';bar.className='dep-hidden';
    bar.appendChild(el('span','dep-title','编辑+'));
    var bAdd=el('button',null,'＋ 复制本页');
    var bBlank=el('button',null,'＋ 空白页');
    var bDel=el('button',null,'🗑 删除本页');
    var sepA=el('span','dep-sep');
    var bText=el('button',null,'＋文字');
    var bCard=el('button',null,'＋卡片');
    var bImg=el('button',null,'＋图片');
    var sepB=el('span','dep-sep');
    var bRect=el('button',null,'▭矩形');
    var bEll=el('button',null,'◯圆');
    var bLine=el('button',null,'／线');
    var bArrow=el('button',null,'➔箭头');
    bar.appendChild(bAdd);bar.appendChild(bBlank);bar.appendChild(bDel);
    bar.appendChild(sepA);
    bar.appendChild(bText);bar.appendChild(bCard);bar.appendChild(bImg);
    bar.appendChild(sepB);
    bar.appendChild(bRect);bar.appendChild(bEll);bar.appendChild(bLine);bar.appendChild(bArrow);
    /* 不再放「导出 HTML」:宿主右下角 #deckExport 已有导出,避免重复 */
    body.appendChild(bar);

    /* 右上角:全量保存 + 上次保存时间(仅编辑模式显示) */
    var saveBox=el('div');saveBox.id='depSaveBox';saveBox.className='dep-hidden';
    var saveBtn=el('button','dep-savebtn','💾 保存');
    saveSt=el('span','dep-savest','未改动');
    saveBox.appendChild(saveBtn);saveBox.appendChild(saveSt);
    body.appendChild(saveBox);
    saveBtn.addEventListener('click',function(){saveFull();});

    /* 页面侧栏 */
    var rail=el('div');rail.id='depRail';rail.className='dep-hidden';
    var railHd=el('div','dep-railhd','页面 · 拖拽排序');
    rail.appendChild(railHd);
    body.appendChild(rail);

    /* 字号工具条 */
    var fontBar=el('div');fontBar.id='depFont';fontBar.className='dep-hidden';
    var fMinus=el('button',null,'A-');var fLabel=el('span','dep-fs','—');
    var fPlus=el('button',null,'A+');var fReset=el('button',null,'↺');
    fontBar.appendChild(fMinus);fontBar.appendChild(fLabel);fontBar.appendChild(fPlus);fontBar.appendChild(fReset);
    /* 文字颜色:主题纯色 + 渐变模板色 + 复位。追加在字号按钮之后,
       故 querySelectorAll('button')[0..2] 仍是 A-/A+/↺,验证脚本索引不受影响。 */
    fontBar.appendChild(el('span','dep-sepv'));
    var TCOLORS=[
      {v:'__grad__',cls:'dep-sw dep-grad',t:'渐变模板色'},
      {v:'#2B6CF0',cls:'dep-sw',t:'主题蓝'},
      {v:'#8273E0',cls:'dep-sw',t:'青紫'},
      {v:'#9267C9',cls:'dep-sw',t:'紫'},
      {v:'#3B9EEF',cls:'dep-sw',t:'亮蓝'},
      {v:'__reset__',cls:'dep-sw dep-reset',t:'恢复默认色'}
    ];
    for(var ci=0;ci<TCOLORS.length;ci++){(function(c){
      var sw=el('button',c.cls);sw.title=c.t;sw.setAttribute('data-depcol',c.v);
      if(c.v==='__reset__')sw.textContent='↺';
      else if(c.v!=='__grad__')sw.style.background=c.v;
      sw.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();applyTextColor(c.v);});
      fontBar.appendChild(sw);
    })(TCOLORS[ci]);}
    /* v2.8 文字格式:加粗/斜体/下划线 + 左中右对齐 + 无序/有序列表。
       追加在色板之后,故 querySelectorAll('button')[0..2] 仍是 A-/A+/↺,既有验证索引不受影响。 */
    fontBar.appendChild(el('span','dep-sepv'));
    var FMTS=[
      {k:'bold',h:'<b>B</b>',t:'加粗'},
      {k:'italic',h:'<i>I</i>',t:'斜体'},
      {k:'underline',h:'<u>U</u>',t:'下划线'},
      {k:'left',h:'⬅',t:'左对齐'},
      {k:'center',h:'⬌',t:'居中'},
      {k:'right',h:'➡',t:'右对齐'},
      {k:'ul',h:'•≡',t:'无序列表'},
      {k:'ol',h:'1≡',t:'有序列表'}
    ];
    var fmtBtns={};
    for(var fi2=0;fi2<FMTS.length;fi2++){(function(fmt){
      var b=el('button','dep-fmt');b.innerHTML=fmt.h;b.title=fmt.t;b.setAttribute('data-depfmt',fmt.k);
      b.addEventListener('mousedown',function(ev){ev.preventDefault();});  /* 防止点按钮时丢失选区/失焦 */
      b.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();applyTextFormat(fmt.k);});
      fmtBtns[fmt.k]=b;fontBar.appendChild(b);
    })(FMTS[fi2]);}
    body.appendChild(fontBar);

    /* 装饰面板:卡片/数字/文字的入场动效 + 描边色(卡片彩色边条 ::before)*/
    var deco=el('div');deco.id='depDeco';deco.className='dep-hidden';
    var decoTarget=null;    /* 真正写动效类的元素(卡片容器,或浮层内层 .dep-fanim)*/
    var decoCard=null;      /* 命中的卡片容器 —— 描边色 + 动效均作用于它 */
    /* 顶部说明:告诉用户「现在改的是什么」+「当前动效是什么」,解决“不知道这是什么动效” */
    var decoCap=el('div','dep-cap');deco.appendChild(decoCap);
    /* 动效行 */
    var anRow=el('div','dep-row dep-row-anim');
    var anLbl=el('span','dep-lbl','动效');anRow.appendChild(anLbl);
    var ANIMS=[{k:'rise',t:'上浮'},{k:'fade',t:'淡入'},{k:'zoom',t:'放大'},{k:'none',t:'无'}];
    var anBtns={};
    for(var ai=0;ai<ANIMS.length;ai++){(function(a){
      var b=el('button','dep-anb',a.t);b.setAttribute('data-depanb',a.k);
      b.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();setAnim(decoTarget,a.k);});
      anBtns[a.k]=b;anRow.appendChild(b);
    })(ANIMS[ai]);}
    deco.appendChild(anRow);
    /* 描边色行 */
    var edRow=el('div','dep-row dep-row-edge');edRow.appendChild(el('span','dep-lbl','描边'));
    var ECOLORS=[
      {v:'__key__',cls:'dep-sw dep-grad',t:'主题渐变边'},
      {v:'#2B6CF0',cls:'dep-sw',t:'蓝'},
      {v:'#8273E0',cls:'dep-sw',t:'青紫'},
      {v:'#9267C9',cls:'dep-sw',t:'紫'},
      {v:'#3B9EEF',cls:'dep-sw',t:'亮蓝'},
      {v:'__reset__',cls:'dep-sw dep-reset',t:'恢复默认边'}
    ];
    for(var ei=0;ei<ECOLORS.length;ei++){(function(c){
      var sw=el('button',c.cls);sw.title=c.t;
      if(c.v==='__reset__')sw.textContent='↺';
      else if(c.v!=='__key__')sw.style.background=c.v;
      sw.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();setEdge(edgeTarget(),c.v);});
      edRow.appendChild(sw);
    })(ECOLORS[ei]);}
    deco.appendChild(edRow);
    body.appendChild(deco);

    /* toast */
    var toast=el('div');toast.id='depToast';body.appendChild(toast);
    var toastT=null;
    function tip(msg){toast.textContent=msg;toast.classList.add('dep-show');
      clearTimeout(toastT);toastT=setTimeout(function(){toast.classList.remove('dep-show');},1600);}

    /* ---------- 页面侧栏渲染 + 拖拽重排 ---------- */
    function buildRail(){
      var fs=frames();
      /* 清空旧 chip */
      var old=rail.querySelectorAll('.dep-chip');
      for(var i=0;i<old.length;i++)rail.removeChild(old[i]);
      fs.forEach(function(f,idx){
        var chip=el('div','dep-chip');chip.setAttribute('draggable','true');chip.__idx=idx;
        if(idx===cur)chip.classList.add('dep-cur');
        chip.appendChild(el('span','dep-idx',pad(idx+1)));
        /* 标题 + 版式代号:让用户一眼认出这是哪一页,而不是只看页码 */
        var meta=el('div','dep-meta');
        var ttl=titleOf(f); if(ttl.length>26)ttl=ttl.slice(0,26)+'…';
        var tEl=el('div','dep-ttl',ttl||'(空白页)');
        tEl.title=titleOf(f)||'';   /* 悬停看全称 */
        meta.appendChild(tEl);
        meta.appendChild(el('div','dep-mod',modOf(f)));
        chip.appendChild(meta);
        var del=el('button','dep-del','✕');del.title='删除此页';
        del.addEventListener('click',function(ev){ev.stopPropagation();deletePage(idx);});
        chip.appendChild(del);
        chip.addEventListener('click',function(){go(idx);buildRail();});
        /* 悬停即跳到该页预览,彻底消除「不知道拖的是哪一页」 */
        chip.addEventListener('mouseenter',function(){if(dragFrom==null&&idx!==cur)go(idx);});
        /* 拖拽重排 */
        chip.addEventListener('dragstart',function(e){dragFrom=idx;chip.classList.add('dep-drag');
          try{e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',''+idx);}catch(_){}});
        chip.addEventListener('dragend',function(){chip.classList.remove('dep-drag');clearOver();});
        chip.addEventListener('dragover',function(e){e.preventDefault();chip.classList.add('dep-over');});
        chip.addEventListener('dragleave',function(){chip.classList.remove('dep-over');});
        chip.addEventListener('drop',function(e){e.preventDefault();chip.classList.remove('dep-over');
          if(dragFrom!=null&&dragFrom!==idx)reorder(dragFrom,idx);dragFrom=null;});
        rail.appendChild(chip);
      });
    }
    var dragFrom=null;
    function clearOver(){var o=rail.querySelectorAll('.dep-over');for(var i=0;i<o.length;i++)o[i].classList.remove('dep-over');}
    /* 只挪高亮,不重建 chip:避免悬停预览时把正 hover 的 chip 销毁 */
    function paintRailCur(){
      var chips=rail.querySelectorAll('.dep-chip');
      for(var i=0;i<chips.length;i++)chips[i].classList.toggle('dep-cur',i===cur);
    }

    function reorder(from,to){
      var fs=frames();if(from<0||to<0||from>=fs.length||to>=fs.length)return;
      var node=fs[from];
      if(from<to)track.insertBefore(node,fs[to].nextSibling);
      else track.insertBefore(node,fs[to]);
      /* 当前页跟随移动 */
      if(cur===from)cur=to; else if(from<cur&&to>=cur)cur--; else if(from>cur&&to<=cur)cur++;
      refreshNav();buildRail();tip('已重排:第 '+(from+1)+' 页 → 第 '+(to+1)+' 页');
      markDirty();
    }

    /* 复制页时给【宿主自己的】内容持久化 id 现铸全新唯一值,斩断跨页串档(bug#7)。
       宿主 data-edt(文字)/ data-edimg(图片位)是 collect()/load() 的存储键、且无
       页命名空间;cloneNode 会把它们原样拷走 → 两页同 id → 一页文字经 localStorage 覆盖
       另一页。这里对复制页内所有带这两个属性的节点重铸唯一 id。 */
    var _reidSeq=0;
    function reidHostEdit(root){
      if(!root||!root.querySelectorAll)return;
      var stamp=hash((++_reidSeq)+'|'+(+new Date())+'|'+Math.random());
      var i,ns;
      ns=root.querySelectorAll('[data-edt]');
      for(i=0;i<ns.length;i++)ns[i].setAttribute('data-edt','dup'+stamp+'-'+i);
      ns=root.querySelectorAll('[data-edimg]');
      for(i=0;i<ns.length;i++)ns[i].setAttribute('data-edimg','dupi'+stamp+'-'+i);
    }

    function addPage(mode){
      var fs=frames();if(!fs.length||!track)return;
      var src=fs[cur];
      var clone;
      if(mode==='blank'){
        clone=src.cloneNode(true);
        /* 空白页:只保留 页眉(.eyebrow/.kicker) + 标题(.ptitle,含装饰 .ptick) + 页脚(.pfoot),
           正文一律清空。正文容器 .content 直接清空(不留任何模块);若无 .content 骨架
           (如封面版式),则移除除页眉/标题/页脚外的所有直接子节点。 */
        var pg=clone.querySelector('.page')||clone.querySelector('.deck-scale')||clone;
        var content=pg.querySelector('.content');
        if(content){
          content.innerHTML='';
        }else{
          /* 封面等【无 .content 骨架】的版式:页面背景色带落在最外层包裹上
             (如 .cover-wrap 的 --fs-grad-mesh),而页眉/标题/页脚又深埋其中。
             早期实现按"删除不在白名单里的直接子节点"处理 —— 但封面的唯一直接子节点
             恰是承载背景的 .cover-wrap,它既不等于任何白名单节点、也不会被逐一匹配到,
             于是被整块删掉 → 页面失去背景 → 在投影黑底(body.deck-projecting{background:#000})
             上呈现为纯黑页(bug#4:首页新增空白页出现纯黑页面)。
             修法:改为"包含式"保留 —— 只删除【既不是保留节点、也不包含任何保留节点】的
             直接子节点,从而始终保住承载背景的包裹层与其中的页眉/标题/页脚。 */
          var keeps=[];
          function pushSel(sel){var ns=pg.querySelectorAll(sel),i;for(i=0;i<ns.length;i++)keeps.push(ns[i]);}
          pushSel('.eyebrow');pushSel('.kicker');pushSel('.ptitle');pushSel('.title-zone');
          pushSel('h1');pushSel('h2');pushSel('.ptick');pushSel('.pfoot');pushSel('.foot');
          function isKept(c){var i;for(i=0;i<keeps.length;i++){if(c===keeps[i]||c.contains(keeps[i]))return true;}return false;}
          var kids=pg.children,rm=[],i;
          for(i=0;i<kids.length;i++){if(!isKept(kids[i]))rm.push(kids[i]);}
          /* 黑屏兜底:若所有直接子节点都被判为可删(纯装饰封面、无任何保留节点),
             则一个都不删 —— 宁可多留内容,也绝不产出没有背景的纯黑页。 */
          if(rm.length<kids.length){for(var r=0;r<rm.length;r++)pg.removeChild(rm[r]);}
          /* 到这里背景包裹层(.cover-wrap 等)已保住;但封面的纯装饰仍深埋其中
             (光晕/飞鸟/联合 LOGO/元信息),留着会让"空白页"几乎等同"复制本页"。
             故在【保住背景之后】再顺手清掉这批可安全识别的纯装饰叶子节点 ——
             它们都不承载页面背景(背景在外层 .cover-wrap 上),删掉只让页面更干净,
             绝不会重新产生黑页。 */
          var deco=pg.querySelectorAll('.bloom,.bird,.cobrand,.lockup,.mh-meta,.rule'),d;
          for(d=0;d<deco.length;d++){if(deco[d].parentNode)deco[d].parentNode.removeChild(deco[d]);}
        }
        /* 标题占位,方便识别与就地改写;左侧栏标题会用 titleOf 动态取这段文本 */
        var t=pg.querySelector('.ptitle')||pg.querySelector('.title-zone h1,.title-zone h2');
        if(t && !(t.textContent||'').replace(/\s+/g,''))t.textContent='新页面标题';
      }else{
        clone=src.cloneNode(true);
      }
      /* 插入到当前页之后 */
      if(src.nextSibling)track.insertBefore(clone,src.nextSibling);
      else track.appendChild(clone);
      /* 剥离复制来的页身份:cloneNode 会把源页的 data-deppg 原样拷走,若不清掉,复制页
         就与源页共用同一存储命名空间 → 改一页两页齐变。清掉后 pageId() 会给复制页现铸
         一枚全新 id,其后一切字号/图片编辑都独立入桶,与源页彻底解耦。源页此前的内联
         编辑(style.fontSize/transform)已随 cloneNode 一起复制,故复制页在生成时【外观
         一致】,仅【后续编辑】各走各路 —— 正是「每页独立」应有的行为。 */
      clone.removeAttribute('data-deppg');
      var _nkids=clone.querySelectorAll('[data-deppg]'),_nk;
      for(_nk=0;_nk<_nkids.length;_nk++)_nkids[_nk].removeAttribute('data-deppg');
      /* 关键(bug#7:改「方案细节1」第一张卡片正文,「方案细节2」同位文字被删)——
         cloneNode 不仅复制 data-deppg,还把【宿主自己的】内容持久化 id 原样拷走:
         data-edt(文字)/ data-edimg(图片位)。宿主 compose_deck 的 collect()/load()
         只按 data-edt 存/取文本、且【无页命名空间】——两页共用同一 data-edt 时,存一页
         的文字会经 localStorage 回写到【所有同 id 节点】,重开即把另一页同位文字覆盖/清空。
         data-deppg 只护住【我方】字号/图片桶,护不住【宿主】这条 id-keyed 存储链。
         故复制页必须给宿主 id 也现铸全新唯一值,彻底斩断跨页串档。图片位内部编号
         (data-edmulti 等无 id 语义的旗标)保持不动。 */
      reidHostEdit(clone);
      cur=cur+1;
      refreshNav();buildRail();
      /* clone 是纯 DOM 拷贝,不带 JS 事件与 __depFloatBound/__depDrag 标记:
         复制页里的浮层会拖不动、± / ✕ 失效,图片位也未武装。对新页作用域内的
         浮层与图片位重新武装(带 __dep* 幂等守卫,不会重复绑到既有元素)。 */
      hydrateFloats(clone);
      if(typeof markZoomable==='function')markZoomable(clone);
      if(body.classList.contains('deck-editing')){armContentEdit(true);armImgSlots(true);}
      tip(mode==='blank'?'已插入空白页(复用本页版式)':'已复制本页');
      markDirty();
    }

    function deletePage(idx){
      var fs=frames();if(fs.length<=1){tip('至少保留一页');return;}
      idx=(idx==null)?cur:idx;
      track.removeChild(fs[idx]);
      if(cur>=idx&&cur>0)cur--;
      refreshNav();buildRail();tip('已删除第 '+(idx+1)+' 页');
      markDirty();
    }

    bAdd.addEventListener('click',function(){addPage('dup');});
    bBlank.addEventListener('click',function(){addPage('blank');});
    bDel.addEventListener('click',function(){deletePage(cur);});

    /* ---------- 字号编辑(任意文字块,含卡片文字 / 大数字)---------- */
    /* v1 只认 data-edt,导致新增卡片文字、宿主模块大数字都调不了。改为白名单文字选择器:
       点中任意文字块即可 A-/A+/↺。只写内联 font-size —— 颜色(在 .num/主题变量上)、
       入场动效(在 .stat/.dep-fanim 上)都不受影响,原样保留。 */
    var fontTarget=null;
    var FTXT='.dep-cardt,.dep-cardb,.dep-float.dep-text .dep-fanim,'
      +'[data-edt],.ptitle,.eyebrow,.kicker,.mh-meta,.brand,.pageno,'
      +'.num .v,.num .u,.num,.stat .t,.stat .d,.lead p,.lead,'
      +'.cap,.rcard,.fpoint,.loopcap,.impact .card,.closing,.t,.d,'
      +'h1,h2,h3,h4,li,p,span';
    var FUISEL='#depBar,#depRail,#depFont,#depToast,#depShape,#depDeco,.dep-scaler,.dep-elx,.dep-rz,.dep-imgtool';
    function sig(e){var p=[],n=e;while(n&&n.nodeType===1&&p.length<6){var i=0,s=n;while((s=s.previousElementSibling))i++;p.unshift(n.tagName+i);n=n.parentElement;}return hash(p.join('>'));}
    /* ---------- 页身份:每页一枚稳定且【全局唯一】的 data-deppg ----------
       用户反馈「改第 3 页却影响第 2、4 页」的根因:
       ① sig() 只取 6 层祖先且不含页号,结构相同的页(尤其「复制本页」)会算出同一
          指纹;② cloneNode 把 data-depfs / data-edimg 原样拷进复制页 —— 于是复制页
          与源页共用同一存储桶,改一页两页齐变;fsFind 又只返回文档内【第一个】命中
          节点,回存时把别页的字号灌到本页,既「串页」又「格式乱」。
       解法:给每页铸一枚由计数器+时间戳+随机数生成的 data-deppg(不由结构推导,故
       cloneNode 复制来的会在 addPage 里被剥离重铸),再把它作为 font/image 存储键的
       命名空间前缀 —— 结构再相同、复制再多次,跨页 key 也绝不相撞;回存时先按 deppg
       锁定目标页、再在页内精确定位节点,改哪页只落哪页。data-deppg 是真实 DOM 属性,
       随宿主导出克隆一起落地,重开导出的 HTML 也能按页精确回填。 */
    var pgSeq=0;
    function frameOf(e){var n=e;while(n&&n.parentNode&&n.parentNode!==track)n=n.parentNode;
      return (n&&n.parentNode===track)?n:null;}
    function pageId(f){if(!f)return 'p0';
      var id=f.getAttribute('data-deppg');if(id)return id;
      id='pg'+hash((++pgSeq)+'|'+(+new Date())+'|'+Math.random());
      f.setAttribute('data-deppg',id);return id;}
    var fsSeq=0;
    /* 稳定 key = 页命名空间(data-deppg) + '::' + 页内本地键。本地键:data-edt 优先;
       否则写一枚 data-depfs 属性 —— 二者都随宿主导出克隆落地,重开导出 HTML 能精确回填。*/
    function fsKey(e){
      var pg=pageId(frameOf(e)),local;
      var id=e.getAttribute('data-edt');
      if(id){local='e:'+id;}
      else{var k=e.getAttribute('data-depfs');
        if(k){local=k;}
        else{k='f:'+hash((e.tagName||'')+'.'+(e.className||'')+'|'+(++fsSeq)+'|'+(+new Date()));
          e.setAttribute('data-depfs',k);local=k;}}
      return pg+'::'+local;
    }
    function fsFind(k){
      var pg=null,local=k,ix=k.indexOf('::');
      if(ix>=0){pg=k.slice(0,ix);local=k.slice(ix+2);}
      var scope=document;
      if(pg){var f=document.querySelector('[data-deppg="'+pg.replace(/"/g,'')+'"]');
        if(!f)return null;scope=f;}   /* 该页已被删除 → 不误落到别页 */
      if(local.slice(0,2)==='e:')return scope.querySelector('[data-edt="'+local.slice(2).replace(/"/g,'')+'"]');
      return scope.querySelector('[data-depfs="'+local.replace(/"/g,'')+'"]');
    }
    function baseFS(e){return Math.round(parseFloat(getComputedStyle(e).fontSize)||16);}
    function applyStoredFonts(){
      for(var k in store.fonts){if(!store.fonts.hasOwnProperty(k))continue;
        var e=fsFind(k);if(e)e.style.fontSize=store.fonts[k]+'px';}
    }
    function placeFontBar(e){
      var r=e.getBoundingClientRect();
      fontBar.style.top=Math.max(8,r.top-38)+'px';
      fontBar.style.left=Math.min(window.innerWidth-160,Math.max(8,r.left))+'px';
    }
    function showFontBar(e){
      fontTarget=e;placeFontBar(e);
      fLabel.textContent=baseFS(e)+'px';
      fontBar.classList.remove('dep-hidden');
    }
    function bumpFont(d){
      if(!fontTarget)return;
      /* 段内特定文字:若在 fontTarget 内有非折叠选区,只放大选中那段(包成 .dep-fs-run)*/
      var sel=window.getSelection&&window.getSelection();
      var hasRange=sel&&sel.rangeCount&&!sel.isCollapsed&&
        fontTarget.contains(sel.anchorNode)&&fontTarget.contains(sel.focusNode);
      if(hasRange){
        var runsp=runForSel(sel,function(){});
        if(runsp){
          var cf=Math.round(parseFloat(getComputedStyle(runsp).fontSize)||baseFS(fontTarget));
          var rp=cf+d; if(rp<8)rp=8; if(rp>300)rp=300;
          runsp.style.fontSize=rp+'px';
          fontTarget.removeAttribute('data-fit');
          fLabel.textContent=rp+'px';
          return;
        }
        /* 选区落在 count-up 数字里 → 不包裹,退回整块放大 */
      }
      var px=baseFS(fontTarget)+d; if(px<8)px=8; if(px>300)px=300;
      fontTarget.style.fontSize=px+'px';
      fontTarget.removeAttribute('data-fit'); /* 冻结:阻止宿主 fit() 在 resize 时回改 */
      fLabel.textContent=px+'px';
      store.fonts[fsKey(fontTarget)]=px;persist();
      placeFontBar(fontTarget);
    }
    /* 把当前选区包进一个 .dep-fs-run span 并回调修改;随导出克隆一起固化 */
    function wrapRun(sel,mut){
      try{
        var rng=sel.getRangeAt(0);
        var span=document.createElement('span');span.className='dep-fs-run';
        span.appendChild(rng.extractContents());
        rng.insertNode(span);
        if(mut)mut(span);
        sel.removeAllRanges();var r2=document.createRange();r2.selectNodeContents(span);sel.addRange(r2);
        return span;
      }catch(e){return null;}
    }
    /* count-up 大数字节点:靠宿主 JS 每帧改写 textContent,任何包在里面的 span 会被下一帧
       count-up 冲掉或与 data-to 错乱(线上出现过 data-to=90 却显示 99990 的脏数据)。
       故段内放大/变色遇到 count-up 节点一律【不包裹】、退回整块作用。 */
    function inCountNode(node){
      var el=node&&node.nodeType===1?node:(node&&node.parentElement);
      while(el&&el!==document.body){
        if(el.getAttribute&&el.getAttribute('data-to')!=null)return true;
        el=el.parentElement;
      }
      return false;
    }
    /* 取选区对应的 run:若选区恰好落在一个已存在的 .dep-fs-run 内且文本一致,则【复用】
       (避免每次点色板/放大都层层新套 span,造成 .dep-grad-text 无限嵌套 → 编辑态获焦消失);
       否则新建一个 .dep-fs-run 包裹。选区落在 count-up 数字里 → 返回 null(交调用方退回整块)。 */
    function runForSel(sel,mut){
      if(inCountNode(sel.anchorNode)||inCountNode(sel.focusNode))return null;
      var anc=(sel.anchorNode&&sel.anchorNode.parentElement)?
        sel.anchorNode.parentElement.closest('.dep-fs-run'):null;
      if(anc&&fontTarget&&fontTarget.contains(anc)&&
         (''+sel).replace(/\s/g,'')===(anc.textContent||'').replace(/\s/g,'')){
        if(mut)mut(anc);
        return anc;                          /* 复用已有 run,不再嵌套 */
      }
      return wrapRun(sel,mut);
    }
    /* 文字颜色:主题纯色 / 渐变模板色(background-clip:text)/ 复位。
       有选区→只作用选中段(包 .dep-fs-run);无选区→作用整个 fontTarget。 */
    function applyTextColor(v){
      var sel=window.getSelection&&window.getSelection();
      var useRange=sel&&sel.rangeCount&&!sel.isCollapsed&&fontTarget&&
        fontTarget.contains(sel.anchorNode)&&fontTarget.contains(sel.focusNode);
      function paint(node){
        if(v==='__reset__'){
          node.classList.remove('dep-grad-text');
          node.style.removeProperty('color');
          node.style.removeProperty('-webkit-text-fill-color');
        }else if(v==='__grad__'){
          /* 渐变模板:交给 .dep-grad-text 类(background-clip:text),先清掉自己写的纯色内联 */
          node.style.removeProperty('color');
          node.style.removeProperty('-webkit-text-fill-color');
          node.classList.add('dep-grad-text');
        }else{
          /* 纯色:用 !important 压过宿主 CSS;并显式覆盖 text-fill-color——宿主渐变字
             用 -webkit-text-fill-color:transparent,不覆盖它字会一直透明看不到颜色。 */
          node.classList.remove('dep-grad-text');
          node.style.setProperty('color',v,'important');
          node.style.setProperty('-webkit-text-fill-color',v,'important');
        }
      }
      if(useRange){
        var rs=runForSel(sel,paint);
        /* 选区落在 count-up 数字内:不新建 run(避免 .dep-grad-text 无限嵌套,现象二根因),
           退而给整块上色——整块只改自身内联样式/类,不产生嵌套,亦不动 data-to。 */
        if(!rs&&fontTarget)paint(fontTarget);
      }
      else if(fontTarget){paint(fontTarget);}
    }
    /* v2.8 文字格式:加粗/斜体/下划线 走 execCommand(有选区作用选区,无选区作用整段);
       对齐/列表作用于整个 fontTarget(块级)。全部落真实 DOM,随导出克隆固化。 */
    function applyTextFormat(k){
      if(!fontTarget)return;
      pushHist();
      var sel=window.getSelection&&window.getSelection();
      var hasRange=sel&&sel.rangeCount&&!sel.isCollapsed&&
        fontTarget.contains(sel.anchorNode)&&fontTarget.contains(sel.focusNode);
      /* execCommand 需要目标可编辑:临时开 contenteditable */
      var wasCE=fontTarget.getAttribute('contenteditable');
      fontTarget.setAttribute('contenteditable','true');
      if(k==='bold'||k==='italic'||k==='underline'){
        if(!hasRange){ /* 无选区 → 全选整段再执行,作用整段 */
          try{var rng=document.createRange();rng.selectNodeContents(fontTarget);
            sel.removeAllRanges();sel.addRange(rng);}catch(_){}
        }
        try{document.execCommand(k,false,null);}catch(e){}
        /* 回显按钮激活态 */
        try{if(fmtBtns[k])fmtBtns[k].classList.toggle('dep-on',document.queryCommandState(k));}catch(e2){}
      }else if(k==='left'||k==='center'||k==='right'){
        fontTarget.style.textAlign=k;
        fmtBtns.left.classList.toggle('dep-on',k==='left');
        fmtBtns.center.classList.toggle('dep-on',k==='center');
        fmtBtns.right.classList.toggle('dep-on',k==='right');
      }else if(k==='ul'||k==='ol'){
        try{var rng2=document.createRange();rng2.selectNodeContents(fontTarget);
          if(!hasRange){sel.removeAllRanges();sel.addRange(rng2);}}catch(_){}
        try{document.execCommand(k==='ul'?'insertUnorderedList':'insertOrderedList',false,null);}catch(e3){}
      }
      /* 还原 contenteditable 原状(内容/结构已落 DOM) */
      if(wasCE==null)fontTarget.removeAttribute('contenteditable');
      else fontTarget.setAttribute('contenteditable',wasCE);
      fontTarget.removeAttribute('data-fit');
    }
    fMinus.addEventListener('click',function(e){e.preventDefault();bumpFont(-1);});
    fPlus.addEventListener('click',function(e){e.preventDefault();bumpFont(1);});
    fReset.addEventListener('click',function(e){e.preventDefault();if(!fontTarget)return;
      fontTarget.style.fontSize='';
      var k=fsKey(fontTarget);delete store.fonts[k];persist();
      fLabel.textContent=baseFS(fontTarget)+'px';placeFontBar(fontTarget);});
    /* 点中任意文字块即挂字号条(排除增强层自身 UI);同时若命中卡片/数字容器,挂装饰面板 */
    document.addEventListener('click',function(e){
      if(!body.classList.contains('deck-editing'))return;
      if(fontBar.contains(e.target)||deco.contains(e.target))return;
      if(shapeBar.contains(e.target))return;   /* 点形状/对齐操作条不改选择 */
      if(e.target.closest&&e.target.closest(FUISEL))return;
      /* 点空白处(既非浮层、也非增强 UI)→ 取消浮层选择 */
      if(!(e.target.closest&&e.target.closest('.dep-float'))){clearSel();}
      var t=e.target.closest?e.target.closest(FTXT):null;
      if(t&&(t.textContent||'').trim()){showFontBar(t);}
      else{fontBar.classList.add('dep-hidden');fontTarget=null;}
      var dh=pickDeco(e.target);
      if(dh){showDeco(dh);}else{hideDeco();}
      dodgeBars();
    },true);

    /* ---------- 修:渐变裁字编辑态获焦即消失 ----------
       -webkit-background-clip:text + -webkit-text-fill-color:transparent 的元素(团队标题
       .tname / 痛点大数字 .bignum 等),在编辑态被 contenteditable + 光标激活时,Chromium
       会漏重绘透明填充的字形 → 文字整块消失,点别处才恢复。做法:focusin 时判断目标(含祖先)
       是否为渐变裁字,是则打 .dep-gradedit(CSS 强制实心 currentColor 填充+关裁剪,逼一次
       完整重绘);focusout 摘类,未编辑的标题保留渐变观感。模板无关,仅编辑态生效,不进产物。 */
    function isGradClip(el){
      if(!el||el.nodeType!==1)return false;
      var c=getComputedStyle(el);
      var clip=(c.webkitBackgroundClip||c.getPropertyValue('-webkit-background-clip')||
                c.backgroundClip||c.getPropertyValue('background-clip')||'');
      if(clip.indexOf('text')<0)return false;
      var fill=(c.webkitTextFillColor||c.getPropertyValue('-webkit-text-fill-color')||'');
      /* 透明填充:rgba(...,0) 或 transparent */
      return /transparent/.test(fill)||/,\s*0\s*\)\s*$/.test(fill);
    }
    /* 关键实测(v3.8 定论):一旦元素被 focus+contenteditable 激活,它的计算
       -webkit-background-clip 会【持续】回退成 border-box(不是只坏一帧,rAF 下一帧仍是
       border-box)——因此任何“在获焦当刻/下一帧用 getComputedStyle 判 clip==text”的方案
       都永远判不出渐变裁字,.dep-gradedit 打不上,文字照旧消失(线上现象一的真因)。
       正解:在【进入编辑模式、尚无任何元素获焦、样式仍稳定】时,把整卷渐变裁字元素预扫一遍
       记进 gradEls;focusin 时不再靠 getComputedStyle,改按【身份匹配】判断目标(含祖先)
       是否属于预扫集合,命中即打类逼重绘。 */
    var gradEls=[];
    function indexOfEl(arr,el){for(var i=0;i<arr.length;i++){if(arr[i]===el)return i;}return -1;}
    /* 取渐变裁字元素的一个“实心可见色”:优先用其 color(若非透明),否则从 background-image
       的渐变里抠第一个 rgb/rgba 色标;都拿不到时给个深色兜底。用于 --dep-solid,避免
       color:transparent 的元素被强制成 currentColor 后依旧透明(线上现象一在 .pct/.cmain 上的残留)。 */
    function gradSolid(el){
      var c=getComputedStyle(el);
      var col=(c.color||'');
      if(col&&!/transparent/.test(col)&&!/,\s*0\s*\)\s*$/.test(col))return col;
      var bg=(c.backgroundImage||'')+' '+(c.background||'');
      var m=bg.match(/rgba?\([^)]*\)/g);
      if(m){for(var i=0;i<m.length;i++){if(!/,\s*0\s*\)\s*$/.test(m[i])&&!/transparent/.test(m[i]))return m[i];}}
      var hex=bg.match(/#[0-9a-fA-F]{3,8}/);
      if(hex)return hex[0];
      return '#202938';
    }
    /* 进编辑态预扫:遍历页面根内所有元素,趁样式稳定(未获焦)记下所有渐变裁字元素。
       不写 DOM 标记(避免污染导出),只存在 JS 闭包数组里。 */
    function markGradEls(){
      gradEls=[];
      if(!track)return;
      var all=track.querySelectorAll('*');
      for(var i=0;i<all.length;i++){
        var el=all[i];
        if(el.closest&&el.closest(FUISEL))continue;      /* 跳过增强 UI */
        if(!(el.textContent||'').trim())continue;         /* 空元素无所谓 */
        /* 已被标记(正获焦、clip 被强制 initial→此刻 isGradClip 判不出)的元素照收 */
        if(el.classList&&el.classList.contains('dep-gradedit')){gradEls.push(el);continue;}
        if(isGradClip(el)){el.__depSolid=gradSolid(el);gradEls.push(el);}
      }
    }
    /* 从事件目标向上找“最近的渐变裁字祖先”(裁字往往在标题元素本身,光标可能落在其内部
       文本节点/子 span 上);优先按预扫集合身份匹配(获焦后 getComputedStyle 已不可信),
       预扫未覆盖时再回退到 isGradClip;限制在页面根内,避免误伤增强 UI。 */
    function gradAncestor(node){
      var el=node&&node.nodeType===1?node:(node&&node.parentElement);
      for(var d=0;el&&d<6;d++){
        if(el.closest&&el.closest(FUISEL))return null;
        if(indexOfEl(gradEls,el)>=0)return el;            /* 预扫命中(主路径) */
        if(isGradClip(el))return el;                      /* 兜底:样式仍稳定时 */
        el=el.parentElement;
      }
      return null;
    }
    var gradEditEl=null;
    function applyGradEdit(target){
      var g=gradAncestor(target);
      if(gradEditEl&&gradEditEl!==g){gradEditEl.classList.remove('dep-gradedit');gradEditEl.style.removeProperty('--dep-solid');}
      if(g){
        gradEditEl=g;
        /* 实心色:优先预扫时记下的 __depSolid;没有则现算(此刻 clip 可能已被激活成
           border-box,gradSolid 仍能从 color / background-image 里抠色) */
        var sc=g.__depSolid||gradSolid(g);
        if(sc)g.style.setProperty('--dep-solid',sc);
        g.classList.add('dep-gradedit');
        return true;
      }
      return false;
    }
    document.addEventListener('focusin',function(e){
      if(!body.classList.contains('deck-editing'))return;
      applyGradEdit(e.target);
    },true);
    document.addEventListener('focusout',function(e){
      if(!gradEditEl)return;
      /* 焦点若仍落在同一渐变元素内部(如子 span),保持;否则摘类还原渐变观感 */
      var to=e.relatedTarget;
      if(to&&gradEditEl.contains(to))return;
      gradEditEl.classList.remove('dep-gradedit');
      gradEditEl.style.removeProperty('--dep-solid');
      gradEditEl=null;
    },true);

    /* ---------- 内容编辑:宿主卡片文字 / 大数字可就地改写 ---------- */
    /* 宿主只把 [data-edt] 设为 contenteditable,卡片正文(.t/.d)与大数字(.v/.u)都没有
       data-edt,所以原来根本改不了内容。这里在编辑模式下给这批文字补 contenteditable:
       颜色(CSS 在元素/主题变量上)、入场动效(在 .stat 等父节点上)都不受影响,原样保留。
       导出时宿主 #deckExport 会克隆并统一去掉所有 contenteditable,产物干净。 */
    var CEDIT='.stat .t,.stat .d,.num .v,.num .u,.meta .t,.meta .d,'
      +'.card .t,.card .d,.card .pct .v,.card .pct .u,'
      +'.fpoint .t,.fpoint .d,.fpoint .num .v,.fpoint .num .u,'
      +'.impact .card .v,.impact .card .u,.rcard .t,.rcard .d,'
      +'.loopcap,.cap,.lead p,.closing';
    function armContentEdit(on){
      var els=document.querySelectorAll(CEDIT);
      for(var i=0;i<els.length;i++){
        var e=els[i];
        if(e.hasAttribute('data-edt'))continue;          /* 宿主已接管的不重复武装 */
        if(e.closest&&e.closest('.dep-float'))continue;   /* 浮层有自己的双击编辑 */
        if(on){e.setAttribute('contenteditable','true');e.setAttribute('data-depce','1');}
        else if(e.getAttribute('data-depce')){e.removeAttribute('contenteditable');}
      }
    }
    /* 改大数字时把新值同步进 data-to:count-up 动效仍在,只是终点变成用户改后的值;
       非数字则去掉 data-to(不参与 count-up),文本按用户输入静态保留。 */
    function syncNumber(el){
      el.setAttribute('data-depedited','1');   /* 标记为「用户已改」→ count-up 永不再覆写 */
      var raw=(el.textContent||'').replace(/[^\d.\-]/g,'');
      var n=parseFloat(raw);
      if(!isNaN(n)){el.setAttribute('data-to',String(n));}
      else{el.removeAttribute('data-to');}
    }

    /* ---------- Batch D:卡片/数字装饰(入场动效可调/删/加 + 描边色)---------- */
    /* 命中「卡片容器级」元素:宿主 SEL 里会入场动画的那些 + 我方浮层卡片。
       动效用类驱动(!important),能扛住宿主 replayCards 只清 inline animation 的重放;
       描边色写元素上的 --dep-edge 变量,由 CSS 规则以 !important 读入 ::before。
       两者都随宿主导出克隆(类名/内联变量/属性)一并固化。 */
    var DECOSEL='.stat,.card,.fpoint,.rcard,.impact .card,.dep-float.dep-card';
    var ANIMCLS=['dep-anim-rise','dep-anim-fade','dep-anim-zoom','dep-anim-none'];
    var ANIMTXT={rise:'上浮',fade:'淡入',zoom:'放大',none:'无'};
    /* 动效恒作用于「整张卡片」——不再对卡片内的数字/文字子块单独加动效。
       原因:给脆弱的文字子节点单独挂 rise/fade,会出现「文字上浮后直接消失 / 淡入时整卡下移」
       等观感问题(子块动画的 transform/opacity 与宿主排版打架);用户也明确要求「对卡片就是
       卡片本身」。故 pickDeco 命中卡片容器即返回,anim 恒为 card 容器本身。 */
    function pickDeco(node){
      if(!node||!node.closest)return null;
      if(node.closest(FUISEL))return null;
      var card=node.closest(DECOSEL);
      if(!card)return null;
      return {card:card,anim:card,kind:'card'};
    }
    /* 浮层卡片的入场动画放在内层 .dep-fanim(外层 .dep-float 的 transform:scale 会与动画
       的 transform 打架);宿主卡片则动画就落在容器本身。取真正承载动画的节点。 */
    function animNode(container){
      if(container&&container.classList&&container.classList.contains('dep-float')){
        var a=container.querySelector('.dep-fanim');return a||container;
      }
      return container;
    }
    function curAnim(elm){
      if(!elm)return '';
      for(var i=0;i<ANIMCLS.length;i++)if(elm.classList.contains(ANIMCLS[i]))return ANIMCLS[i].slice(9);
      return '';
    }
    /* 用类切换 + 强制回流来重放:因动效类带 !important,inline animation:none 压不住它,
       只有「移除类→回流→重新加类」才能让 computed animation 真正 off→on 触发重播。 */
    function restartAnim(elm,cls){
      elm.classList.remove(cls);void elm.offsetWidth;elm.classList.add(cls);
    }
    function setAnim(target,kind){
      if(!target)return;
      var elm=animNode(target);
      for(var i=0;i<ANIMCLS.length;i++)elm.classList.remove(ANIMCLS[i]);
      void elm.offsetWidth;                 /* 回流,保证下面加类能触发动画(即时预览)*/
      elm.classList.add('dep-anim-'+kind);
      /* 动效恒作用于整卡:卡片容器本身就是动画载体,且我方类带 !important 直接盖过宿主
         mcCardIn,无需再静音——清掉任何遗留的 dep-hostoff,避免把卡片自身动效也静音。 */
      if(decoCard&&decoCard.classList)decoCard.classList.remove('dep-hostoff');
      paintDecoState();
      var nm=ANIMTXT[kind]||kind;
      tip('卡片动效:'+nm+(kind==='none'?'(已移除)':'(已预览)'));
    }
    function edgeTarget(){return decoCard;}   /* 描边(::before 彩条)只有卡片有,恒指向卡片容器 */
    function setEdge(elm,v){
      if(!elm){tip('描边只作用于卡片,请先点选一张卡片');return;}
      if(v==='__reset__'){elm.removeAttribute('data-dep-edge');elm.style.removeProperty('--dep-edge');tip('已恢复默认边');}
      else{
        elm.setAttribute('data-dep-edge','1');
        var col=(v==='__key__')?'var(--fs-grad-keyline,linear-gradient(90deg,#8273E0 0%,#2B6CF0 50%,#9267C9 100%))':v;
        elm.style.setProperty('--dep-edge',col);
        tip('卡片描边已更新');
      }
    }
    /* 回显:高亮当前动效按钮 + 用文案告诉用户「现在改的是什么、当前是什么动效」 */
    function paintDecoState(){
      var elm=decoTarget?animNode(decoTarget):null;
      var k=elm?curAnim(elm):'';
      for(var a in anBtns){if(anBtns.hasOwnProperty(a))anBtns[a].classList.toggle('dep-on',a===k);}
      var animTxt=k?(ANIMTXT[k]||k):'默认';
      decoCap.innerHTML='正在设置:<b>卡片整体</b> · 当前动效 '+animTxt;
    }
    function placeDeco(elm){
      var r=elm.getBoundingClientRect();
      deco.style.top=Math.min(window.innerHeight-118,Math.max(8,r.bottom+8))+'px';
      deco.style.left=Math.min(window.innerWidth-206,Math.max(8,r.left))+'px';
    }
    function showDeco(pick){
      decoTarget=pick.anim;decoCard=pick.card;
      placeDeco(pick.card);paintDecoState();
      deco.classList.remove('dep-hidden');
    }
    function hideDeco(){deco.classList.add('dep-hidden');decoTarget=null;decoCard=null;}

    /* ---------- 工具条防重叠(issue#3) ----------
       一次点击可能同时浮出 #depFont(元素上方)、#depShape(元素上方)、#depDeco(元素下方),
       三者 position:fixed 且各自独立定位,极易视觉重叠。这里在所有放置逻辑跑完后统一收敛一次:
       按优先级把可见工具条竖直错开,后来的若与已放置的相交则下移(超出视口底则上移),
       并做左右视口夹取。用 setTimeout(0) 去抖,保证同一轮点击里的多次放置都已落定。 */
    function barVisible(b){return b&&!b.classList.contains('dep-hidden')&&b.offsetWidth>0;}
    function overlaps(a,b){
      return !(a.right<=b.left||a.left>=b.right||a.bottom<=b.top||a.top>=b.bottom);
    }
    /* 锚点元素:一次点击真正要「看得见」的那个内容元素——优先取字号条锚定的文字块,
       否则装饰面板锚定的卡片,再否则当前选中浮层。工具条要围绕它避让,绝不压在它上面。 */
    function curAnchorEl(){
      if(barVisible(fontBar)&&fontTarget)return fontTarget;
      if(barVisible(deco)&&decoCard)return decoCard;
      if(sels&&sels.length)return sels[0];
      return null;
    }
    function resolveBarOverlap(){
      var GAP=8,VT=8,VB=window.innerHeight-8,i,b,r;
      var anEl=curAnchorEl();
      var ar=anEl&&anEl.getBoundingClientRect?anEl.getBoundingClientRect():null;
      if(!ar||!(ar.width||ar.height)){resolveBarStackOnly();return;}
      /* 锚点可见:字号条/形状条向上叠(远离锚点顶),装饰面板向下叠(远离锚点底);
         某侧放不下则溢出到另一侧,并全程做视口夹取。这样任何工具条都不会盖住被点内容。 */
      var aboveGrp=[fontBar,shapeBar],belowGrp=[deco],overflowBelow=[];
      var topEdge=ar.top-GAP;
      for(i=0;i<aboveGrp.length;i++){b=aboveGrp[i];if(!barVisible(b))continue;
        r=b.getBoundingClientRect();var t=topEdge-r.height;
        if(t<VT){overflowBelow.push(b);continue;}   /* 上方没地方 → 排到下方队列 */
        b.style.top=t+'px';topEdge=t-GAP;
      }
      var botEdge=ar.bottom+GAP;
      var below=belowGrp.concat(overflowBelow);
      for(i=0;i<below.length;i++){b=below[i];if(!barVisible(b))continue;
        r=b.getBoundingClientRect();var tt=botEdge;
        if(tt+r.height>VB){tt=Math.max(VT,ar.top-GAP-r.height);}  /* 下方也满 → 顶到最上 */
        b.style.top=tt+'px';botEdge=tt+r.height+GAP;
      }
    }
    /* 无锚点(极少数,如仅程序化显示)时的兜底:仅按优先级竖直错开,互不重叠 */
    function resolveBarStackOnly(){
      var order=[fontBar,shapeBar,deco],placed=[],GAP=8,i,j;
      for(i=0;i<order.length;i++){
        var b=order[i]; if(!barVisible(b))continue;
        var r=b.getBoundingClientRect();
        var top=r.top,changed=false,guard=0;
        for(j=0;j<placed.length&&guard<12;j++){
          var pr=placed[j];
          if(overlaps({left:r.left,right:r.right,top:top,bottom:top+r.height},pr)){
            top=pr.bottom+GAP;changed=true;j=-1;guard++;
          }
        }
        if(top+r.height>window.innerHeight-8){
          var minTop=window.innerHeight-8;
          for(j=0;j<placed.length;j++)if(placed[j].top<minTop)minTop=placed[j].top;
          top=Math.max(8,minTop-r.height-GAP);changed=true;
        }
        if(top<8)top=8;
        if(changed)b.style.top=top+'px';
        placed.push({left:r.left,right:r.right,top:top,bottom:top+r.height});
      }
    }
    var _barTok=null;
    function dodgeBars(){
      if(_barTok)clearTimeout(_barTok);
      _barTok=setTimeout(function(){_barTok=null;resolveBarOverlap();},0);
    }


    /* ---------- 图片位置 / 缩放 ---------- */
    /* 图片存储键同样按页命名空间(data-deppg::本地标识):本地标识优先用宿主/自身的
       data-edimg,缺失时用 'auto'+sig 现铸并写回属性。这样即便复制页把 data-edimg 原样
       拷走(值相同),两页的存储桶因页命名空间不同而互不干扰 —— 改一页图片不动别页。 */
    function imgLocal(slot){var id=slot.getAttribute('data-edimg');if(id)return id;
      id='auto'+sig(slot);slot.setAttribute('data-edimg',id);return id;}
    function imgId(slot){return pageId(frameOf(slot))+'::'+imgLocal(slot);}
    function firstImg(slot){return slot.querySelector('img');}
    /* 解析一枚图片当前的内联 transform → {x,y,s}。用于「采纳」导出 HTML 里已烘进
       inline style 的位置(见 adoptImgT):重开导出件时 docSig 旋转、store 为空,若不
       先把内联 transform 读进 store,applyT 会把它抹掉 → 用户上次摆好的位置「莫名归位」。*/
    function parseT(img){
      if(!img)return null;
      var tr=(img.style&&img.style.transform)||'';
      if(!tr)return null;
      var x=0,y=0,s=1,got=false;
      var mt=tr.match(/translate\(\s*(-?[\d.]+)px\s*,\s*(-?[\d.]+)px\s*\)/);
      if(mt){x=parseFloat(mt[1])||0;y=parseFloat(mt[2])||0;got=true;}
      var ms=tr.match(/scale\(\s*(-?[\d.]+)\s*\)/);
      if(ms){s=parseFloat(ms[1]);if(isNaN(s))s=1;got=true;}
      if(!got)return null;
      /* 恒等变换无需入桶(保持 store 精简 & applyT 空操作) */
      if(x===0&&y===0&&s===1)return null;
      return {x:x,y:y,s:s};
    }
    /* 采纳内联 transform:store 尚无该图记录、但图片自带非恒等 inline transform 时,
       把它读进 store。这样【重开导出件 / 换指纹】后,用户上次摆放的位置成为新的基准,
       后续拖拽在此之上继续,applyT 也不再把它抹回原位(修「图片默认返回原始状态」)。*/
    function adoptImgT(slot){
      var id=imgId(slot);if(store.imgt[id])return;
      var t=parseT(firstImg(slot));if(t)store.imgt[id]=t;
    }
    function applyT(slot){
      var id=imgId(slot),t=store.imgt[id];var img=firstImg(slot);if(!img)return;
      /* v3.9:store 无记录时【不再抹掉】图片自带的内联 transform —— 导出件里烘进的
         用户摆位就在 inline style 上,抹掉即「归位」。无记录 = 尊重底稿现状,直接返回。
         (真正的复位由 ↺ 按钮写入 {x:0,y:0,s:1} 显式驱动,那时 t 有值、走下面分支。) */
      if(!t){return;}
      img.style.transformOrigin='center center';
      img.style.transform='translate('+(t.x||0)+'px,'+(t.y||0)+'px) scale('+(t.s||1)+')';
    }
    function applyStoredImgs(){
      var slots=document.querySelectorAll('[data-edimg]');
      /* 先采纳导出件里烘进的内联摆位(store 为空时),再按 store 应用 —— 顺序不能反,
         否则 applyT 读到空记录、把内联 transform 留在原地却未纳入 store,后续拖拽会从
         0 起算而非从当前摆位续拖。 */
      for(var i=0;i<slots.length;i++)adoptImgT(slots[i]);
      for(var j=0;j<slots.length;j++)applyT(slots[j]);
    }
    function armImgSlots(on){
      var slots=document.querySelectorAll('[data-edimg]');
      for(var i=0;i<slots.length;i++){(function(slot){
        if(on){
          slot.classList.add('dep-imgpos');
          if(getComputedStyle(slot).position==='static')slot.style.position='relative';
          if(!slot.__depDrag){slot.__depDrag=1;bindImgDrag(slot);}
          /* __depTool 是 JS 属性,cloneNode 不复制:复制页的 slot 带的是「死」工具条
             (DOM 复制来的,无事件),用 DOM 存在性判断会漏掉它。改用 JS 标记判断,
             并先摘掉可能存在的死工具条,再挂一份带事件的。 */
          if(!slot.__depTool){
            slot.__depTool=1;
            var dead=slot.querySelector('.dep-imgtool');if(dead)dead.parentNode.removeChild(dead);
            addImgTool(slot);
          }
        }else{
          slot.classList.remove('dep-imgpos');
          var tool=slot.querySelector('.dep-imgtool');if(tool)tool.parentNode.removeChild(tool);
          slot.__depTool=0;
        }
      })(slots[i]);}
    }
    function getT(slot){var id=imgId(slot);return store.imgt[id]||(store.imgt[id]={x:0,y:0,s:1});}
    function bindImgDrag(slot){
      var dragging=false,sx=0,sy=0,ox=0,oy=0;
      slot.addEventListener('mousedown',function(e){
        if(!body.classList.contains('deck-editing'))return;
        if(e.target.closest('.dep-imgtool'))return;
        var img=firstImg(slot);if(!img)return;
        dragging=true;var t=getT(slot);ox=t.x||0;oy=t.y||0;sx=e.clientX;sy=e.clientY;
        e.preventDefault();
      });
      document.addEventListener('mousemove',function(e){
        if(!dragging)return;var t=getT(slot);
        t.x=ox+(e.clientX-sx);t.y=oy+(e.clientY-sy);applyT(slot);
      });
      document.addEventListener('mouseup',function(){if(dragging){dragging=false;persist();}});
      slot.addEventListener('wheel',function(e){
        if(!body.classList.contains('deck-editing'))return;
        e.preventDefault();var t=getT(slot);
        t.s=Math.max(.2,Math.min(5,(t.s||1)+(e.deltaY<0?.05:-.05)));applyT(slot);persist();
      },{passive:false});
    }
    function addImgTool(slot){
      var tool=el('div','dep-imgtool');
      var zi=el('button',null,'＋');var zo=el('button',null,'－');var rs=el('button',null,'↺');
      zi.title='放大';zo.title='缩小';rs.title='复位';
      zi.addEventListener('click',function(e){e.stopPropagation();var t=getT(slot);t.s=Math.min(5,(t.s||1)+.1);applyT(slot);persist();});
      zo.addEventListener('click',function(e){e.stopPropagation();var t=getT(slot);t.s=Math.max(.2,(t.s||1)-.1);applyT(slot);persist();});
      rs.addEventListener('click',function(e){e.stopPropagation();var id=imgId(slot);store.imgt[id]={x:0,y:0,s:1};applyT(slot);persist();});
      tool.appendChild(zo);tool.appendChild(zi);tool.appendChild(rs);
      slot.appendChild(tool);
    }

    /* ---------- 新增浮层元素:文字 / 卡片 / 图片 ---------- */
    /* 设计:新增内容脱离原栅格,以「可拖拽浮层」插入当前页 root。
       位置写 left/top、缩放写 transform:scale(),都是内联样式落在真实 DOM 上,
       所以宿主导出(克隆 documentElement)会天然固化——与「增删页」同属结构变更,
       故不进 localStorage(避免与页数 hash 冲突),以导出即固化为准。 */
    var floatSeq=0;
    /* 当前页缩放因子:.deck-scale 被 CSS transform:scale(k) 缩放,
       屏幕位移换算回页面 1280×720 坐标需除以 k。 */
    function pageScale(f){
      var s=f?f.querySelector('.deck-scale'):null; if(!s)return 1;
      var r=s.getBoundingClientRect(); var w=s.offsetWidth||1;
      var k=r.width/w; return k>0?k:1;
    }
    function ensurePosRoot(root){
      if(getComputedStyle(root).position==='static')root.style.position='relative';
    }
    function makeScaler(fl){
      var sc=el('div','dep-scaler');
      var zo=el('button',null,'－');var zi=el('button',null,'＋');var rs=el('button',null,'↺');
      zo.title='缩小';zi.title='放大';rs.title='复位';
      function setS(v){v=Math.max(.3,Math.min(4,v));fl.__s=v;fl.style.transform='scale('+v+')';}
      zi.addEventListener('click',function(e){e.stopPropagation();setS((fl.__s||1)+.1);});
      zo.addEventListener('click',function(e){e.stopPropagation();setS((fl.__s||1)-.1);});
      rs.addEventListener('click',function(e){e.stopPropagation();setS(1);});
      sc.appendChild(zo);sc.appendChild(zi);sc.appendChild(rs);
      fl.appendChild(sc);
    }
    /* 文字框手动调宽高(issue#1,PPT 式):右下角手柄拖拽写内联 width/height,
       解除 min/max 约束(打 data-depsized)。位移按页面缩放系数 pageScale 换算;
       与 .dep-scaler(整体等比缩放)正交——这里改的是盒子尺寸,文本随框换行。 */
    function makeResizer(fl){
      var g=el('div','dep-rz');g.title='拖拽调整宽高';
      var rzing=false,sx=0,sy=0,w0=0,h0=0,k=1;
      g.addEventListener('mousedown',function(e){
        if(!body.classList.contains('deck-editing'))return;
        e.preventDefault();e.stopPropagation();
        rzing=true;
        var f=fl.closest('.deck-frame');k=pageScale(f);
        var r=fl.getBoundingClientRect();
        /* 起始尺寸取当前渲染尺寸(再除缩放系数回到页面坐标);若被 scale 过则一并还原 */
        var s=fl.__s||1;
        w0=(parseFloat(fl.style.width)||r.width/k/s);
        h0=(parseFloat(fl.style.height)||r.height/k/s);
        sx=e.clientX;sy=e.clientY;
        pushHist();
      });
      document.addEventListener('mousemove',function(e){
        if(!rzing)return;
        var s=fl.__s||1;
        var dw=(e.clientX-sx)/k/s, dh=(e.clientY-sy)/k/s;
        var nw=Math.max(40,w0+dw), nh=Math.max(24,h0+dh);
        fl.style.width=nw+'px';fl.style.height=nh+'px';
        fl.style.maxWidth='none';fl.style.minWidth='0';
        fl.setAttribute('data-depsized','1');
      });
      document.addEventListener('mouseup',function(){rzing=false;});
      fl.appendChild(g);
    }
    function makeDelX(fl){
      var x=el('button','dep-elx','✕');x.title='删除此元素';
      x.addEventListener('click',function(e){e.stopPropagation();
        if(fl.parentNode)fl.parentNode.removeChild(fl);tip('已删除元素');});
      fl.appendChild(x);
    }
    function bindFloatDrag(fl){
      if(fl.__depFloatBound)return; fl.__depFloatBound=1;
      var dragging=false,sx=0,sy=0,k=1,moved=false,starts=[];
      fl.addEventListener('mousedown',function(e){
        if(!body.classList.contains('deck-editing'))return;
        if(e.target.closest('.dep-elx')||e.target.closest('.dep-scaler')||e.target.closest('.dep-rz'))return;
        if(fl.getAttribute('data-editing')==='1')return;   /* 正在编辑文字时不拖 */
        /* 选择模型:Shift 追加/切换多选;否则若未在选择集里则改为只选它 */
        if(e.shiftKey){toggleSel(fl);}
        else if(sels.indexOf(fl)<0){selectFloat(fl);}
        dragging=true; moved=false;
        var f=fl.closest('.deck-frame'); k=pageScale(f);
        sx=e.clientX; sy=e.clientY;
        /* 记录所有被选浮层的起点,拖拽时一起平移 */
        starts=[];
        for(var i=0;i<sels.length;i++){
          starts.push({fl:sels[i],x:parseFloat(sels[i].style.left)||0,y:parseFloat(sels[i].style.top)||0});
        }
        e.preventDefault();
      });
      document.addEventListener('mousemove',function(e){
        if(!dragging)return;
        if(!moved){moved=true;pushHist();}   /* 首次移动才入历史,避免纯点击也记一笔 */
        var dx=(e.clientX-sx)/k, dy=(e.clientY-sy)/k;
        for(var i=0;i<starts.length;i++){
          starts[i].fl.style.left=(starts[i].x+dx)+'px';
          starts[i].fl.style.top=(starts[i].y+dy)+'px';
        }
        if(sels.length===1)applySnap(fl); else clearGuides();
      });
      document.addEventListener('mouseup',function(){if(dragging){dragging=false;clearGuides();}});
    }
    /* ---------- v2.8 选择模型(多选) ---------- */
    var sels=[];
    function paintSel(){
      var all=document.querySelectorAll('.dep-float.dep-sel,.dep-float.dep-msel'),i;
      for(i=0;i<all.length;i++){all[i].classList.remove('dep-sel');all[i].classList.remove('dep-msel');}
      if(sels.length===1){sels[0].classList.add('dep-sel');}
      else{for(i=0;i<sels.length;i++)sels[i].classList.add('dep-msel');}
      maybeShapeBar();
    }
    function selectFloat(fl){sels=fl?[fl]:[];paintSel();}
    function toggleSel(fl){var i=sels.indexOf(fl);if(i<0)sels.push(fl);else sels.splice(i,1);paintSel();}
    function clearSel(){sels=[];
      var s=document.querySelectorAll('.dep-float.dep-sel,.dep-float.dep-msel');
      for(var i=0;i<s.length;i++){s[i].classList.remove('dep-sel');s[i].classList.remove('dep-msel');}
      hideShapeBar();}

    /* ================= v2.8 PPT 能力增量 ================= */

    /* ---------- 撤销/重做:对当前页 DOM 做快照栈(结构态,不进 localStorage) ---------- */
    var histStack=[],redoStack=[],histBusy=false;
    function curPageRoot(){var fs=frames();var f=fs[cur];return f?(frameRoot(f)||f):null;}
    function pushHist(){
      if(histBusy)return;
      var root=curPageRoot(); if(!root)return;
      histStack.push({idx:cur,html:root.innerHTML});
      if(histStack.length>60)histStack.shift();
      redoStack.length=0;
      markDirty();   /* 任何进历史的结构改动都标记「未保存」 */
    }
    function restoreSnap(snap){
      if(!snap)return;
      histBusy=true;
      if(snap.idx!==cur)go(snap.idx);
      var root=curPageRoot();
      if(root){root.innerHTML=snap.html;
        clearSel();
        hydrateFloats(root);armImgSlots(true);
        markZoomable(frames()[cur]);}
      histBusy=false;
    }
    function undo(){
      if(!histStack.length){tip('没有可撤销的操作');return;}
      var root=curPageRoot(); if(!root)return;
      redoStack.push({idx:cur,html:root.innerHTML});
      var snap=histStack.pop();
      restoreSnap(snap); tip('已撤销');
    }
    function redo(){
      if(!redoStack.length){tip('没有可重做的操作');return;}
      var root=curPageRoot(); if(!root)return;
      histStack.push({idx:cur,html:root.innerHTML});
      var snap=redoStack.pop();
      restoreSnap(snap); tip('已重做');
    }

    /* ---------- 复制 / 粘贴 / 删除(浮层元素;编辑态) ---------- */
    var clip=[];
    function copySel(){
      if(!sels.length)return false;
      clip=[]; for(var i=0;i<sels.length;i++)clip.push(sels[i].outerHTML);
      tip('已复制 '+clip.length+' 个元素'); return true;
    }
    function pasteClip(){
      if(!clip.length){tip('剪贴板为空');return;}
      var f=frames()[cur]; var root=frameRoot(f)||f; if(!root)return; ensurePosRoot(root);
      pushHist();
      var made=[];
      for(var i=0;i<clip.length;i++){
        var tmp=document.createElement('div'); tmp.innerHTML=clip[i];
        var fl=tmp.firstChild; if(!fl)continue;
        fl.classList.remove('dep-sel');fl.classList.remove('dep-msel');
        fl.__depHydrated=0;fl.__depFloatBound=0;
        fl.style.left=((parseFloat(fl.style.left)||150)+24)+'px';
        fl.style.top=((parseFloat(fl.style.top)||150)+24)+'px';
        root.appendChild(fl); made.push(fl);
      }
      hydrateFloats(root);
      sels=made; paintSel();
      tip('已粘贴 '+made.length+' 个元素');
    }
    function deleteSel(){
      if(!sels.length)return false;
      pushHist();
      for(var i=0;i<sels.length;i++){if(sels[i].parentNode)sels[i].parentNode.removeChild(sels[i]);}
      var n=sels.length; sels=[]; hideShapeBar();
      tip('已删除 '+n+' 个元素'); return true;
    }

    /* ---------- 层级(z-order):写内联 z-index,随导出克隆固化 ---------- */
    function allFloatsOnPage(){
      var f=frames()[cur]; var root=frameRoot(f)||f; if(!root)return [];
      return Array.prototype.slice.call(root.querySelectorAll(':scope > .dep-float,:scope .dep-float'));
    }
    function zOf(fl){return parseInt(fl.style.zIndex,10)||40;}
    function zRange(){
      var all=allFloatsOnPage(),mn=40,mx=40;
      for(var i=0;i<all.length;i++){var z=zOf(all[i]);if(z<mn)mn=z;if(z>mx)mx=z;}
      return {min:mn,max:mx};
    }
    function zOrder(op){
      if(!sels.length){tip('先选中一个元素');return;}
      pushHist();
      var r=zRange(),i;
      for(i=0;i<sels.length;i++){
        var cz=zOf(sels[i]);
        if(op==='front')sels[i].style.zIndex=(r.max+1);
        else if(op==='back')sels[i].style.zIndex=(r.min-1);
        else if(op==='fwd')sels[i].style.zIndex=(cz+1);
        else if(op==='bwd')sels[i].style.zIndex=(cz-1);
      }
      tip(op==='front'?'已置顶':op==='back'?'已置底':op==='fwd'?'已上移一层':'已下移一层');
    }

    /* ---------- 对齐 / 分布(多选)---------- */
    function flRect(fl){
      var x=parseFloat(fl.style.left)||0,y=parseFloat(fl.style.top)||0;
      var s=fl.__s||1; var w=(fl.offsetWidth||0)*s, h=(fl.offsetHeight||0)*s;
      return {fl:fl,x:x,y:y,w:w,h:h,cx:x+w/2,cy:y+h/2,r:x+w,b:y+h};
    }
    function alignSel(how){
      if(sels.length<2){tip('对齐需要选中 2 个以上元素');return;}
      pushHist();
      var rs=[],i; for(i=0;i<sels.length;i++)rs.push(flRect(sels[i]));
      var mnx=Infinity,mxr=-Infinity,mny=Infinity,mxb=-Infinity;
      for(i=0;i<rs.length;i++){if(rs[i].x<mnx)mnx=rs[i].x;if(rs[i].r>mxr)mxr=rs[i].r;
        if(rs[i].y<mny)mny=rs[i].y;if(rs[i].b>mxb)mxb=rs[i].b;}
      var ccx=(mnx+mxr)/2, ccy=(mny+mxb)/2;
      for(i=0;i<rs.length;i++){
        var o=rs[i];
        if(how==='left')o.fl.style.left=mnx+'px';
        else if(how==='right')o.fl.style.left=(mxr-o.w)+'px';
        else if(how==='hcenter')o.fl.style.left=(ccx-o.w/2)+'px';
        else if(how==='top')o.fl.style.top=mny+'px';
        else if(how==='bottom')o.fl.style.top=(mxb-o.h)+'px';
        else if(how==='vcenter')o.fl.style.top=(ccy-o.h/2)+'px';
      }
      tip('已对齐');
    }
    function distribute(axis){
      if(sels.length<3){tip('分布需要选中 3 个以上元素');return;}
      pushHist();
      var rs=[],i; for(i=0;i<sels.length;i++)rs.push(flRect(sels[i]));
      rs.sort(function(a,b){return axis==='h'?(a.cx-b.cx):(a.cy-b.cy);});
      var first=rs[0],last=rs[rs.length-1];
      if(axis==='h'){
        var span=last.cx-first.cx, step=span/(rs.length-1);
        for(i=1;i<rs.length-1;i++){var tc=first.cx+step*i;rs[i].fl.style.left=(tc-rs[i].w/2)+'px';}
      }else{
        var spanv=last.cy-first.cy, stepv=spanv/(rs.length-1);
        for(i=1;i<rs.length-1;i++){var tcy=first.cy+stepv*i;rs[i].fl.style.top=(tcy-rs[i].h/2)+'px';}
      }
      tip('已均匀分布');
    }

    /* ---------- 智能吸附辅助线(单选拖拽时)---------- */
    var guideV=null,guideH=null;
    function ensureGuides(root){
      if(!guideV){guideV=el('div','dep-guide dep-gv');guideV.style.display='none';}
      if(!guideH){guideH=el('div','dep-guide dep-gh');guideH.style.display='none';}
      if(guideV.parentNode!==root)root.appendChild(guideV);
      if(guideH.parentNode!==root)root.appendChild(guideH);
    }
    function clearGuides(){if(guideV)guideV.style.display='none';if(guideH)guideH.style.display='none';}
    function applySnap(fl){
      var f=frames()[cur]; var root=frameRoot(f)||f; if(!root)return; ensureGuides(root);
      var TH=6; /* 吸附阈值(页面坐标) */
      var me=flRect(fl);
      /* 页面中心线 1280×720 */
      var targets=[{x:640}]; var targetsY=[{y:360}];
      var others=allFloatsOnPage(),i;
      for(i=0;i<others.length;i++){if(others[i]===fl)continue;var o=flRect(others[i]);
        targets.push({x:o.cx},{x:o.x},{x:o.r}); targetsY.push({y:o.cy},{y:o.y},{y:o.b});}
      var snapped=false;
      var myXs=[{v:me.cx,off:me.w/2},{v:me.x,off:0},{v:me.r,off:me.w}];
      var showX=null;
      for(i=0;i<targets.length&&!showX;i++){
        for(var j=0;j<myXs.length;j++){
          if(Math.abs(myXs[j].v-targets[i].x)<=TH){
            fl.style.left=(targets[i].x-myXs[j].off)+'px';showX=targets[i].x;snapped=true;break;
          }
        }
      }
      var myYs=[{v:me.cy,off:me.h/2},{v:me.y,off:0},{v:me.b,off:me.h}];
      var showY=null;
      for(i=0;i<targetsY.length&&!showY;i++){
        for(var j2=0;j2<myYs.length;j2++){
          if(Math.abs(myYs[j2].v-targetsY[i].y)<=TH){
            fl.style.top=(targetsY[i].y-myYs[j2].off)+'px';showY=targetsY[i].y;snapped=true;break;
          }
        }
      }
      if(showX!=null){guideV.style.left=showX+'px';guideV.style.display='block';}else guideV.style.display='none';
      if(showY!=null){guideH.style.top=showY+'px';guideH.style.display='block';}else guideH.style.display='none';
    }

    /* ---------- 成组 / 解组 ---------- */
    function groupSel(){
      if(sels.length<2){tip('成组需要选中 2 个以上元素');return;}
      var f=frames()[cur]; var root=frameRoot(f)||f; if(!root)return; ensurePosRoot(root);
      pushHist();
      var rs=[],i,mnx=Infinity,mny=Infinity;
      for(i=0;i<sels.length;i++){var o=flRect(sels[i]);rs.push(o);if(o.x<mnx)mnx=o.x;if(o.y<mny)mny=o.y;}
      var g=el('div','dep-float dep-group');g.setAttribute('data-depfloat','group');
      g.style.left=mnx+'px';g.style.top=mny+'px';g.__s=1;
      root.appendChild(g);
      for(i=0;i<sels.length;i++){
        var fl=sels[i];
        fl.style.left=((parseFloat(fl.style.left)||0)-mnx)+'px';
        fl.style.top=((parseFloat(fl.style.top)||0)-mny)+'px';
        g.appendChild(fl);
      }
      g.__depHydrated=1; bindFloatDrag(g); makeDelX(g); makeScaler(g);
      selectFloat(g); tip('已成组');
    }
    function ungroupSel(){
      var g=null,i;
      for(i=0;i<sels.length;i++){if(sels[i].classList.contains('dep-group')){g=sels[i];break;}}
      if(!g){tip('请选中一个组');return;}
      var root=g.parentNode; if(!root)return; pushHist();
      var gx=parseFloat(g.style.left)||0, gy=parseFloat(g.style.top)||0;
      var kids=Array.prototype.slice.call(g.querySelectorAll(':scope > .dep-float'));
      var out=[];
      for(i=0;i<kids.length;i++){
        var fl=kids[i];
        fl.style.left=(gx+(parseFloat(fl.style.left)||0))+'px';
        fl.style.top=(gy+(parseFloat(fl.style.top)||0))+'px';
        root.appendChild(fl); out.push(fl);
      }
      if(g.parentNode)g.parentNode.removeChild(g);
      hydrateFloats(root); sels=out; paintSel(); tip('已解组');
    }

    /* ---------- 形状元素:矩形 / 圆 / 线 / 箭头 ---------- */
    function newShape(kind){
      var fl=el('div','dep-float dep-shape dep-'+kind);
      fl.setAttribute('data-depfloat','shape');
      fl.setAttribute('data-depshape',kind);
      var body=el('div','dep-shbody');
      fl.appendChild(body);
      makeDelX(fl);makeScaler(fl);bindFloatDrag(fl);
      fl.__depHydrated=1;
      return fl;
    }
    function addShape(kind){
      var fs=frames(); if(!fs.length){tip('没有可编辑的页面');return;}
      var f=fs[cur]; var root=frameRoot(f)||f; ensurePosRoot(root);
      pushHist();
      var fl=newShape(kind);
      var n=(floatSeq++)%6;
      fl.style.left=(180+n*26)+'px';
      fl.style.top=(180+n*26)+'px';
      fl.__s=1;
      root.appendChild(fl);
      selectFloat(fl);
      tip(kind==='rect'?'已加矩形':kind==='ellipse'?'已加圆形':kind==='line'?'已加线条':'已加箭头');
    }

    /* ---------- 选中浮层时的浮动操作条(层级/对齐/成组/形状样式)---------- */
    var shapeBar=el('div');shapeBar.id='depShape';shapeBar.className='dep-hidden';
    body.appendChild(shapeBar);
    var SHFILLS=['#2b6cff','#12b886','#f76707','#e8590c','#7048e8','#1a2233','#ffffff'];
    function buildShapeBar(){
      shapeBar.innerHTML='';
      function btn(txt,title,fn){var b=el('button',null,txt);b.title=title||txt;
        b.addEventListener('mousedown',function(e){e.preventDefault();});
        b.addEventListener('click',function(e){e.stopPropagation();fn();});return b;}
      shapeBar.appendChild(el('span','dep-cap','层级'));
      shapeBar.appendChild(btn('⤒','置顶',function(){zOrder('front');}));
      shapeBar.appendChild(btn('↑','上移一层',function(){zOrder('fwd');}));
      shapeBar.appendChild(btn('↓','下移一层',function(){zOrder('bwd');}));
      shapeBar.appendChild(btn('⤓','置底',function(){zOrder('back');}));
      shapeBar.appendChild(el('span','dep-sepv'));
      shapeBar.appendChild(el('span','dep-cap','对齐'));
      shapeBar.appendChild(btn('⇤','左对齐',function(){alignSel('left');}));
      shapeBar.appendChild(btn('⇔','水平居中',function(){alignSel('hcenter');}));
      shapeBar.appendChild(btn('⇥','右对齐',function(){alignSel('right');}));
      shapeBar.appendChild(btn('⤒T','顶对齐',function(){alignSel('top');}));
      shapeBar.appendChild(btn('⇕','垂直居中',function(){alignSel('vcenter');}));
      shapeBar.appendChild(btn('⤓B','底对齐',function(){alignSel('bottom');}));
      shapeBar.appendChild(btn('⇎','水平分布',function(){distribute('h');}));
      shapeBar.appendChild(btn('⇳','垂直分布',function(){distribute('v');}));
      shapeBar.appendChild(el('span','dep-sepv'));
      shapeBar.appendChild(btn('组','成组',function(){groupSel();}));
      shapeBar.appendChild(btn('解','解组',function(){ungroupSel();}));
      /* 若选中的是形状,追加填充色板 */
      var oneShape=(sels.length===1&&sels[0].classList.contains('dep-shape'))?sels[0]:null;
      if(oneShape){
        shapeBar.appendChild(el('span','dep-sepv'));
        shapeBar.appendChild(el('span','dep-cap','填充'));
        for(var i=0;i<SHFILLS.length;i++){(function(c){
          var sw=el('button','dep-cw');sw.style.background=c;sw.title=c;
          sw.addEventListener('mousedown',function(e){e.preventDefault();});
          sw.addEventListener('click',function(e){e.stopPropagation();
            pushHist();oneShape.style.setProperty('--dep-fill',c);tip('已改填充色');});
          shapeBar.appendChild(sw);
        })(SHFILLS[i]);}
      }
    }
    function shapeBarSpot(){
      /* 定位在选中元素上方,回退到顶部工具条下方 */
      var ref=sels.length?sels[0]:null;
      if(ref){var r=ref.getBoundingClientRect();
        shapeBar.style.left=Math.max(8,Math.min(window.innerWidth-shapeBar.offsetWidth-8,r.left))+'px';
        shapeBar.style.top=Math.max(56,r.top-shapeBar.offsetHeight-10)+'px';
      }else{shapeBar.style.left='12px';shapeBar.style.top='56px';}
    }
    function maybeShapeBar(){
      if(!body.classList.contains('deck-editing')||!sels.length){hideShapeBar();return;}
      buildShapeBar();
      shapeBar.classList.remove('dep-hidden');
      shapeBarSpot();
      dodgeBars();
    }
    function hideShapeBar(){shapeBar.classList.add('dep-hidden');}

    /* 形状按钮接线 */
    bRect.addEventListener('click',function(){addShape('rect');});
    bEll.addEventListener('click',function(){addShape('ellipse');});
    bLine.addEventListener('click',function(){addShape('line');});
    bArrow.addEventListener('click',function(){addShape('arrow');});

    /* ---------- 键盘快捷键(编辑态):Undo/Redo/复制/粘贴/删除 ---------- */
    function inTextEditing(){
      var a=document.activeElement;
      if(a&&(a.isContentEditable||a.tagName==='INPUT'||a.tagName==='TEXTAREA'))return true;
      /* 浮层正在双击编辑文字 */
      for(var i=0;i<sels.length;i++)if(sels[i].getAttribute('data-editing')==='1')return true;
      return false;
    }
    document.addEventListener('keydown',function(e){
      if(!body.classList.contains('deck-editing'))return;
      var mod=e.ctrlKey||e.metaKey;
      var k=(e.key||'').toLowerCase();
      if(mod&&k==='z'){ if(e.shiftKey){redo();}else{undo();} e.preventDefault();e.stopImmediatePropagation();return;}
      if(mod&&k==='y'){ redo(); e.preventDefault();e.stopImmediatePropagation();return;}
      if(inTextEditing())return;   /* 正在改文字时不拦截 C/V/Delete */
      if(mod&&k==='c'){ if(copySel()){e.preventDefault();e.stopImmediatePropagation();} return;}
      if(mod&&k==='v'){ pasteClip(); e.preventDefault();e.stopImmediatePropagation(); return;}
      if(mod&&k==='g'){ if(e.shiftKey)ungroupSel(); else groupSel(); e.preventDefault();e.stopImmediatePropagation(); return;}
      if(k==='delete'||k==='backspace'){ if(deleteSel()){e.preventDefault();e.stopImmediatePropagation();} return;}
    },true);


    function enableTextEdit(fl,area){
      fl.addEventListener('dblclick',function(e){
        if(!body.classList.contains('deck-editing'))return;
        e.stopPropagation();
        area.setAttribute('contenteditable','true');
        fl.setAttribute('data-editing','1');
        area.focus();
        try{var rng=document.createRange();rng.selectNodeContents(area);
          var selc=window.getSelection();selc.removeAllRanges();selc.addRange(rng);}catch(_){}
      });
      area.addEventListener('blur',function(){
        area.removeAttribute('contenteditable');
        fl.removeAttribute('data-editing');
      });
    }
    function enableImgPick(fl,box,ph){
      fl.addEventListener('dblclick',function(e){
        if(!body.classList.contains('deck-editing'))return;
        e.stopPropagation();
        var inp=document.createElement('input');inp.type='file';inp.accept='image/*';
        inp.addEventListener('change',function(){
          var file=inp.files&&inp.files[0]; if(!file)return;
          var rd=new FileReader();
          rd.onload=function(){
            var img=box.querySelector('img');
            if(!img){img=document.createElement('img');box.insertBefore(img,box.firstChild);}
            img.src=rd.result;
            fl.classList.add('dep-has-img');
            if(ph&&ph.parentNode)ph.parentNode.removeChild(ph);
          };
          rd.readAsDataURL(file);
        });
        inp.click();
      });
    }

    function newFloat(kind){
      var fl=el('div','dep-float dep-'+kind);
      fl.setAttribute('data-depfloat',kind);
      var anim=el('div','dep-fanim dep-anim');
      if(kind==='text'){
        anim.textContent='双击编辑文字';
        fl.appendChild(anim);
        enableTextEdit(fl,anim);
      }else if(kind==='card'){
        var t=el('div','dep-cardt');t.textContent='卡片标题';
        var b=el('div','dep-cardb');b.textContent='双击编辑卡片内容,支持多行说明文字。';
        anim.appendChild(t);anim.appendChild(b);
        fl.appendChild(anim);
        /* 卡片:双击进入编辑,标题与正文都可编 */
        fl.addEventListener('dblclick',function(e){
          if(!body.classList.contains('deck-editing'))return;
          e.stopPropagation();
          t.setAttribute('contenteditable','true');b.setAttribute('contenteditable','true');
          fl.setAttribute('data-editing','1');
          var tgt=(e.target.closest('.dep-cardb'))?b:t; tgt.focus();
        });
        function endCard(){t.removeAttribute('contenteditable');b.removeAttribute('contenteditable');
          fl.removeAttribute('data-editing');}
        t.addEventListener('blur',function(){setTimeout(function(){
          if(document.activeElement!==b&&document.activeElement!==t)endCard();},0);});
        b.addEventListener('blur',function(){setTimeout(function(){
          if(document.activeElement!==b&&document.activeElement!==t)endCard();},0);});
      }else{ /* img */
        var box=anim; box.classList.add('dep-imgbox');
        var ph=el('div','dep-imgph','双击上传图片');
        box.appendChild(ph);
        fl.appendChild(anim);
        enableImgPick(fl,box,ph);
      }
      makeDelX(fl);makeScaler(fl);
      if(kind==='text')makeResizer(fl);
      bindFloatDrag(fl);
      fl.__depHydrated=1;   /* 新建即已带活事件,避免后续 hydrateFloats 再摘控件重绑 */
      return fl;
    }

    function addFloat(kind){
      var fs=frames(); if(!fs.length){tip('没有可编辑的页面');return;}
      var f=fs[cur]; var root=frameRoot(f)||f; ensurePosRoot(root);
      var fl=newFloat(kind);
      /* 级联落点:页面中上部,依次错开,避免堆叠 */
      var n=(floatSeq++)%6;
      fl.style.left=(150+n*26)+'px';
      fl.style.top=(150+n*26)+'px';
      fl.__s=1;
      root.appendChild(fl);
      clearSel();fl.classList.add('dep-sel');
      tip(kind==='text'?'已加文字(双击编辑,拖拽移动)'
        :kind==='card'?'已加卡片(双击编辑内容)'
        :'已加图片位(双击上传)');
    }

    /* 复活既有浮层(来自上一轮导出的 HTML,或复制页克隆出的新页):重绑拖拽 + 按钮。
       传 scope 只处理该子树(复制页用);不传则全文。__depFloatBound 幂等守卫避免重复绑拖拽。 */
    function hydrateFloats(scope){
      var root=scope||document;
      var fls=root.querySelectorAll('.dep-float');
      for(var i=0;i<fls.length;i++){(function(fl){
        if(fl.__depHydrated)return;      /* 幂等:已复活过的不再重绑 dblclick,避免叠加 */
        fl.__depHydrated=1;
        var kind=fl.getAttribute('data-depfloat')||'text';
        /* 克隆/导出保留的是「死」控件(无 JS 事件):先摘掉旧的 ✕ / ± 再重建带事件的,
           否则 querySelector 命中旧节点会跳过重建,导致复制页/重开页的按钮点了没反应。 */
        var oldx=fl.querySelectorAll(':scope > .dep-elx,:scope > .dep-scaler,:scope > .dep-rz');
        for(var q=0;q<oldx.length;q++)oldx[q].parentNode.removeChild(oldx[q]);
        makeDelX(fl);makeScaler(fl);
        if(kind==='text')makeResizer(fl);
        if(fl.style.transform){var m=(''+fl.style.transform).match(/scale\(([\d.]+)\)/);if(m)fl.__s=parseFloat(m[1]);}
        var anim=fl.querySelector('.dep-fanim');
        if(kind==='text'&&anim)enableTextEdit(fl,anim);
        else if(kind==='img'&&anim){var ph=anim.querySelector('.dep-imgph');enableImgPick(fl,anim,ph);
          if(anim.querySelector('img'))fl.classList.add('dep-has-img');}
        else if(kind==='card'&&anim){
          var t=anim.querySelector('.dep-cardt'),b=anim.querySelector('.dep-cardb');
          fl.addEventListener('dblclick',function(e){if(!body.classList.contains('deck-editing'))return;
            e.stopPropagation();if(t)t.setAttribute('contenteditable','true');if(b)b.setAttribute('contenteditable','true');
            fl.setAttribute('data-editing','1');var tgt=(e.target.closest('.dep-cardb'))?b:t;if(tgt)tgt.focus();});
        }
        bindFloatDrag(fl);
      })(fls[i]);}
    }

    /* 翻页时重放浮层入场动效(与原生卡片重放语言一致) */
    function replayFloats(f){
      var scope=f||frames()[cur]; if(!scope)return;
      var as=scope.querySelectorAll('.dep-fanim.dep-anim');
      for(var i=0;i<as.length;i++){(function(a){
        a.style.animation='none'; /* 强制回流后清空以重触发 */
        void a.offsetWidth;
        a.style.animation='';
      })(as[i]);}
    }

    bText.addEventListener('click',function(){addFloat('text');});
    bCard.addEventListener('click',function(){addFloat('card');});
    bImg.addEventListener('click',function(){addFloat('img');});

    /* ---------- 编辑模式联动:监听 body.deck-editing ---------- */
    function setEnhance(on){
      bar.classList.toggle('dep-hidden',!on);
      rail.classList.toggle('dep-hidden',!on);
      saveBox.classList.toggle('dep-hidden',!on);
      if(on){buildRail();armImgSlots(true);armContentEdit(true);paintSaveStatus();markGradEls();}
      else{armImgSlots(false);armContentEdit(false);fontBar.classList.add('dep-hidden');fontTarget=null;hideDeco();clearSel();clearGuides();
        if(gradEditEl){gradEditEl.classList.remove('dep-gradedit');gradEditEl.style.removeProperty('--dep-solid');gradEditEl=null;}}
    }
    var lastEditing=body.classList.contains('deck-editing');
    /* bug#3:进入投影/演示态时,若当前页正停在「刚在编辑态新建、动效已在编辑时播完」的页上,
       不会再有 deck:nav 触发 → 该页浮层/卡片动效在全屏投影里不重放。演示者(speaker)窗口是
       blob/磁盘重载的新文档,CSS both 入场动效随插入自动播,故那边天然正常;真正出问题的只有
       投影(projector)主窗:它复用同一 live DOM,动效早在编辑时播完并停在终态。
       —— v2.3/v2.5 的教训 ——
       之前用「进投影后固定延时(60ms / fullscreenchange 后 90ms)重放一次」。但真机的【全屏切换
       过渡】耗时是【可变的几百毫秒】,任何固定延时都可能落在过渡【期间】(黑屏/缩放中)把动效播掉,
       等画面真正就位用户只看到终态。无头环境无真过渡,故两版都通过了却在真机失败。
       —— v2.6 的正确做法(不再赌延时)——
       1) 一进投影(projector)就给「当前页的动效节点」加 .dep-projhold,把它们摁回起始态
          (opacity:0、暂停动画)——这样过渡期无论多长,都【绝不】露出终态;
       2) 真正的播放由【事件】驱动:fullscreenchange(全屏真正就位)后 rAF+一拍才 play();
          play() 摘掉 hold → 回流 → 干净重放入场动效——此刻全屏已可见,是用户真正看到的那次;
       3) 安全兜底:900ms 内若 fullscreenchange 一直没来(如弹窗被拦、非全屏就地投影),
          强制 play() 一次,保证卡片绝不会永远停在 opacity:0。 */
    var lastProj=body.classList.contains('deck-projecting')||body.classList.contains('deck-speaker');
    function animNodesIn(scope){
      var out=[]; if(!scope)return out;
      var a=scope.querySelectorAll('.dep-fanim.dep-anim'),i;
      for(i=0;i<a.length;i++)out.push(a[i]);
      var b=scope.querySelectorAll('.dep-anim-rise,.dep-anim-fade,.dep-anim-zoom');
      for(i=0;i<b.length;i++)if(out.indexOf(b[i])<0)out.push(b[i]);
      return out;
    }
    function holdAnims(scope){
      var ns=animNodesIn(scope),i;for(i=0;i<ns.length;i++)ns[i].classList.add('dep-projhold');
    }
    function releaseAnims(scope){
      var ns=animNodesIn(scope),i;for(i=0;i<ns.length;i++)ns[i].classList.remove('dep-projhold');
    }
    /* speaker(blob 新文档)动效随插入自动播,无需干预;这里只处理 projector 主窗的补播 */
    var _projArmed=false;
    function playProjCurrent(){
      var fs=frames();var f=fs[cur]||fs[0];if(!f)return;
      releaseAnims(f);
      void body.offsetWidth;                 /* 回流:确保摘 hold 后动画能 off→on 重触发 */
      replayFloats(f);replayDeco(f);
    }
    function armProjectionArrival(){
      if(_projArmed)return; _projArmed=true;
      var fs=frames();var f=fs[cur]||fs[0];
      holdAnims(f);                           /* 立刻摁回起始态,过渡期不露终态 */
      var played=false;
      function play(){
        if(played)return; played=true;
        document.removeEventListener('fullscreenchange',onFs);
        document.removeEventListener('webkitfullscreenchange',onFs);
        clearTimeout(safety);
        /* 兜底再兜底:摘掉【全文档】所有 projhold,任何页都不可能被卡在 opacity:0 */
        var held=document.querySelectorAll('.dep-projhold'),k;
        for(k=0;k<held.length;k++)held[k].classList.remove('dep-projhold');
        playProjCurrent();
      }
      function onFs(){
        if(!document.fullscreenElement&&!document.webkitFullscreenElement)return;
        if(!body.classList.contains('deck-projecting'))return;
        /* 全屏真正就位后再等 rAF + 一拍,让宿主 fitProjector 的 transform 落定再播 */
        requestAnimationFrame(function(){setTimeout(play,120);});
      }
      document.addEventListener('fullscreenchange',onFs);
      document.addEventListener('webkitfullscreenchange',onFs);
      /* 兜底:全屏事件一直不来(弹窗被拦/就地投影/浏览器不触发)也必须播,绝不卡在 opacity:0 */
      var safety=setTimeout(play,900);
      /* 万一进入时已经处于全屏,补触发一次判定 */
      if(document.fullscreenElement||document.webkitFullscreenElement)onFs();
    }
    new MutationObserver(function(){
      var now=body.classList.contains('deck-editing');
      if(now!==lastEditing){
        lastEditing=now;setEnhance(now);
        /* bug#5:退出编辑回到【默认视图】时,若当前页有「刚在编辑态新建、入场动效已在插入时
           播完并停在终态」的浮层(＋卡片/＋文字/＋图片),因既不翻页(无 deck:nav)也不进投影,
           这些浮层的入场动效不会再播——用户看到的是「直接就位、没有动效」。演讲者(speaker)窗口
           是 blob/磁盘重载的新文档,CSS both 随插入自动播故那边天然正常;投影(projector)由
           armProjectionArrival 兜底;唯独【默认视图退出编辑】缺重放钩子。此处补一次当前页重放,
           让新建卡片的入场动效在默认模式也能看到。仅在非投影/演示态触发,避免与投影 hold-then-play
           竞争;导出流程里宿主同步 setEditing(false→was) 被本 observer 异步合并,退出编辑的重放
           发生在 clone 之后,不污染导出产物。 */
        if(!now&&!body.classList.contains('deck-projecting')&&!body.classList.contains('deck-speaker')){
          var _fs=frames();var _f=_fs[cur]||_fs[0];
          if(_f)setTimeout((function(ff){return function(){replayFloats(ff);replayDeco(ff);};})(_f),30);
        }
      }
      var proj=body.classList.contains('deck-projecting')||body.classList.contains('deck-speaker');
      if(proj!==lastProj){
        lastProj=proj;
        if(proj){
          if(body.classList.contains('deck-projecting'))armProjectionArrival();
          else replayCurrentSimple();          /* speaker 就地态:直接补一次即可 */
        }else{
          /* 退出投影:清掉可能遗留的 hold,别让卡片停在 opacity:0 */
          _projArmed=false;
          var fs=frames();releaseAnims(fs[cur]||fs[0]);
        }
      }
    }).observe(body,{attributes:true,attributeFilter:['class']});
    function replayCurrentSimple(){
      var fs=frames();var f=fs[cur]||fs[0];if(!f)return;
      setTimeout(function(){replayFloats(f);replayDeco(f);},60);
    }

    /* ---------- bug#2:编辑态导出 == 退出编辑后导出 ----------
       宿主 #deckExport 的点击处理里「同步」clone documentElement 下载;而我方增强控件
       的收起是靠上面的 MutationObserver「异步」响应 body 类变化的。于是「编辑模式下点导出」
       时,clone 发生在我方 setEnhance(false) 之前 → 把 #depBar/#depRail/.dep-imgtool 以及
       data-depce 的 contenteditable 一并固化进产物,和「退出编辑后再导出」不一致。
       修法:在 document 上加 capture 阶段监听,命中 #deckExport 时同步收起增强层。
       为何挂 document 而非按钮本身:同一元素上的多个监听按「注册顺序」在 target 阶段触发,
       capture 标志此时被忽略;宿主 export 监听注册在前,若挂按钮上我方会晚于宿主 clone 执行 →
       无效。挂到祖先 document 的 capture 阶段则真正先于目标按钮自身的监听执行。
       宿主处理末尾会 setEditing(was) 复原编辑态,body 类翻回 → 我方 observer 自动重新武装。 */
    /* v3.9:导出前把 docSig【按当前(已编辑)内容】重新烘进产物。
       背景:v3.9 为治「最后一页数字/文字改了刷新又变回原样」把 docSig 冻成注入期常量
       (BAKED_SIG),让【同一文件】反复重载指纹稳定、既有快照读得回。但这会带回审查早已修掉的
       bug#8——【导出的新文件】若原样继承同一枚常量,则「内容变了、指纹却没变」,重开时会被
       按同一把 key 缓存的【旧快照】遮蔽(表现:最后一页保存/导出后打开无变化、无痕≠正常)。
       两者的调和点:常量只对「同一份磁盘文件的重复载入」需要稳定,而【导出】本就是产出一份
       内容可能已变的【新文件】——所以在导出克隆发生前,用 deckSig() 按当前 live 内容重算一枚
       指纹,改写我方 <script> 里的 `var BAKED_SIG='…'` 字面量。于是:
        · 内容没改 → 重算结果与原常量相同 → 无副作用;
        · 内容改了 → 导出件带上不同的常量 → 重开获得不同 sig → 旧快照自然不再命中,新内容如实透出。
       宿主 #deckExport 是「同步 clone documentElement 下载」,故必须在【capture 阶段、先于按钮
       自身监听】完成改写(与下面收起增强层同理),克隆才能吃到新字面量。改写 script.textContent
       不会令其重新执行,只影响序列化产物。 */
    function rebakeExportSig(){
      try{
        var sc=document.getElementById('deckEditorPlusJS');
        if(!sc)return;
        var fresh=deckSig();
        var txt=sc.textContent;
        var re=/var BAKED_SIG='[^']*';/;
        if(re.test(txt))sc.textContent=txt.replace(re,"var BAKED_SIG='"+fresh+"';");
      }catch(e){}
    }
    document.addEventListener('click',function(e){
      var t=e.target;
      if(t&&t.closest&&t.closest('#deckExport')){
        if(body.classList.contains('deck-editing'))setEnhance(false);
        rebakeExportSig();
      }
    },true);

    /* ---------- bug#1:结构变更后双屏(投影+演讲者)仍同步 ----------
       宿主 launchProjector() 用 window.open(file://...?present=speaker) 开演讲者窗口——那是
       「从磁盘重载原始文件」,不含运行时新增/删除/重排的页。故必须把「当前 live DOM(含新增页)」
       交给演讲者窗口。
       曾用 Blob URL 直接喂给演讲者:页数是对了,但 Blob 文档是 opaque `null` 源,与 file:// 投影
       窗口【跨源】→ 宿主赖以同步的 BroadcastChannel('deck-sync') 与 localStorage 在两个源之间
       都【不通】→「双屏彻底不同步」(这是本轮回归的真正根因,真实双窗探针见 repro_twowin.py:
       演讲者 origin=null / scheme=blob:,投影 origin=file://)。
       修法(二合一,缺一不可):
        ① 仍用 Blob 承载新增页——演讲者内容才正确,且 Blob 是全新文档,CSS `both` 入场动效随
           节点插入【自动播】,故「演讲者模式动效正常」;
        ② 另建一条【postMessage 跨源桥】补上被 Blob 源隔断的按页同步——postMessage 允许跨源
           (探针 probe_postmsg.py 实证 file:// ↔ blob:null 双向可达、opener 可用)。
       桥两端(投影窗 / 演讲者窗)跑的是同一份注入脚本(Blob 即 live DOM 克隆,含本增强层),故对称:
       任一端翻页 → 经 deck:nav 向对端 postMessage({__depSync:idx}) → 对端 __deck.go(idx)(带
       __depSyncMute 防回环)。演讲者就绪后向 opener 报到({__depReady}),投影据此把当前页推过去,
       完成首帧对齐。属结构态,不进 localStorage。见 verify_editor_dualsync_export.py / repro_e2e.py。 */
    function buildSpeakerDocURL(){
      var wasEd=body.classList.contains('deck-editing');
      if(wasEd)setEnhance(false);
      var clone=document.documentElement.cloneNode(true);
      var eds=clone.querySelectorAll('[contenteditable]');
      for(var i=0;i<eds.length;i++)eds[i].removeAttribute('contenteditable');
      var htmlStr='<!doctype html>\n'+clone.outerHTML;
      if(wasEd)setEnhance(true);
      try{return URL.createObjectURL(new Blob([htmlStr],{type:'text/html;charset=utf-8'}));}catch(e){return null;}
    }
    var _depSpk=null;         /* 投影侧:持有的演讲者窗口句柄 */
    var _depSyncMute=false;   /* 收到远端 idx 并 go() 时置位,阻断 deck:nav 回环 */
    function depSyncSend(idx){
      try{if(_depSpk&&!_depSpk.closed)_depSpk.postMessage({__depSync:idx},'*');}catch(e){}
      try{if(window.opener)window.opener.postMessage({__depSync:idx},'*');}catch(e){}
    }
    window.addEventListener('message',function(e){
      var d=e.data;if(!d)return;
      if(d.__depReady){if(window.__deck)depSyncSend(window.__deck.cur());return;}
      if(typeof d.__depSync!=='number'||!window.__deck)return;
      if(d.__depSync===window.__deck.cur())return;
      _depSyncMute=true;try{window.__deck.go(d.__depSync);}catch(_e){}_depSyncMute=false;
    });
    document.addEventListener('deck:nav',function(e){
      if(_depSyncMute)return;
      var idx=(e.detail&&typeof e.detail.idx==='number')?e.detail.idx:(window.__deck?window.__deck.cur():0);
      depSyncSend(idx);
    });
    /* 演讲者(blob)就绪 → 向 opener 报到,让投影把当前页推过来,首帧即对齐 */
    document.addEventListener('deck:ready',function(){
      try{if(window.opener)window.opener.postMessage({__depReady:true},'*');}catch(e){}
    });
    if(!window.__depOpenPatched){
      window.__depOpenPatched=1;
      var _open=window.open;
      window.open=function(u,name,feat){
        try{
          if(typeof u==='string'&&u.indexOf('present=speaker')>=0){
            var burl=buildSpeakerDocURL();
            if(burl){
              var w=_open.call(window,burl+'#present=speaker',name,feat);
              _depSpk=w;
              try{setTimeout(function(){if(window.__deck)depSyncSend(window.__deck.cur());},600);}catch(e){}
              return w;
            }
          }
        }catch(e){}
        return _open.call(window,u,name,feat);
      };
    }

    /* ---------- bug#6:翻页入场动效必须在【页面滑入到位后】才播,而不是固定 30ms ----------
       宿主 #deckTrack 有 `transition:transform .55s` 的整页横向滑入过渡。旧实现在 deck:nav 后
       固定 30ms 就重放卡片的 0.5s 入场动效 —— 于是动效整段都发生在【页面还在侧滑、尚未进入视口
       中央】的过程里,等滑动结束(~550ms)动效恰好也刚播完并停在终态,用户看到的永远是「页面到位
       即终态、没有入场」。全屏投影下滑动更显眼,故用户在「新建页面上的新建卡片」最容易察觉(该页
       是运行时插入的,armProjectionArrival 只武装了进投影时的当前页,翻到新页只走 deck:nav 这条
       固定延时路径 → 必现)。这正是 v2.6 projhold 早已警告过的「固定延时会落在过渡期把动效播掉」,
       只是发生在【翻页】而非【进投影】路径上。
       修法(与 hold-then-play 同一套哲学,统一到所有模式):翻到目标页先 holdAnims 摁回起始态
       (滑入期绝不露终态),再由 track 的 transitionend(transform,滑动真正到位)驱动 release+
       重放 —— 此刻页面已居中静止,是用户真正看到入场动效的那一次。附 620ms(>0.55s)安全兜底:
       reduced-motion / 目标即当前位 / 浏览器不触发 transitionend 时也必定重放,绝不卡在 opacity:0。
       _navTok 保证连续快速翻页只有最后一次生效,避免过期回调把新页动效误摘/误播。 */
    var _navTok=0;
    function prefersReduced(){
      try{return window.matchMedia&&window.matchMedia('(prefers-reduced-motion:reduce)').matches;}catch(e){return false;}
    }
    function armNavArrival(f){
      if(!f)return;
      var tok=++_navTok;
      /* reduced-motion:宿主 track 过渡被禁用(无 transitionend),不 hold,直接重放,避免空等兜底 */
      if(prefersReduced()){releaseAnims(f);replayFloats(f);replayDeco(f);return;}
      holdAnims(f);
      var played=false,safety=null;
      function play(){
        if(played||tok!==_navTok)return; played=true;
        if(track)track.removeEventListener('transitionend',onEnd);
        clearTimeout(safety);
        releaseAnims(f);
        void body.offsetWidth;               /* 回流:摘 hold 后 animation 才能 off→on 重触发 */
        replayFloats(f);replayDeco(f);
      }
      function onEnd(ev){
        if(ev.target!==track)return;         /* 只认 track 自身的 transform 过渡,忽略子元素 */
        if(ev.propertyName&&ev.propertyName!=='transform')return;
        play();
      }
      if(track)track.addEventListener('transitionend',onEnd);
      safety=setTimeout(play,620);           /* 无滑动过渡也必播的兜底 */
    }
    /* 侧栏当前页高亮跟随翻页 + 每次翻到该页都重放动效(演示态同样生效)*/
    document.addEventListener('deck:nav',function(e){
      cur=(e.detail&&typeof e.detail.idx==='number')?e.detail.idx:cur;
      if(!rail.classList.contains('dep-hidden'))paintRailCur();
      var fs=frames();var f=fs[cur];
      if(f&&window.__deckEditorPlus&&window.__deckEditorPlus.markZoom)window.__deckEditorPlus.markZoom(f);
      armNavArrival(f);   /* 滑入到位(transitionend)后再重放入场动效,别在侧滑期把动效偷播掉 */
    });
    /* 首屏就位也重放一次:保证第一页(或直接定位到某页)进入时动效就播,
       而不必等翻页;宿主 deck:ready 同样触发。 */
    document.addEventListener('deck:ready',function(){
      var fs=frames();var f=fs[cur]||fs[0];
      setTimeout(function(){replayFloats(f);replayDeco(f);},60);
    });
    /* 重放用户改过动效的卡片/数字/文字。动效类带 !important,inline animation:none 压不住,
       必须「摘类→回流→重挂类」才能重播;命中 .stat/.card 容器、卡片内 .num/文字子块、
       以及浮层内层 .dep-fanim。数字若带动效则顺带重跑宿主 count-up,数字从头计数。 */
    function replayDeco(f){
      var scope=f||frames()[cur]; if(!scope)return;
      var ns=scope.querySelectorAll('.dep-anim-rise,.dep-anim-fade,.dep-anim-zoom');
      var hitNum=false;
      for(var i=0;i<ns.length;i++){(function(a){
        var cls='';
        for(var j=0;j<ANIMCLS.length;j++)if(a.classList.contains(ANIMCLS[j])){cls=ANIMCLS[j];break;}
        if(cls)restartAnim(a,cls);
        if(a.classList&&a.classList.contains('num'))hitNum=true;
        else if(a.querySelector&&a.querySelector('.num .v[data-to]'))hitNum=true;
      })(ns[i]);}
      /* 有被赋予动效的数字 → 让宿主 count-up 从头再数一遍,与 CSS 动效同步 */
      if(hitNum){
        try{if(window.__mcCountReset)window.__mcCountReset(scope);}catch(er){}
        try{if(window.__mcCount)window.__mcCount(scope);}catch(er2){}
      }
    }

    /* ---------- 编辑态:把宿主 count-up「静置」化,根治「最后一页数字保存不下来」---------- */
    /* 真因:宿主 count-up 的 tick() 每一帧都把 el.textContent 覆写成 round(ease(p)*to),持续约
       1.3s,且闭包一旦 requestAnimationFrame 启动就【无法取消】。用户翻到某页(尤其最后的总览页)
       后立刻点进数字改成如 99,动画仍在跑:每帧把「99」冲掉,syncNumber 读到的永远是动画中间值,
       data-to 也就永远变不成 99 → 表现为「数字改了、翻页/保存后又变回去」。
       之前只放宽 syncNumber 命中范围治标不治本——只要动画还在逐帧写 textContent,输入必被冲掉。
       做法:宿主把 __mcCount/__mcCountReset 挂在 window 上,且其 deck:nav 处理器是【运行时动态读取】
       这两个函数的;我们在此【包装覆盖】它们——
         · 编辑态:不做逐帧动画,直接把数字静置到 data-to 终值,并【完全跳过】用户正在编辑
           (当前有焦点)或已编辑过(带 data-depedited)的数字,一个字都不碰;
         · 演示态:原样委托宿主实现,count-up 动画照旧。
       因宿主每次翻页都会重新读取 window.__mcCount,我们的覆盖能在真正的冲写点(deck:nav)命中。 */
    var _hostCount=window.__mcCount,_hostReset=window.__mcCountReset;
    function _editingNow(){return body.classList.contains('deck-editing');}
    function _numBusy(el){
      if(!el)return false;
      if(el.getAttribute&&el.getAttribute('data-depedited')==='1')return true;  /* 用户已改过 */
      var a=document.activeElement;                                             /* 用户正在改:焦点落在该数字或其内层 */
      return !!(a&&a.nodeType===1&&a!==body&&(a===el||(el.contains&&el.contains(a))));
    }
    function _settleVs(scope){
      var vs=(scope||document).querySelectorAll('.v[data-to]');
      for(var i=0;i<vs.length;i++){var el=vs[i];
        if(_numBusy(el))continue;                 /* 用户在改/改过的数字:绝不覆写 */
        var to=el.getAttribute('data-to');
        el.textContent=(to==null?el.textContent:String(to));
        el.setAttribute('data-counted','1');
      }
    }
    window.__mcCount=function(scope){
      if(_editingNow()){_settleVs(scope);return;}
      try{if(_hostCount)return _hostCount(scope);}catch(e){}
    };
    window.__mcCountReset=function(scope){
      /* 编辑态里「清零重数」正是冲掉用户输入的元凶,故编辑态用静置替代;演示态委托宿主 */
      if(_editingNow()){_settleVs(scope);return;}
      try{if(_hostReset)return _hostReset(scope);}catch(e){}
    };

    /* 就地编辑标题 → 左侧栏 chip 标题实时同步(动态取实际标题,不整栏重建)*/
    var railSyncT=null;
    function syncRailTitles(){
      if(rail.classList.contains('dep-hidden'))return;
      var chips=rail.querySelectorAll('.dep-chip'),fs=frames();
      for(var i=0;i<chips.length&&i<fs.length;i++){
        var tEl=chips[i].querySelector('.dep-ttl');if(!tEl)continue;
        var full=titleOf(fs[i]);var show=full;if(show.length>26)show=show.slice(0,26)+'…';
        tEl.textContent=show||'(空白页)';tEl.title=full||'';
      }
    }
    document.addEventListener('input',function(e){
      if(!body.classList.contains('deck-editing'))return;
      /* 改的是大数字 → 同步 data-to,让 count-up 动效终点跟随用户新值。
         v3.9:命中范围放宽——不再只认 `.num .v`(那只覆盖 m-c/m-d2/m-f 卡片),
         价值总览页(m-g)的百分比数字在 `.pct .v[data-to]` 里,旧判定漏掉它,导致
         用户在最后一页(总览页)改数字后 data-to 不更新,count-up 每次载入把它冲回原值
         →「最后一页数字改了保存不下来」。改为:被编辑节点自身或其祖先带 data-to,
         即取那枚 data-to 节点做 syncNumber(既覆盖 .num/.pct 等一切数字位,也兼顾
         用户光标落在数字内层文本节点的情况)。 */
      var t=e.target,numEl=null;
      if(t&&t.nodeType===1){
        if(t.getAttribute&&t.getAttribute('data-to')!=null)numEl=t;
        else if(t.closest){numEl=t.closest('[data-to]');}
      }
      if(numEl)syncNumber(numEl);
      clearTimeout(railSyncT);railSyncT=setTimeout(syncRailTitles,180);
    },true);

    /* ---------- 图片点击放大(lightbox)----------
       非编辑态点内容图片 → 全屏居中放大;右上角 ✕ / 点背景 / Esc 恢复。
       编辑态点=拖拽/选中,故这里显式守卫 deck-editing 时不拦截。
       overlay 挂 body,平时 display:none;随宿主导出克隆一并带走(仍受同一份注入 CSS
       约束:关闭态不可见、@media print 隐藏),导出的 HTML 里图片放大能力照样可用。 */
    var lb=el('div');lb.id='depLightbox';
    var lbImg=el('img');lb.appendChild(lbImg);
    var lbClose=el('button',null,'✕');lbClose.id='depLbClose';lbClose.title='关闭 (Esc)';
    lb.appendChild(lbClose);
    body.appendChild(lb);
    function openLightbox(src){
      if(!src)return;
      lbImg.setAttribute('src',src);
      lb.classList.add('dep-show');
    }
    function closeLightbox(){
      lb.classList.remove('dep-show');
      /* 收起动画结束后清空 src,释放大图占用 */
      setTimeout(function(){if(!lb.classList.contains('dep-show'))lbImg.removeAttribute('src');},240);
    }
    /* 点背景(非图片本身)或 ✕ 关闭;Esc 关闭 */
    lb.addEventListener('click',function(e){if(e.target===lbImg)return;closeLightbox();});
    lbClose.addEventListener('click',function(e){e.stopPropagation();closeLightbox();});
    document.addEventListener('keydown',function(e){
      if((e.key==='Escape'||e.keyCode===27)&&lb.classList.contains('dep-show'))closeLightbox();
    },true);

    function imgSrcOf(node){
      if(node.tagName==='IMG')return node.getAttribute('src');
      var im=node.querySelector('img');return im?im.getAttribute('src'):null;
    }
    /* 排除 logo / 装饰(飞鸟/光晕/联合LOGO/品牌)/ 控件里的图 / 明确的小图标 */
    function isDecorImg(im){
      if(!im)return true;
      if(im.closest&&im.closest('.bird,.bloom,.lockup,.cobrand,.brand,.deck-dots,'+
         '#depBar,#depRail,#depFont,#depDeco,#depLightbox'))return true;
      var w=im.naturalWidth||im.width||0,h=im.naturalHeight||im.height||0;
      if(w&&h&&(w<80||h<60))return true;   /* 尺寸已知且很小 → 视作图标/logo,不放大 */
      return false;
    }
    /* 标注可放大图片:图片位(data-edimg)、新增图片浮层(.dep-float.dep-img)、
       以及页面正文里独立的内容图;给 zoom-in 光标。data-depzoom 随导出克隆固化。 */
    function markZoomable(scope){
      scope=scope||document;
      var slots=scope.querySelectorAll('[data-edimg],.dep-float.dep-img'),i;
      for(i=0;i<slots.length;i++){
        var im=slots[i].querySelector('img');
        if(im&&!isDecorImg(im))slots[i].setAttribute('data-depzoom','1');
        else slots[i].removeAttribute('data-depzoom');
      }
      var imgs=scope.querySelectorAll('.deck-frame img'),j;
      for(j=0;j<imgs.length;j++){
        var m=imgs[j];
        if(m.closest&&m.closest('[data-edimg],.dep-float.dep-img'))continue;
        if(isDecorImg(m))m.removeAttribute('data-depzoom');
        else m.setAttribute('data-depzoom','1');
      }
    }
    /* 委托点击:非编辑态点到可放大图片 → 开 lightbox。编辑态一律不拦(点=拖拽/选中)。 */
    document.addEventListener('click',function(e){
      if(body.classList.contains('deck-editing'))return;
      var t=e.target;
      if(t&&t.closest&&(t.closest('.dep-imgtool')||t.closest('.dep-scaler')||
         t.closest('.dep-elx')||t.closest('#depLightbox')))return;
      var z=t&&t.closest?t.closest('[data-depzoom]'):null;
      if(!z)return;
      var src=imgSrcOf(z);
      if(src){e.preventDefault();openLightbox(src);}
    });

    /* ---------- 启动:恢复草稿 ---------- */
    /* 先给【首屏既有页】铸一枚【确定性】data-deppg(按 DOM 次序 'p0/p1/…')——它必须
       可跨「普通重载」复现,回存(applyStoredFonts/Imgs)才能按页命名空间精确命中原页;
       随后【运行时】新建/复制页由 pageId() 现铸【随机唯一】id,故绝不会与首屏页或彼此相撞。
       导出产物里 data-deppg 已随克隆固化,重开时此处见到已有值即跳过,页身份原样保留。 */
    function stampInitialPages(){
      if(!track)return;var fs=track.children,i;
      for(i=0;i<fs.length;i++){if(!fs[i].getAttribute('data-deppg'))fs[i].setAttribute('data-deppg','p'+i);}
    }
    stampInitialPages();
    /* 若存在【全量保存】快照,先整段还原 #deckTrack(含增/删/重排页、浮层、内联字号/图片/形状等
       编辑已烘进 HTML),再走常规回存/复活。快照里 data-deppg 已随保存固化,stampInitialPages
       见到已有值即跳过,页命名空间与保存时一致,store 桶回存能精确命中。

       v3.4:全量快照存于 IndexedDB(取回是【异步】的),故还原分两步——
       ①同步:fullMeta() 判定「有无快照」,有则先把状态回显成「已保存」并【暂缓】常规回存
         (避免在旧 DOM 上先复活一遍、再被整段替换掉,做无用功且可能闪一下);
       ②异步:restoreFullAsync 取回大 HTML 替换 track 后,再统一跑复活 revive()。
       无快照时立即 revive()。 */
    function revive(restored){
      applyStoredFonts();applyStoredImgs();hydrateFloats();markZoomable();
      if(restored){
        refreshNav();
        /* 快照是保存那一刻的静态 HTML:宿主 count-up 数字被烙成当时的文本(可能是未跑完的中途值),
           且新 DOM 上没有宿主的计数状态。还原后对当前页补一次 replayDeco → 内部 __mcCountReset/__mcCount
           让带动效的数字从头再数、收敛到 data-to;并直接兜底重跑一次宿主全量 count-up。 */
        var _rf=frames()[cur]||frames()[0];
        if(_rf)replayDeco(_rf);
        try{if(window.__mcCount)window.__mcCount(track);}catch(e){}
      }
      paintSaveStatus();
      if(lastEditing)setEnhance(true);
    }
    var _meta=fullMeta();
    /* 「打开即清缓存」逃生口(修 bug:同一 HTML 无痕模式与正常模式展示不一致——正常模式被本站
       旧缓存快照遮蔽)。带 ?depfresh=1(或 #depfresh)打开时,启动早期清掉【本文档】的
       deckeditplus* 键 + IDB 快照,然后【跳过还原】直接透出文件自带内容,使正常模式与无痕一致。
       只清本文档(按 docSig 定位的键),不动别的 deck 的存档。 */
    function wantFresh(){
      var s=(''+(location.search||''))+'&'+(''+(location.hash||''));
      return /(?:[?#&])depfresh(?:=(?:1|true|yes))?(?:[&#]|$)/i.test(s);
    }
    if(wantFresh()){
      clearFull(true);                      /* 静默清本文档 localStorage 键 + IDB 快照 */
      _savedTs=0;_dirty=false;paintSaveStatus();
      revive(false);                        /* 跳过还原,显示文件自带内容 */
    }else if(_meta){
      _savedTs=_meta.ts||0;paintSaveStatus();   /* 先同步回显「已保存 …」,避免异步取回前状态空窗 */
      restoreFullAsync(function(ok){ revive(ok); });
    }else{
      revive(false);
    }

    function warn(m){if(window.console&&console.warn)console.warn('[deck-editor] '+m);}
    window.__deckEditorPlus.go=go;
    window.__deckEditorPlus.markZoom=markZoomable;
    window.__deckEditorPlus.dodgeBars=resolveBarOverlap;   /* 测试钩子:同步跑一次工具条去重叠 */
    window.__deckEditorPlus.refresh=function(){refreshNav();if(!rail.classList.contains('dep-hidden'))buildRail();};
  });
})();
</script>
"""


def _djb2(s: str) -> str:
    """与运行期 JS 的 hash() 同算法(djb2 变体,逆序遍历),保证同串同码。
    JS: var h=5381,i=s.length;while(i){h=(h*33)^s.charCodeAt(--i);}return (h>>>0).toString(36);"""
    h = 5381
    for ch in reversed(s):
        h = ((h * 33) ^ ord(ch)) & 0xFFFFFFFF
    # (h>>>0).toString(36)
    if h == 0:
        return "0"
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    out = ""
    while h:
        out = digits[h % 36] + out
        h //= 36
    return out


def _host_only(html: str) -> str:
    """剥掉我方注入块,拿到宿主原始 HTML(用于算稳定指纹)。"""
    if BEGIN in html and END in html:
        pre = html.split(BEGIN, 1)[0]
        post = html.split(END, 1)[1]
        return pre + post
    return html


def compute_baked_sig(host_html: str) -> str:
    """在【注入时】按宿主原始内容算一枚稳定指纹,写死进文件当运行期常量。
    取自 <title> + 全文可见文本(粗略去标签/脚本/样式)+【图片/媒体摘要】——只要宿主底稿不变
    就稳定,宿主重新生成(内容变,含【仅换图】)则指纹变、旧快照自然不再命中。这是文件级常量,
    运行期不再受宿主 data-edt 回存层改写 DOM 的影响(修「同一文件每次重载指纹漂移、快照对不上」)。
    v3.11:补采图片/媒体——旧版只哈希可见文本,对图失明,导致【文字相同、配图不同】的两卷命中
    同一把 key,A 卷缓存快照在 B 卷【正常模式】下整段遮蔽 B 真身(无痕无缓存故正常)。故把每个
    img src / svg <image> href / style background url 的【摘要】并入指纹。"""
    # <title>
    m = re.search(r"<title[^>]*>(.*?)</title>", host_html, re.S | re.I)
    title = re.sub(r"\s+", " ", (m.group(1) if m else "")).strip()
    # 去掉 script/style 内容,再去标签,取可见文本
    body = host_html
    body = re.sub(r"<script\b[^>]*>.*?</script>", " ", body, flags=re.S | re.I)
    body = re.sub(r"<style\b[^>]*>.*?</style>", " ", body, flags=re.S | re.I)
    text = re.sub(r"<[^>]+>", " ", body)
    text = re.sub(r"\s+", " ", text).strip()
    # 图片/媒体摘要:img src、svg <image> (xlink:)href、内联 style 的 background url
    media = []
    for mm in re.finditer(r"<img\b[^>]*?\ssrc\s*=\s*(['\"])(.*?)\1", host_html, re.S | re.I):
        media.append("i" + _djb2(mm.group(2)))
    for mm in re.finditer(r"<image\b[^>]*?\s(?:xlink:)?href\s*=\s*(['\"])(.*?)\1", host_html, re.S | re.I):
        media.append("s" + _djb2(mm.group(2)))
    for mm in re.finditer(r"background[^:>]*:\s*[^;>\"']*url\(([^)]*)\)", host_html, re.S | re.I):
        media.append("b" + _djb2(mm.group(1)))
    media_str = " ".join(media)
    return _djb2(title + "|" + text + "||@M@" + media_str)


def build_block(baked_sig: str = ""):
    js = EDITOR_JS.strip()
    if baked_sig:
        js = js.replace(SIG_TOKEN, baked_sig)
    return "\n".join([BEGIN, EDITOR_CSS.strip(), js, END, ""])


def inject(html: str):
    """返回 (new_html, status)。status: 'injected' | 'reinjected' | 'nomarker'"""
    baked_sig = compute_baked_sig(_host_only(html))
    block = build_block(baked_sig)
    if BEGIN in html and END in html:
        # 已注入过 → 原样替换我们自己的块(升级增强层)
        pre = html.split(BEGIN, 1)[0]
        post = html.split(END, 1)[1]
        return pre + block + post, "reinjected"
    lower = html.lower()
    idx = lower.rfind("</body>")
    if idx == -1:
        # 没有 </body>,退到 </html> 前;再没有就直接追加
        idx = lower.rfind("</html>")
    if idx == -1:
        return html + "\n" + block, "injected-appended"
    return html[:idx] + block + html[idx:], "injected"


def main():
    ap = argparse.ArgumentParser(description="把增强编辑层注入 deck.html")
    ap.add_argument("input", help="输入 deck.html 路径")
    ap.add_argument("-o", "--out", help="输出路径(默认 <input>.edit.html)")
    ap.add_argument("--in-place", action="store_true", help="原地写回(先备份 .bak)")
    ap.add_argument("--check", action="store_true", help="只检测是否已注入,不写文件")
    args = ap.parse_args()

    if not os.path.isfile(args.input):
        print("ERROR: 输入文件不存在: %s" % args.input, file=sys.stderr)
        sys.exit(2)

    with open(args.input, "r", encoding="utf-8") as f:
        html = f.read()

    if args.check:
        has = (MARKER in html) or (BEGIN in html)
        print("INJECTED" if has else "CLEAN")
        sys.exit(0)

    new_html, status = inject(html)

    if args.in_place:
        shutil.copyfile(args.input, args.input + ".bak")
        out = args.input
    else:
        out = args.out or (os.path.splitext(args.input)[0] + ".edit.html")

    with open(out, "w", encoding="utf-8") as f:
        f.write(new_html)

    print("OK status=%s out=%s bytes=%d" % (status, out, len(new_html)))


if __name__ == "__main__":
    main()
