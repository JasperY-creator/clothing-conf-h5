from playwright.sync_api import sync_playwright
import pathlib, sys, tempfile, shutil

# Regression for Task 5 (v3.7): bug#8 — last-page edits "disappear" on export, and same
# HTML shows differently in incognito vs normal mode. Root cause: deckSig() only sampled
# the first page's title + first data-edt, so a NON-first-page (esp. last page) text edit
# didn't change the fingerprint → the exported file (new content baked in) got masked by an
# OLD cached snapshot sharing the same sig. Fixes:
#   A) deckSig() now samples EVERY page's stable text (count-up numbers keyed by data-to,
#      so it stays stable across reloads) → content change ⇒ new sig ⇒ old snapshot no
#      longer masks the fresh file.
#   B) ?depfresh=1 opens the HTML with a clean slate (clears this doc's cache + skips
#      restore) so normal mode matches incognito.
#
# Uses a real detail-page fixture with .fpoint cards (depce bottom text on the LAST page).

_t = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/real_deck.edit.html"
url = "file://" + str(pathlib.Path(_t).resolve())
LAUNCH_ARGS = ["--disable-dev-shm-usage", "--no-sandbox", "--disable-gpu"]

JS_CLEAR_ALL = """()=>new Promise(function(res){
  try{for(var i=localStorage.length-1;i>=0;i--){var k=localStorage.key(i);if(k&&k.indexOf('deckeditplus')===0)localStorage.removeItem(k);}}catch(e){}
  try{var rq=indexedDB.open('deckeditplus',1);
    rq.onupgradeneeded=function(e){try{e.target.result.createObjectStore('snaps');}catch(_){}};
    rq.onsuccess=function(){var db=rq.result;try{var tx=db.transaction('snaps','readwrite');tx.objectStore('snaps').clear();tx.oncomplete=function(){db.close();res(true);};tx.onerror=function(){try{db.close();}catch(_){}res(true);};}catch(e){try{db.close();}catch(_){}res(true);}};
    rq.onerror=function(){res(true);};
  }catch(e){res(true);}
})"""

# edit the first depce-only bottom card text (no data-edt) on the LAST page to `marker`
def _js_edit_last_depce(marker):
    return (r"""(i)=>{var f=document.getElementById('deckTrack').children[i];
      var c=f.querySelectorAll('[data-depce]');
      for(var k=0;k<c.length;k++){if(!c[k].getAttribute('data-edt')){c[k].innerHTML='"""+marker+r"""';c[k].dispatchEvent(new Event('input',{bubbles:true}));return true;}}
      return false;}""")

def _js_last_has(marker):
    return (r"""()=>{var t=document.getElementById('deckTrack');var f=t.children[t.children.length-1];
      return f.innerHTML.indexOf('"""+marker+r"""')>=0;}""")

fails=[]
def ck(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ")+name+("" if cond else "  <<< "+str(extra)))
    if not cond: fails.append(name)

class Session(object):
    def __init__(self, pw, profile, u):
        self.pw=pw; self.profile=profile; self.url=u; self.ctx=None; self.pg=None; self._launch()
    def _launch(self):
        self.ctx=self.pw.chromium.launch_persistent_context(self.profile, headless=True, args=LAUNCH_ARGS, viewport={"width":1280,"height":720})
        self.pg=self.ctx.pages[0] if self.ctx.pages else self.ctx.new_page()
        self.pg.on("dialog", lambda d: d.accept())
    def _relaunch(self):
        try: self.ctx.close()
        except Exception: pass
        self._launch()
    def goto(self, wait=900, tries=5, u=None):
        target=u or self.url; last=None
        for _ in range(tries):
            try:
                self.pg.goto(target, wait_until="load"); self.pg.wait_for_timeout(wait); return
            except Exception as e:
                last=e
                try: self._relaunch()
                except Exception: pass
        raise last
    def reload(self, wait=1200, u=None): self._relaunch(); self.goto(wait, u=u)
    def ev(self, js, *a): return self.pg.evaluate(js, *a) if a else self.pg.evaluate(js)
    def wait(self, ms):
        try: self.pg.wait_for_timeout(ms)
        except Exception: pass
    def poll(self, js, want=True, timeout=5000, step=120):
        waited=0
        while waited<timeout:
            try:
                if self.ev(js)==want: return True
            except Exception: pass
            self.wait(step); waited+=step
        return False
    def close(self):
        try: self.ctx.close()
        except Exception: pass

with sync_playwright() as p:
    prof = tempfile.mkdtemp(prefix="deckedit_t5_")
    try:
        S = Session(p, prof, url)
        S.goto(900)
        S.ev(JS_CLEAR_ALL)
        S.reload(900)
        ck("version is 3.11", S.ev("()=>window.__deckEditorPlus&&window.__deckEditorPlus.v")=="3.11")
        n = S.ev("()=>document.getElementById('deckTrack').children.length")
        ck("fixture has >=2 pages", n>=2, n)

        # --- SESSION 1: edit LAST page depce text -> save (creates cached snapshot V1) ---
        S.ev("()=>document.getElementById('deckEdit').click()"); S.wait(250)
        S.ev("(i)=>window.__deck.go(i)", n-1); S.wait(200)
        ck("edited a last-page depce node (V1)", S.ev(_js_edit_last_depce('V1-SNAP-MARKER'), n-1))
        S.wait(200)
        S.ev("()=>{var b=document.querySelector('#depSaveBox .dep-savebtn');if(b)b.click();}")
        S.wait(1000)

        # within-session reload still restores the saved edit (normal save/restore intact)
        S.reload(1400)
        ck("A) same-session reload restores saved last-page edit", S.poll(_js_last_has('V1-SNAP-MARKER'), True, 5000))

        # --- SESSION 2 (same profile → cache present): live-edit LAST page to V2 (NO save), export ---
        S.ev(r"""()=>{window.__exp=null;var _c=URL.createObjectURL;URL.createObjectURL=function(b){try{b.text().then(function(x){window.__exp=x;});}catch(e){}try{return _c.call(URL,b);}catch(e){return 'blob:stub';}};}""")
        S.ev("()=>document.getElementById('deckEdit').click()"); S.wait(250)
        S.ev("(i)=>window.__deck.go(i)", n-1); S.wait(200)
        ck("edited last-page depce node (V2 live)", S.ev(_js_edit_last_depce('V2-LIVE-MARKER'), n-1))
        S.wait(150)
        S.ev("()=>document.getElementById('deckEdit').click()"); S.wait(250)   # exit WITHOUT our save
        S.ev("()=>{var b=document.getElementById('deckExport');if(b)b.click();}")
        S.wait(700)
        exp = S.ev("()=>window.__exp||''")
        ck("B) export reflects the NEW last-page edit (V2 present)", ('V2-LIVE-MARKER' in exp), len(exp))
        ck("B) export does NOT contain stale V1", ('V1-SNAP-MARKER' not in exp))

        # write exported file, reopen in SAME profile (V1 snapshot still cached in IDB)
        outp = "/tmp/e2r/_t5_exported.html"
        pathlib.Path(outp).write_text(exp, encoding="utf-8")
        S.close()

        S2 = Session(p, prof, "file://"+str(pathlib.Path(outp).resolve()))
        S2.goto(1400)
        ck("C) reopened export shows its OWN new content (V2), not stale cache (V1)",
           S2.poll(_js_last_has('V2-LIVE-MARKER'), True, 5000) and not S2.ev(_js_last_has('V1-SNAP-MARKER')))
        S2.close()

        # --- depfresh: reopen ORIGINAL fixture (which HAS the V1 cache) with ?depfresh=1 ---
        # It must ignore the cached snapshot and show the file's own baseline (no marker).
        S3 = Session(p, prof, url)
        # first confirm cache still masks without the flag:
        S3.goto(1400)
        cachedShows = S3.poll(_js_last_has('V1-SNAP-MARKER'), True, 4000)
        # note: after reopening the exported file above we did NOT save, so IDB still holds V1
        ck("D-pre) without depfresh, cached V1 still restores", cachedShows)
        # now with the flag
        S3.reload(1400, u=url+"?depfresh=1")
        S3.wait(600)
        ck("D) ?depfresh=1 clears cache -> last page shows baseline, NOT cached V1",
           not S3.ev(_js_last_has('V1-SNAP-MARKER')))
        ck("D) ?depfresh=1 wiped the meta record",
           not S3.ev("()=>{for(var i=0;i<localStorage.length;i++){if((localStorage.key(i)||'').indexOf('deckeditplusmeta:')===0)return true;}return false;}"))
        S3.close()
    finally:
        shutil.rmtree(prof, ignore_errors=True)

print("\n==== "+("ALL PASS" if not fails else ("FAILED: "+", ".join(fails)))+" ====")
sys.exit(1 if fails else 0)
