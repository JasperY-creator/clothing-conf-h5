from playwright.sync_api import sync_playwright
import pathlib, sys

# Functional test for the gradient-clip edit-mode fix (v3.7).
# On focusin of a gradient-clipped element in edit mode, the editor should add .dep-gradedit
# and the CSS should flip -webkit-text-fill-color from transparent -> solid currentColor,
# forcing a repaint (the fix for "text vanishes on click"). On focusout it reverts.

t = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/real_deck.edit.html"
url = "file://" + str(pathlib.Path(t).resolve())
ARGS = ["--disable-dev-shm-usage", "--no-sandbox", "--disable-gpu"]

def transparent(fill):
    return "transparent" in fill or fill.strip().endswith(", 0)")

FIND = r"""()=>{
  // find first gradient-clipped element anywhere in the deck
  var all=document.querySelectorAll('.tname,.bignum,.cover h2,h1,h2,.ptitle,[class]');
  for(var i=0;i<all.length;i++){
    var e=all[i]; var c=getComputedStyle(e);
    var clip=(c.webkitBackgroundClip||c.getPropertyValue('-webkit-background-clip')||'');
    var fill=(c.webkitTextFillColor||'');
    if(clip.indexOf('text')>=0 && (/transparent/.test(fill)||/,\s*0\s*\)\s*$/.test(fill))
       && (e.textContent||'').trim()){
      // tag it so we can re-select
      e.setAttribute('data-gctest','1');
      return {tag:e.tagName, cls:e.className, txt:(e.textContent||'').slice(0,16)};
    }
  }
  return null;
}"""

with sync_playwright() as p:
    b = p.chromium.launch(headless=True, args=ARGS)
    pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.goto(url, wait_until="load"); pg.wait_for_timeout(900)
    ver = pg.evaluate("()=>window.__deckEditorPlus&&window.__deckEditorPlus.v")
    print("editor version:", ver)
    # enter edit mode
    pg.evaluate("()=>{var e=document.getElementById('deckEdit');if(e)e.click();else document.body.classList.add('deck-editing');}")
    pg.wait_for_timeout(400)
    target = pg.evaluate(FIND)
    print("gradient-clipped target:", target)
    if not target:
        print(">>> NO gradient-clipped element found in this fixture — skip")
        b.close(); sys.exit(0)
    sel = "[data-gctest='1']"
    before = pg.eval_on_selector(sel, "el=>{var c=getComputedStyle(el);return c.webkitTextFillColor;}")
    # make it editable + focus (reproduce host click-to-edit)
    pg.eval_on_selector(sel, """el=>{el.setAttribute('contenteditable','true');el.focus();
      var r=document.createRange();r.selectNodeContents(el);var s=getSelection();
      s.removeAllRanges();s.addRange(r);s.collapseToEnd();}""")
    pg.wait_for_timeout(250)
    has_cls = pg.eval_on_selector(sel, "el=>el.classList.contains('dep-gradedit')")
    after = pg.eval_on_selector(sel, "el=>{var c=getComputedStyle(el);return c.webkitTextFillColor;}")
    # blur -> revert
    pg.eval_on_selector(sel, "el=>{el.blur();document.body.focus&&document.body.focus();}")
    pg.evaluate("()=>{var d=document.createElement('button');d.id='__blurhelper';document.body.appendChild(d);d.focus();}")
    pg.wait_for_timeout(250)
    has_cls_after = pg.eval_on_selector(sel, "el=>el.classList.contains('dep-gradedit')")
    revert = pg.eval_on_selector(sel, "el=>{var c=getComputedStyle(el);return c.webkitTextFillColor;}")

    print("\n  fill BEFORE focus :", before, "(transparent=%s)" % transparent(before))
    print("  .dep-gradedit on focus:", has_cls)
    print("  fill DURING focus :", after, "(transparent=%s)" % transparent(after))
    print("  .dep-gradedit after blur:", has_cls_after)
    print("  fill AFTER  blur  :", revert, "(transparent=%s)" % transparent(revert))

    ok = (transparent(before) and has_cls and (not transparent(after))
          and (not has_cls_after))
    print("\n>>> FIX %s" % ("WORKS ✓" if ok else "FAILED ✗"))
    b.close()
    sys.exit(0 if ok else 1)
