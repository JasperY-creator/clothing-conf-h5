from playwright.sync_api import sync_playwright
import pathlib, sys, json
# 需求1 回归 —— 图片点击放大 lightbox。
# 断言:
#  A) 非编辑态点内容图片(data-edimg / .dep-float.dep-img)→ #depLightbox 显示且 img.src 被填;
#  B) 点右上角 ✕ → 关闭(dep-show 移除);再开,点背景 → 关闭;再开,按 Esc → 关闭;
#  C) 编辑态点图片【不】开 lightbox(点=拖拽/选中),depLightbox 保持关闭;
#  D) logo/装饰图(.bird/.lockup 等)不被标 data-depzoom(不可放大);
#  E) 导出克隆里仍带 #depLightbox 结构 + 图片 data-depzoom(导出的 HTML 放大能力照常)。
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())

def lb_shown(pg):
    return pg.evaluate("()=>{var l=document.getElementById('depLightbox');return !!l&&l.classList.contains('dep-show');}")

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(1000)

    assert pg.evaluate("()=>!!document.getElementById('depLightbox')"), "#depLightbox must exist"
    assert not lb_shown(pg), "lightbox closed initially"

    # 该 fixture 只有装饰 logo、无内容图。仿 verify_editor_img.py:向一个内容页注入一张合成内容图
    # (足够大以躲过 isDecorImg 的尺寸阈值),再让增强层重新标记 data-depzoom。
    pg.evaluate(r"""()=>{
      var frs=window.__deck.frames, i, host=null;
      for(i=1;i<frs.length;i++){var c=frs[i].querySelector('.content,.deck-scale')||frs[i];if(c){host=c;break;}}
      if(!host)host=frs[frs.length-1];
      var slot=document.createElement('div');
      slot.setAttribute('data-edimg','synthetic-lb');
      slot.style.cssText='width:300px;height:200px;';
      var img=document.createElement('img');
      var cv=document.createElement('canvas');cv.width=300;cv.height=200;
      var cx=cv.getContext('2d');cx.fillStyle='#4a80ff';cx.fillRect(0,0,300,200);
      img.src=cv.toDataURL('image/png');
      img.width=300;img.height=200;
      img.style.cssText='width:300px;height:200px;';
      slot.appendChild(img); host.appendChild(slot);
      if(window.__deckEditorPlus&&window.__deckEditorPlus.markZoom)window.__deckEditorPlus.markZoom();
    }"""); pg.wait_for_timeout(150)

    # find a page holding a zoomable content image; navigate to it
    info = pg.evaluate(r"""()=>{
      var frs=window.__deck.frames, i, found=-1, src='';
      for(i=0;i<frs.length;i++){
        var z=frs[i].querySelector('[data-edimg][data-depzoom],.dep-float.dep-img[data-depzoom],img[data-depzoom]');
        if(z){found=i;var im=(z.tagName==='IMG')?z:z.querySelector('img');src=im?im.getAttribute('src'):'';break;}
      }
      return {found:found,total:frs.length};}""")
    print("zoomable page:", info)
    assert info["found"] >= 0, "at least one zoomable image must be marked in the deck"
    pg.evaluate("(i)=>window.__deck.go(i)", info["found"]); pg.wait_for_timeout(250)

    # (A) click the zoomable image -> opens
    pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var z=f.querySelector('[data-edimg][data-depzoom],.dep-float.dep-img[data-depzoom],img[data-depzoom]');
      (z.tagName==='IMG'?z:z.querySelector('img')||z).click();}""")
    pg.wait_for_timeout(150)
    src_now = pg.evaluate("()=>document.getElementById('depLightbox').querySelector('img').getAttribute('src')||''")
    print("A) opened?", lb_shown(pg), "| img src set?", bool(src_now))
    assert lb_shown(pg), "clicking a content image must OPEN the lightbox"
    assert src_now, "lightbox <img> src must be set to the clicked image"

    # (B1) close via ✕
    pg.evaluate("()=>document.getElementById('depLbClose').click()"); pg.wait_for_timeout(150)
    assert not lb_shown(pg), "✕ must CLOSE the lightbox"
    # (B2) reopen, close via background click
    pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var z=f.querySelector('[data-depzoom]');(z.tagName==='IMG'?z:z.querySelector('img')||z).click();}""")
    pg.wait_for_timeout(120); assert lb_shown(pg)
    pg.evaluate("()=>document.getElementById('depLightbox').click()"); pg.wait_for_timeout(150)
    assert not lb_shown(pg), "clicking backdrop must CLOSE the lightbox"
    # (B3) reopen, close via Esc
    pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var z=f.querySelector('[data-depzoom]');(z.tagName==='IMG'?z:z.querySelector('img')||z).click();}""")
    pg.wait_for_timeout(120); assert lb_shown(pg)
    pg.keyboard.press("Escape"); pg.wait_for_timeout(150)
    assert not lb_shown(pg), "Esc must CLOSE the lightbox"
    print("B) close via ✕ / backdrop / Esc all OK")

    # (C) edit mode: click must NOT open lightbox
    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(200)
    pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      var z=f.querySelector('[data-depzoom]');if(z){(z.tagName==='IMG'?z:z.querySelector('img')||z).click();}}""")
    pg.wait_for_timeout(150)
    print("C) edit-mode click opened?", lb_shown(pg))
    assert not lb_shown(pg), "in EDIT mode clicking an image must NOT open the lightbox (click = drag/select)"
    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(200)  # exit edit

    # (D) decorative images (bird/lockup) not zoomable
    deco = pg.evaluate(r"""()=>{var d=document.querySelectorAll('.bird img,.lockup img,.cobrand img,.brand img'),bad=0,i;
      for(i=0;i<d.length;i++){if(d[i].getAttribute('data-depzoom')==='1')bad++;}return {count:d.length,bad:bad};}""")
    print("D) decorative imgs:", deco)
    assert deco["bad"] == 0, "logo/decorative images must NOT be marked zoomable"

    # (E) export clone keeps lightbox structure + zoom marks
    ex = pg.evaluate(r"""()=>{var c=document.documentElement.cloneNode(true);
      return {hasLb:!!c.querySelector('#depLightbox'),
              zoomCount:c.querySelectorAll('[data-depzoom="1"]').length};}""")
    print("E) export clone:", ex)
    assert ex["hasLb"], "exported clone must contain #depLightbox"
    assert ex["zoomCount"] >= 1, "exported clone must keep at least one zoomable image mark"

    print("LIGHTBOX (req#1) PASSED — click-to-zoom, ✕/backdrop/Esc close, edit-mode safe, decor excluded, export-persisted")
    b.close()
