from playwright.sync_api import sync_playwright
import pathlib, json, sys, re
def parse_px(s):
    m = re.search(r"[-\d.]+", s or "")
    return float(m.group()) if m else 0.0
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.goto(url); pg.wait_for_timeout(700)
    pg.evaluate("() => { var e=document.getElementById('deckEdit'); if(e) e.click(); }")
    pg.wait_for_timeout(300)

    # --- (A) blank page = only header/title/footer, content emptied ---
    # navigate to a content page first (cover has no .content skeleton)
    pg.evaluate("() => { window.__deck && window.__deck.go && window.__deck.go(1); }")
    pg.wait_for_timeout(200)
    blank = pg.evaluate(r"""() => {
      var bar=document.getElementById('depBar');
      var btns=bar.querySelectorAll('button'); // [0]dup [1]blank [2]del ...
      var before=document.querySelectorAll('#deckTrack > *').length;
      btns[1].click(); // blank
      var fs=document.querySelectorAll('#deckTrack > *');
      var newFrame=fs[fs.length>=2?1:0]; // blank inserted after current (cur=0 -> idx1)
      // find the just-inserted blank: it's the frame at cur (controller moved cur to +1)
      // simpler: scan for a frame whose .content is empty
      var target=null;
      for(var i=0;i<fs.length;i++){
        var pgx=fs[i].querySelector('.page');
        if(!pgx) continue;
        var c=pgx.querySelector('.content');
        if(c && c.children.length===0){ target=fs[i]; break; }
      }
      var res={before:before, after:fs.length};
      if(target){
        var pgx=target.querySelector('.page');
        res.hasEyebrow = !!(pgx.querySelector('.eyebrow')||pgx.querySelector('.kicker'));
        res.hasTitle   = !!pgx.querySelector('.ptitle');
        res.hasFoot    = !!pgx.querySelector('.pfoot');
        var c=pgx.querySelector('.content');
        res.contentChildren = c ? c.children.length : -1;
        res.titleText = (pgx.querySelector('.ptitle')||{}).textContent || '';
      } else {
        res.foundBlank=false;
      }
      return res;
    }""")
    print("A blank page:", json.dumps(blank, ensure_ascii=False))
    assert blank["after"] == blank["before"] + 1, "blank should add one frame"
    assert blank.get("hasEyebrow") and blank.get("hasTitle") and blank.get("hasFoot"), "blank keeps header/title/footer"
    assert blank.get("contentChildren") == 0, "blank .content must be empty"

    # --- (B) card float text resizable ---
    cardfont = pg.evaluate(r"""() => {
      var bar=document.getElementById('depBar');
      var btns=bar.querySelectorAll('button');
      btns[4].click(); // +card
      var card=document.querySelector('.dep-float.dep-card');
      var t=card.querySelector('.dep-cardt')||card.querySelector('.dep-cardb');
      t.click();
      var fb=document.getElementById('depFont');
      var shown=!fb.classList.contains('dep-hidden');
      var before=getComputedStyle(t).fontSize;
      var fb2=fb.querySelectorAll('button'); // [A-,A+,reset]
      fb2[1].click(); fb2[1].click(); fb2[1].click();
      return {barShown:shown, before:before, after:getComputedStyle(t).fontSize,
              hasFit:t.hasAttribute('data-fit')};
    }""")
    print("B card font:", json.dumps(cardfont, ensure_ascii=False))
    assert cardfont["barShown"], "font bar must show on card text"
    assert parse_px(cardfont["after"]) > parse_px(cardfont["before"]), "card text font must grow"

    # --- (C) host big-number / arbitrary text resizable, color+fit preserved ---
    bignum = pg.evaluate(r"""() => {
      // go to a content page; find a big number .num .v or any .num/.stat text
      var cand=document.querySelector('.num .v, .num, .stat .t, .ptitle, h2, p');
      if(!cand) return {found:false};
      // scroll its frame into current view isn't needed; just click
      var colorBefore=getComputedStyle(cand).color;
      cand.click();
      var fb=document.getElementById('depFont');
      var shown=!fb.classList.contains('dep-hidden');
      var before=getComputedStyle(cand).fontSize;
      var fb2=fb.querySelectorAll('button');
      fb2[1].click(); fb2[1].click();
      return {found:true, barShown:shown, before:before, after:getComputedStyle(cand).fontSize,
              colorBefore:colorBefore, colorAfter:getComputedStyle(cand).color,
              hasFit:cand.hasAttribute('data-fit'), tag:cand.tagName, cls:cand.className};
    }""")
    print("C big/text font:", json.dumps(bignum, ensure_ascii=False))
    assert bignum["found"], "should find a text/number element"
    assert bignum["barShown"], "font bar must show on host text/number"
    assert parse_px(bignum["after"]) > parse_px(bignum["before"]), "host text font must grow"
    assert bignum["colorAfter"] == bignum["colorBefore"], "color must be preserved"
    assert bignum["hasFit"] == False, "data-fit must be dropped so host won't revert"

    # --- (D) dynamic rail title: edit a title, chip text follows ---
    dyn = pg.evaluate(r"""() => {
      // pick frame 1 (content), set its .ptitle text, dispatch input, read its chip
      var fs=document.querySelectorAll('#deckTrack > *');
      var idx=1<fs.length?1:0;
      var t=fs[idx].querySelector('.ptitle');
      if(!t) return {ok:false};
      t.textContent='动态标题测试XYZ';
      t.dispatchEvent(new Event('input',{bubbles:true}));
      return {ok:true};
    }""")
    pg.wait_for_timeout(300)
    dyn2 = pg.evaluate(r"""() => {
      var chips=document.querySelectorAll('#depRail .dep-chip');
      var idx=1<chips.length?1:0;
      var ttl=chips[idx].querySelector('.dep-ttl');
      return {chipText: ttl?ttl.textContent:'', chipTitle: ttl?ttl.title:''};
    }""")
    print("D dynamic title:", json.dumps(dyn2, ensure_ascii=False))
    assert '动态标题测试XYZ' in dyn2["chipTitle"], "rail chip title must follow edited title"

    print("BATCH B ASSERTIONS PASSED")
    b.close()
