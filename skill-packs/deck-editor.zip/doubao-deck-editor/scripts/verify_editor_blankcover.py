from playwright.sync_api import sync_playwright
import pathlib, sys, json
# bug#4 回归 —— 首页(封面)新增空白页不得出现纯黑页面。
# 根因:封面版式为 .deck-scale > .cover-wrap(承载页面背景 --fs-grad-mesh)> .cover > ...,
#   没有 .content、也没有 .ptitle/.eyebrow/.pfoot。早期 addPage('blank') 的 else 分支按
#   "删除不在白名单里的直接子节点" 处理 —— 封面唯一的直接子节点恰是承载背景的 .cover-wrap,
#   它不匹配任何白名单 → 被整块删除 → 页面失去背景 → 投影黑底上呈现为纯黑页。
# 修法:改为"包含式保留"(保住包含标题/页眉/页脚的背景包裹层)+ 黑屏兜底(绝不删光所有子节点)
#   + 保住背景后再清掉可安全识别的纯装饰叶子(光晕/飞鸟/联合LOGO/元信息)。
# 断言:首页 +空白页 后,新页仍保有 .cover-wrap 且其 background-image 非 none;
#   纯装饰(.bloom/.bird/.cobrand)被清掉;标题保留可改写;侧栏 chip 数同步;
#   渲染像素为浅色(非黑)。
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width":1280,"height":720})
    pg.goto(url); pg.wait_for_timeout(1000)
    pg.evaluate("()=>document.getElementById('deckEdit').click()"); pg.wait_for_timeout(200)
    # 确认首页确为无 .content 的封面版式(否则本用例前提不成立)
    isCover = pg.evaluate(r"""()=>{var f=window.__deck.frames[0];var ds=f.querySelector('.deck-scale')||f;
      return {noContent:!ds.querySelector('.content'), hasCoverWrap:!!ds.querySelector('.cover-wrap')};}""")
    print("first frame:", isCover)
    assert isCover["noContent"] and isCover["hasCoverWrap"], "precondition: first frame is a no-.content cover with .cover-wrap"

    n0 = pg.evaluate("()=>window.__deck.total")
    pg.evaluate("()=>window.__deck.go(0)"); pg.wait_for_timeout(120)
    pg.evaluate(r"""()=>{var bs=document.getElementById('depBar').querySelectorAll('button');
      for(var i=0;i<bs.length;i++){if(/空白/.test(bs[i].textContent)){bs[i].click();return;}}}""")
    pg.wait_for_timeout(300)

    r = pg.evaluate(r"""()=>{var i=window.__deck.cur();var f=window.__deck.frames[i];
      var ds=f.querySelector('.deck-scale')||f;var wrap=ds.querySelector('.cover-wrap');
      var surf=wrap||ds;var scs=getComputedStyle(surf);
      return {cur:i,total:window.__deck.total,hasCoverWrap:!!wrap,
        bgimg:scs.backgroundImage,
        hasBloom:!!ds.querySelector('.bloom'),hasBird:!!ds.querySelector('.bird'),
        hasCobrand:!!ds.querySelector('.cobrand'),
        title:((ds.querySelector('.ptitle,.title-zone h1,.title-zone h2')||{}).textContent||'').trim(),
        rail:document.querySelectorAll('#depRail .dep-chip').length};}""")
    print("after +blank on cover:", json.dumps(r, ensure_ascii=False))

    assert r["total"] == n0 + 1, "frame count must +1"
    assert r["cur"] == 1, "new blank page inserted right after page 0"
    assert r["hasCoverWrap"], "background-carrying .cover-wrap MUST survive (else black page)"
    assert r["bgimg"] and r["bgimg"] != "none", "surface must keep a background image (mesh gradient), not be transparent/black"
    assert not (r["hasBloom"] or r["hasBird"] or r["hasCobrand"]), "cover decorations should be stripped -> a real blank, not a cover copy"
    assert r["title"], "a title placeholder must remain for identification/inline-edit"
    assert r["rail"] == r["total"], "rail chip count stays in sync with frames"

    # 像素级:渲染出来必须是浅色,不能是纯黑
    pg.evaluate("()=>window.__deck.go(1)"); pg.wait_for_timeout(200)
    pg.screenshot(path="/tmp/e2r/_blankcover_check.png")
    from PIL import Image
    im = Image.open("/tmp/e2r/_blankcover_check.png").convert("RGB")
    w,h = im.size
    dark = 0; samples = [(w//2,h//2),(w//4,h//3),(3*w//4,2*h//3),(w//2,h//4),(w//3,h//2)]
    for x,y in samples:
        px = im.getpixel((x,y)); s = sum(px)
        if s < 90: dark += 1  # near-black
        print("  px", (x,y), px)
    assert dark == 0, "rendered blank-on-cover page must NOT be black at any sample point"

    print("BLANKCOVER (bug#4) PASSED — cover blank page keeps background, no black page")
    b.close()
