from playwright.sync_api import sync_playwright
import pathlib, json, sys
# bug#3 v2.6 权威回归 —— 模拟真机【可变长度】全屏切换过渡,复现前两版(固定延时)漏掉的真根因。
# 之前 v2.3/v2.5 都在「进投影后固定延时」重放:真机过渡耗时可变(几百 ms),固定延时可能落在过渡
# 期间把动效播掉 → 用户只看到终态。无头无真过渡,故那两版通过了却在真机失败。
# v2.6 改为:进投影先给动效节点摁上 .dep-projhold(opacity:0、暂停),过渡多长都不露终态;
# 真正播放由 fullscreenchange【事件】驱动(全屏就位后),外加 900ms 安全兜底。
# 本测试断言三件事:
#   A) 进投影后、fullscreenchange 之前的【整个过渡期】,卡片恒 opacity:0(被 hold,不露终态、不偷播);
#   B) 伪造全屏就位 + 派发 fullscreenchange 之后,动效被【重新触发】——采样出现 0<opacity<1 的中间帧,
#      最终收敛到 opacity:1;
#   C) (安全兜底)另一条路径:fullscreenchange 永不到来时,900ms 后卡片必须到 opacity:1(不卡在 0)。
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())

def setup(pg):
    pg.goto(url); pg.wait_for_timeout(1200)
    pg.evaluate("()=>{document.getElementById('deckEdit').click();}"); pg.wait_for_timeout(250)
    pg.evaluate("()=>{document.getElementById('depBar').querySelectorAll('button')[1].click();}"); pg.wait_for_timeout(250)
    total = pg.evaluate("()=>window.__deck.total")
    pg.evaluate("(n)=>{window.__deck.go(n-1);}", total); pg.wait_for_timeout(200)
    cardPage = pg.evaluate("()=>window.__deck.cur()")
    pg.evaluate("()=>{document.getElementById('depBar').querySelectorAll('button')[4].click();}"); pg.wait_for_timeout(200)
    pg.evaluate(r"""()=>{var f=window.__deck.frames[window.__deck.cur()];
      f.querySelector('.dep-float.dep-card').click();
      document.getElementById('depDeco').querySelectorAll('.dep-anb')[0].click();}"""); pg.wait_for_timeout(300)
    pg.evaluate("()=>{document.getElementById('deckEdit').click();}"); pg.wait_for_timeout(300)
    pg.evaluate(r"""(cp)=>{var f=window.__deck.frames[cp];
      window.__cardInner=f.querySelector('.dep-float.dep-card .dep-fanim');}""", cardPage)
    return cardPage

def cs(pg):
    return pg.evaluate(r"""()=>{var el=window.__cardInner;var c=getComputedStyle(el);
      return {opacity:c.opacity,transform:c.transform,anim:c.animationName};}""")

with sync_playwright() as p:
    b = p.chromium.launch(headless=True)

    # ---------- Path A/B: transition then fullscreenchange arrives ----------
    pg = b.new_page(viewport={"width":1280,"height":720})
    cardPage = setup(pg)
    # enter projection (host launchProjector adds this class first)
    pg.evaluate("()=>document.body.classList.add('deck-projecting')")
    pg.wait_for_timeout(50)  # let observer arm + hold apply
    # (A) sample across a LONG variable transition (700ms) — card must stay held at opacity:0
    heldOK = True
    for _ in range(7):
        pg.wait_for_timeout(100)
        s = cs(pg)
        if s["opacity"] != "0":
            heldOK = False
        print("  during-transition:", json.dumps(s, ensure_ascii=False))
    print("A) held at start-state (opacity:0) through whole transition? ->", heldOK)
    assert heldOK, "card must be HELD at opacity:0 during fullscreen transition (never flash end-state, never pre-play)"

    # (B) fullscreen truly engages -> dispatch fullscreenchange
    pg.evaluate(r"""()=>{
      try{Object.defineProperty(document,'fullscreenElement',{configurable:true,get:function(){return document.documentElement;}});}catch(e){}
      document.dispatchEvent(new Event('fullscreenchange'));
    }""")
    frames=[]
    for tag in ["fs+80","fs+180","fs+300","fs+460","fs+680"]:
        pg.wait_for_timeout(90)
        s=cs(pg); s["tag"]=tag; frames.append(s); print("  ", json.dumps(s, ensure_ascii=False))
    mid = any(0.0 < float(f["opacity"]) < 1.0 or f["transform"] not in ("none","matrix(1, 0, 0, 1, 0, 0)") for f in frames)
    pg.wait_for_timeout(500)  # let the .6s entrance fully complete before checking settle
    settled = float(cs(pg)["opacity"]) == 1.0
    print("B) mid-animation frame after fullscreenchange? ->", mid, "| settled to 1? ->", settled)
    assert mid, "animation must RE-TRIGGER after fullscreen engages (user actually sees the entrance)"
    assert settled, "animation must settle to opacity:1"

    # ---------- Path C: fullscreenchange NEVER arrives -> safety timer plays ----------
    pg2 = b.new_page(viewport={"width":1280,"height":720})
    setup(pg2)
    pg2.evaluate("()=>document.body.classList.add('deck-projecting')")
    # do NOT dispatch fullscreenchange; wait past the 900ms safety net
    pg2.wait_for_timeout(1800)
    s2 = pg2.evaluate(r"""()=>{var c=getComputedStyle(window.__cardInner);return {opacity:c.opacity,transform:c.transform};}""")
    print("C) no-fullscreen safety fallback final:", json.dumps(s2, ensure_ascii=False))
    assert float(s2["opacity"]) == 1.0, "safety timer must play/settle card even if fullscreenchange never fires (never stuck at opacity:0)"

    print("PROJHOLD REPLAY (v2.6) PASSED — held during transition, plays on fullscreen, safe fallback")
    b.close()
