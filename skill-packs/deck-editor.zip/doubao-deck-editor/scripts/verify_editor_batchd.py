from playwright.sync_api import sync_playwright
import pathlib, json, sys, re
def parse_px(s):
    m = re.search(r"[-\d.]+", s or "")
    return float(m.group()) if m else 0.0
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.goto(url); pg.wait_for_timeout(1400)  # count-up
    pg.evaluate("() => { var e=document.getElementById('deckEdit'); if(e) e.click(); }")
    pg.wait_for_timeout(300)
    pg.evaluate("() => { window.__deck && window.__deck.go && window.__deck.go(1); }")
    pg.wait_for_timeout(250)

    # --- (1) card/number animation: adjust / delete / add via #depDeco ---
    anim = pg.evaluate(r"""() => {
      var stat=document.querySelector('.stat');
      if(!stat) return {found:false};
      stat.click();
      var deco=document.getElementById('depDeco');
      var shown=!deco.classList.contains('dep-hidden');
      var anb=deco.querySelectorAll('.dep-anb'); // [rise,fade,zoom,none]
      // set zoom
      anb[2].click();
      var hasZoom=stat.classList.contains('dep-anim-zoom');
      // delete (none)
      anb[3].click();
      var hasNone=stat.classList.contains('dep-anim-none');
      var hasZoom2=stat.classList.contains('dep-anim-zoom');
      // add rise
      anb[0].click();
      var hasRise=stat.classList.contains('dep-anim-rise');
      return {found:true, shown:shown, hasZoom:hasZoom, hasNone:hasNone,
              zoomClearedAfterNone:!hasZoom2, hasRise:hasRise};
    }""")
    print("1 anim:", json.dumps(anim, ensure_ascii=False))
    assert anim["found"], "should find a .stat card"
    assert anim["shown"], "deco panel must show on card"
    assert anim["hasZoom"], "zoom applied"
    assert anim["hasNone"] and anim["zoomClearedAfterNone"], "none replaces/deletes prior anim"
    assert anim["hasRise"], "rise added"

    # --- (1b) animation actually EFFECTIVE: computed animation-name must be our keyframe ---
    anim2 = pg.evaluate(r"""() => {
      var stat=document.querySelector('.stat');
      var deco=document.getElementById('depDeco');
      stat.click();
      var anb=deco.querySelectorAll('.dep-anb'); // [rise,fade,zoom,none]
      anb[2].click(); // zoom
      var cs=getComputedStyle(stat);
      var name=cs.animationName;
      // and a float card too (anim must land on inner .dep-fanim, not scaled outer)
      var bar=document.getElementById('depBar');
      bar.querySelectorAll('button')[4].click(); // +card
      var fc=document.querySelector('.dep-float.dep-card');
      fc.click();
      deco.querySelectorAll('.dep-anb')[0].click(); // rise on float card
      var inner=fc.querySelector('.dep-fanim');
      return {statAnimName:name, statHasClass:stat.classList.contains('dep-anim-zoom'),
              floatInnerName:getComputedStyle(inner).animationName,
              floatInnerHasClass:inner.classList.contains('dep-anim-rise'),
              floatOuterHasClass:fc.classList.contains('dep-anim-rise')};
    }""")
    print("1b anim effective:", json.dumps(anim2, ensure_ascii=False))
    assert anim2["statAnimName"]=="depZoomIn", "host card computed animation-name must be our keyframe (not none/host)"
    assert anim2["floatInnerName"]=="depRiseIn", "float card anim must land on inner .dep-fanim and be effective"
    assert anim2["floatInnerHasClass"] and not anim2["floatOuterHasClass"], "float anim class goes on inner, not scaled outer"

    # --- (2) card edge color (::before keyline) via --dep-edge ---
    edge = pg.evaluate(r"""() => {
      var stat=document.querySelector('.stat');
      var deco=document.getElementById('depDeco');
      stat.click();
      var sws=deco.querySelectorAll('.dep-row')[1].querySelectorAll('.dep-sw'); // edge row
      // sws: [key-grad, blue, cyan, purple, brightblue, reset]
      sws[1].click(); // solid blue
      var edgeVar=stat.style.getPropertyValue('--dep-edge').trim();
      var hasAttr=stat.getAttribute('data-dep-edge');
      var beforeBg=getComputedStyle(stat,'::before').backgroundImage+getComputedStyle(stat,'::before').backgroundColor;
      // switch to gradient template
      sws[0].click();
      var edgeVarGrad=stat.style.getPropertyValue('--dep-edge').trim();
      // reset
      sws[5].click();
      var afterReset=stat.getAttribute('data-dep-edge');
      return {edgeVar:edgeVar, hasAttr:hasAttr, edgeVarGrad:edgeVarGrad, afterReset:afterReset};
    }""")
    print("2 edge:", json.dumps(edge, ensure_ascii=False))
    assert edge["hasAttr"]=="1", "data-dep-edge set"
    assert "#2B6CF0" in edge["edgeVar"] or "43, 108, 240" in edge["edgeVar"] or "2b6cf0" in edge["edgeVar"].lower(), "solid edge color written"
    assert "gradient" in edge["edgeVarGrad"] or "fs-grad-keyline" in edge["edgeVarGrad"], "gradient edge written"
    assert edge["afterReset"] in (None,""), "reset clears data-dep-edge"

    # --- (3) in-paragraph specific text enlarge (range -> .dep-fs-run span) ---
    run = pg.evaluate(r"""() => {
      // find a paragraph-ish text element with enough text
      var el=null, cands=document.querySelectorAll('.ptitle, p, .stat .d, .lead p, li');
      for(var i=0;i<cands.length;i++){ if((cands[i].textContent||'').replace(/\s/g,'').length>=6){el=cands[i];break;} }
      if(!el) return {found:false};
      el.click(); // arm font bar with this as fontTarget
      // select first 3 chars inside
      var tn=null;
      (function walk(n){ if(tn)return; if(n.nodeType===3&&(n.textContent||'').trim().length>=3){tn=n;return;}
        for(var i=0;i<n.childNodes.length;i++)walk(n.childNodes[i]); })(el);
      if(!tn) return {found:false};
      var rng=document.createRange(); rng.setStart(tn,0); rng.setEnd(tn,3);
      var sel=window.getSelection(); sel.removeAllRanges(); sel.addRange(rng);
      var fb=document.getElementById('depFont');
      var btns=fb.querySelectorAll('button'); // [0]A- [1]A+ [2]reset ...
      var wholeBefore=getComputedStyle(el).fontSize;
      btns[1].click(); btns[1].click(); btns[1].click(); // enlarge selection
      var span=el.querySelector('.dep-fs-run');
      return {found:true, hasRun:!!span,
              runFs: span?getComputedStyle(span).fontSize:null,
              wholeBefore:wholeBefore, wholeAfter:getComputedStyle(el).fontSize,
              runText: span?span.textContent:null};
    }""")
    print("3 range enlarge:", json.dumps(run, ensure_ascii=False))
    assert run["found"], "should find a text element"
    assert run["hasRun"], "a .dep-fs-run span must wrap the selection"
    assert parse_px(run["runFs"]) > parse_px(run["wholeBefore"]), "selected run font must be bigger than base"

    # --- (4) text color: solid + gradient template + reset ---
    col = pg.evaluate(r"""() => {
      var el=document.querySelector('.ptitle') || document.querySelector('h2') || document.querySelector('p');
      el.click();
      var fb=document.getElementById('depFont');
      var grad=fb.querySelector('[data-depcol="__grad__"]');
      var blue=fb.querySelector('[data-depcol="#2B6CF0"]');
      var reset=fb.querySelector('[data-depcol="__reset__"]');
      window.getSelection().removeAllRanges();
      blue.click();
      var solidColor=el.style.color;
      var solidFill=getComputedStyle(el).webkitTextFillColor;
      window.getSelection().removeAllRanges();
      grad.click();
      var hasGrad=el.classList.contains('dep-grad-text');
      var clip=getComputedStyle(el).webkitBackgroundClip||getComputedStyle(el).backgroundClip;
      window.getSelection().removeAllRanges();
      reset.click();
      var afterReset=el.classList.contains('dep-grad-text');
      return {solidColor:solidColor, solidFill:solidFill, hasGrad:hasGrad, clip:clip, afterReset:afterReset,
              colorAfterReset:el.style.color};
    }""")
    print("4 text color:", json.dumps(col, ensure_ascii=False))
    assert col["solidColor"], "solid text color applied inline"
    # Bug #1: fill-color must be the real color (not transparent) so text is visible
    assert "43, 108, 240" in (col["solidFill"] or ""), "text-fill-color must follow solid color (else host gradient keeps text transparent)"
    assert col["hasGrad"], "gradient template class applied"
    assert "text" in (col["clip"] or ""), "background-clip:text active for gradient"
    assert col["afterReset"]==False and col["colorAfterReset"]=="", "reset clears color+gradient"

    # --- (4b) Bug #1 core: recolor an ENLARGED card text run, fill must be visible ---
    cardcol = pg.evaluate(r"""() => {
      // find a card number/title, enlarge whole element, then recolor -> must show color
      var el=document.querySelector('.stat .t, .num .v, .stat .d');
      if(!el) return {found:false};
      el.click();
      var fb=document.getElementById('depFont');
      var btns=fb.querySelectorAll('button'); // [0]A- [1]A+ [2]reset
      window.getSelection().removeAllRanges();
      btns[1].click(); btns[1].click(); // enlarge whole element
      var enlarged=getComputedStyle(el).fontSize;
      var blue=fb.querySelector('[data-depcol="#2B6CF0"]');
      window.getSelection().removeAllRanges();
      blue.click();
      return {found:true, fontSize:enlarged,
              fill:getComputedStyle(el).webkitTextFillColor,
              color:getComputedStyle(el).color};
    }""")
    print("4b card text recolor:", json.dumps(cardcol, ensure_ascii=False))
    assert cardcol["found"], "should find a card text element"
    assert "43, 108, 240" in (cardcol["fill"] or ""), "enlarged card text must actually change color (fill not transparent)"

    # --- (5) export固化: classes/vars/spans survive documentElement clone ---
    exp = pg.evaluate(r"""() => {
      var stat=document.querySelector('.stat');
      stat.click();
      var deco=document.getElementById('depDeco');
      deco.querySelectorAll('.dep-anb')[0].click(); // rise
      deco.querySelectorAll('.dep-row')[1].querySelectorAll('.dep-sw')[0].click(); // grad edge
      var clone=document.documentElement.cloneNode(true);
      return {animInClone: clone.querySelectorAll('.dep-anim-rise').length,
              edgeInClone: clone.querySelectorAll('[data-dep-edge]').length,
              runInClone: clone.querySelectorAll('.dep-fs-run').length,
              gradTextInClone: clone.querySelectorAll('.dep-grad-text').length};
    }""")
    print("5 export clone:", json.dumps(exp, ensure_ascii=False))
    assert exp["animInClone"]>=1, "anim class固化 in clone"
    assert exp["edgeInClone"]>=1, "edge attr固化 in clone"
    assert exp["runInClone"]>=1, "fs-run固化 in clone"

    print("BATCH D ASSERTIONS PASSED")
    b.close()
