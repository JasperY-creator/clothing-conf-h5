from playwright.sync_api import sync_playwright
import pathlib, json, sys
# 回归:①新增页后双屏(投影+演讲者)仍同步  ②编辑态导出 == 退出编辑后导出
_target = sys.argv[1] if len(sys.argv) > 1 else "/tmp/e2r/deck.edit.html"
url = "file://" + str(pathlib.Path(_target).resolve())
with sync_playwright() as p:
    b = p.chromium.launch(headless=True)
    pg = b.new_page(viewport={"width": 1280, "height": 720})
    pg.goto(url); pg.wait_for_timeout(1300)

    # enter edit mode
    pg.evaluate("()=>{var e=document.getElementById('deckEdit');if(e)e.click();}")
    pg.wait_for_timeout(300)

    # add a page via dup so frames increase
    before = pg.evaluate("()=>window.__deck.total")
    pg.evaluate("()=>{var b=document.getElementById('depBar');b.querySelectorAll('button')[0].click();}") # +复制本页
    pg.wait_for_timeout(300)
    after = pg.evaluate("()=>window.__deck.total")
    print("frames before/after add:", before, after)
    assert after == before + 1, "page added"

    # ---- BUG#1: our window.open patch turns a present=speaker request into a blob of live DOM ----
    b1 = pg.evaluate(r"""() => {
      var madeBlob=null, blobHtml=null;
      var origCreate=URL.createObjectURL;
      URL.createObjectURL=function(blob){ madeBlob=blob; var u=origCreate.call(URL,blob); return u; };
      // Spy the native forward: our patch calls the captured native open. Stub Window native temporarily
      // is impossible (closure), so we detect the patch fired by (a) createObjectURL was called and
      // (b) window.open returns null in headless. We still assert the blob is produced.
      var ret=window.open(location.href.split('#')[0]+'?present=speaker','deckSpeaker','width=1');
      URL.createObjectURL=origCreate;
      return {patched:!!window.__depOpenPatched, blobMade:!!madeBlob};
    }""")
    print("bug1 open-patch:", json.dumps(b1, ensure_ascii=False))
    assert b1["patched"], "window.open patched flag set"
    assert b1["blobMade"], "present=speaker open built a Blob from live DOM (not on-disk file)"

    # verify the blob doc carries the added page (frame count == main window's live count)
    blob_total = pg.evaluate(r"""async () => {
      var burl=null;
      var origCreate=URL.createObjectURL;
      URL.createObjectURL=function(blob){ burl=origCreate.call(URL,blob); return burl; };
      window.open(location.href.split('#')[0]+'?present=speaker','deckSpeaker','width=1');
      URL.createObjectURL=origCreate;
      var r=await fetch(burl); var txt=await r.text();
      var doc=new DOMParser().parseFromString(txt,'text/html');
      var trk=doc.getElementById('deckTrack');
      var hasRole=/present=speaker/.test(txt) || true; // role is passed via URL hash, not baked
      return trk?trk.children.length:-1;
    }""")
    print("bug1 blob frame count:", blob_total)
    assert blob_total == after, "speaker blob doc has same (added) frame count as main window"


    # ---- BUG#2: edit-mode export == non-edit export (no .dep-* / data-depce in clone) ----
    b2 = pg.evaluate(r"""() => {
      if(!document.body.classList.contains('deck-editing')){document.getElementById('deckEdit').click();}
      var exp=document.getElementById('deckExport');
      // Capture the ACTUAL clone the host makes: stub cloneNode on documentElement for one call.
      var snap=null;
      var origClone=document.documentElement.cloneNode;
      document.documentElement.cloneNode=function(deep){
        var c=origClone.call(this,deep);
        if(snap===null){
          snap={
            editingAtClone: document.body.classList.contains('deck-editing'),
            depBarHidden: c.querySelector('#depBar').classList.contains('dep-hidden'),
            depRailHidden: c.querySelector('#depRail').classList.contains('dep-hidden'),
            imgtoolCount: c.querySelectorAll('.dep-imgtool').length,
            depceCount: c.querySelectorAll('[data-depce][contenteditable]').length
          };
        }
        return c;
      };
      // Neutralize the actual file download.
      var origA=HTMLAnchorElement.prototype.click;
      HTMLAnchorElement.prototype.click=function(){};
      exp.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));
      HTMLAnchorElement.prototype.click=origA;
      document.documentElement.cloneNode=origClone;
      return snap;
    }""")
    print("bug2 export-clone state:", json.dumps(b2, ensure_ascii=False))
    assert b2 is not None, "host export handler cloned documentElement"
    assert b2["depBarHidden"] and b2["depRailHidden"], "enhancement bars hidden at export clone"
    assert b2["imgtoolCount"] == 0, "no live img tools baked into export clone"
    assert b2["depceCount"] == 0, "no data-depce contenteditable baked into export clone"

    print("BUG1+BUG2 PROBE PASSED")
    b.close()
